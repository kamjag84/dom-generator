// ==================================================================
// File: src/domViewProvider.ts
// ==================================================================
import * as vscode from 'vscode';
import * as path from 'path';
import { DOMCaptureManager, DOMCapture } from './domCaptureManager';

export class DOMViewProvider implements vscode.TreeDataProvider<DOMCaptureItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<DOMCaptureItem | undefined | null | void> = new vscode.EventEmitter<DOMCaptureItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<DOMCaptureItem | undefined | null | void> = this._onDidChangeTreeData.event;

    private domCaptureManager: DOMCaptureManager;

    constructor(private context: vscode.ExtensionContext) {
        this.domCaptureManager = new DOMCaptureManager(context);
    }

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: DOMCaptureItem): vscode.TreeItem {
        return element;
    }

    getChildren(element?: DOMCaptureItem): Thenable<DOMCaptureItem[]> {
        if (!element) {
            // Root level - show date folders
            return this.getDateFolders();
        } else if (element.contextValue === 'dateFolder') {
            // Show time folders for a date
            return this.getTimeFolders(element.label as string);
        } else if (element.contextValue === 'timeFolder') {
            // Show captures for a time folder
            return this.getCaptures(element.dateFolder!, element.label as string);
        }
        return Promise.resolve([]);
    }

    private async getDateFolders(): Promise<DOMCaptureItem[]> {
        const structure = await this.domCaptureManager.getCaptureFolderStructure();
        const items: DOMCaptureItem[] = [];

        for (const dateFolder of Object.keys(structure).sort().reverse()) {
            const captureCount = this.countCaptures(structure[dateFolder]);
            const item = new DOMCaptureItem(
                dateFolder,
                vscode.TreeItemCollapsibleState.Collapsed,
                'dateFolder'
            );
            item.description = `${captureCount} capture${captureCount !== 1 ? 's' : ''}`;
            item.iconPath = new vscode.ThemeIcon('calendar');
            items.push(item);
        }

        return items;
    }

    private async getTimeFolders(dateFolder: string): Promise<DOMCaptureItem[]> {
        const structure = await this.domCaptureManager.getCaptureFolderStructure();
        const items: DOMCaptureItem[] = [];

        if (structure[dateFolder]) {
            for (const timeFolder of Object.keys(structure[dateFolder]).sort().reverse()) {
                const captures = structure[dateFolder][timeFolder];
                const item = new DOMCaptureItem(
                    timeFolder,
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'timeFolder'
                );
                item.dateFolder = dateFolder;
                item.description = `${captures.length} test${captures.length !== 1 ? 's' : ''}`;
                item.iconPath = new vscode.ThemeIcon('clock');
                items.push(item);
            }
        }

        return items;
    }

    private async getCaptures(dateFolder: string, timeFolder: string): Promise<DOMCaptureItem[]> {
        const structure = await this.domCaptureManager.getCaptureFolderStructure();
        const items: DOMCaptureItem[] = [];

        if (structure[dateFolder] && structure[dateFolder][timeFolder]) {
            const captures: DOMCapture[] = structure[dateFolder][timeFolder];
            
            for (const capture of captures) {
                const item = new DOMCaptureItem(
                    capture.testName,
                    vscode.TreeItemCollapsibleState.None,
                    'capture'
                );
                item.capture = capture;
                item.tooltip = `Click to open ${capture.testName}`;
                item.iconPath = new vscode.ThemeIcon('file-code');
                item.command = {
                    command: 'domGenerator.openCapture',
                    title: 'Open Capture',
                    arguments: [capture]
                };
                items.push(item);
            }
        }

        return items;
    }

    private countCaptures(timeFolders: any): number {
        let count = 0;
        for (const timeFolder of Object.values(timeFolders)) {
            count += (timeFolder as any[]).length;
        }
        return count;
    }
}

class DOMCaptureItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly contextValue: string
    ) {
        super(label, collapsibleState);
    }

    dateFolder?: string;
    capture?: DOMCapture;
}

// ==================================================================
// File: src/copilotIntegration.ts
// ==================================================================
import * as vscode from 'vscode';
import { DOMCaptureManager } from './domCaptureManager';

export class CopilotIntegration {
    constructor(
        private context: vscode.ExtensionContext,
        private domCaptureManager: DOMCaptureManager
    ) {}

    async handleChatRequest(
        request: vscode.ChatRequest,
        context: vscode.ChatContext,
        response: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ): Promise<void> {
        try {
            response.progress('Fetching latest DOM capture...');
            
            const latestCapture = await this.domCaptureManager.getLatestCapture();
            
            if (!latestCapture) {
                response.markdown('No DOM captures found. Please run a test that fails to generate captures.');
                return;
            }

            // Display the capture
            await this.domCaptureManager.displayCapture(latestCapture);

            // Provide information in chat
            response.markdown(`## Latest DOM Capture\n\n`);
            response.markdown(`**Test:** ${latestCapture.testName}\n`);
            response.markdown(`**Timestamp:** ${latestCapture.timestamp.toLocaleString()}\n\n`);
            
            response.markdown(`### Files opened:\n`);
            response.markdown(`- **DOM HTML:** ${latestCapture.domPath}\n`);
            response.markdown(`- **Screenshot:** ${latestCapture.screenshotPath}\n`);
            response.markdown(`- **Report:** ${latestCapture.reportPath}\n\n`);
            
            response.markdown(`The DOM capture has been opened in the editor. You can now:\n`);
            response.markdown(`- Review the complete DOM structure\n`);
            response.markdown(`- Examine the screenshot in the preview panel\n`);
            response.markdown(`- Check the detailed failure report\n`);
            
            // Add buttons for common actions
            response.button({
                command: 'domGenerator.showLatestCapture',
                title: 'Show Latest Capture',
                arguments: []
            });
            
            response.button({
                command: 'domGenerator.openCaptureFolder',
                title: 'Open Capture Folder',
                arguments: []
            });

        } catch (error: any) {
            response.markdown(`Error: ${error.message}`);
        }
    }
}

// ==================================================================
// File: src/utils/fileUtils.ts
// ==================================================================
import * as fs from 'fs';
import * as path from 'path';

export class FileUtils {
    static async exists(filePath: string): Promise<boolean> {
        try {
            await fs.promises.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    static async ensureDir(dirPath: string): Promise<void> {
        try {
            await fs.promises.mkdir(dirPath, { recursive: true });
        } catch (error) {
            console.error(`Error creating directory ${dirPath}:`, error);
        }
    }

    static async readFile(filePath: string): Promise<string> {
        return fs.promises.readFile(filePath, 'utf-8');
    }

    static async writeFile(filePath: string, content: string): Promise<void> {
        await fs.promises.writeFile(filePath, content, 'utf-8');
    }

    static async copyFile(source: string, destination: string): Promise<void> {
        await fs.promises.copyFile(source, destination);
    }

    static async listFiles(dirPath: string, pattern?: RegExp): Promise<string[]> {
        const files = await fs.promises.readdir(dirPath);
        if (pattern) {
            return files.filter(file => pattern.test(file));
        }
        return files;
    }

    static getRelativePath(from: string, to: string): string {
        return path.relative(from, to);
    }

    static joinPath(...paths: string[]): string {
        return path.join(...paths);
    }
}

// ==================================================================
// File: src/utils/constants.ts
// ==================================================================
export const EXTENSION_NAME = 'DOM Generator';
export const EXTENSION_ID = 'dom-generator';
export const CAPTURE_BASE_PATH = 'test-results/dom-captures';

export const DATE_FORMAT = 'dd-MM-yyyy';
export const TIME_FORMAT = 'HH-mm-a';
export const FILE_TIMESTAMP_FORMAT = 'yyyyMMdd_HHmmss';

export const DEFAULT_JAVA_PACKAGE = 'com.wellsfargo.automation.appid';

export const LISTENER_CLASS_NAMES = {
    DOM_CAPTURE: 'DOMCaptureListener',
    TESTNG_DOM_CAPTURE: 'TestNGDOMCaptureListener',
    DOM_CAPTURE_UTIL: 'DOMCaptureUtil'
};

export const FILE_PATTERNS = {
    DOM_HTML: /_DOM\.html$/,
    SCREENSHOT: /_screenshot\.png$/,
    REPORT: /_Report\.html$/,
    METADATA: /_metadata\.json$/,
    SUMMARY: /_summary\.txt$/
};

export const DRIVER_STRATEGIES = [
    'REFLECTION_FIELD',
    'TEST_CONTEXT',
    'THREAD_LOCAL',
    'GETTER_METHOD',
    'SUITE_ATTRIBUTE',
    'CUSTOM_PROVIDER'
];

// ==================================================================
// File: tsconfig.json
// ==================================================================
{
  "compilerOptions": {
    "module": "commonjs",
    "target": "ES2020",
    "outDir": "out",
    "lib": ["ES2020"],
    "sourceMap": true,
    "rootDir": "src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "exclude": ["node_modules", ".vscode-test"]
}

// ==================================================================
// File: .vscodeignore
// ==================================================================
.vscode/**
.vscode-test/**
src/**
.gitignore
.yarnrc
vsc-extension-quickstart.md
**/tsconfig.json
**/.eslintrc.json
**/*.map
**/*.ts
node_modules/**
*.vsix

// ==================================================================
// File: .gitignore
// ==================================================================
out
dist
node_modules
.vscode-test/
*.vsix
.DS_Store
*.log
coverage/
.nyc_output/