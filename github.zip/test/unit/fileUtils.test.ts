import * as assert from 'assert';
import * as path from 'path';
import * as fs from 'fs';
import { FileUtils } from '../../src/utils/fileUtils';

suite('FileUtils Test Suite', () => {
    const testDir = path.join(__dirname, 'test-files');
    const testFile = path.join(testDir, 'test.txt');

    setup(async () => {
        // Create test directory
        await fs.promises.mkdir(testDir, { recursive: true });
    });

    teardown(async () => {
        // Clean up test files
        try {
            await fs.promises.rm(testDir, { recursive: true, force: true });
        } catch {}
    });

    test('exists should return true for existing file', async () => {
        await fs.promises.writeFile(testFile, 'test content');
        const exists = await FileUtils.exists(testFile);
        assert.strictEqual(exists, true);
    });

    test('exists should return false for non-existing file', async () => {
        const exists = await FileUtils.exists(path.join(testDir, 'nonexistent.txt'));
        assert.strictEqual(exists, false);
    });

    test('writeFile should create file with content', async () => {
        const content = 'Hello, World!';
        await FileUtils.writeFile(testFile, content);
        const readContent = await fs.promises.readFile(testFile, 'utf-8');
        assert.strictEqual(readContent, content);
    });

    test('readFile should read file content', async () => {
        const content = 'Test content';
        await fs.promises.writeFile(testFile, content);
        const readContent = await FileUtils.readFile(testFile);
        assert.strictEqual(readContent, content);
    });

    test('ensureDir should create directory', async () => {
        const newDir = path.join(testDir, 'subdir');
        await FileUtils.ensureDir(newDir);
        const exists = await FileUtils.exists(newDir);
        assert.strictEqual(exists, true);
    });

    test('deleteFile should remove file', async () => {
        await fs.promises.writeFile(testFile, 'test');
        await FileUtils.deleteFile(testFile);
        const exists = await FileUtils.exists(testFile);
        assert.strictEqual(exists, false);
    });

    test('sanitizeFileName should remove invalid characters', () => {
        const unsafe = 'test<>:|?*.txt';
        const safe = FileUtils.sanitizeFileName(unsafe);
        assert.strictEqual(safe, 'test_____.txt');
    });

    test('isValidPath should reject path traversal', () => {
        const valid = FileUtils.isValidPath('/valid/path');
        const invalid = FileUtils.isValidPath('../../../etc/passwd');
        assert.strictEqual(valid, true);
        assert.strictEqual(invalid, false);
    });

    test('getStats should return file stats', async () => {
        await fs.promises.writeFile(testFile, 'test');
        const stats = await FileUtils.getStats(testFile);
        assert.ok(stats);
        assert.ok(stats!.isFile());
    });

    test('listDirectory should return directory contents', async () => {
        await fs.promises.writeFile(path.join(testDir, 'file1.txt'), 'test');
        await fs.promises.writeFile(path.join(testDir, 'file2.txt'), 'test');
        const files = await FileUtils.listDirectory(testDir);
        assert.strictEqual(files.length, 2);
        assert.ok(files.includes('file1.txt'));
        assert.ok(files.includes('file2.txt'));
    });
});