import * as assert from 'assert';
import { ValidationUtils } from '../../src/utils/validationUtils';

suite('ValidationUtils Test Suite', () => {
    
    suite('Java Package Validation', () => {
        test('should validate correct Java package names', () => {
            assert.strictEqual(ValidationUtils.isValidJavaPackage('com.example.test'), true);
            assert.strictEqual(ValidationUtils.isValidJavaPackage('org.selenium.webdriver'), true);
            assert.strictEqual(ValidationUtils.isValidJavaPackage('mypackage'), true);
        });

        test('should reject invalid Java package names', () => {
            assert.strictEqual(ValidationUtils.isValidJavaPackage('Com.Example'), false);
            assert.strictEqual(ValidationUtils.isValidJavaPackage('123package'), false);
            assert.strictEqual(ValidationUtils.isValidJavaPackage('my-package'), false);
            assert.strictEqual(ValidationUtils.isValidJavaPackage(''), false);
        });

        test('should sanitize Java package names', () => {
            assert.strictEqual(
                ValidationUtils.sanitizeJavaPackage('Com.Example.Test'),
                'com.example.test'
            );
            assert.strictEqual(
                ValidationUtils.sanitizeJavaPackage('my-package'),
                'my_package'
            );
            assert.strictEqual(
                ValidationUtils.sanitizeJavaPackage('123package'),
                '_23package'
            );
        });
    });

    suite('WebDriver Strategy Validation', () => {
        test('should validate correct driver strategies', () => {
            assert.strictEqual(ValidationUtils.isValidDriverStrategy('REFLECTION_FIELD'), true);
            assert.strictEqual(ValidationUtils.isValidDriverStrategy('TEST_CONTEXT'), true);
            assert.strictEqual(ValidationUtils.isValidDriverStrategy('THREAD_LOCAL'), true);
        });

        test('should reject invalid driver strategies', () => {
            assert.strictEqual(ValidationUtils.isValidDriverStrategy('INVALID_STRATEGY'), false);
            assert.strictEqual(ValidationUtils.isValidDriverStrategy(''), false);
            assert.strictEqual(ValidationUtils.isValidDriverStrategy('reflection_field'), false);
        });
    });

    suite('Test Class/Method Validation', () => {
        test('should validate correct test class names', () => {
            assert.strictEqual(ValidationUtils.isValidTestClassName('LoginTest'), true);
            assert.strictEqual(ValidationUtils.isValidTestClassName('UserRegistrationTest'), true);
            assert.strictEqual(ValidationUtils.isValidTestClassName('Test123'), true);
        });

        test('should reject invalid test class names', () => {
            assert.strictEqual(ValidationUtils.isValidTestClassName('loginTest'), false);
            assert.strictEqual(ValidationUtils.isValidTestClassName('123Test'), false);
            assert.strictEqual(ValidationUtils.isValidTestClassName('test-class'), false);
        });

        test('should validate correct test method names', () => {
            assert.strictEqual(ValidationUtils.isValidTestMethodName('testLogin'), true);
            assert.strictEqual(ValidationUtils.isValidTestMethodName('shouldReturnTrue'), true);
            assert.strictEqual(ValidationUtils.isValidTestMethodName('test123'), true);
        });

        test('should reject invalid test method names', () => {
            assert.strictEqual(ValidationUtils.isValidTestMethodName('TestLogin'), false);
            assert.strictEqual(ValidationUtils.isValidTestMethodName('123test'), false);
            assert.strictEqual(ValidationUtils.isValidTestMethodName('test-method'), false);
        });
    });

    suite('Maven Coordinate Validation', () => {
        test('should validate correct Maven coordinates', () => {
            assert.strictEqual(
                ValidationUtils.isValidMavenCoordinate('org.testng:testng:7.8.0'),
                true
            );
            assert.strictEqual(
                ValidationUtils.isValidMavenCoordinate('com.example:my-artifact:1.0.0-SNAPSHOT'),
                true
            );
        });

        test('should reject invalid Maven coordinates', () => {
            assert.strictEqual(
                ValidationUtils.isValidMavenCoordinate('invalid'),
                false
            );
            assert.strictEqual(
                ValidationUtils.isValidMavenCoordinate('org.testng:testng'),
                false
            );
            assert.strictEqual(
                ValidationUtils.isValidMavenCoordinate(''),
                false
            );
        });
    });

    suite('Configuration Validation', () => {
        test('should validate correct configuration', () => {
            const config = {
                capturePath: 'test-results',
                javaPackage: 'com.example.test',
                defaultDriverStrategy: 'REFLECTION_FIELD',
                autoSetup: true,
                showNotifications: false
            };
            const result = ValidationUtils.validateConfiguration(config);
            assert.strictEqual(result.valid, true);
            assert.strictEqual(result.errors.length, 0);
        });

        test('should detect invalid configuration', () => {
            const config = {
                javaPackage: 'Invalid-Package',
                defaultDriverStrategy: 'INVALID',
                autoSetup: 'yes' // Should be boolean
            };
            const result = ValidationUtils.validateConfiguration(config);
            assert.strictEqual(result.valid, false);
            assert.ok(result.errors.length > 0);
        });
    });

    suite('Input Sanitization', () => {
        test('should sanitize user input', () => {
            const input = 'Hello\x00World\x1f';
            const sanitized = ValidationUtils.sanitizeInput(input);
            assert.strictEqual(sanitized, 'HelloWorld');
        });

        test('should limit input length', () => {
            const longInput = 'a'.repeat(300);
            const sanitized = ValidationUtils.sanitizeInput(longInput, 100);
            assert.strictEqual(sanitized.length, 100);
        });
    });

    suite('Version Validation', () => {
        test('should validate semantic versions', () => {
            assert.strictEqual(ValidationUtils.isValidVersion('1.0.0'), true);
            assert.strictEqual(ValidationUtils.isValidVersion('2.1.3-alpha'), true);
            assert.strictEqual(ValidationUtils.isValidVersion('0.0.1-SNAPSHOT'), true);
        });

        test('should reject invalid versions', () => {
            assert.strictEqual(ValidationUtils.isValidVersion('v1.0.0'), false);
            assert.strictEqual(ValidationUtils.isValidVersion('1.0'), false);
            assert.strictEqual(ValidationUtils.isValidVersion(''), false);
        });
    });
});