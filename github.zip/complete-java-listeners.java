// ==================================================================
// File 1: /src/test/java/com/wellsfargo/automation/appid/listeners/DOMCaptureListener.java
// ==================================================================
package com.wellsfargo.automation.appid.listeners;

import org.testng.*;
import org.openqa.selenium.*;
import org.apache.commons.io.FileUtils;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.google.gson.GsonBuilder;
import javax.inject.Inject;

/**
 * Enhanced DOM Generator Listener with multiple WebDriver access strategies
 * Captures DOM, screenshots, and reports on test failures
 */
public class DOMCaptureListener implements ITestListener, ISuiteListener {
    
    private static final String DUMP_BASE_PATH = "test-results/dom-captures";
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH-mm-a");
    private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    
    // Thread-safe storage for WebDriver instances
    private static final Map<Long, WebDriver> threadDriverMap = new ConcurrentHashMap<>();
    
    private enum DriverAccessStrategy {
        REFLECTION_FIELD,
        TEST_CONTEXT,
        THREAD_LOCAL,
        GETTER_METHOD,
        SUITE_ATTRIBUTE,
        CUSTOM_PROVIDER
    }
    
    private DriverAccessStrategy strategy = DriverAccessStrategy.REFLECTION_FIELD;
    
    @Override
    public void onStart(ISuite suite) {
        String strategyParam = suite.getParameter("dom.generator.driver.strategy");
        if (strategyParam != null) {
            try {
                strategy = DriverAccessStrategy.valueOf(strategyParam.toUpperCase());
                System.out.println("[DOM Generator] Using driver access strategy: " + strategy);
            } catch (IllegalArgumentException e) {
                System.err.println("[DOM Generator] Invalid strategy: " + strategyParam);
            }
        }
    }
    
    @Override
    public void onTestFailure(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String className = result.getTestClass().getName();
        LocalDateTime now = LocalDateTime.now();
        
        // Create directory structure: /dd-MM-yyyy/HH-mm-a/
        String dateFolder = now.format(DATE_FORMAT);
        String timeFolder = now.format(TIME_FORMAT);
        Path failureDir = Paths.get(DUMP_BASE_PATH, dateFolder, timeFolder);
        
        try {
            Files.createDirectories(failureDir);
            
            WebDriver driver = getDriverFromTest(result);
            
            if (driver != null) {
                String timestamp = now.format(FILE_TIMESTAMP);
                
                // Capture DOM
                captureDom(driver, failureDir, testName, timestamp);
                
                // Capture Screenshot
                captureScreenshot(driver, failureDir, testName, timestamp);
                
                // Generate Report
                generateReport(driver, failureDir, testName, timestamp, result);
                
                // Capture additional metadata
                capturePageMetadata(driver, failureDir, testName, timestamp);
                
                System.out.println("[DOM Generator] Test failure captured: " + failureDir);
                
                // Create summary
                createSummaryFile(result, failureDir, testName, timestamp);
            } else {
                System.err.println("[DOM Generator] Could not obtain WebDriver instance");
                captureTestFailureInfo(result, failureDir, testName);
            }
        } catch (Exception e) {
            System.err.println("[DOM Generator] Failed to capture test failure: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void captureDom(WebDriver driver, Path outputDir, String testName, String timestamp) throws IOException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        // Get complete DOM including DOCTYPE
        String dom = (String) js.executeScript(
            "var serializer = new XMLSerializer();" +
            "var dom = serializer.serializeToString(document);" +
            "if (!dom.startsWith('<!DOCTYPE')) {" +
            "  dom = '<!DOCTYPE html>' + dom;" +
            "}" +
            "return dom;"
        );
        
        // Enhance DOM with metadata
        String enhancedDom = enhanceDomWithMetadata(dom, driver.getCurrentUrl(), testName);
        
        String filename = String.format("%s_%s_DOM.html", testName, timestamp);
        Path domFile = outputDir.resolve(filename);
        Files.write(domFile, enhancedDom.getBytes("UTF-8"));
    }
    
    private String enhanceDomWithMetadata(String dom, String url, String testName) {
        // Add metadata comments to the DOM
        StringBuilder enhanced = new StringBuilder();
        enhanced.append("<!-- DOM Capture Generated by DOM Generator Extension -->\n");
        enhanced.append("<!-- Test: ").append(testName).append(" -->\n");
        enhanced.append("<!-- URL: ").append(url).append(" -->\n");
        enhanced.append("<!-- Timestamp: ").append(LocalDateTime.now()).append(" -->\n");
        enhanced.append(dom);
        return enhanced.toString();
    }
    
    private void captureScreenshot(WebDriver driver, Path outputDir, String testName, String timestamp) throws IOException {
        if (driver instanceof TakesScreenshot) {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String filename = String.format("%s_%s_screenshot.png", testName, timestamp);
            Path screenshotFile = outputDir.resolve(filename);
            FileUtils.copyFile(screenshot, screenshotFile.toFile());
        }
    }
    
    private void generateReport(WebDriver driver, Path outputDir, String testName, 
                               String timestamp, ITestResult result) throws IOException {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n<html>\n<head>\n");
        html.append("<title>Test Failure Report - ").append(testName).append("</title>\n");
        html.append("<style>\n");
        html.append("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }\n");
        html.append(".container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }\n");
        html.append("h1 { color: #d9534f; border-bottom: 3px solid #d9534f; padding-bottom: 10px; }\n");
        html.append("h2 { color: #333; margin-top: 30px; border-bottom: 1px solid #e0e0e0; padding-bottom: 8px; }\n");
        html.append(".info-box { background: #f8f9fa; padding: 15px; border-left: 4px solid #5bc0de; margin: 15px 0; border-radius: 4px; }\n");
        html.append(".error-box { background: #f2dede; color: #a94442; padding: 15px; border-left: 4px solid #d9534f; margin: 15px 0; border-radius: 4px; }\n");
        html.append(".success-box { background: #dff0d8; color: #3c763d; padding: 15px; border-left: 4px solid #5cb85c; margin: 15px 0; border-radius: 4px; }\n");
        html.append("pre { background: #2d2d2d; color: #f8f8f2; padding: 15px; overflow-x: auto; border-radius: 4px; font-size: 13px; line-height: 1.5; }\n");
        html.append("table { width: 100%; border-collapse: collapse; margin: 15px 0; }\n");
        html.append("th { background: #f0f0f0; padding: 10px; text-align: left; border-bottom: 2px solid #ddd; }\n");
        html.append("td { padding: 10px; border-bottom: 1px solid #ddd; }\n");
        html.append(".timestamp { color: #666; font-size: 14px; }\n");
        html.append(".badge { display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }\n");
        html.append(".badge-danger { background: #d9534f; color: white; }\n");
        html.append(".badge-info { background: #5bc0de; color: white; }\n");
        html.append("</style>\n</head>\n<body>\n");
        html.append("<div class='container'>\n");
        
        // Header
        html.append("<h1>Test Failure Report <span class='badge badge-danger'>FAILED</span></h1>\n");
        html.append("<p class='timestamp'>Generated: ").append(LocalDateTime.now()).append("</p>\n");
        
        // Test Information
        html.append("<div class='info-box'>\n");
        html.append("<h2>Test Information</h2>\n");
        html.append("<table>\n");
        html.append("<tr><th>Test Name</th><td>").append(testName).append("</td></tr>\n");
        html.append("<tr><th>Class</th><td>").append(result.getTestClass().getName()).append("</td></tr>\n");
        html.append("<tr><th>Method</th><td>").append(result.getMethod().getMethodName()).append("</td></tr>\n");
        html.append("<tr><th>Duration</th><td>").append(result.getEndMillis() - result.getStartMillis()).append(" ms</td></tr>\n");
        html.append("<tr><th>Start Time</th><td>").append(new Date(result.getStartMillis())).append("</td></tr>\n");
        html.append("<tr><th>End Time</th><td>").append(new Date(result.getEndMillis())).append("</td></tr>\n");
        html.append("</table>\n");
        html.append("</div>\n");
        
        // Page Information
        html.append("<div class='info-box'>\n");
        html.append("<h2>Page Information</h2>\n");
        html.append("<table>\n");
        html.append("<tr><th>URL</th><td>").append(driver.getCurrentUrl()).append("</td></tr>\n");
        html.append("<tr><th>Title</th><td>").append(driver.getTitle()).append("</td></tr>\n");
        
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String userAgent = (String) js.executeScript("return navigator.userAgent;");
        html.append("<tr><th>Browser</th><td>").append(userAgent).append("</td></tr>\n");
        
        Dimension windowSize = driver.manage().window().getSize();
        html.append("<tr><th>Window Size</th><td>").append(windowSize.getWidth()).append(" x ").append(windowSize.getHeight()).append("</td></tr>\n");
        html.append("</table>\n");
        html.append("</div>\n");
        
        // Failure Details
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            html.append("<div class='error-box'>\n");
            html.append("<h2>Failure Details</h2>\n");
            html.append("<p><strong>Error Message:</strong> ").append(escapeHtml(throwable.getMessage())).append("</p>\n");
            html.append("<p><strong>Error Type:</strong> ").append(throwable.getClass().getName()).append("</p>\n");
            
            // Stack trace
            html.append("<h3>Stack Trace:</h3>\n");
            html.append("<pre>");
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            throwable.printStackTrace(pw);
            html.append(escapeHtml(sw.toString()));
            html.append("</pre>\n");
            html.append("</div>\n");
        }
        
        // Test Parameters
        Object[] params = result.getParameters();
        if (params != null && params.length > 0) {
            html.append("<div class='info-box'>\n");
            html.append("<h2>Test Parameters</h2>\n");
            html.append("<table>\n");
            for (int i = 0; i < params.length; i++) {
                html.append("<tr><th>Parameter ").append(i + 1).append("</th><td>").append(params[i]).append("</td></tr>\n");
            }
            html.append("</table>\n");
            html.append("</div>\n");
        }
        
        // Related Files
        html.append("<div class='info-box'>\n");
        html.append("<h2>Related Captures</h2>\n");
        html.append("<ul>\n");
        html.append("<li>DOM Capture: <a href='").append(testName).append("_").append(timestamp).append("_DOM.html'>View DOM</a></li>\n");
        html.append("<li>Screenshot: <a href='").append(testName).append("_").append(timestamp).append("_screenshot.png'>View Screenshot</a></li>\n");
        html.append("</ul>\n");
        html.append("</div>\n");
        
        html.append("</div>\n</body>\n</html>");
        
        String filename = String.format("%s_%s_Report.html", testName, timestamp);
        Path reportFile = outputDir.resolve(filename);
        Files.write(reportFile, html.toString().getBytes("UTF-8"));
    }
    
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                  .replace("<", "&lt;")
                  .replace(">", "&gt;")
                  .replace("\"", "&quot;")
                  .replace("'", "&#39;");
    }
    
    // All the driver retrieval methods from the attached file
    private WebDriver getDriverFromTest(ITestResult result) {
        WebDriver driver = null;
        
        driver = getDriverFromTestContext(result);
        if (driver != null) return driver;
        
        driver = getDriverFromReflection(result);
        if (driver != null) return driver;
        
        driver = getDriverFromThreadLocal();
        if (driver != null) return driver;
        
        driver = getDriverFromGetterMethod(result);
        if (driver != null) return driver;
        
        driver = getDriverFromSuiteAttribute(result);
        if (driver != null) return driver;
        
        driver = getDriverFromCustomProvider(result);
        if (driver != null) return driver;
        
        return null;
    }
    
    private WebDriver getDriverFromTestContext(ITestResult result) {
        try {
            ITestContext context = result.getTestContext();
            String[] commonNames = {"driver", "webDriver", "webdriver", "selenium.driver"};
            
            for (String name : commonNames) {
                Object attribute = context.getAttribute(name);
                if (attribute instanceof WebDriver) {
                    return (WebDriver) attribute;
                }
            }
            
            ISuite suite = context.getSuite();
            for (String name : commonNames) {
                Object attribute = suite.getAttribute(name);
                if (attribute instanceof WebDriver) {
                    return (WebDriver) attribute;
                }
            }
        } catch (Exception e) {
            // Continue to next strategy
        }
        return null;
    }
    
    private WebDriver getDriverFromReflection(ITestResult result) {
        Object testInstance = result.getInstance();
        if (testInstance == null) return null;
        
        try {
            Class<?> clazz = testInstance.getClass();
            while (clazz != null && clazz != Object.class) {
                Field[] fields = clazz.getDeclaredFields();
                
                for (Field field : fields) {
                    if (WebDriver.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        Object value = field.get(testInstance);
                        if (value != null) {
                            return (WebDriver) value;
                        }
                    }
                    
                    if (field.getName().toLowerCase().contains("driver")) {
                        field.setAccessible(true);
                        Object value = field.get(testInstance);
                        if (value instanceof WebDriver) {
                            return (WebDriver) value;
                        }
                    }
                }
                
                clazz = clazz.getSuperclass();
            }
        } catch (Exception e) {
            // Continue to next strategy
        }
        return null;
    }
    
    private WebDriver getDriverFromThreadLocal() {
        try {
            WebDriver driver = threadDriverMap.get(Thread.currentThread().getId());
            if (driver != null) {
                return driver;
            }
        } catch (Exception e) {
            // Continue to next strategy
        }
        return null;
    }
    
    private WebDriver getDriverFromGetterMethod(ITestResult result) {
        Object testInstance = result.getInstance();
        if (testInstance == null) return null;
        
        try {
            Class<?> clazz = testInstance.getClass();
            String[] methodNames = {
                "getDriver", "getWebDriver", "driver", "webDriver",
                "getSeleniumDriver", "getCurrentDriver"
            };
            
            while (clazz != null && clazz != Object.class) {
                for (String methodName : methodNames) {
                    try {
                        Method method = clazz.getDeclaredMethod(methodName);
                        method.setAccessible(true);
                        Object returnValue = method.invoke(testInstance);
                        if (returnValue instanceof WebDriver) {
                            return (WebDriver) returnValue;
                        }
                    } catch (NoSuchMethodException e) {
                        // Try next method
                    }
                }
                clazz = clazz.getSuperclass();
            }
        } catch (Exception e) {
            // Continue to next strategy
        }
        return null;
    }
    
    private WebDriver getDriverFromSuiteAttribute(ITestResult result) {
        try {
            ISuite suite = result.getTestContext().getSuite();
            Map<String, Object> suiteAttributes = suite.getAttributeMap();
            
            for (Map.Entry<String, Object> entry : suiteAttributes.entrySet()) {
                if (entry.getValue() instanceof WebDriver) {
                    return (WebDriver) entry.getValue();
                }
            }
        } catch (Exception e) {
            // Continue to next strategy
        }
        return null;
    }
    
    private WebDriver getDriverFromCustomProvider(ITestResult result) {
        Object testInstance = result.getInstance();
        if (testInstance == null) return null;
        
        try {
            if (testInstance instanceof WebDriverProvider) {
                return ((WebDriverProvider) testInstance).getWebDriver();
            }
            
            Field[] fields = testInstance.getClass().getDeclaredFields();
            for (Field field : fields) {
                if (field.isAnnotationPresent(Inject.class) ||
                    field.getAnnotations().length > 0) {
                    if (WebDriver.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        Object value = field.get(testInstance);
                        if (value != null) {
                            return (WebDriver) value;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // No custom provider available
        }
        return null;
    }
    
    private void capturePageMetadata(WebDriver driver, Path failureDir, String testName, String timestamp) throws IOException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("url", driver.getCurrentUrl());
        metadata.put("title", driver.getTitle());
        metadata.put("timestamp", LocalDateTime.now().toString());
        metadata.put("testName", testName);
        
        // Window and document dimensions
        metadata.put("window", js.executeScript(
            "return {" +
            "  innerWidth: window.innerWidth," +
            "  innerHeight: window.innerHeight," +
            "  scrollX: window.scrollX," +
            "  scrollY: window.scrollY" +
            "};"
        ));
        
        metadata.put("document", js.executeScript(
            "return {" +
            "  scrollWidth: document.documentElement.scrollWidth," +
            "  scrollHeight: document.documentElement.scrollHeight," +
            "  clientWidth: document.documentElement.clientWidth," +
            "  clientHeight: document.documentElement.clientHeight" +
            "};"
        ));
        
        metadata.put("userAgent", js.executeScript("return navigator.userAgent;"));
        
        // Cookies
        Set<Cookie> cookies = driver.manage().getCookies();
        List<Map<String, Object>> cookieList = new ArrayList<>();
        for (Cookie cookie : cookies) {
            Map<String, Object> cookieMap = new HashMap<>();
            cookieMap.put("name", cookie.getName());
            cookieMap.put("domain", cookie.getDomain());
            cookieMap.put("path", cookie.getPath());
            cookieMap.put("secure", cookie.isSecure());
            cookieList.add(cookieMap);
        }
        metadata.put("cookies", cookieList);
        
        String metadataJson = new GsonBuilder()
            .setPrettyPrinting()
            .create()
            .toJson(metadata);
        
        String filename = String.format("%s_%s_metadata.json", testName, timestamp);
        Path metadataFile = failureDir.resolve(filename);
        Files.write(metadataFile, metadataJson.getBytes());
    }
    
    private void createSummaryFile(ITestResult result, Path failureDir, String testName, String timestamp) throws IOException {
        StringBuilder summary = new StringBuilder();
        summary.append("TEST FAILURE SUMMARY\n");
        summary.append("====================\n\n");
        summary.append("Test Name: ").append(testName).append("\n");
        summary.append("Test Class: ").append(result.getTestClass().getName()).append("\n");
        summary.append("Test Method: ").append(result.getMethod().getMethodName()).append("\n");
        summary.append("Timestamp: ").append(LocalDateTime.now()).append("\n");
        summary.append("Duration: ").append(result.getEndMillis() - result.getStartMillis()).append(" ms\n");
        
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            summary.append("\nFailure Message:\n");
            summary.append(throwable.getMessage()).append("\n");
        }
        
        String filename = String.format("%s_%s_summary.txt", testName, timestamp);
        Path summaryFile = failureDir.resolve(filename);
        Files.write(summaryFile, summary.toString().getBytes());
    }
    
    private void captureTestFailureInfo(ITestResult result, Path failureDir, String testName) throws IOException {
        StringBuilder info = new StringBuilder();
        info.append("TEST FAILURE (No WebDriver Available)\n");
        info.append("=====================================\n\n");
        info.append("Test: ").append(testName).append("\n");
        info.append("Class: ").append(result.getTestClass().getName()).append("\n");
        info.append("Method: ").append(result.getMethod().getMethodName()).append("\n");
        
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            throwable.printStackTrace(pw);
            info.append("\nStack Trace:\n").append(sw.toString());
        }
        
        String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP);
        String filename = String.format("%s_%s_error.txt", testName, timestamp);
        Path infoFile = failureDir.resolve(filename);
        Files.write(infoFile, info.toString().getBytes());
    }
    
    public static void registerDriver(WebDriver driver) {
        threadDriverMap.put(Thread.currentThread().getId(), driver);
    }
    
    public static void unregisterDriver() {
        threadDriverMap.remove(Thread.currentThread().getId());
    }
    
    public interface WebDriverProvider {
        WebDriver getWebDriver();
    }
}