# DOM Generator VSCode Extension

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com/wellsfargo/dom-generator)
[![VSCode](https://img.shields.io/badge/VSCode-%5E1.85.0-green.svg)](https://code.visualstudio.com/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

A powerful VSCode extension that automatically captures DOM state, screenshots, and detailed reports when Selenium/TestNG tests fail. Supports multiple testing frameworks including Selenium, Playwright, Cypress, WebdriverIO, and Puppeteer.

## Key Features

### 🎯 Auto-Detection & Configuration
- **Automatic build system detection** (Maven/Gradle)
- **Framework detection** (Selenium + TestNG, Playwright, Cypress, WebdriverIO, Puppeteer)
- **Smart project configuration** with single-click setup
- **Auto-dependency management** for missing libraries

### 📸 Advanced DOM Capture
- **Complete DOM state capture** in JSON format
- **Full-page screenshots** with automatic naming
- **Detailed failure analysis reports** (diff.html)
- **Full DOM HTML preservation** for debugging
- **Shadow DOM and iframe support**
- **Dynamic content handling** with mutation tracking
- **Performance metrics collection**

### 🔧 WebDriver Strategies
Multiple WebDriver access strategies for maximum compatibility:
- Reflection Field Access
- Test Context Attribute
- Thread Local Storage
- Getter Method Detection
- Suite Attribute Access
- Custom Provider Interface

### 📁 Organized Output Structure
```
test-results/
└── dom-captures/
    └── yyyy-MM-dd/
        ├── ClassName_testMethod_status_YYYYMMDD_HHMMSS.json
        ├── ClassName_testMethod_status_YYYYMMDD_HHMMSS_screenshot.png
        ├── ClassName_testMethod_status_YYYYMMDD_HHMMSS_diff.html
        └── ClassName_testMethod_status_YYYYMMDD_HHMMSS_full_dom.html
```

## Installation

### From VSIX Package
```bash
code --install-extension dom-generator-2.0.0.vsix
```

### From Marketplace (Coming Soon)
Search for "DOM Generator" in the VSCode Extensions Marketplace

### Build From Source
```bash
git clone https://github.com/wellsfargo/dom-generator.git
cd dom-generator
npm install
npm run compile
npm run package
```

## Quick Start

### For Selenium + TestNG Projects

#### Option A: Auto-Configure (Recommended)
Best for Wells Fargo standard projects:

1. **Open your Java project** containing TestNG tests
2. **Run auto-configuration**:
   - Open Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`)
   - Run: `DOM Generator: Auto-Configure Project`
   - Select your TestNG XML file from the config folder
3. **Verify setup**: `DOM Generator: Verify Setup`
4. **Run tests**: Your tests will now automatically capture DOM on failures

#### Option B: Basic Setup
For custom project structures:

1. **Open your Java project**
2. **Run**: `DOM Generator: Setup Project`
3. **Follow the setup wizard** to configure your project

### For Playwright Projects

1. **Open your Playwright project**
2. **Run**: `DOM Generator: Setup Project`
3. **Extension automatically configures** Playwright hooks

### Manual Configuration

Add listener to your TestNG XML:
```xml
<listeners>
    <listener class-name="com.wellsfargo.automation.appid.listeners.DOMCaptureListener"/>
</listeners>
```

Or use annotations:
```java
@Listeners({DOMCaptureListener.class})
public class YourTestClass {
    // Your tests
}
```

## Commands

Access commands via Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`):

| Command | Description |
|---------|-------------|
| `DOM Generator: Setup Project` | Initial project setup wizard for basic configuration |
| `DOM Generator: Auto-Configure Project` | Automatic configuration with Wells Fargo standards |
| `DOM Generator: Verify Setup` | Validate DOM capture configuration |
| `DOM Generator: Show Latest Capture` | View the most recent test failure capture |
| `DOM Generator: Search Captures` | Search through historical captures |
| `DOM Generator: Show Dashboard` | Open capture analytics dashboard |

### Tree View Navigation
The DOM Captures explorer panel in the sidebar provides quick access buttons:
- 👁️ **Eye icon**: Show latest capture
- 🔍 **Search icon**: Search captures
- 📊 **Dashboard icon**: Open analytics dashboard

## Configuration Options

Configure via VSCode settings (`Ctrl+,` / `Cmd+,`):

```json
{
  "domGenerator.capturePath": "test-results/dom-captures",
  "domGenerator.autoSetup": true,
  "domGenerator.javaPackage": "com.wellsfargo.automation.appid",
  "domGenerator.autoDetectBuildSystem": true,
  "domGenerator.autoAddDependencies": true,
  "domGenerator.defaultDriverStrategy": "REFLECTION_FIELD",
  "domGenerator.captureRetentionDays": 30,
  "domGenerator.maxCaptureSize": 10485760
}
```

### Settings Description

| Setting | Default | Description |
|---------|---------|-------------|
| `capturePath` | `test-results/dom-captures` | Directory for storing captures |
| `autoSetup` | `true` | Auto-setup on project open |
| `javaPackage` | `com.wellsfargo.automation.appid` | Base Java package for listeners |
| `autoDetectBuildSystem` | `true` | Auto-detect Maven/Gradle |
| `autoAddDependencies` | `true` | Auto-add missing dependencies |
| `defaultDriverStrategy` | `REFLECTION_FIELD` | WebDriver access strategy |
| `captureRetentionDays` | `30` | Days to retain captures |
| `maxCaptureSize` | `10MB` | Max size per capture file |

## Captured Data

Each test failure generates 4 files:

### 1. JSON Data File
Contains:
- Test metadata (class, method, status, timestamp)
- Browser information (name, version, platform)
- Complete DOM state
- Page URL and title
- Cookies, localStorage, sessionStorage
- Window dimensions and scroll position
- Error details and stack trace

### 2. Screenshot (_screenshot.png)
- Full page screenshot at moment of failure
- Preserves visual state for debugging

### 3. Analysis Report (_diff.html)
- Formatted HTML report with:
  - Test execution details
  - Error message and relevant stack trace
  - JavaScript console errors
  - DOM statistics
  - Page analysis
  - Links to related captures

### 4. Full DOM HTML (_full_dom.html)
- Complete HTML snapshot
- Preserves exact DOM structure
- Useful for debugging CSS/layout issues

## WebDriver Strategy Guide

Choose the appropriate strategy based on your test architecture:

| Strategy | Use When |
|----------|----------|
| `REFLECTION_FIELD` | WebDriver stored as class field |
| `TEST_CONTEXT` | Using TestNG ITestContext |
| `THREAD_LOCAL` | Thread-local WebDriver management |
| `GETTER_METHOD` | WebDriver accessed via getter |
| `SUITE_ATTRIBUTE` | Stored in TestNG suite attributes |
| `CUSTOM_PROVIDER` | Implementing WebDriverProvider interface |

## CI/CD Integration

### Jenkins
```groovy
pipeline {
    agent any
    stages {
        stage('Test') {
            steps {
                sh 'mvn test -DcaptureOnSuccess=false'
            }
            post {
                always {
                    archiveArtifacts artifacts: 'test-results/dom-captures/**/*', 
                                     allowEmptyArchive: true
                }
            }
        }
    }
}
```

### GitHub Actions
```yaml
- name: Run Tests
  run: mvn test
  
- name: Upload DOM Captures
  if: failure()
  uses: actions/upload-artifact@v2
  with:
    name: dom-captures
    path: test-results/dom-captures/
```

## Troubleshooting

### Running Tests
Tests should be run using your standard build tools:
- **Maven**: `mvn test` in terminal
- **Gradle**: `gradle test` or `./gradlew test`
- DOM captures will be generated automatically when tests fail

### Common Issues

1. **WebDriver not found**
   - Check WebDriver strategy setting in VSCode settings
   - Ensure WebDriver is accessible from test class
   - Try different access strategies in configuration

2. **Captures not generated**
   - Verify listener is registered in TestNG XML
   - Check file permissions in output directory
   - Review console output for errors
   - Run `DOM Generator: Verify Setup` to check configuration

3. **Build system not detected**
   - Ensure pom.xml or build.gradle is in project root
   - Use `DOM Generator: Setup Project` for detection

### Debug Mode

Enable detailed logging:
```java
System.setProperty("domGenerator.debug", "true");
```

## Advanced Usage

### Custom WebDriver Provider
```java
public class BaseTest implements DOMCaptureListener.WebDriverProvider {
    private WebDriver driver;
    
    @Override
    public WebDriver getWebDriver() {
        return this.driver;
    }
}
```

### Programmatic Registration
```java
@BeforeClass
public void setup() {
    WebDriver driver = new ChromeDriver();
    DOMCaptureListener.registerDriver(driver);
}

@AfterClass
public void teardown() {
    DOMCaptureListener.unregisterDriver();
}
```

### Capture Success Tests
```bash
mvn test -DcaptureSuccess=true
```

## Requirements

- VSCode 1.85.0+
- Java 8+
- TestNG 7.0+ (for Selenium projects)
- Maven 3.6+ or Gradle 6.0+
- Selenium WebDriver 4.0+ (for Selenium projects)

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details.

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## Support

- **Issues**: [GitHub Issues](https://github.com/wellsfargo/dom-generator/issues)
- **Documentation**: [Wiki](https://github.com/wellsfargo/dom-generator/wiki)
- **Email**: dom-generator-support@wellsfargo.com

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Wells Fargo Open Source Program Office
- TestNG and Selenium communities
- VSCode Extension API team

## Changelog

### Version 2.0.0
- Added multi-framework support (Playwright, Cypress, WebdriverIO, Puppeteer)
- Implemented advanced DOM capture strategies
- Added Shadow DOM and iframe support
- Introduced auto-configuration command
- Improved WebDriver detection strategies
- Enhanced error reporting and analysis
- Restructured output format for better organization
- Added performance metrics collection
- Improved mutation tracking for dynamic content

### Version 1.0.0
- Initial release with Selenium + TestNG support
- Basic DOM and screenshot capture
- Maven/Gradle detection

---

**Made with ❤️ by Wells Fargo**