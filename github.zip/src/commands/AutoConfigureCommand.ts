/**
 * Auto-Configuration Command Handler
 * Automatically configures projects for DOM capture based on detected framework
 */

import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { FrameworkDetector, TestFramework } from '../adapters/FrameworkDetector';

export class AutoConfigureCommand {
    private outputChannel: vscode.OutputChannel;
    private createdFiles: string[] = [];
    private updatedFiles: string[] = [];

    constructor() {
        this.outputChannel = vscode.window.createOutputChannel('DOM Generator Auto-Configure');
    }

    /**
     * Execute auto-configuration
     */
    async execute(): Promise<void> {
        try {
            this.outputChannel.clear();
            this.outputChannel.show();
            this.log('Starting DOM Generator Auto-Configuration...\n');

            // Get workspace
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (!workspaceFolder) {
                vscode.window.showErrorMessage('No workspace folder open');
                return;
            }

            const workspace = workspaceFolder.uri.fsPath;
            this.log(`Workspace: ${workspace}\n`);

            // Detect framework
            this.log('Detecting testing framework...');
            const detector = new FrameworkDetector(workspace);
            const detection = await detector.detectFrameworks();

            if (detection.frameworks.length === 0) {
                vscode.window.showErrorMessage('No testing framework detected. Please ensure Selenium or Playwright is configured.');
                this.log('ERROR: No testing framework detected');
                return;
            }

            const primaryFramework = detection.primaryFramework;
            this.log(`Detected framework: ${this.getFrameworkName(primaryFramework!)}\n`);

            // Configure based on framework
            if (primaryFramework === TestFramework.SELENIUM_TESTNG || 
                primaryFramework === TestFramework.SELENIUM_JUNIT) {
                await this.configureSeleniumProject(workspace);
            } else if (primaryFramework === TestFramework.PLAYWRIGHT) {
                await this.configurePlaywrightProject(workspace);
            } else {
                vscode.window.showWarningMessage(`Framework ${primaryFramework} is not yet supported for auto-configuration`);
                this.log(`Framework ${primaryFramework} is not yet supported`);
                return;
            }

            // Show success message
            this.showSuccessMessage();

        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            vscode.window.showErrorMessage(`Auto-configuration failed: ${message}`);
            this.log(`ERROR: ${message}`);
        }
    }

    /**
     * Configure Selenium project
     */
    private async configureSeleniumProject(workspace: string): Promise<void> {
        this.log('Configuring Selenium project...\n');

        // Create folder structure
        await this.createSeleniumFolders(workspace);

        // Create Java files
        await this.createSeleniumFiles(workspace);

        // Select and update XML file
        await this.updateTestNGXml(workspace);
    }

    /**
     * Create Selenium folder structure
     */
    private async createSeleniumFolders(workspace: string): Promise<void> {
        const basePath = path.join(workspace, 'src', 'test', 'java', 'com', 'wellsfargo', 'automation', 'appid');
        const listenersPath = path.join(basePath, 'listeners');
        const utilitiesPath = path.join(basePath, 'utilities');

        // Create listeners folder
        if (!fs.existsSync(listenersPath)) {
            await fs.promises.mkdir(listenersPath, { recursive: true });
            this.log(`Created folder: ${listenersPath}`);
        }

        // Create utilities folder
        if (!fs.existsSync(utilitiesPath)) {
            await fs.promises.mkdir(utilitiesPath, { recursive: true });
            this.log(`Created folder: ${utilitiesPath}`);
        }
    }

    /**
     * Create Selenium Java files
     */
    private async createSeleniumFiles(workspace: string): Promise<void> {
        const basePath = path.join(workspace, 'src', 'test', 'java', 'com', 'wellsfargo', 'automation', 'appid');

        // Create DOMCaptureListener.java
        const domCaptureListenerPath = path.join(basePath, 'listeners', 'DOMCaptureListener.java');
        await this.createFile(domCaptureListenerPath, this.getDOMCaptureListenerContent());

        // Create ScreenshotListener.java
        const screenshotListenerPath = path.join(basePath, 'listeners', 'ScreenshotListener.java');
        await this.createFile(screenshotListenerPath, this.getScreenshotListenerContent());

        // Create DOMCaptureUtil.java
        const domCaptureUtilPath = path.join(basePath, 'utilities', 'DOMCaptureUtil.java');
        await this.createFile(domCaptureUtilPath, this.getDOMCaptureUtilContent());

        // Create WaitUtils.java
        const waitUtilsPath = path.join(basePath, 'utilities', 'WaitUtils.java');
        await this.createFile(waitUtilsPath, this.getWaitUtilsContent());
    }

    /**
     * Update TestNG XML file
     */
    private async updateTestNGXml(workspace: string): Promise<void> {
        const configPath = path.join(workspace, 'config');
        
        if (!fs.existsSync(configPath)) {
            this.log('No config folder found, skipping XML update');
            return;
        }

        // Find all XML files in config folder
        const xmlFiles = await this.findXmlFiles(configPath);
        
        if (xmlFiles.length === 0) {
            this.log('No XML files found in config folder');
            return;
        }

        // Show quick pick to select XML file
        const selectedFile = await vscode.window.showQuickPick(
            xmlFiles.map(file => ({
                label: path.basename(file),
                description: path.relative(workspace, file),
                value: file
            })),
            {
                placeHolder: 'Select TestNG XML file to update',
                title: 'DOM Generator: Select TestNG XML File'
            }
        );

        if (!selectedFile) {
            this.log('No XML file selected, skipping XML update');
            return;
        }

        // Update the selected XML file
        await this.updateXmlFile(selectedFile.value);
    }

    /**
     * Find all XML files in a directory
     */
    private async findXmlFiles(dir: string): Promise<string[]> {
        const files = await fs.promises.readdir(dir);
        const xmlFiles = files
            .filter(file => file.endsWith('.xml'))
            .map(file => path.join(dir, file));
        return xmlFiles;
    }

    /**
     * Update XML file with listener and parameters
     */
    private async updateXmlFile(xmlPath: string): Promise<void> {
        this.log(`\nUpdating XML file: ${xmlPath}`);
        
        let content = await fs.promises.readFile(xmlPath, 'utf-8');
        
        // Check if listener already exists
        const listenerClass = 'com.wellsfargo.automation.appid.listeners.DOMCaptureListener';
        const hasListener = content.includes(listenerClass);
        
        if (!hasListener) {
            // Add listener
            if (content.includes('<listeners>')) {
                // Add to existing listeners section
                content = content.replace(
                    '</listeners>',
                    `    <listener class-name="${listenerClass}"/>\n    </listeners>`
                );
            } else if (content.includes('<suite')) {
                // Add new listeners section after suite tag
                content = content.replace(
                    /<suite([^>]*)>/,
                    `<suite$1>\n    <listeners>\n        <listener class-name="${listenerClass}"/>\n    </listeners>`
                );
            }
            this.log('Added DOM capture listener');
        }

        // Add parameters if they don't exist
        const parameters = [
            { name: 'enableDOMCapture', value: 'true' },
            { name: 'captureOnFailureOnly', value: 'true' },
            { name: 'capturePath', value: './test-results/dom-captures' }
        ];

        for (const param of parameters) {
            if (!content.includes(`name="${param.name}"`)) {
                if (content.includes('<suite')) {
                    const suiteMatch = content.match(/<suite[^>]*>/);
                    if (suiteMatch) {
                        const insertion = `\n    <parameter name="${param.name}" value="${param.value}"/>`;
                        const insertPos = suiteMatch.index! + suiteMatch[0].length;
                        content = content.slice(0, insertPos) + insertion + content.slice(insertPos);
                        this.log(`Added parameter: ${param.name}`);
                    }
                }
            }
        }

        await fs.promises.writeFile(xmlPath, content, 'utf-8');
        this.updatedFiles.push(xmlPath);
        this.log(`Updated: ${xmlPath}`);
    }

    /**
     * Configure Playwright project
     */
    private async configurePlaywrightProject(workspace: string): Promise<void> {
        this.log('Configuring Playwright project...\n');

        // Create folder structure
        await this.createPlaywrightFolders(workspace);

        // Create TypeScript files
        await this.createPlaywrightFiles(workspace);

        // Update playwright.config.ts
        await this.updatePlaywrightConfig(workspace);
    }

    /**
     * Create Playwright folder structure
     */
    private async createPlaywrightFolders(workspace: string): Promise<void> {
        const testsPath = path.join(workspace, 'tests');
        const fixturesPath = path.join(testsPath, 'fixtures');
        const helpersPath = path.join(testsPath, 'helpers');

        // Create fixtures folder
        if (!fs.existsSync(fixturesPath)) {
            await fs.promises.mkdir(fixturesPath, { recursive: true });
            this.log(`Created folder: ${fixturesPath}`);
        }

        // Create helpers folder
        if (!fs.existsSync(helpersPath)) {
            await fs.promises.mkdir(helpersPath, { recursive: true });
            this.log(`Created folder: ${helpersPath}`);
        }
    }

    /**
     * Create Playwright TypeScript files
     */
    private async createPlaywrightFiles(workspace: string): Promise<void> {
        const testsPath = path.join(workspace, 'tests');

        // Create dom-capture.fixture.ts
        const fixturePath = path.join(testsPath, 'fixtures', 'dom-capture.fixture.ts');
        await this.createFile(fixturePath, this.getDOMCaptureFixtureContent());

        // Create dom-capture.helper.ts
        const helperPath = path.join(testsPath, 'helpers', 'dom-capture.helper.ts');
        await this.createFile(helperPath, this.getDOMCaptureHelperContent());
    }

    /**
     * Update Playwright config
     */
    private async updatePlaywrightConfig(workspace: string): Promise<void> {
        const configPath = path.join(workspace, 'playwright.config.ts');
        
        if (!fs.existsSync(configPath)) {
            // Create new config if it doesn't exist
            await this.createFile(configPath, this.getPlaywrightConfigContent());
        } else {
            // Update existing config
            let content = await fs.promises.readFile(configPath, 'utf-8');
            
            // Add DOM capture reporter if not exists
            if (!content.includes('dom-capture-reporter')) {
                content = this.addPlaywrightReporter(content);
            }
            
            // Add global setup if not exists
            if (!content.includes('globalSetup')) {
                content = this.addPlaywrightGlobalSetup(content);
            }
            
            await fs.promises.writeFile(configPath, content, 'utf-8');
            this.updatedFiles.push(configPath);
            this.log(`Updated: ${configPath}`);
        }
    }

    /**
     * Create a file with content
     */
    private async createFile(filePath: string, content: string): Promise<void> {
        await fs.promises.writeFile(filePath, content, 'utf-8');
        this.createdFiles.push(filePath);
        this.log(`Created: ${filePath}`);
    }

    /**
     * Get DOMCaptureListener.java content
     */
    private getDOMCaptureListenerContent(): string {
        return `package com.wellsfargo.automation.appid.listeners;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.ITestContext;
import com.wellsfargo.automation.appid.utilities.DOMCaptureUtil;
import org.openqa.selenium.WebDriver;
import java.lang.reflect.Field;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TestNG Listener for DOM Capture on test failure
 * Auto-generated by DOM Generator VSCode Extension
 */
public class DOMCaptureListener implements ITestListener {
    
    private static final String CAPTURE_PATH = System.getProperty("capturePath", "./test-results/dom-captures");
    private static final boolean CAPTURE_ON_FAILURE_ONLY = Boolean.parseBoolean(
        System.getProperty("captureOnFailureOnly", "true")
    );
    private static final boolean ENABLE_DOM_CAPTURE = Boolean.parseBoolean(
        System.getProperty("enableDOMCapture", "true")
    );
    
    @Override
    public void onTestStart(ITestResult result) {
        if (!ENABLE_DOM_CAPTURE || CAPTURE_ON_FAILURE_ONLY) {
            return;
        }
        captureDOM(result, "test-start");
    }
    
    @Override
    public void onTestSuccess(ITestResult result) {
        if (!ENABLE_DOM_CAPTURE || CAPTURE_ON_FAILURE_ONLY) {
            return;
        }
        captureDOM(result, "test-success");
    }
    
    @Override
    public void onTestFailure(ITestResult result) {
        if (!ENABLE_DOM_CAPTURE) {
            return;
        }
        captureDOM(result, "test-failure");
    }
    
    @Override
    public void onTestSkipped(ITestResult result) {
        // Optionally capture for skipped tests
    }
    
    @Override
    public void onStart(ITestContext context) {
        // Initialize capture directory
        try {
            Files.createDirectories(Paths.get(CAPTURE_PATH));
        } catch (Exception e) {
            System.err.println("Failed to create capture directory: " + e.getMessage());
        }
    }
    
    @Override
    public void onFinish(ITestContext context) {
        // Cleanup if needed
    }
    
    private void captureDOM(ITestResult result, String trigger) {
        try {
            WebDriver driver = getWebDriver(result.getInstance());
            if (driver == null) {
                System.err.println("Could not obtain WebDriver instance for DOM capture");
                return;
            }
            
            // Capture DOM
            Map<String, Object> domSnapshot = DOMCaptureUtil.captureDOM(driver);
            
            // Add test metadata
            domSnapshot.put("testClass", result.getTestClass().getName());
            domSnapshot.put("testMethod", result.getMethod().getMethodName());
            domSnapshot.put("trigger", trigger);
            domSnapshot.put("timestamp", LocalDateTime.now().toString());
            
            if (result.getThrowable() != null) {
                domSnapshot.put("error", result.getThrowable().getMessage());
                domSnapshot.put("stackTrace", getStackTrace(result.getThrowable()));
            }
            
            // Save capture
            String fileName = generateFileName(result, trigger);
            DOMCaptureUtil.saveCapture(domSnapshot, CAPTURE_PATH, fileName);
            
            System.out.println("DOM capture saved: " + fileName);
            
        } catch (Exception e) {
            System.err.println("Failed to capture DOM: " + e.getMessage());
        }
    }
    
    private WebDriver getWebDriver(Object testInstance) throws Exception {
        // Try different strategies to get WebDriver
        
        // Strategy 1: Direct field access
        Field[] fields = testInstance.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (WebDriver.class.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return (WebDriver) field.get(testInstance);
            }
        }
        
        // Strategy 2: Check parent class fields
        Class<?> superClass = testInstance.getClass().getSuperclass();
        if (superClass != null) {
            fields = superClass.getDeclaredFields();
            for (Field field : fields) {
                if (WebDriver.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    return (WebDriver) field.get(testInstance);
                }
            }
        }
        
        // Strategy 3: Try getter method
        try {
            java.lang.reflect.Method getDriver = testInstance.getClass().getMethod("getDriver");
            return (WebDriver) getDriver.invoke(testInstance);
        } catch (Exception e) {
            // Method doesn't exist
        }
        
        return null;
    }
    
    private String generateFileName(ITestResult result, String trigger) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        String className = result.getTestClass().getRealClass().getSimpleName();
        String methodName = result.getMethod().getMethodName();
        return String.format("%s_%s_%s_%s.json", className, methodName, trigger, timestamp);
    }
    
    private String getStackTrace(Throwable throwable) {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement element : throwable.getStackTrace()) {
            sb.append(element.toString()).append("\\n");
        }
        return sb.toString();
    }
}`;
    }

    /**
     * Get ScreenshotListener.java content
     */
    private getScreenshotListenerContent(): string {
        return `package com.wellsfargo.automation.appid.listeners;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.wellsfargo.automation.appid.utilities.DOMCaptureUtil;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * Enhanced Screenshot Listener with DOM Capture
 * Auto-generated by DOM Generator VSCode Extension
 */
public class ScreenshotListener implements ITestListener {
    
    private static final String SCREENSHOT_PATH = System.getProperty("screenshotPath", "./test-results/screenshots");
    
    @Override
    public void onTestFailure(ITestResult result) {
        try {
            WebDriver driver = getWebDriver(result.getInstance());
            if (driver == null) {
                System.err.println("Could not obtain WebDriver for screenshot");
                return;
            }
            
            // Take screenshot
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            
            // Generate filename
            String fileName = generateFileName(result);
            String screenshotFile = fileName + ".png";
            String domFile = fileName + "_dom.json";
            
            // Create directory
            Files.createDirectories(Paths.get(SCREENSHOT_PATH));
            
            // Save screenshot
            Files.copy(
                screenshot.toPath(),
                Paths.get(SCREENSHOT_PATH, screenshotFile),
                StandardCopyOption.REPLACE_EXISTING
            );
            
            // Capture and save DOM
            Map<String, Object> domSnapshot = DOMCaptureUtil.captureDOM(driver);
            domSnapshot.put("screenshotFile", screenshotFile);
            domSnapshot.put("testClass", result.getTestClass().getName());
            domSnapshot.put("testMethod", result.getMethod().getMethodName());
            domSnapshot.put("error", result.getThrowable().getMessage());
            
            DOMCaptureUtil.saveCapture(domSnapshot, SCREENSHOT_PATH, domFile);
            
            System.out.println("Screenshot saved: " + screenshotFile);
            System.out.println("DOM capture saved: " + domFile);
            
        } catch (Exception e) {
            System.err.println("Failed to capture screenshot/DOM: " + e.getMessage());
        }
    }
    
    private WebDriver getWebDriver(Object testInstance) throws Exception {
        Field[] fields = testInstance.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (WebDriver.class.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return (WebDriver) field.get(testInstance);
            }
        }
        
        // Check parent class
        Class<?> superClass = testInstance.getClass().getSuperclass();
        if (superClass != null) {
            fields = superClass.getDeclaredFields();
            for (Field field : fields) {
                if (WebDriver.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    return (WebDriver) field.get(testInstance);
                }
            }
        }
        
        return null;
    }
    
    private String generateFileName(ITestResult result) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        String className = result.getTestClass().getRealClass().getSimpleName();
        String methodName = result.getMethod().getMethodName();
        return String.format("%s_%s_%s", className, methodName, timestamp);
    }
}`;
    }

    /**
     * Get DOMCaptureUtil.java content
     */
    private getDOMCaptureUtilContent(): string {
        return `package com.wellsfargo.automation.appid.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;

/**
 * DOM Capture Utility - Core DOM capture operations
 * Auto-generated by DOM Generator VSCode Extension
 */
public class DOMCaptureUtil {
    
    private static final ObjectMapper mapper = new ObjectMapper()
        .enable(SerializationFeature.INDENT_OUTPUT);
    
    /**
     * Capture complete DOM state
     */
    public static Map<String, Object> captureDOM(WebDriver driver) {
        Map<String, Object> capture = new HashMap<>();
        
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            
            // Basic page info
            capture.put("url", driver.getCurrentUrl());
            capture.put("title", driver.getTitle());
            capture.put("timestamp", System.currentTimeMillis());
            
            // Capture HTML
            String html = (String) js.executeScript("return document.documentElement.outerHTML;");
            capture.put("html", html);
            
            // Capture viewport
            Map<String, Object> viewport = new HashMap<>();
            viewport.put("width", js.executeScript("return window.innerWidth;"));
            viewport.put("height", js.executeScript("return window.innerHeight;"));
            viewport.put("scrollX", js.executeScript("return window.scrollX;"));
            viewport.put("scrollY", js.executeScript("return window.scrollY;"));
            capture.put("viewport", viewport);
            
            // Capture console logs
            String consoleLogs = (String) js.executeScript(
                "return JSON.stringify(window.console.logs || []);"
            );
            capture.put("consoleLogs", consoleLogs);
            
            // Capture local storage
            String localStorage = (String) js.executeScript(
                "return JSON.stringify(localStorage);"
            );
            capture.put("localStorage", localStorage);
            
            // Capture session storage
            String sessionStorage = (String) js.executeScript(
                "return JSON.stringify(sessionStorage);"
            );
            capture.put("sessionStorage", sessionStorage);
            
            // Capture cookies
            capture.put("cookies", driver.manage().getCookies());
            
            // Capture performance metrics
            String performanceMetrics = (String) js.executeScript(
                "return JSON.stringify(performance.timing);"
            );
            capture.put("performanceMetrics", performanceMetrics);
            
            // Detect JavaScript errors
            String jsErrors = (String) js.executeScript(
                "return JSON.stringify(window.jsErrors || []);"
            );
            capture.put("jsErrors", jsErrors);
            
        } catch (Exception e) {
            capture.put("captureError", e.getMessage());
        }
        
        return capture;
    }
    
    /**
     * Capture specific element
     */
    public static Map<String, Object> captureElement(WebDriver driver, String selector) {
        Map<String, Object> elementData = new HashMap<>();
        
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            
            String script = String.format(
                "var element = document.querySelector('%s');" +
                "if (element) {" +
                "  var rect = element.getBoundingClientRect();" +
                "  return {" +
                "    html: element.outerHTML," +
                "    text: element.innerText," +
                "    visible: element.offsetParent !== null," +
                "    rect: {" +
                "      top: rect.top," +
                "      left: rect.left," +
                "      width: rect.width," +
                "      height: rect.height" +
                "    }," +
                "    styles: window.getComputedStyle(element).cssText" +
                "  };" +
                "} else {" +
                "  return null;" +
                "}", selector
            );
            
            Object result = js.executeScript(script);
            if (result != null) {
                elementData.put("element", result);
            } else {
                elementData.put("error", "Element not found: " + selector);
            }
            
        } catch (Exception e) {
            elementData.put("error", e.getMessage());
        }
        
        return elementData;
    }
    
    /**
     * Save capture to file
     */
    public static void saveCapture(Map<String, Object> capture, String directory, String fileName) {
        try {
            Path dir = Paths.get(directory);
            Files.createDirectories(dir);
            
            Path filePath = dir.resolve(fileName);
            String json = mapper.writeValueAsString(capture);
            Files.write(filePath, json.getBytes());
            
        } catch (IOException e) {
            System.err.println("Failed to save capture: " + e.getMessage());
        }
    }
    
    /**
     * Load capture from file
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> loadCapture(String filePath) {
        try {
            String json = new String(Files.readAllBytes(Paths.get(filePath)));
            return mapper.readValue(json, Map.class);
        } catch (IOException e) {
            System.err.println("Failed to load capture: " + e.getMessage());
            return new HashMap<>();
        }
    }
    
    /**
     * Compare two DOM captures
     */
    public static Map<String, Object> compareCaptures(
        Map<String, Object> before,
        Map<String, Object> after
    ) {
        Map<String, Object> diff = new HashMap<>();
        
        // Compare URLs
        if (!before.get("url").equals(after.get("url"))) {
            diff.put("urlChanged", true);
            diff.put("urlBefore", before.get("url"));
            diff.put("urlAfter", after.get("url"));
        }
        
        // Compare HTML length (simple change detection)
        String htmlBefore = (String) before.get("html");
        String htmlAfter = (String) after.get("html");
        if (htmlBefore != null && htmlAfter != null) {
            diff.put("htmlLengthBefore", htmlBefore.length());
            diff.put("htmlLengthAfter", htmlAfter.length());
            diff.put("htmlChanged", !htmlBefore.equals(htmlAfter));
        }
        
        // Compare viewport
        Map<String, Object> viewportBefore = (Map<String, Object>) before.get("viewport");
        Map<String, Object> viewportAfter = (Map<String, Object>) after.get("viewport");
        if (viewportBefore != null && viewportAfter != null) {
            if (!viewportBefore.equals(viewportAfter)) {
                diff.put("viewportChanged", true);
                diff.put("viewportBefore", viewportBefore);
                diff.put("viewportAfter", viewportAfter);
            }
        }
        
        return diff;
    }
    
    /**
     * Inject capture script
     */
    public static void injectCaptureScript(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        String script = 
            "// Capture console logs\\n" +
            "window.console.logs = [];\\n" +
            "const originalLog = console.log;\\n" +
            "console.log = function() {\\n" +
            "  window.console.logs.push(Array.from(arguments).join(' '));\\n" +
            "  originalLog.apply(console, arguments);\\n" +
            "};\\n" +
            "\\n" +
            "// Capture JavaScript errors\\n" +
            "window.jsErrors = [];\\n" +
            "window.addEventListener('error', function(e) {\\n" +
            "  window.jsErrors.push({\\n" +
            "    message: e.message,\\n" +
            "    source: e.filename,\\n" +
            "    line: e.lineno,\\n" +
            "    col: e.colno,\\n" +
            "    stack: e.error ? e.error.stack : ''\\n" +
            "  });\\n" +
            "});";
        
        js.executeScript(script);
    }
}`;
    }

    /**
     * Get WaitUtils.java content
     */
    private getWaitUtilsContent(): string {
        return `package com.wellsfargo.automation.appid.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import java.time.Duration;
import java.util.Map;

/**
 * Smart Wait Utilities with DOM state checking
 * Auto-generated by DOM Generator VSCode Extension
 */
public class WaitUtils {
    
    private static final int DEFAULT_TIMEOUT = 30;
    private static final int POLLING_INTERVAL = 500;
    
    /**
     * Wait for element with DOM state capture on timeout
     */
    public static WebElement waitForElementWithCapture(
        WebDriver driver,
        By locator,
        int timeoutSeconds
    ) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (Exception e) {
            // Capture DOM state on timeout
            Map<String, Object> domState = DOMCaptureUtil.captureDOM(driver);
            domState.put("failedLocator", locator.toString());
            domState.put("timeoutSeconds", timeoutSeconds);
            
            String fileName = "timeout_" + System.currentTimeMillis() + ".json";
            DOMCaptureUtil.saveCapture(domState, "./test-results/timeouts", fileName);
            
            throw new RuntimeException(
                "Element not found: " + locator + ". DOM captured to: " + fileName, e
            );
        }
    }
    
    /**
     * Wait for element to be clickable
     */
    public static WebElement waitForClickable(WebDriver driver, By locator) {
        return waitForClickable(driver, locator, DEFAULT_TIMEOUT);
    }
    
    public static WebElement waitForClickable(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }
    
    /**
     * Wait for JavaScript to complete
     */
    public static void waitForJavaScript(WebDriver driver) {
        waitForJavaScript(driver, DEFAULT_TIMEOUT);
    }
    
    public static void waitForJavaScript(WebDriver driver, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        wait.until((ExpectedCondition<Boolean>) wd -> {
            JavascriptExecutor js = (JavascriptExecutor) wd;
            return js.executeScript("return document.readyState").equals("complete");
        });
    }
    
    /**
     * Wait for jQuery to complete
     */
    public static void waitForJQuery(WebDriver driver) {
        waitForJQuery(driver, DEFAULT_TIMEOUT);
    }
    
    public static void waitForJQuery(WebDriver driver, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        wait.until((ExpectedCondition<Boolean>) wd -> {
            JavascriptExecutor js = (JavascriptExecutor) wd;
            return (Boolean) js.executeScript("return typeof jQuery !== 'undefined' && jQuery.active == 0");
        });
    }
    
    /**
     * Wait for Angular to complete
     */
    public static void waitForAngular(WebDriver driver) {
        waitForAngular(driver, DEFAULT_TIMEOUT);
    }
    
    public static void waitForAngular(WebDriver driver, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        wait.until((ExpectedCondition<Boolean>) wd -> {
            JavascriptExecutor js = (JavascriptExecutor) wd;
            return (Boolean) js.executeScript(
                "return typeof angular !== 'undefined' && " +
                "angular.element(document).injector() && " +
                "angular.element(document).injector().get('$http').pendingRequests.length === 0"
            );
        });
    }
    
    /**
     * Wait for element to disappear
     */
    public static boolean waitForElementToDisappear(WebDriver driver, By locator) {
        return waitForElementToDisappear(driver, locator, DEFAULT_TIMEOUT);
    }
    
    public static boolean waitForElementToDisappear(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }
    
    /**
     * Wait for text to be present
     */
    public static boolean waitForText(WebDriver driver, By locator, String text) {
        return waitForText(driver, locator, text, DEFAULT_TIMEOUT);
    }
    
    public static boolean waitForText(WebDriver driver, By locator, String text, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }
    
    /**
     * Smart wait with multiple conditions
     */
    public static void smartWait(WebDriver driver) {
        // Wait for document ready
        waitForJavaScript(driver);
        
        // Check for jQuery and wait if present
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Boolean hasJQuery = (Boolean) js.executeScript("return typeof jQuery !== 'undefined'");
        if (hasJQuery) {
            waitForJQuery(driver);
        }
        
        // Check for Angular and wait if present
        Boolean hasAngular = (Boolean) js.executeScript("return typeof angular !== 'undefined'");
        if (hasAngular) {
            waitForAngular(driver);
        }
        
        // Wait for no spinners/loaders (common classes)
        String[] loaderSelectors = {
            ".spinner", ".loader", ".loading", 
            "[class*='spinner']", "[class*='loader']", "[class*='loading']"
        };
        
        for (String selector : loaderSelectors) {
            try {
                waitForElementToDisappear(driver, By.cssSelector(selector), 2);
            } catch (Exception e) {
                // Loader not found or still visible, continue
            }
        }
    }
    
    /**
     * Wait with custom condition
     */
    public static <T> T waitForCondition(
        WebDriver driver,
        ExpectedCondition<T> condition,
        int timeoutSeconds
    ) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        wait.pollingEvery(Duration.ofMillis(POLLING_INTERVAL));
        return wait.until(condition);
    }
}`;
    }

    /**
     * Get DOM capture fixture content for Playwright
     */
    private getDOMCaptureFixtureContent(): string {
        return `import { test as base, Page } from '@playwright/test';
import { DOMCaptureHelper } from './dom-capture.helper';

/**
 * DOM Capture Test Fixture for Playwright
 * Auto-generated by DOM Generator VSCode Extension
 */

// Extend basic test with DOM capture capabilities
export const test = base.extend<{
    domCapture: DOMCaptureHelper;
    captureOnFailure: boolean;
}>({
    // Initialize DOM capture helper
    domCapture: async ({ page }, use) => {
        const helper = new DOMCaptureHelper(page);
        await helper.initialize();
        await use(helper);
    },

    // Auto-capture on failure setting
    captureOnFailure: [true, { option: true }],

    // Override page fixture to add auto-capture
    page: async ({ page, captureOnFailure }, use, testInfo) => {
        // Inject capture script on page load
        await page.addInitScript(() => {
            // Capture console logs
            window.consoleLogs = [];
            const originalLog = console.log;
            console.log = function(...args) {
                window.consoleLogs.push({
                    type: 'log',
                    message: args.join(' '),
                    timestamp: Date.now()
                });
                originalLog.apply(console, args);
            };

            // Capture errors
            window.jsErrors = [];
            window.addEventListener('error', (e) => {
                window.jsErrors.push({
                    message: e.message,
                    source: e.filename,
                    line: e.lineno,
                    col: e.colno,
                    stack: e.error?.stack
                });
            });

            // Capture unhandled rejections
            window.addEventListener('unhandledrejection', (e) => {
                window.jsErrors.push({
                    type: 'unhandledRejection',
                    reason: e.reason,
                    promise: 'Promise'
                });
            });
        });

        // Use the page
        await use(page);

        // Capture on test failure
        if (captureOnFailure && testInfo.status === 'failed') {
            const helper = new DOMCaptureHelper(page);
            const capture = await helper.captureFullDOM();
            
            // Add test metadata
            capture.testInfo = {
                title: testInfo.title,
                file: testInfo.file,
                line: testInfo.line,
                column: testInfo.column,
                status: testInfo.status,
                error: testInfo.error?.message,
                duration: testInfo.duration
            };

            // Save capture
            await helper.saveCapture(capture, testInfo);
        }
    }
});

export { expect } from '@playwright/test';`;
    }

    /**
     * Get DOM capture helper content for Playwright
     */
    private getDOMCaptureHelperContent(): string {
        return `import { Page, TestInfo } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

/**
 * DOM Capture Helper for Playwright
 * Auto-generated by DOM Generator VSCode Extension
 */
export class DOMCaptureHelper {
    private page: Page;
    private capturesDir = './test-results/dom-captures';

    constructor(page: Page) {
        this.page = page;
    }

    /**
     * Initialize capture helper
     */
    async initialize() {
        // Ensure captures directory exists
        if (!fs.existsSync(this.capturesDir)) {
            fs.mkdirSync(this.capturesDir, { recursive: true });
        }
    }

    /**
     * Capture full DOM state
     */
    async captureFullDOM() {
        const capture: any = {
            timestamp: new Date().toISOString(),
            url: this.page.url(),
            title: await this.page.title(),
            viewport: this.page.viewportSize(),
            html: await this.page.content(),
            cookies: await this.page.context().cookies(),
        };

        // Capture console logs and errors
        const logs = await this.page.evaluate(() => {
            return {
                consoleLogs: (window as any).consoleLogs || [],
                jsErrors: (window as any).jsErrors || []
            };
        });
        capture.consoleLogs = logs.consoleLogs;
        capture.jsErrors = logs.jsErrors;

        // Capture local and session storage
        const storage = await this.page.evaluate(() => {
            return {
                localStorage: { ...localStorage },
                sessionStorage: { ...sessionStorage }
            };
        });
        capture.localStorage = storage.localStorage;
        capture.sessionStorage = storage.sessionStorage;

        // Capture performance metrics
        const metrics = await this.page.evaluate(() => {
            return {
                timing: performance.timing,
                navigation: performance.navigation,
                memory: (performance as any).memory
            };
        });
        capture.performanceMetrics = metrics;

        // Capture network activity
        const cdp = await this.page.context().newCDPSession(this.page);
        await cdp.send('Network.enable');
        const { requestWillBeSent } = await cdp.send('Network.getRequestPostData', {});
        capture.networkActivity = requestWillBeSent || [];

        // Capture accessibility tree
        const accessibilityTree = await this.page.accessibility.snapshot();
        capture.accessibilityTree = accessibilityTree;

        return capture;
    }

    /**
     * Capture specific element
     */
    async captureElement(selector: string) {
        const element = await this.page.locator(selector);
        
        if (!await element.count()) {
            return { error: \`Element not found: \${selector}\` };
        }

        const capture = await element.evaluate((el) => {
            const rect = el.getBoundingClientRect();
            const styles = window.getComputedStyle(el);
            
            return {
                tagName: el.tagName,
                id: el.id,
                className: el.className,
                innerText: (el as HTMLElement).innerText,
                innerHTML: el.innerHTML,
                attributes: Array.from(el.attributes).map(attr => ({
                    name: attr.name,
                    value: attr.value
                })),
                boundingBox: {
                    top: rect.top,
                    left: rect.left,
                    width: rect.width,
                    height: rect.height
                },
                styles: {
                    display: styles.display,
                    visibility: styles.visibility,
                    opacity: styles.opacity,
                    position: styles.position,
                    zIndex: styles.zIndex
                },
                isVisible: rect.width > 0 && rect.height > 0
            };
        });

        return capture;
    }

    /**
     * Save capture to file
     */
    async saveCapture(capture: any, testInfo?: TestInfo) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const testName = testInfo ? testInfo.title.replace(/[^a-z0-9]/gi, '_') : 'manual';
        const fileName = \`\${testName}_\${timestamp}.json\`;
        const filePath = path.join(this.capturesDir, fileName);

        await fs.promises.writeFile(
            filePath,
            JSON.stringify(capture, null, 2),
            'utf-8'
        );

        console.log(\`DOM capture saved: \${filePath}\`);
        return filePath;
    }

    /**
     * Compare two captures
     */
    compareCaptures(before: any, after: any) {
        const diff: any = {
            urlChanged: before.url !== after.url,
            titleChanged: before.title !== after.title,
            htmlLengthDiff: after.html.length - before.html.length,
            newErrors: after.jsErrors.length - before.jsErrors.length,
            newLogs: after.consoleLogs.length - before.consoleLogs.length
        };

        // Check for DOM changes (simple check)
        diff.domChanged = before.html !== after.html;

        return diff;
    }

    /**
     * Wait for element with capture on timeout
     */
    async waitForElementWithCapture(selector: string, options?: { timeout?: number }) {
        try {
            await this.page.waitForSelector(selector, options);
        } catch (error) {
            // Capture DOM on timeout
            const capture = await this.captureFullDOM();
            capture.failedSelector = selector;
            capture.error = error.message;
            
            await this.saveCapture(capture);
            throw error;
        }
    }

    /**
     * Click with automatic before/after capture
     */
    async clickWithCapture(selector: string) {
        const before = await this.captureFullDOM();
        await this.page.click(selector);
        await this.page.waitForLoadState('networkidle');
        const after = await this.captureFullDOM();

        const diff = this.compareCaptures(before, after);
        console.log('DOM changes after click:', diff);

        return { before, after, diff };
    }
}`;
    }

    /**
     * Get Playwright config content
     */
    private getPlaywrightConfigContent(): string {
        return `import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright Configuration with DOM Capture
 * Auto-generated/updated by DOM Generator VSCode Extension
 */
export default defineConfig({
    testDir: './tests',
    fullyParallel: true,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: process.env.CI ? 1 : undefined,
    
    reporter: [
        ['html'],
        ['json', { outputFile: 'test-results/results.json' }],
        ['./tests/reporters/dom-capture-reporter.ts']
    ],

    use: {
        actionTimeout: 0,
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
        video: 'retain-on-failure',
        
        // DOM capture settings
        captureOnFailure: true,
        capturePath: './test-results/dom-captures'
    },

    projects: [
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'] },
        },
        {
            name: 'firefox',
            use: { ...devices['Desktop Firefox'] },
        },
        {
            name: 'webkit',
            use: { ...devices['Desktop Safari'] },
        }
    ],

    globalSetup: './tests/global-setup.ts',
    globalTeardown: './tests/global-teardown.ts'
});`;
    }

    /**
     * Add Playwright reporter to existing config
     */
    private addPlaywrightReporter(content: string): string {
        // Add reporter import
        if (!content.includes('dom-capture-reporter')) {
            // Find reporter array and add our reporter
            const reporterMatch = content.match(/reporter:\s*\[([^\]]*)\]/s);
            if (reporterMatch) {
                const updatedReporter = reporterMatch[0].replace(
                    ']',
                    `,\n        ['./tests/reporters/dom-capture-reporter.ts']\n    ]`
                );
                content = content.replace(reporterMatch[0], updatedReporter);
            } else {
                // Add reporter section
                content = content.replace(
                    'export default defineConfig({',
                    `export default defineConfig({\n    reporter: [['./tests/reporters/dom-capture-reporter.ts']],`
                );
            }
        }
        return content;
    }

    /**
     * Add Playwright global setup
     */
    private addPlaywrightGlobalSetup(content: string): string {
        if (!content.includes('globalSetup')) {
            content = content.replace(
                'export default defineConfig({',
                `export default defineConfig({\n    globalSetup: './tests/global-setup.ts',`
            );
        }
        return content;
    }

    /**
     * Get framework display name
     */
    private getFrameworkName(framework: TestFramework | null): string {
        switch (framework) {
            case TestFramework.SELENIUM_TESTNG:
                return 'Selenium with TestNG';
            case TestFramework.SELENIUM_JUNIT:
                return 'Selenium with JUnit';
            case TestFramework.PLAYWRIGHT:
                return 'Playwright';
            case TestFramework.CYPRESS:
                return 'Cypress';
            default:
                return 'Unknown';
        }
    }

    /**
     * Log to output channel
     */
    private log(message: string): void {
        this.outputChannel.appendLine(message);
    }

    /**
     * Show success message
     */
    private showSuccessMessage(): void {
        const message = `DOM Generator Auto-Configuration completed successfully!

Created ${this.createdFiles.length} files
Updated ${this.updatedFiles.length} files`;

        vscode.window.showInformationMessage(message);
        
        this.log('\n' + '='.repeat(50));
        this.log('AUTO-CONFIGURATION COMPLETED SUCCESSFULLY');
        this.log('='.repeat(50));
        this.log(`\nCreated files (${this.createdFiles.length}):`);
        this.createdFiles.forEach(file => this.log(`  ✓ ${file}`));
        
        if (this.updatedFiles.length > 0) {
            this.log(`\nUpdated files (${this.updatedFiles.length}):`);
            this.updatedFiles.forEach(file => this.log(`  ✓ ${file}`));
        }
        
        this.log('\n' + '='.repeat(50));
    }

    /**
     * Verify DOM capture setup
     */
    async verifySetup(): Promise<void> {
        this.outputChannel.clear();
        this.outputChannel.show();
        this.log('Verifying DOM Generator Setup...\n');

        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            vscode.window.showErrorMessage('No workspace folder open');
            return;
        }

        const workspace = workspaceFolder.uri.fsPath;
        const issues: string[] = [];
        const found: string[] = [];

        // Detect framework
        const detector = new FrameworkDetector(workspace);
        const detection = await detector.detectFrameworks();

        if (detection.frameworks.length === 0) {
            issues.push('No testing framework detected');
        } else {
            found.push(`Framework: ${this.getFrameworkName(detection.primaryFramework!)}`);
        }

        // Check Selenium files
        if (detection.primaryFramework === TestFramework.SELENIUM_TESTNG || 
            detection.primaryFramework === TestFramework.SELENIUM_JUNIT) {
            
            const basePath = path.join(workspace, 'src', 'test', 'java', 'com', 'wellsfargo', 'automation', 'appid');
            
            // Check listener files
            const listenerFiles = [
                'listeners/DOMCaptureListener.java',
                'listeners/ScreenshotListener.java'
            ];
            
            for (const file of listenerFiles) {
                const filePath = path.join(basePath, file);
                if (fs.existsSync(filePath)) {
                    found.push(`✓ ${file}`);
                } else {
                    issues.push(`Missing: ${file}`);
                }
            }
            
            // Check utility files
            const utilityFiles = [
                'utilities/DOMCaptureUtil.java',
                'utilities/WaitUtils.java'
            ];
            
            for (const file of utilityFiles) {
                const filePath = path.join(basePath, file);
                if (fs.existsSync(filePath)) {
                    found.push(`✓ ${file}`);
                } else {
                    issues.push(`Missing: ${file}`);
                }
            }
            
            // Check for XML files
            const configPath = path.join(workspace, 'config');
            if (fs.existsSync(configPath)) {
                const xmlFiles = await this.findXmlFiles(configPath);
                if (xmlFiles.length > 0) {
                    found.push(`XML files: ${xmlFiles.length} found in config/`);
                } else {
                    issues.push('No XML files found in config/');
                }
            } else {
                issues.push('No config/ folder found');
            }
        }

        // Check Playwright files
        if (detection.primaryFramework === TestFramework.PLAYWRIGHT) {
            const testsPath = path.join(workspace, 'tests');
            
            const playwrightFiles = [
                'fixtures/dom-capture.fixture.ts',
                'helpers/dom-capture.helper.ts'
            ];
            
            for (const file of playwrightFiles) {
                const filePath = path.join(testsPath, file);
                if (fs.existsSync(filePath)) {
                    found.push(`✓ ${file}`);
                } else {
                    issues.push(`Missing: ${file}`);
                }
            }
            
            // Check config
            const configPath = path.join(workspace, 'playwright.config.ts');
            if (fs.existsSync(configPath)) {
                found.push('✓ playwright.config.ts');
            } else {
                issues.push('Missing: playwright.config.ts');
            }
        }

        // Show results
        this.log('='.repeat(50));
        this.log('VERIFICATION RESULTS');
        this.log('='.repeat(50));
        
        if (found.length > 0) {
            this.log('\nFOUND:');
            found.forEach(item => this.log(`  ${item}`));
        }
        
        if (issues.length > 0) {
            this.log('\nISSUES:');
            issues.forEach(issue => this.log(`  ✗ ${issue}`));
            
            vscode.window.showWarningMessage(
                `DOM Generator setup incomplete. Found ${issues.length} issue(s). Check output for details.`
            );
        } else {
            this.log('\n✓ All checks passed!');
            vscode.window.showInformationMessage('DOM Generator setup verified successfully!');
        }
        
        this.log('\n' + '='.repeat(50));
    }
}

export default AutoConfigureCommand;