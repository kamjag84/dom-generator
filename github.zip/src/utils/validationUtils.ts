import * as vscode from 'vscode';
import * as path from 'path';
import { FileUtils } from './fileUtils';
import { DRIVER_STRATEGIES, DEFAULT_JAVA_PACKAGE } from './constants';

/**
 * Validation utilities for DOM Generator extension
 */
export class ValidationUtils {
    /**
     * Validate Java package name
     */
    static isValidJavaPackage(packageName: string): boolean {
        if (!packageName || typeof packageName !== 'string') {
            return false;
        }

        // Java package naming rules
        const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/;
        return packageRegex.test(packageName);
    }

    /**
     * Validate and sanitize Java package name
     */
    static sanitizeJavaPackage(packageName: string): string {
        if (!packageName) {
            return DEFAULT_JAVA_PACKAGE;
        }

        // Convert to lowercase and replace invalid characters
        let sanitized = packageName.toLowerCase()
            .replace(/[^a-z0-9_.]/g, '_')
            .replace(/^[0-9]/, '_')
            .replace(/\.{2,}/g, '.')
            .replace(/^\.|\.$/, '');

        // Ensure valid package structure
        if (!this.isValidJavaPackage(sanitized)) {
            return DEFAULT_JAVA_PACKAGE;
        }

        return sanitized;
    }

    /**
     * Validate WebDriver strategy
     */
    static isValidDriverStrategy(strategy: string): boolean {
        return Object.values(DRIVER_STRATEGIES).includes(strategy as any);
    }

    /**
     * Validate test class name
     */
    static isValidTestClassName(className: string): boolean {
        if (!className || typeof className !== 'string') {
            return false;
        }

        // Java class naming rules
        const classRegex = /^[A-Z][a-zA-Z0-9_]*$/;
        return classRegex.test(className);
    }

    /**
     * Validate test method name
     */
    static isValidTestMethodName(methodName: string): boolean {
        if (!methodName || typeof methodName !== 'string') {
            return false;
        }

        // Java method naming rules
        const methodRegex = /^[a-z][a-zA-Z0-9_]*$/;
        return methodRegex.test(methodName);
    }

    /**
     * Validate Maven coordinates
     */
    static isValidMavenCoordinate(coordinate: string): boolean {
        if (!coordinate || typeof coordinate !== 'string') {
            return false;
        }

        // Format: groupId:artifactId:version
        const parts = coordinate.split(':');
        if (parts.length !== 3) {
            return false;
        }

        const [groupId, artifactId, version] = parts;
        
        // Validate each part
        const idRegex = /^[a-zA-Z0-9._-]+$/;
        const versionRegex = /^[0-9]+\.[0-9]+(\.[0-9]+)?(-[a-zA-Z0-9.-]+)?$/;
        
        return idRegex.test(groupId) && 
               idRegex.test(artifactId) && 
               versionRegex.test(version);
    }

    /**
     * Validate capture path
     */
    static async isValidCapturePath(capturePath: string): Promise<boolean> {
        if (!capturePath || typeof capturePath !== 'string') {
            return false;
        }

        // Check if path is valid
        if (!FileUtils.isValidPath(capturePath)) {
            return false;
        }

        // Ensure it's within workspace
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            return false;
        }

        const absolutePath = path.isAbsolute(capturePath) 
            ? capturePath 
            : path.join(workspaceFolder.uri.fsPath, capturePath);

        return absolutePath.startsWith(workspaceFolder.uri.fsPath);
    }

    /**
     * Validate configuration object
     */
    static validateConfiguration(config: any): { valid: boolean; errors: string[] } {
        const errors: string[] = [];

        // Validate capture path
        if (config.capturePath && typeof config.capturePath === 'string') {
            if (!this.isValidCapturePath(config.capturePath)) {
                errors.push('Invalid capture path');
            }
        }

        // Validate Java package
        if (config.javaPackage && !this.isValidJavaPackage(config.javaPackage)) {
            errors.push('Invalid Java package name');
        }

        // Validate driver strategy
        if (config.defaultDriverStrategy && !this.isValidDriverStrategy(config.defaultDriverStrategy)) {
            errors.push('Invalid WebDriver strategy');
        }

        // Validate boolean fields
        const booleanFields = ['autoSetup', 'autoDetectBuildSystem', 'autoAddDependencies', 'autoRunTestsOnSave', 'showNotifications'];
        for (const field of booleanFields) {
            if (config[field] !== undefined && typeof config[field] !== 'boolean') {
                errors.push(`${field} must be a boolean value`);
            }
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }

    /**
     * Validate XML structure
     */
    static isValidXML(xmlContent: string): boolean {
        try {
            // Basic XML validation
            const openTags = xmlContent.match(/<[^/][^>]*>/g) || [];
            const closeTags = xmlContent.match(/<\/[^>]+>/g) || [];
            
            // Check for basic XML structure
            if (!xmlContent.includes('<?xml') && !xmlContent.includes('<!DOCTYPE')) {
                return false;
            }

            // Simple balance check (not perfect but catches basic errors)
            const tagBalance = openTags.length >= closeTags.length;
            return tagBalance;
        } catch {
            return false;
        }
    }

    /**
     * Validate CI/CD system name
     */
    static isValidCISystem(system: string): boolean {
        const validSystems = ['GitHub Actions', 'Jenkins', 'GitLab CI', 'Azure DevOps', 'CircleCI', 'Travis CI'];
        return validSystems.includes(system);
    }

    /**
     * Validate timestamp format
     */
    static isValidTimestamp(timestamp: string, format: string): boolean {
        try {
            // Simple validation based on format length and characters
            if (format === 'yyyyMMdd_HHmmss') {
                const regex = /^\d{8}_\d{6}$/;
                return regex.test(timestamp);
            }
            return false;
        } catch {
            return false;
        }
    }

    /**
     * Validate build system type
     */
    static isValidBuildSystem(system: string): boolean {
        const validSystems = ['Maven', 'Gradle', 'Gradle (Kotlin DSL)'];
        return validSystems.includes(system);
    }

    /**
     * Sanitize user input for safety
     */
    static sanitizeInput(input: string, maxLength: number = 255): string {
        if (!input || typeof input !== 'string') {
            return '';
        }

        // Remove control characters and limit length
        return input
            .replace(/[\x00-\x1f\x80-\x9f]/g, '')
            .substring(0, maxLength)
            .trim();
    }

    /**
     * Validate URL
     */
    static isValidURL(url: string): boolean {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    }

    /**
     * Validate version string
     */
    static isValidVersion(version: string): boolean {
        // Semantic versioning pattern
        const semverRegex = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
        return semverRegex.test(version);
    }
}