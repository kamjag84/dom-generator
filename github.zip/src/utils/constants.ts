/**
 * Constants used throughout the DOM Generator Extension
 */

export const EXTENSION_NAME = 'DOM Generator';
export const EXTENSION_ID = 'dom-generator';
export const PUBLISHER = 'wellsfargo';

// Paths
export const CAPTURE_BASE_PATH = 'test-results/dom-captures';
export const DEFAULT_JAVA_PACKAGE = 'com.wellsfargo.automation.appid';

// File patterns
export const MAVEN_BUILD_FILE = 'pom.xml';
export const GRADLE_BUILD_FILE = 'build.gradle';
export const GRADLE_KOTLIN_BUILD_FILE = 'build.gradle.kts';
export const TESTNG_CONFIG_PATTERN = '**/testng.xml';
export const TEST_FILE_PATTERN = '**/*Test.java';

// WebDriver strategies
export const DRIVER_STRATEGIES = {
    REFLECTION_FIELD: 'REFLECTION_FIELD',
    TEST_CONTEXT: 'TEST_CONTEXT',
    THREAD_LOCAL: 'THREAD_LOCAL',
    GETTER_METHOD: 'GETTER_METHOD',
    SUITE_ATTRIBUTE: 'SUITE_ATTRIBUTE',
    CUSTOM_PROVIDER: 'CUSTOM_PROVIDER'
} as const;

// Date/Time formats
export const DATE_FORMAT = 'dd-MM-yyyy';
export const TIME_FORMAT = 'HH-mm-a';
export const FILE_TIMESTAMP_FORMAT = 'yyyyMMdd_HHmmss';

// Limits
export const MAX_CAPTURE_SIZE = 10 * 1024 * 1024; // 10MB
export const MAX_CAPTURES_IN_VIEW = 100;
export const CAPTURE_RETENTION_DAYS = 30;

// CI/CD Systems
export const CI_SYSTEMS = {
    GITHUB_ACTIONS: 'GitHub Actions',
    JENKINS: 'Jenkins',
    GITLAB_CI: 'GitLab CI',
    AZURE_DEVOPS: 'Azure DevOps',
    CIRCLE_CI: 'CircleCI',
    TRAVIS_CI: 'Travis CI'
} as const;

// Error Messages
export const ERROR_MESSAGES = {
    NO_WORKSPACE: 'No workspace folder open. Please open a Java project.',
    NO_BUILD_SYSTEM: 'No build system detected (Maven/Gradle)',
    NO_WEBDRIVER: 'Could not obtain WebDriver instance',
    CAPTURE_FAILED: 'Failed to capture test failure',
    INVALID_PATH: 'Invalid file path provided',
    FILE_TOO_LARGE: 'File exceeds maximum size limit',
    PERMISSION_DENIED: 'Permission denied to access file'
} as const;

// Success Messages  
export const SUCCESS_MESSAGES = {
    SETUP_COMPLETE: 'DOM Generator setup completed successfully!',
    CAPTURE_SAVED: 'DOM capture saved successfully',
    CONFIG_UPDATED: 'Configuration updated successfully',
    DEPENDENCIES_ADDED: 'Dependencies added successfully'
} as const;