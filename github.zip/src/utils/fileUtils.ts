import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { ERROR_MESSAGES, MAX_CAPTURE_SIZE } from './constants';

/**
 * Utility functions for file operations with comprehensive error handling
 */
export class FileUtils {
    /**
     * Check if a file or directory exists
     */
    static async exists(filePath: string): Promise<boolean> {
        try {
            // Validate input
            if (!this.isValidPath(filePath)) {
                console.warn(`Invalid path provided: ${filePath}`);
                return false;
            }

            await fs.promises.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    /**
     * Read file with error handling and size validation
     */
    static async readFile(filePath: string, encoding: BufferEncoding = 'utf-8'): Promise<string> {
        try {
            // Validate path
            if (!this.isValidPath(filePath)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            // Check file exists
            if (!await this.exists(filePath)) {
                throw new Error(`File not found: ${filePath}`);
            }

            // Check file size
            const stats = await fs.promises.stat(filePath);
            if (stats.size > MAX_CAPTURE_SIZE) {
                throw new Error(ERROR_MESSAGES.FILE_TOO_LARGE);
            }

            return await fs.promises.readFile(filePath, encoding);
        } catch (error: any) {
            if (error.code === 'EACCES') {
                throw new Error(ERROR_MESSAGES.PERMISSION_DENIED);
            }
            throw error;
        }
    }

    /**
     * Write file with directory creation and validation
     */
    static async writeFile(filePath: string, content: string, encoding: BufferEncoding = 'utf-8'): Promise<void> {
        try {
            // Validate path
            if (!this.isValidPath(filePath)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            // Ensure directory exists
            const dir = path.dirname(filePath);
            await this.ensureDir(dir);

            // Write file with atomic operation
            const tempPath = `${filePath}.tmp`;
            await fs.promises.writeFile(tempPath, content, encoding);
            await fs.promises.rename(tempPath, filePath);
        } catch (error: any) {
            if (error.code === 'EACCES') {
                throw new Error(ERROR_MESSAGES.PERMISSION_DENIED);
            }
            // Clean up temp file if exists
            try {
                await fs.promises.unlink(`${filePath}.tmp`);
            } catch {}
            throw error;
        }
    }

    /**
     * Ensure directory exists, create if not
     */
    static async ensureDir(dirPath: string): Promise<void> {
        try {
            if (!this.isValidPath(dirPath)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            await fs.promises.mkdir(dirPath, { recursive: true });
        } catch (error: any) {
            if (error.code !== 'EEXIST') {
                throw error;
            }
        }
    }

    /**
     * Delete file with error handling
     */
    static async deleteFile(filePath: string): Promise<void> {
        try {
            if (!this.isValidPath(filePath)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            if (await this.exists(filePath)) {
                await fs.promises.unlink(filePath);
            }
        } catch (error: any) {
            if (error.code === 'EACCES') {
                throw new Error(ERROR_MESSAGES.PERMISSION_DENIED);
            }
            throw error;
        }
    }

    /**
     * Copy file with validation
     */
    static async copyFile(source: string, destination: string): Promise<void> {
        try {
            if (!this.isValidPath(source) || !this.isValidPath(destination)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            // Ensure destination directory exists
            const destDir = path.dirname(destination);
            await this.ensureDir(destDir);

            await fs.promises.copyFile(source, destination);
        } catch (error: any) {
            if (error.code === 'EACCES') {
                throw new Error(ERROR_MESSAGES.PERMISSION_DENIED);
            }
            throw error;
        }
    }

    /**
     * Get file stats safely
     */
    static async getStats(filePath: string): Promise<fs.Stats | null> {
        try {
            if (!this.isValidPath(filePath)) {
                return null;
            }

            if (!await this.exists(filePath)) {
                return null;
            }

            return await fs.promises.stat(filePath);
        } catch {
            return null;
        }
    }

    /**
     * List directory contents
     */
    static async listDirectory(dirPath: string): Promise<string[]> {
        try {
            if (!this.isValidPath(dirPath)) {
                throw new Error(ERROR_MESSAGES.INVALID_PATH);
            }

            if (!await this.exists(dirPath)) {
                return [];
            }

            return await fs.promises.readdir(dirPath);
        } catch (error: any) {
            if (error.code === 'EACCES') {
                throw new Error(ERROR_MESSAGES.PERMISSION_DENIED);
            }
            if (error.code === 'ENOTDIR') {
                return [];
            }
            throw error;
        }
    }

    /**
     * Validate file path for security
     */
    static isValidPath(filePath: string): boolean {
        if (!filePath || typeof filePath !== 'string') {
            return false;
        }

        // Normalize the path
        const normalized = path.normalize(filePath);

        // Check for path traversal attempts
        if (normalized.includes('..') || normalized.includes('./')) {
            // Allow relative paths but validate they don't escape workspace
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (workspaceFolder) {
                const resolved = path.resolve(workspaceFolder.uri.fsPath, normalized);
                return resolved.startsWith(workspaceFolder.uri.fsPath);
            }
        }

        // Check for invalid characters (platform-specific)
        const invalidChars = process.platform === 'win32' 
            ? /[<>:"|?*\x00-\x1f]/
            : /[\x00]/;
        
        if (invalidChars.test(filePath)) {
            return false;
        }

        return true;
    }

    /**
     * Sanitize filename for safe file operations
     */
    static sanitizeFileName(fileName: string): string {
        // Remove invalid characters
        let sanitized = fileName.replace(/[<>:"|?*\/\\]/g, '_');
        
        // Remove control characters
        sanitized = sanitized.replace(/[\x00-\x1f\x80-\x9f]/g, '');
        
        // Limit length
        if (sanitized.length > 255) {
            const ext = path.extname(sanitized);
            const name = path.basename(sanitized, ext);
            sanitized = name.substring(0, 255 - ext.length) + ext;
        }
        
        return sanitized;
    }

    /**
     * Get relative path from workspace
     */
    static getRelativePath(absolutePath: string): string {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (workspaceFolder) {
            return path.relative(workspaceFolder.uri.fsPath, absolutePath);
        }
        return absolutePath;
    }

    /**
     * Join paths safely
     */
    static joinPath(...paths: string[]): string {
        const joined = path.join(...paths);
        if (!this.isValidPath(joined)) {
            throw new Error(ERROR_MESSAGES.INVALID_PATH);
        }
        return joined;
    }
}