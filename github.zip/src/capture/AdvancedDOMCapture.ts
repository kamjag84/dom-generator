/**
 * Advanced DOM Capture Engine with comprehensive state collection
 * Supports Shadow DOM, iframes, mutations, and performance metrics
 */

export interface CaptureOptions {
    captureShadowDOM: boolean;
    captureIframes: boolean;
    captureComputedStyles: boolean;
    captureJSState: boolean;
    capturePerformanceMetrics: boolean;
    captureMutations: boolean;
    captureNetworkActivity: boolean;
    captureConsoleOutput: boolean;
    captureAnimations: boolean;
    waitForDynamicContent: boolean;
    maxWaitTime: number;
    maxDepth: number;
    crossOriginIframeHandling: 'skip' | 'placeholder' | 'proxy';
}

export interface DOMSnapshot {
    html: string;
    shadowDOM: ShadowDOMData[];
    iframes: IFrameData[];
    computedStyles: ComputedStyleData;
    jsState: JavaScriptState;
    formData: FormDataSnapshot;
    scrollPositions: ScrollData;
    animations: AnimationState[];
    performanceMetrics: PerformanceData;
    mutations: MutationRecord[];
    networkActivity: NetworkRequest[];
    consoleOutput: ConsoleEntry[];
    timestamp: number;
    url: string;
    viewport: ViewportData;
    metadata: CaptureMetadata;
}

export interface ShadowDOMData {
    hostSelector: string;
    content: string;
    styles: string[];
    mode: 'open' | 'closed';
}

export interface IFrameData {
    selector: string;
    src: string;
    content: string | null;
    crossOrigin: boolean;
    dimensions: { width: number; height: number };
}

export interface ComputedStyleData {
    critical: Map<string, CSSStyleDeclaration>;
    animations: Map<string, Animation[]>;
    pseudoElements: Map<string, CSSStyleDeclaration>;
}

export interface JavaScriptState {
    globalVariables: Record<string, any>;
    localStorage: Record<string, string>;
    sessionStorage: Record<string, string>;
    cookies: string;
    customElements: string[];
    eventListeners: EventListenerData[];
}

export interface FormDataSnapshot {
    inputs: Array<{
        selector: string;
        type: string;
        value: any;
        checked?: boolean;
        selectedOptions?: string[];
    }>;
    formStates: Map<string, FormState>;
}

export interface ScrollData {
    window: { x: number; y: number };
    elements: Map<string, { x: number; y: number }>;
}

export interface AnimationState {
    selector: string;
    animationName: string;
    currentTime: number;
    playState: string;
    duration: number;
}

export interface PerformanceData {
    timing: PerformanceTiming;
    metrics: {
        firstContentfulPaint: number;
        largestContentfulPaint: number;
        cumulativeLayoutShift: number;
        totalBlockingTime: number;
        timeToInteractive: number;
    };
    resources: ResourceTiming[];
    memory?: MemoryInfo;
}

export interface MutationRecord {
    type: string;
    target: string;
    timestamp: number;
    changes: any;
}

export interface NetworkRequest {
    url: string;
    method: string;
    status: number;
    duration: number;
    size: number;
    timestamp: number;
    headers: Record<string, string>;
    response?: any;
}

export interface ConsoleEntry {
    type: 'log' | 'warn' | 'error' | 'info';
    message: string;
    timestamp: number;
    stack?: string;
}

export interface ViewportData {
    width: number;
    height: number;
    devicePixelRatio: number;
    orientation: string;
}

export interface CaptureMetadata {
    framework: 'selenium' | 'playwright' | 'cypress' | 'unknown';
    browser: string;
    version: string;
    platform: string;
    testName?: string;
    testSuite?: string;
    tags?: string[];
    trigger?: string;
    [key: string]: any; // Allow additional properties
}

interface EventListenerData {
    selector: string;
    type: string;
    count: number;
    useCapture: boolean;
}

interface FormState {
    valid: boolean;
    dirty: boolean;
    touched: boolean;
    errors: string[];
}

interface ResourceTiming {
    name: string;
    type: string;
    duration: number;
    size: number;
    startTime: number;
}

interface MemoryInfo {
    usedJSHeapSize: number;
    totalJSHeapSize: number;
    jsHeapSizeLimit: number;
}

/**
 * Main Advanced DOM Capture Class
 */
export class AdvancedDOMCapture {
    private options: CaptureOptions;
    private mutationObserver: MutationObserver | null = null;
    private mutations: MutationRecord[] = [];
    private networkRequests: NetworkRequest[] = [];
    private consoleEntries: ConsoleEntry[] = [];

    constructor(options: Partial<CaptureOptions> = {}) {
        this.options = {
            captureShadowDOM: true,
            captureIframes: true,
            captureComputedStyles: true,
            captureJSState: true,
            capturePerformanceMetrics: true,
            captureMutations: true,
            captureNetworkActivity: true,
            captureConsoleOutput: true,
            captureAnimations: true,
            waitForDynamicContent: true,
            maxWaitTime: 5000,
            maxDepth: 10,
            crossOriginIframeHandling: 'placeholder',
            ...options
        };
    }

    /**
     * Capture complete DOM state with all advanced features
     */
    async captureFullState(): Promise<DOMSnapshot> {
        const startTime = performance.now();

        // Wait for dynamic content if enabled
        if (this.options.waitForDynamicContent) {
            await this.waitForDynamicContent();
        }

        // Start mutation observer if enabled
        if (this.options.captureMutations) {
            this.startMutationObserver();
        }

        // Intercept network activity if enabled
        if (this.options.captureNetworkActivity) {
            this.interceptNetworkActivity();
        }

        // Intercept console output if enabled
        if (this.options.captureConsoleOutput) {
            this.interceptConsoleOutput();
        }

        // Capture all components
        const snapshot: DOMSnapshot = {
            html: this.captureHTML(),
            shadowDOM: this.options.captureShadowDOM ? this.captureShadowDOM() : [],
            iframes: this.options.captureIframes ? await this.captureIFrames() : [],
            computedStyles: this.options.captureComputedStyles ? this.captureComputedStyles() : {} as ComputedStyleData,
            jsState: this.options.captureJSState ? this.captureJavaScriptState() : {} as JavaScriptState,
            formData: this.captureFormData(),
            scrollPositions: this.captureScrollPositions(),
            animations: this.options.captureAnimations ? this.captureAnimations() : [],
            performanceMetrics: this.options.capturePerformanceMetrics ? await this.capturePerformanceMetrics() : {} as PerformanceData,
            mutations: this.mutations,
            networkActivity: this.networkRequests,
            consoleOutput: this.consoleEntries,
            timestamp: Date.now(),
            url: window.location.href,
            viewport: this.captureViewport(),
            metadata: this.captureMetadata()
        };

        // Stop mutation observer
        if (this.mutationObserver) {
            this.mutationObserver.disconnect();
        }

        const captureTime = performance.now() - startTime;
        console.log(`DOM capture completed in ${captureTime.toFixed(2)}ms`);

        return snapshot;
    }

    /**
     * Capture HTML with proper serialization
     */
    private captureHTML(): string {
        const doctype = document.doctype ? 
            `<!DOCTYPE ${document.doctype.name}>` : '';
        return doctype + document.documentElement.outerHTML;
    }

    /**
     * Capture all Shadow DOM content
     */
    private captureShadowDOM(root: Element = document.body, depth: number = 0): ShadowDOMData[] {
        if (depth > this.options.maxDepth) return [];

        const shadowData: ShadowDOMData[] = [];
        const elements = root.querySelectorAll('*');

        elements.forEach(element => {
            if (element.shadowRoot) {
                const selector = this.generateSelector(element);
                const shadowContent = element.shadowRoot.innerHTML;
                const styles = Array.from(element.shadowRoot.styleSheets)
                    .map(sheet => {
                        try {
                            return Array.from(sheet.cssRules)
                                .map(rule => rule.cssText)
                                .join('\n');
                        } catch {
                            return '/* Unable to access stylesheet */';
                        }
                    });

                shadowData.push({
                    hostSelector: selector,
                    content: shadowContent,
                    styles,
                    mode: element.shadowRoot.mode
                });

                // Recursively capture nested shadow DOM
                shadowData.push(...this.captureShadowDOM(element.shadowRoot as any, depth + 1));
            }
        });

        return shadowData;
    }

    /**
     * Capture iframe contents with cross-origin handling
     */
    private async captureIFrames(): Promise<IFrameData[]> {
        const iframes = Array.from(document.querySelectorAll('iframe'));
        const iframeData: IFrameData[] = [];

        for (const iframe of iframes) {
            const selector = this.generateSelector(iframe);
            const isCrossOrigin = this.isCrossOrigin(iframe.src);
            
            let content: string | null = null;
            
            if (!isCrossOrigin) {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                    if (iframeDoc) {
                        content = iframeDoc.documentElement.outerHTML;
                    }
                } catch (e) {
                    console.warn(`Cannot access iframe content: ${iframe.src}`);
                }
            } else if (this.options.crossOriginIframeHandling === 'placeholder') {
                content = `<!-- Cross-origin iframe: ${iframe.src} -->`;
            }

            iframeData.push({
                selector,
                src: iframe.src,
                content,
                crossOrigin: isCrossOrigin,
                dimensions: {
                    width: iframe.offsetWidth,
                    height: iframe.offsetHeight
                }
            });
        }

        return iframeData;
    }

    /**
     * Capture computed styles for critical elements
     */
    private captureComputedStyles(): ComputedStyleData {
        const critical = new Map<string, CSSStyleDeclaration>();
        const animations = new Map<string, Animation[]>();
        const pseudoElements = new Map<string, CSSStyleDeclaration>();

        // Capture styles for visible elements
        const visibleElements = Array.from(document.querySelectorAll('*'))
            .filter(el => {
                const rect = el.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
            })
            .slice(0, 1000); // Limit to prevent memory issues

        visibleElements.forEach(element => {
            const selector = this.generateSelector(element);
            critical.set(selector, window.getComputedStyle(element));

            // Capture animations
            const elementAnimations = element.getAnimations?.();
            if (elementAnimations && elementAnimations.length > 0) {
                animations.set(selector, elementAnimations);
            }

            // Capture pseudo-elements
            ['::before', '::after'].forEach(pseudo => {
                const pseudoStyle = window.getComputedStyle(element, pseudo);
                if (pseudoStyle.content !== 'none') {
                    pseudoElements.set(`${selector}${pseudo}`, pseudoStyle);
                }
            });
        });

        return { critical, animations, pseudoElements };
    }

    /**
     * Capture JavaScript state
     */
    private captureJavaScriptState(): JavaScriptState {
        const globalVars: Record<string, any> = {};
        
        // Capture select global variables (avoid circular references)
        const allowedGlobals = ['userData', 'appState', 'config', '__REACT_DEVTOOLS_GLOBAL_HOOK__'];
        allowedGlobals.forEach(key => {
            if (key in window) {
                try {
                    globalVars[key] = JSON.parse(JSON.stringify((window as any)[key]));
                } catch {
                    globalVars[key] = String((window as any)[key]);
                }
            }
        });

        return {
            globalVariables: globalVars,
            localStorage: { ...localStorage },
            sessionStorage: { ...sessionStorage },
            cookies: document.cookie,
            customElements: [],  // CustomElementRegistry.entries() is not available in all environments
            eventListeners: this.captureEventListeners()
        };
    }

    /**
     * Capture form data and states
     */
    private captureFormData(): FormDataSnapshot {
        const inputs: FormDataSnapshot['inputs'] = [];
        const formStates = new Map<string, FormState>();

        // Capture all form inputs
        const formElements = document.querySelectorAll('input, select, textarea');
        formElements.forEach(element => {
            const input = element as HTMLInputElement;
            const selector = this.generateSelector(element);
            
            const inputData: any = {
                selector,
                type: input.type || 'text',
                value: input.value
            };

            if (input.type === 'checkbox' || input.type === 'radio') {
                inputData.checked = input.checked;
            }

            if (element.tagName === 'SELECT') {
                const select = element as HTMLSelectElement;
                inputData.selectedOptions = Array.from(select.selectedOptions)
                    .map(option => option.value);
            }

            inputs.push(inputData);
        });

        // Capture form validation states
        document.querySelectorAll('form').forEach(form => {
            const selector = this.generateSelector(form);
            formStates.set(selector, {
                valid: form.checkValidity(),
                dirty: form.classList.contains('dirty') || form.classList.contains('ng-dirty'),
                touched: form.classList.contains('touched') || form.classList.contains('ng-touched'),
                errors: Array.from(form.querySelectorAll('.error, .invalid'))
                    .map(el => el.textContent || '')
                    .filter(Boolean)
            });
        });

        return { inputs, formStates };
    }

    /**
     * Capture scroll positions
     */
    private captureScrollPositions(): ScrollData {
        const elements = new Map<string, { x: number; y: number }>();
        
        // Capture scrollable elements
        document.querySelectorAll('*').forEach(element => {
            if (element.scrollHeight > element.clientHeight || 
                element.scrollWidth > element.clientWidth) {
                const selector = this.generateSelector(element);
                elements.set(selector, {
                    x: element.scrollLeft,
                    y: element.scrollTop
                });
            }
        });

        return {
            window: {
                x: window.scrollX,
                y: window.scrollY
            },
            elements
        };
    }

    /**
     * Capture animation states
     */
    private captureAnimations(): AnimationState[] {
        const animations: AnimationState[] = [];
        
        document.querySelectorAll('*').forEach(element => {
            const elementAnimations = element.getAnimations?.();
            if (elementAnimations && elementAnimations.length > 0) {
                elementAnimations.forEach(animation => {
                    animations.push({
                        selector: this.generateSelector(element),
                        animationName: animation.id || 'unnamed',
                        currentTime: animation.currentTime as number,
                        playState: animation.playState,
                        duration: (animation.effect?.getTiming().duration as number) || 0
                    });
                });
            }
        });

        return animations;
    }

    /**
     * Capture performance metrics
     */
    private async capturePerformanceMetrics(): Promise<PerformanceData> {
        const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
        const paint = performance.getEntriesByType('paint');
        
        // Get LCP
        const lcpEntries = performance.getEntriesByType('largest-contentful-paint');
        const lcp = lcpEntries.length > 0 ? lcpEntries[lcpEntries.length - 1].startTime : 0;

        // Get CLS
        let cls = 0;
        const layoutShifts = performance.getEntriesByType('layout-shift') as any[];
        layoutShifts.forEach(shift => {
            if (!shift.hadRecentInput) {
                cls += shift.value;
            }
        });

        // Get resources
        const resources = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
        
        return {
            timing: navigation.toJSON() as PerformanceTiming,
            metrics: {
                firstContentfulPaint: paint.find(p => p.name === 'first-contentful-paint')?.startTime || 0,
                largestContentfulPaint: lcp,
                cumulativeLayoutShift: cls,
                totalBlockingTime: this.calculateTBT(),
                timeToInteractive: navigation.loadEventEnd - navigation.fetchStart
            },
            resources: resources.slice(0, 100).map(r => ({
                name: r.name,
                type: r.initiatorType,
                duration: r.duration,
                size: r.transferSize,
                startTime: r.startTime
            })),
            memory: (performance as any).memory ? {
                usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
                totalJSHeapSize: (performance as any).memory.totalJSHeapSize,
                jsHeapSizeLimit: (performance as any).memory.jsHeapSizeLimit
            } : undefined
        };
    }

    /**
     * Start mutation observer
     */
    private startMutationObserver(): void {
        this.mutationObserver = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                this.mutations.push({
                    type: mutation.type,
                    target: this.generateSelector(mutation.target as Element),
                    timestamp: Date.now(),
                    changes: {
                        addedNodes: mutation.addedNodes.length,
                        removedNodes: mutation.removedNodes.length,
                        attributeName: mutation.attributeName,
                        oldValue: mutation.oldValue
                    }
                });
            });
        });

        this.mutationObserver.observe(document.body, {
            childList: true,
            attributes: true,
            characterData: true,
            subtree: true,
            attributeOldValue: true,
            characterDataOldValue: true
        });
    }

    /**
     * Intercept network activity
     */
    private interceptNetworkActivity(): void {
        // Override fetch
        const originalFetch = window.fetch;
        window.fetch = async (...args) => {
            const startTime = Date.now();
            const [resource, config] = args;
            const url = typeof resource === 'string' ? resource : (resource as Request).url || resource.toString();
            
            try {
                const response = await originalFetch.apply(window, args);
                const clonedResponse = response.clone();
                
                this.networkRequests.push({
                    url,
                    method: config?.method || 'GET',
                    status: response.status,
                    duration: Date.now() - startTime,
                    size: 0, // Will be calculated from response
                    timestamp: startTime,
                    headers: Object.fromEntries(response.headers.entries()),
                    response: response.status < 400 ? await clonedResponse.text() : undefined
                });
                
                return response;
            } catch (error) {
                this.networkRequests.push({
                    url,
                    method: config?.method || 'GET',
                    status: 0,
                    duration: Date.now() - startTime,
                    size: 0,
                    timestamp: startTime,
                    headers: {},
                    response: error?.toString()
                });
                throw error;
            }
        };

        // Override XMLHttpRequest
        const XHROpen = XMLHttpRequest.prototype.open;
        const XHRSend = XMLHttpRequest.prototype.send;
        
        XMLHttpRequest.prototype.open = function(method: string, url: string, ...args: any[]) {
            (this as any)._requestMethod = method;
            (this as any)._requestURL = url;
            return XHROpen.apply(this, [method, url, ...args] as any);
        };
        
        XMLHttpRequest.prototype.send = function(data?: any) {
            const startTime = Date.now();
            
            this.addEventListener('load', () => {
                (this as any).networkRequests = (this as any).networkRequests || [];
                (this as any).networkRequests.push({
                    url: (this as any)._requestURL,
                    method: (this as any)._requestMethod,
                    status: this.status,
                    duration: Date.now() - startTime,
                    size: this.responseText?.length || 0,
                    timestamp: startTime,
                    headers: {},
                    response: this.responseText
                });
            });
            
            return XHRSend.apply(this, [data] as any);
        };
    }

    /**
     * Intercept console output
     */
    private interceptConsoleOutput(): void {
        const methods: Array<'log' | 'warn' | 'error' | 'info'> = ['log', 'warn', 'error', 'info'];
        
        methods.forEach(method => {
            const original = console[method];
            console[method] = (...args: any[]) => {
                this.consoleEntries.push({
                    type: method,
                    message: args.map(arg => {
                        try {
                            return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
                        } catch {
                            return String(arg);
                        }
                    }).join(' '),
                    timestamp: Date.now(),
                    stack: new Error().stack
                });
                
                return original.apply(console, args);
            };
        });
    }

    /**
     * Wait for dynamic content to load
     */
    private async waitForDynamicContent(): Promise<void> {
        const startTime = Date.now();
        let lastMutationTime = Date.now();
        let mutationCount = 0;

        return new Promise((resolve) => {
            const observer = new MutationObserver(() => {
                mutationCount++;
                lastMutationTime = Date.now();
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true
            });

            const checkInterval = setInterval(() => {
                const now = Date.now();
                const timeSinceStart = now - startTime;
                const timeSinceLastMutation = now - lastMutationTime;

                // Stop waiting if:
                // 1. Max wait time reached
                // 2. No mutations for 500ms
                // 3. Document is ready and no pending requests
                if (timeSinceStart > this.options.maxWaitTime ||
                    (timeSinceLastMutation > 500 && mutationCount > 0) ||
                    (document.readyState === 'complete' && this.networkRequests.filter(r => r.status === 0).length === 0)) {
                    
                    clearInterval(checkInterval);
                    observer.disconnect();
                    resolve();
                }
            }, 100);
        });
    }

    /**
     * Generate unique selector for element
     */
    private generateSelector(element: Element | null): string {
        if (!element) return '';
        
        const path: string[] = [];
        let current: Element | null = element;

        while (current && current !== document.body) {
            let selector = current.tagName.toLowerCase();
            
            if (current.id) {
                selector = `#${current.id}`;
                path.unshift(selector);
                break;
            } else if (current.className) {
                const classes = Array.from(current.classList).join('.');
                selector += `.${classes}`;
            }

            const siblings = current.parentElement?.children;
            if (siblings && siblings.length > 1) {
                const index = Array.from(siblings).indexOf(current);
                selector += `:nth-child(${index + 1})`;
            }

            path.unshift(selector);
            current = current.parentElement;
        }

        return path.join(' > ');
    }

    /**
     * Check if URL is cross-origin
     */
    private isCrossOrigin(url: string): boolean {
        if (!url) return false;
        try {
            const urlObj = new URL(url, window.location.origin);
            return urlObj.origin !== window.location.origin;
        } catch {
            return false;
        }
    }

    /**
     * Capture event listeners
     */
    private captureEventListeners(): EventListenerData[] {
        const listeners: EventListenerData[] = [];
        const elements = document.querySelectorAll('*');

        elements.forEach(element => {
            const eventTypes = ['click', 'change', 'submit', 'focus', 'blur', 'keydown', 'keyup'];
            eventTypes.forEach(type => {
                // This is a simplified check - real implementation would need deeper inspection
                if ((element as any)[`on${type}`] || element.getAttribute(`on${type}`)) {
                    listeners.push({
                        selector: this.generateSelector(element),
                        type,
                        count: 1,
                        useCapture: false
                    });
                }
            });
        });

        return listeners;
    }

    /**
     * Calculate Total Blocking Time
     */
    private calculateTBT(): number {
        const longTasks = performance.getEntriesByType('longtask') as any[];
        let tbt = 0;
        
        longTasks.forEach(task => {
            if (task.duration > 50) {
                tbt += task.duration - 50;
            }
        });
        
        return tbt;
    }

    /**
     * Capture viewport information
     */
    private captureViewport(): ViewportData {
        return {
            width: window.innerWidth,
            height: window.innerHeight,
            devicePixelRatio: window.devicePixelRatio,
            orientation: window.screen.orientation?.type || 'unknown'
        };
    }

    /**
     * Capture metadata
     */
    private captureMetadata(): CaptureMetadata {
        const userAgent = navigator.userAgent;
        let framework: CaptureMetadata['framework'] = 'unknown';
        
        // Detect framework
        if ((window as any)['__playwright__']) {
            framework = 'playwright';
        } else if ((window as any)['Cypress']) {
            framework = 'cypress';
        } else if ((window as any)['selenium'] || document.cookie.includes('selenium')) {
            framework = 'selenium';
        }

        return {
            framework,
            browser: this.detectBrowser(userAgent),
            version: navigator.appVersion,
            platform: navigator.platform,
            testName: this.extractTestName(),
            testSuite: this.extractTestSuite()
        };
    }

    /**
     * Detect browser from user agent
     */
    private detectBrowser(userAgent: string): string {
        if (userAgent.includes('Chrome')) return 'Chrome';
        if (userAgent.includes('Firefox')) return 'Firefox';
        if (userAgent.includes('Safari')) return 'Safari';
        if (userAgent.includes('Edge')) return 'Edge';
        return 'Unknown';
    }

    /**
     * Extract test name from various sources
     */
    private extractTestName(): string {
        // Try various methods to get test name
        return window['__currentTestName__'] || 
               document.querySelector('meta[name="test-name"]')?.getAttribute('content') ||
               '';
    }

    /**
     * Extract test suite
     */
    private extractTestSuite(): string {
        return window['__currentTestSuite__'] || 
               document.querySelector('meta[name="test-suite"]')?.getAttribute('content') ||
               '';
    }
}