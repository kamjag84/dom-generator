import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { glob } from 'glob';
import { FileUtils } from '../utils/fileUtils';
import { CAPTURE_BASE_PATH } from '../utils/constants';

export interface DOMCapture {
    domPath: string; // JSON file with DOM data and metadata
    screenshotPath: string; // PNG screenshot
    reportPath: string; // diff.html analysis report
    metadataPath?: string; // full_dom.html (using metadataPath for backward compatibility)
    summaryPath?: string; // deprecated
    timestamp: Date;
    testName: string;
    folder: string;
}

export class DOMCaptureManager {
    private context: vscode.ExtensionContext;
    private captureBasePath: string;

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (workspaceFolders && workspaceFolders.length > 0) {
            const config = vscode.workspace.getConfiguration('domGenerator');
            const configuredPath = config.get<string>('capturePath') || CAPTURE_BASE_PATH;
            this.captureBasePath = path.join(workspaceFolders[0].uri.fsPath, configuredPath);
        } else {
            this.captureBasePath = CAPTURE_BASE_PATH;
        }
    }

    async getCaptureFolder(): Promise<string | undefined> {
        if (await FileUtils.exists(this.captureBasePath)) {
            return this.captureBasePath;
        }
        return undefined;
    }

    async getLatestCapture(): Promise<DOMCapture | undefined> {
        const captures = await this.getAllCaptures();
        if (captures.length === 0) {
            return undefined;
        }
        
        captures.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
        return captures[0];
    }

    async getAllCaptures(): Promise<DOMCapture[]> {
        const captures: DOMCapture[] = [];
        
        if (!await FileUtils.exists(this.captureBasePath)) {
            return captures;
        }

        try {
            const pattern = path.join(this.captureBasePath, '**/*.json');
            const jsonFiles = await glob(pattern, { windowsPathsNoEscape: true });

            for (const jsonFile of jsonFiles) {
                // Only process capture JSON files (not other JSON files)
                if (jsonFile.includes('_failure_') || jsonFile.includes('_success_')) {
                    const capture = await this.parseCaptureFromPath(jsonFile);
                    if (capture) {
                        captures.push(capture);
                    }
                }
            }
        } catch (error) {
            console.error('Error scanning captures:', error);
        }

        return captures;
    }

    async searchCaptures(query: string): Promise<DOMCapture[]> {
        const allCaptures = await this.getAllCaptures();
        const lowerQuery = query.toLowerCase();
        
        return allCaptures.filter(capture => 
            capture.testName.toLowerCase().includes(lowerQuery) ||
            capture.timestamp.toISOString().includes(query) ||
            capture.folder.toLowerCase().includes(lowerQuery)
        );
    }

    private async parseCaptureFromPath(jsonPath: string): Promise<DOMCapture | undefined> {
        try {
            const dir = path.dirname(jsonPath);
            const filename = path.basename(jsonPath);
            
            // Match pattern: ClassName_testMethod_status_YYYYMMDD_HHMMSS.json
            const match = filename.match(/(.+)_(.+)_(failure|success)_(\d{8})_(\d{6})\.json$/);
            if (!match) {
                return undefined;
            }

            const className = match[1];
            const methodName = match[2];
            const status = match[3];
            const dateStr = match[4];
            const timeStr = match[5];
            const testName = `${className}.${methodName}`;
            
            const year = parseInt(dateStr.substring(0, 4));
            const month = parseInt(dateStr.substring(4, 6)) - 1;
            const day = parseInt(dateStr.substring(6, 8));
            const hour = parseInt(timeStr.substring(0, 2));
            const minute = parseInt(timeStr.substring(2, 4));
            const second = parseInt(timeStr.substring(4, 6));
            
            const timestamp = new Date(year, month, day, hour, minute, second);

            const baseFileName = filename.replace('.json', '');
            const screenshotPath = path.join(dir, `${baseFileName}_screenshot.png`);
            const diffPath = path.join(dir, `${baseFileName}_diff.html`);
            const fullDomPath = path.join(dir, `${baseFileName}_full_dom.html`);

            return {
                domPath: jsonPath,
                screenshotPath,
                reportPath: diffPath,
                metadataPath: fullDomPath, // Using metadataPath to store fullDomPath for backward compatibility
                summaryPath: undefined,
                timestamp,
                testName,
                folder: dir
            };
        } catch (error) {
            console.error('Error parsing capture path:', error);
            return undefined;
        }
    }

    async displayCapture(capture: DOMCapture): Promise<void> {
        try {
            if (!await FileUtils.exists(capture.domPath)) {
                throw new Error(`JSON file not found: ${capture.domPath}`);
            }

            // Open JSON data file
            const jsonUri = vscode.Uri.file(capture.domPath);
            await vscode.commands.executeCommand('vscode.open', jsonUri, {
                viewColumn: vscode.ViewColumn.One
            });

            if (await FileUtils.exists(capture.screenshotPath)) {
                await this.showScreenshotInWebview(capture.screenshotPath, capture.testName);
            }

            // Open diff report
            if (await FileUtils.exists(capture.reportPath)) {
                const reportUri = vscode.Uri.file(capture.reportPath);
                await vscode.commands.executeCommand('vscode.open', reportUri, {
                    viewColumn: vscode.ViewColumn.Three,
                    preview: true
                });
            }

            // Open full DOM HTML if available (stored in metadataPath for backward compatibility)
            if (capture.metadataPath && await FileUtils.exists(capture.metadataPath)) {
                const fullDomUri = vscode.Uri.file(capture.metadataPath);
                await vscode.commands.executeCommand('vscode.open', fullDomUri, {
                    viewColumn: vscode.ViewColumn.Beside,
                    preview: true
                });
            }

        } catch (error: any) {
            vscode.window.showErrorMessage(
                `Failed to display capture: ${error.message}`,
                'Show Folder'
            ).then(selection => {
                if (selection === 'Show Folder') {
                    vscode.commands.executeCommand('revealInExplorer', 
                        vscode.Uri.file(capture.folder));
                }
            });
        }
    }

    private async showScreenshotInWebview(screenshotPath: string, testName: string): Promise<void> {
        const panel = vscode.window.createWebviewPanel(
            'domScreenshot',
            `Screenshot: ${testName}`,
            vscode.ViewColumn.Two,
            {
                enableScripts: true,
                localResourceRoots: [vscode.Uri.file(path.dirname(screenshotPath))]
            }
        );

        const screenshotUri = panel.webview.asWebviewUri(vscode.Uri.file(screenshotPath));
        const filename = path.basename(screenshotPath);

        panel.webview.html = this.getScreenshotWebviewContent(screenshotUri, filename, screenshotPath);
    }

    private getScreenshotWebviewContent(screenshotUri: vscode.Uri, filename: string, fullPath: string): string {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screenshot: ${filename}</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #1e1e1e;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        .header {
            color: #cccccc;
            margin-bottom: 20px;
            text-align: center;
        }
        h2 {
            margin: 0 0 10px 0;
            font-size: 24px;
            font-weight: 500;
        }
        .image-container {
            position: relative;
            max-width: 100%;
            overflow: auto;
            background: #2d2d2d;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
        }
        img {
            display: block;
            max-width: 100%;
            height: auto;
        }
        .metadata {
            margin-top: 20px;
            padding: 15px;
            background: #2d2d2d;
            border-radius: 6px;
            color: #999;
            font-size: 13px;
			
			line-height: 1.6;
        }
        .metadata p {
            margin: 5px 0;
        }
        .metadata strong {
            color: #ccc;
        }
        .controls {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        button {
            padding: 8px 16px;
            background: #007ACC;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }
        button:hover {
            background: #005a9e;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Test Screenshot</h2>
    </div>
    <div class="image-container">
        <img src="${screenshotUri}" alt="Test screenshot" id="screenshot" />
    </div>
    <div class="metadata">
        <p><strong>File:</strong> ${filename}</p>
        <p><strong>Path:</strong> ${fullPath}</p>
        <p><strong>Captured:</strong> <span id="timestamp"></span></p>
    </div>
    <div class="controls">
        <button onclick="zoomIn()">Zoom In</button>
        <button onclick="zoomOut()">Zoom Out</button>
        <button onclick="resetZoom()">Reset</button>
    </div>
    <script>
        let scale = 1;
        const img = document.getElementById('screenshot');
        
        function zoomIn() {
            scale *= 1.2;
            img.style.transform = 'scale(' + scale + ')';
        }
        
        function zoomOut() {
            scale /= 1.2;
            img.style.transform = 'scale(' + scale + ')';
        }
        
        function resetZoom() {
            scale = 1;
            img.style.transform = 'scale(1)';
        }
        
        // Set timestamp
        const timestampEl = document.getElementById('timestamp');
        timestampEl.textContent = new Date().toLocaleString();
    </script>
</body>
</html>`;
    }

    async getCaptureFolderStructure(): Promise<any> {
        const structure: any = {};
        
        if (!await FileUtils.exists(this.captureBasePath)) {
            return structure;
        }

        const captures = await this.getAllCaptures();
        
        for (const capture of captures) {
            const relativePath = path.relative(this.captureBasePath, capture.folder);
            const parts = relativePath.split(path.sep);
            
            if (parts.length >= 2) {
                const dateFolder = parts[0];
                const timeFolder = parts[1];
                
                if (!structure[dateFolder]) {
                    structure[dateFolder] = {};
                }
                
                if (!structure[dateFolder][timeFolder]) {
                    structure[dateFolder][timeFolder] = [];
                }
                
                structure[dateFolder][timeFolder].push(capture);
            }
        }
        
        return structure;
    }

    async deleteCapture(capture: DOMCapture): Promise<void> {
        const files = [
            capture.domPath, // JSON file
            capture.screenshotPath,
            capture.reportPath // diff.html
        ];

        // Also delete full_dom.html if it exists
        if (capture.metadataPath) files.push(capture.metadataPath);

        for (const file of files) {
            if (await FileUtils.exists(file)) {
                await fs.promises.unlink(file);
            }
        }

        vscode.window.showInformationMessage(`Deleted capture: ${capture.testName}`);
    }

    async exportCapture(capture: DOMCapture): Promise<void> {
        const saveUri = await vscode.window.showSaveDialog({
            defaultUri: vscode.Uri.file(`${capture.testName}_export.zip`),
            filters: { 'ZIP files': ['zip'] }
        });

        if (saveUri) {
            // Implementation would require a zip library
            vscode.window.showInformationMessage('Export functionality requires additional setup');
        }
    }
}