import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import * as xml2js from 'xml2js';
import { FileUtils } from '../utils/fileUtils';
import { glob } from 'glob';
import { BuildSystemDetector, BuildSystem } from './buildSystemDetector';
import { getDOMCaptureListenerTemplate } from '../templates/listenerTemplates';

export class TestConfigManager {
    private context: vscode.ExtensionContext;
    private workspaceRoot: string;
    private javaPackage: string;
    private buildDetector: BuildSystemDetector;

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (workspaceFolders && workspaceFolders.length > 0) {
            this.workspaceRoot = workspaceFolders[0].uri.fsPath;
        } else {
            this.workspaceRoot = '';
        }
        
        const config = vscode.workspace.getConfiguration('domGenerator');
        this.javaPackage = config.get<string>('javaPackage') || 'com.wellsfargo.automation.appid';
        this.buildDetector = new BuildSystemDetector(this.workspaceRoot);
    }

    async autoSetup(): Promise<void> {
        if (!this.workspaceRoot) {
            return;
        }

        const buildConfig = await this.buildDetector.detectBuildSystem();
        if (!buildConfig) {
            vscode.window.showWarningMessage('No build system detected. Manual setup may be required.');
        } else {
            vscode.window.showInformationMessage(`Detected ${buildConfig.system} build system`);
        }

        const listenersExist = await this.checkListenersExist();
        if (!listenersExist) {
            await this.copyListenerFiles();
        }

        await this.updateTestConfigurations();

        if (buildConfig) {
            if (buildConfig.system === BuildSystem.MAVEN) {
                await this.buildDetector.checkMavenDependencies(buildConfig.buildFile, buildConfig);
            } else if (buildConfig.system === BuildSystem.GRADLE || buildConfig.system === BuildSystem.GRADLE_KOTLIN) {
                await this.buildDetector.checkGradleDependencies(buildConfig.buildFile, buildConfig, buildConfig.system);
            }
        }
    }

    async setupProject(): Promise<void> {
        await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "Setting up DOM Generator",
            cancellable: false
        }, async (progress) => {
            progress.report({ increment: 0, message: "Detecting build system..." });
            
            const buildConfig = await this.buildDetector.detectBuildSystem();
            if (buildConfig) {
                vscode.window.showInformationMessage(`Setting up DOM Generator for ${buildConfig.system} project`);
            }

            progress.report({ increment: 25, message: "Copying listener files..." });
            await this.copyListenerFiles();

            progress.report({ increment: 50, message: "Updating test configurations..." });
            await this.updateTestConfigurations();

            progress.report({ increment: 75, message: "Creating directories..." });
            await this.createCaptureDirectories();

            await this.buildDetector.installBuildWrapper();

            const configPath = await this.buildDetector.getTestConfigPath();
            const testXmlPath = path.join(configPath, 'test.xml');
            if (!await FileUtils.exists(testXmlPath)) {
                await this.buildDetector.generateTestNGConfig(configPath);
            }

            progress.report({ increment: 100, message: "Complete!" });
        });

        const compile = await vscode.window.showInformationMessage(
            'Setup complete. Compile the project now?',
            'Yes', 'No'
        );
        
        if (compile === 'Yes') {
            await this.buildDetector.compileBuild();
        }
    }

    async selectDriverStrategy(): Promise<void> {
        const strategies = [
            { label: '$(symbol-field) Reflection Field', value: 'REFLECTION_FIELD', description: 'Scans test class fields (default)' },
            { label: '$(symbol-namespace) Test Context', value: 'TEST_CONTEXT', description: 'Gets from TestNG context' },
            { label: '$(sync) Thread Local', value: 'THREAD_LOCAL', description: 'For parallel execution' },
            { label: '$(symbol-method) Getter Method', value: 'GETTER_METHOD', description: 'Calls getDriver() method' },
            { label: '$(package) Suite Attribute', value: 'SUITE_ATTRIBUTE', description: 'Suite-level driver' },
            { label: '$(extensions) Custom Provider', value: 'CUSTOM_PROVIDER', description: 'WebDriverProvider interface' }
        ];
        
        const selected = await vscode.window.showQuickPick(strategies, {
            placeHolder: 'Select WebDriver access strategy',
            title: 'WebDriver Access Strategy'
        });
        
        if (selected) {
            await this.updateDriverStrategy(selected.value);
            vscode.window.showInformationMessage(`Updated driver strategy to: ${selected.label}`);
        }
    }

    private async updateDriverStrategy(strategy: string): Promise<void> {
        const configPath = await this.buildDetector.getTestConfigPath();
        const patterns = [
            path.join(configPath, '**/*test*.xml'),
            path.join(configPath, '**/testng.xml')
        ];
        
        let testFiles: string[] = [];
        for (const pattern of patterns) {
            const files = await glob(pattern, { windowsPathsNoEscape: true });
            testFiles = testFiles.concat(files);
        }

        for (const testFile of testFiles) {
            await this.updateTestXMLStrategy(testFile, strategy);
        }
    }

    private async updateTestXMLStrategy(xmlPath: string, strategy: string): Promise<void> {
        try {
            const content = await fs.promises.readFile(xmlPath, 'utf-8');
            const parser = new xml2js.Parser();
            const builder = new xml2js.Builder();
            
            const result = await parser.parseStringPromise(content);
            
            if (result.suite) {
                if (!result.suite.parameter) {
                    result.suite.parameter = [];
                }
                
                const paramIndex = result.suite.parameter.findIndex((p: any) =>
                    p.$?.name === 'dom.generator.driver.strategy'
                );
                
                if (paramIndex >= 0) {
                    result.suite.parameter[paramIndex].$.value = strategy;
                } else {
                    result.suite.parameter.push({
                        $: {
                            name: 'dom.generator.driver.strategy',
                            value: strategy
                        }
                    });
                }
                
                const xml = builder.buildObject(result);
                await fs.promises.writeFile(xmlPath, xml);
            }
        } catch (error) {
            console.error(`Error updating strategy in ${xmlPath}:`, error);
        }
    }

    private async checkListenersExist(): Promise<boolean> {
        const javaSourcePath = await this.buildDetector.getJavaSourcePath();
        const listenerPath = path.join(
            javaSourcePath,
            this.javaPackage.replace(/\./g, '/'),
            'listeners',
            'DOMCaptureListener.java'
        );
        
        return await FileUtils.exists(listenerPath);
    }

    private async copyListenerFiles(): Promise<void> {
        const javaSourcePath = await this.buildDetector.getJavaSourcePath();
        const targetBasePath = path.join(
            javaSourcePath,
            this.javaPackage.replace(/\./g, '/')
        );

        const listenersPath = path.join(targetBasePath, 'listeners');
        const utilitiesPath = path.join(targetBasePath, 'utilities');
        
        await FileUtils.ensureDir(listenersPath);
        await FileUtils.ensureDir(utilitiesPath);

        const domCaptureListenerContent = getDOMCaptureListenerTemplate(this.javaPackage);
        const testNGListenerContent = this.getTestNGDOMCaptureListenerContent();
        const domCaptureUtilContent = this.getDOMCaptureUtilContent();

        await fs.promises.writeFile(
            path.join(listenersPath, 'DOMCaptureListener.java'),
            domCaptureListenerContent
        );
        
        await fs.promises.writeFile(
            path.join(listenersPath, 'TestNGDOMCaptureListener.java'),
            testNGListenerContent
        );
        
        await fs.promises.writeFile(
            path.join(utilitiesPath, 'DOMCaptureUtil.java'),
            domCaptureUtilContent
        );

        vscode.window.showInformationMessage('DOM Generator listener files created successfully');
    }

    private async updateTestConfigurations(): Promise<void> {
        const configPath = await this.buildDetector.getTestConfigPath();
        
        if (!await FileUtils.exists(configPath)) {
            await FileUtils.ensureDir(configPath);
        }

        const patterns = [
            path.join(configPath, '**/*test*.xml'),
            path.join(configPath, '**/testng.xml')
        ];
        
        let testFiles: string[] = [];
        for (const pattern of patterns) {
            const files = await glob(pattern, { windowsPathsNoEscape: true });
            testFiles = testFiles.concat(files);
        }

        const buildConfig = await this.buildDetector.detectBuildSystem();
        if (buildConfig && buildConfig.system === BuildSystem.MAVEN) {
            const resourcePath = path.join(this.workspaceRoot, buildConfig.resourcePath);
            if (await FileUtils.exists(resourcePath)) {
                const resourcePattern = path.join(resourcePath, '**/*test*.xml');
                const resourceFiles = await glob(resourcePattern, { windowsPathsNoEscape: true });
                testFiles = testFiles.concat(resourceFiles);
            }
        }

        testFiles = [...new Set(testFiles)];

        for (const testFile of testFiles) {
            await this.updateTestXML(testFile);
        }

        if (testFiles.length > 0) {
            vscode.window.showInformationMessage(`Updated ${testFiles.length} test configuration file(s)`);
        } else {
            await this.buildDetector.generateTestNGConfig(configPath);
        }
    }

    private async updateTestXML(xmlPath: string): Promise<void> {
        try {
            const content = await fs.promises.readFile(xmlPath, 'utf-8');
            const parser = new xml2js.Parser();
            const builder = new xml2js.Builder();
            
            const result = await parser.parseStringPromise(content);
            
            if (result.suite) {
                if (!result.suite.listeners) {
                    result.suite.listeners = [{ listener: [] }];
                }
                
                const listeners = result.suite.listeners[0].listener || [];
                const listenerClass = `${this.javaPackage}.listeners.DOMCaptureListener`;
                
                const exists = listeners.some((l: any) => 
                    l.$?.['class-name'] === listenerClass
                );
                
                if (!exists) {
                    listeners.push({
                        $: { 'class-name': listenerClass }
                    });
                    result.suite.listeners[0].listener = listeners;
                    
                    if (!result.suite.parameter) {
                        result.suite.parameter = [];
                    }
                    
                    const paramExists = result.suite.parameter.some((p: any) =>
                        p.$?.name === 'dom.generator.driver.strategy'
                    );
                    
                    if (!paramExists) {
                        const config = vscode.workspace.getConfiguration('domGenerator');
                        const defaultStrategy = config.get<string>('defaultDriverStrategy') || 'REFLECTION_FIELD';
                        
                        result.suite.parameter.push({
                            $: {
                                name: 'dom.generator.driver.strategy',
                                value: defaultStrategy
                            }
                        });
                    }
                    
                    const xml = builder.buildObject(result);
                    await fs.promises.writeFile(xmlPath, xml);
                    
                    console.log(`Updated test configuration: ${xmlPath}`);
                }
            }
        } catch (error) {
            console.error(`Error updating ${xmlPath}:`, error);
        }
    }

    private async createCaptureDirectories(): Promise<void> {
        const config = vscode.workspace.getConfiguration('domGenerator');
        const capturePath = config.get<string>('capturePath') || 'test-results/dom-captures';
        const fullPath = path.join(this.workspaceRoot, capturePath);
        
        await FileUtils.ensureDir(fullPath);
        vscode.window.showInformationMessage(`DOM capture directory created: ${fullPath}`);
    }

    async runTestsWithBuildSystem(testClass?: string, testMethod?: string): Promise<void> {
        await this.buildDetector.runTests(testClass, testMethod);
    }

    async cleanAndRunTests(): Promise<void> {
        await this.buildDetector.cleanBuild();
        setTimeout(() => {
            this.buildDetector.runTests();
        }, 2000);
    }

    async validateSetup(): Promise<boolean> {
        const issues: string[] = [];
        
        const buildConfig = await this.buildDetector.detectBuildSystem();
        if (!buildConfig) {
            issues.push('No build system detected (Maven/Gradle)');
        }
        
        if (!await this.checkListenersExist()) {
            issues.push('DOM Capture listeners not found');
        }
        
        const configPath = await this.buildDetector.getTestConfigPath();
        const testXmlPath = path.join(configPath, 'test.xml');
        if (!await FileUtils.exists(testXmlPath)) {
            issues.push('TestNG configuration (test.xml) not found');
        }
        
        const config = vscode.workspace.getConfiguration('domGenerator');
        const capturePath = config.get<string>('capturePath') || 'test-results/dom-captures';
        const fullPath = path.join(this.workspaceRoot, capturePath);
        if (!await FileUtils.exists(fullPath)) {
            issues.push('DOM capture directory not created');
        }
        
        if (buildConfig) {
            if (!await this.buildDetector.hasTestFramework()) {
                issues.push('TestNG dependency not found in build file');
            }
        }
        
        if (issues.length > 0) {
            const fix = await vscode.window.showWarningMessage(
                `Setup validation found ${issues.length} issue(s):\n${issues.join('\n')}`,
                'Fix Issues', 'View Details', 'Ignore'
            );
            
            if (fix === 'Fix Issues') {
                await this.setupProject();
                return true;
            } else if (fix === 'View Details') {
                const outputChannel = vscode.window.createOutputChannel('DOM Generator Validation');
                outputChannel.appendLine('Setup Validation Results:');
                outputChannel.appendLine('========================');
                issues.forEach(issue => outputChannel.appendLine(`❌ ${issue}`));
                outputChannel.show();
            }
            return false;
        }
        
        vscode.window.showInformationMessage('✅ DOM Generator setup validated successfully');
        return true;
    }

    async exportCIConfiguration(): Promise<void> {
        const buildConfig = await this.buildDetector.detectBuildSystem();
        if (!buildConfig) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }
        
        const ciSystem = await vscode.window.showQuickPick(
            ['GitHub Actions', 'Jenkins', 'GitLab CI', 'Azure DevOps', 'CircleCI', 'Travis CI'],
            { placeHolder: 'Select CI/CD system' }
        );
        
        if (!ciSystem) {
            return;
        }
        
        let configContent = '';
        const capturePath = vscode.workspace.getConfiguration('domGenerator').get<string>('capturePath') || 'test-results/dom-captures';
        
        switch (ciSystem) {
            case 'GitHub Actions':
                configContent = this.generateGitHubActionsConfig(buildConfig, capturePath);
                break;
            case 'Jenkins':
                configContent = this.generateJenkinsConfig(buildConfig, capturePath);
                break;
            case 'GitLab CI':
                configContent = this.generateGitLabCIConfig(buildConfig, capturePath);
                break;
            case 'Azure DevOps':
                configContent = this.generateAzureDevOpsConfig(buildConfig, capturePath);
                break;
            case 'CircleCI':
                configContent = this.generateCircleCIConfig(buildConfig, capturePath);
                break;
            case 'Travis CI':
                configContent = this.generateTravisCIConfig(buildConfig, capturePath);
                break;
        }
        
        const ciFileName = this.getCIFileName(ciSystem);
        const ciFilePath = path.join(this.workspaceRoot, ciFileName);
        
        // Create directory if needed
        const dir = path.dirname(ciFilePath);
        if (!await FileUtils.exists(dir)) {
            await FileUtils.ensureDir(dir);
        }
        
        await FileUtils.writeFile(ciFilePath, configContent);
        vscode.window.showInformationMessage(`CI/CD configuration exported to ${ciFileName}`);
        
        const uri = vscode.Uri.file(ciFilePath);
        await vscode.commands.executeCommand('vscode.open', uri);
    }

    createTestWatcher(): vscode.FileSystemWatcher {
        const javaPattern = new vscode.RelativePattern(this.workspaceRoot, '**/src/test/**/*.java');
        const watcher = vscode.workspace.createFileSystemWatcher(javaPattern);
        
        watcher.onDidChange(async (uri) => {
            const config = vscode.workspace.getConfiguration('domGenerator');
            if (config.get<boolean>('autoRunTestsOnSave')) {
                const fileName = path.basename(uri.fsPath, '.java');
                
                const runTest = await vscode.window.showInformationMessage(
                    `Test file ${fileName} changed. Run tests?`,
                    'Yes', 'No', 'Don\'t ask again'
                );
                
                if (runTest === 'Yes') {
                    const content = await FileUtils.readFile(uri.fsPath);
                    const packageMatch = content.match(/package\s+([\w.]+);/);
                    const classMatch = content.match(/public\s+class\s+(\w+)/);
                    
                    if (packageMatch && classMatch) {
                        const fullClassName = `${packageMatch[1]}.${classMatch[1]}`;
                        await this.buildDetector.runTests(fullClassName);
                    }
                } else if (runTest === 'Don\'t ask again') {
                    await config.update('autoRunTestsOnSave', false, vscode.ConfigurationTarget.Workspace);
                }
            }
        });
        
        return watcher;
    }

    private generateGitHubActionsConfig(buildConfig: any, capturePath: string): string {
        const buildCommand = buildConfig.system === BuildSystem.MAVEN ? 'mvn test' : './gradlew test';
        
        return `name: DOM Generator Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up JDK 11
      uses: actions/setup-java@v3
      with:
        java-version: '11'
        distribution: 'temurin'
    
    - name: Setup Chrome
      uses: browser-actions/setup-chrome@latest
    
    - name: Run tests with DOM capture
      run: ${buildCommand}
    
    - name: Upload DOM captures
      if: failure()
      uses: actions/upload-artifact@v3
      with:
        name: dom-captures
        path: ${capturePath}/
        retention-days: 7
    
    - name: Test Report
      if: always()
      uses: dorny/test-reporter@v1
      with:
        name: TestNG Results
        path: '**/surefire-reports/TEST-*.xml'
        reporter: java-junit`;
    }

    private generateJenkinsConfig(buildConfig: any, capturePath: string): string {
        const buildCommand = buildConfig.system === BuildSystem.MAVEN ? 'mvn test' : './gradlew test';
        
        return `pipeline {
    agent any
    
    tools {
        jdk 'JDK11'
        ${buildConfig.system === BuildSystem.MAVEN ? "maven 'Maven3'" : ""}
    }
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }
        
        stage('Test with DOM Capture') {
            steps {
                sh '${buildCommand}'
            }
        }
    }
    
    post {
        failure {
            archiveArtifacts artifacts: '${capturePath}/**/*', allowEmptyArchive: true
        }
        always {
            junit '**/surefire-reports/TEST-*.xml'
        }
    }
}`;
    }

    private generateGitLabCIConfig(buildConfig: any, capturePath: string): string {
        const buildCommand = buildConfig.system === BuildSystem.MAVEN ? 'mvn test' : './gradlew test';
        
        return `image: maven:3.8.5-openjdk-11

stages:
  - test

test:
  stage: test
  script:
    - ${buildCommand}
  artifacts:
    when: on_failure
    paths:
      - ${capturePath}/
    expire_in: 1 week
  reports:
    junit:
      - '**/surefire-reports/TEST-*.xml'`;
    }

    private generateAzureDevOpsConfig(buildConfig: any, capturePath: string): string {
        return `trigger:
- main
- develop

pool:
  vmImage: 'ubuntu-latest'

steps:
- task: UseJavaVersion@0
  inputs:
    versionSpec: '11'
    jdkArchitectureOption: 'x64'

- task: ${buildConfig.system === BuildSystem.MAVEN ? 'Maven@3' : 'Gradle@2'}
  inputs:
    ${buildConfig.system === BuildSystem.MAVEN ? 'mavenPomFile' : 'gradleWrapperFile'}: '${buildConfig.system === BuildSystem.MAVEN ? 'pom.xml' : 'gradlew'}'
    goals: 'test'
    publishJUnitResults: true
    testResultsFiles: '**/surefire-reports/TEST-*.xml'

- task: PublishBuildArtifacts@1
  condition: failed()
  inputs:
    pathToPublish: '${capturePath}'
    artifactName: 'dom-captures'`;
    }

    private generateCircleCIConfig(buildConfig: any, capturePath: string): string {
        const buildCommand = buildConfig.system === BuildSystem.MAVEN ? 'mvn test' : './gradlew test';
        
        return `version: 2.1

jobs:
  test:
    docker:
      - image: cimg/openjdk:11.0
    steps:
      - checkout
      - run:
          name: Run tests with DOM capture
          command: ${buildCommand}
      - store_test_results:
          path: target/surefire-reports
      - store_artifacts:
          path: ${capturePath}
          when: on_fail

workflows:
  test-workflow:
    jobs:
      - test`;
    }

    private generateTravisCIConfig(buildConfig: any, capturePath: string): string {
        return `language: java
jdk:
  - openjdk11

script:
  - ${buildConfig.system === BuildSystem.MAVEN ? 'mvn test' : './gradlew test'}

after_failure:
  - tar -czf dom-captures.tar.gz ${capturePath}/

deploy:
  provider: releases
  file: dom-captures.tar.gz
  skip_cleanup: true
  on:
    tags: true`;
    }

    private getCIFileName(ciSystem: string): string {
        switch (ciSystem) {
            case 'GitHub Actions':
                return '.github/workflows/dom-generator-tests.yml';
            case 'Jenkins':
                return 'Jenkinsfile';
            case 'GitLab CI':
                return '.gitlab-ci.yml';
            case 'Azure DevOps':
                return 'azure-pipelines.yml';
            case 'CircleCI':
                return '.circleci/config.yml';
            case 'Travis CI':
                return '.travis.yml';
            default:
                return 'ci-config.yml';
        }
    }

    private getTestNGDOMCaptureListenerContent(): string {
        return `package ${this.javaPackage}.listeners;

import org.testng.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Simplified TestNG DOM Capture Listener
 * Extends DOMCaptureListener for basic functionality
 */
public class TestNGDOMCaptureListener extends DOMCaptureListener implements ITestListener {
    
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH-mm-a");
    
    @Override
    public void onTestStart(ITestResult result) {
        System.out.println("[DOM Generator] Test started: " + result.getMethod().getMethodName());
    }
    
    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("[DOM Generator] Test passed: " + result.getMethod().getMethodName());
    }
    
    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("[DOM Generator] Test skipped: " + result.getMethod().getMethodName());
    }
    
    @Override
    public void onFinish(ITestContext context) {
        System.out.println("[DOM Generator] Test suite finished: " + context.getName());
    }
}`;
    }

    private getDOMCaptureUtilContent(): string {
        return `package ${this.javaPackage}.utilities;

import org.openqa.selenium.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.apache.commons.io.FileUtils;

/**
 * Utility class for DOM capture operations
 */
public class DOMCaptureUtil {
    
    private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    
    public static void captureDOM(WebDriver driver, String outputPath, String testName) throws IOException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String dom = (String) js.executeScript(
            "var serializer = new XMLSerializer();" +
            "var dom = serializer.serializeToString(document);" +
            "if (!dom.startsWith('<!DOCTYPE')) {" +
            "  dom = '<!DOCTYPE html>' + dom;" +
            "}" +
            "return dom;"
        );
        
        String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP);
        String filename = String.format("%s_%s_DOM.html", testName, timestamp);
        Path filePath = Paths.get(outputPath, filename);
        Files.write(filePath, dom.getBytes("UTF-8"));
    }
    
    public static void captureScreenshot(WebDriver driver, String outputPath, String testName) throws IOException {
        if (driver instanceof TakesScreenshot) {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP);
            String filename = String.format("%s_%s_screenshot.png", testName, timestamp);
            Path filePath = Paths.get(outputPath, filename);
            FileUtils.copyFile(screenshot, filePath.toFile());
        }
    }
}`;
    }
}