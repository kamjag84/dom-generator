import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import * as xml2js from 'xml2js';
import { FileUtils } from '../utils/fileUtils';
import { glob } from 'glob';

export enum BuildSystem {
    MAVEN = 'Maven',
    GRADLE = 'Gradle',
    GRADLE_KOTLIN = 'Gradle (Kotlin DSL)',
    UNKNOWN = 'Unknown'
}

export interface BuildConfig {
    system: BuildSystem;
    buildFile: string;
    testCommand: string;
    dependencies: Map<string, string>;
    testSourcePath: string;
    resourcePath: string;
    outputPath: string;
}

export class BuildSystemDetector {
    private workspaceRoot: string;
    private outputChannel: vscode.OutputChannel;

    constructor(workspaceRoot: string) {
        this.workspaceRoot = workspaceRoot;
        this.outputChannel = vscode.window.createOutputChannel('DOM Generator - Build');
    }

    async detectBuildSystem(): Promise<BuildConfig | null> {
        this.outputChannel.appendLine('Detecting build system...');
        
        // Check for Maven
        const pomPath = path.join(this.workspaceRoot, 'pom.xml');
        if (await FileUtils.exists(pomPath)) {
            this.outputChannel.appendLine('Maven project detected (pom.xml found)');
            return this.configureMavenProject(pomPath);
        }

        // Check for Gradle with Groovy DSL
        const buildGradlePath = path.join(this.workspaceRoot, 'build.gradle');
        if (await FileUtils.exists(buildGradlePath)) {
            this.outputChannel.appendLine('Gradle project detected (build.gradle found)');
            return this.configureGradleProject(buildGradlePath, BuildSystem.GRADLE);
        }

        // Check for Gradle with Kotlin DSL
        const buildGradleKtsPath = path.join(this.workspaceRoot, 'build.gradle.kts');
        if (await FileUtils.exists(buildGradleKtsPath)) {
            this.outputChannel.appendLine('Gradle project with Kotlin DSL detected (build.gradle.kts found)');
            return this.configureGradleProject(buildGradleKtsPath, BuildSystem.GRADLE_KOTLIN);
        }

        // Check for nested build files (multi-module projects)
        const nestedPom = await glob('**/pom.xml', { 
            cwd: this.workspaceRoot, 
            ignore: ['**/node_modules/**', '**/target/**']
        });
        
        if (nestedPom.length > 0) {
            this.outputChannel.appendLine(`Maven multi-module project detected (${nestedPom.length} pom.xml files found)`);
            const rootPom = nestedPom.find(p => !p.includes('/')) || nestedPom[0];
            return this.configureMavenProject(path.join(this.workspaceRoot, rootPom));
        }

        const nestedGradle = await glob('**/build.gradle{,.kts}', { 
            cwd: this.workspaceRoot,
            ignore: ['**/node_modules/**', '**/build/**']
        });
        
        if (nestedGradle.length > 0) {
            this.outputChannel.appendLine(`Gradle multi-module project detected (${nestedGradle.length} build files found)`);
            const rootBuild = nestedGradle.find(p => !p.includes('/')) || nestedGradle[0];
            const isKotlinDsl = rootBuild.endsWith('.kts');
            return this.configureGradleProject(
                path.join(this.workspaceRoot, rootBuild),
                isKotlinDsl ? BuildSystem.GRADLE_KOTLIN : BuildSystem.GRADLE
            );
        }

        this.outputChannel.appendLine('No recognized build system detected');
        return null;
    }

    private async configureMavenProject(pomPath: string): Promise<BuildConfig> {
        const config: BuildConfig = {
            system: BuildSystem.MAVEN,
            buildFile: pomPath,
            testCommand: 'mvn test',
            dependencies: new Map([
                ['selenium-java', '4.15.0'],
                ['testng', '7.8.0'],
                ['commons-io', '2.11.0'],
                ['gson', '2.10.1']
            ]),
            testSourcePath: 'src/test/java',
            resourcePath: 'src/test/resources',
            outputPath: 'target'
        };

        await this.checkMavenDependencies(pomPath, config);
        return config;
    }

    private async configureGradleProject(buildPath: string, system: BuildSystem): Promise<BuildConfig> {
        const config: BuildConfig = {
            system: system,
            buildFile: buildPath,
            testCommand: './gradlew test',
            dependencies: new Map([
                ['org.seleniumhq.selenium:selenium-java', '4.15.0'],
                ['org.testng:testng', '7.8.0'],
                ['commons-io:commons-io', '2.11.0'],
                ['com.google.code.gson:gson', '2.10.1']
            ]),
            testSourcePath: 'src/test/java',
            resourcePath: 'src/test/resources',
            outputPath: 'build'
        };

        const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
        if (!await FileUtils.exists(gradlewPath)) {
            config.testCommand = 'gradle test';
        }

        await this.checkGradleDependencies(buildPath, config, system);
        return config;
    }

    async checkMavenDependencies(pomPath: string, config: BuildConfig): Promise<void> {
        try {
            const pomContent = await FileUtils.readFile(pomPath);
            const parser = new xml2js.Parser();
            const result = await parser.parseStringPromise(pomContent);
            
            const existingDeps = new Set<string>();
            if (result.project?.dependencies?.[0]?.dependency) {
                for (const dep of result.project.dependencies[0].dependency) {
                    const artifactId = dep.artifactId?.[0];
                    if (artifactId) {
                        existingDeps.add(artifactId);
                    }
                }
            }

            const missingDeps: string[] = [];
            for (const [artifact, version] of config.dependencies) {
                if (!existingDeps.has(artifact)) {
                    missingDeps.push(artifact);
                }
            }

            if (missingDeps.length > 0 && vscode.workspace.getConfiguration('domGenerator').get('autoAddDependencies')) {
                const add = await vscode.window.showInformationMessage(
                    `Missing dependencies detected: ${missingDeps.join(', ')}. Add them to pom.xml?`,
                    'Yes', 'No'
                );
                
                if (add === 'Yes') {
                    await this.addMavenDependencies(pomPath, missingDeps, config);
                }
            }

            this.outputChannel.appendLine(`Maven dependencies check complete. Missing: ${missingDeps.length}`);
        } catch (error) {
            this.outputChannel.appendLine(`Error checking Maven dependencies: ${error}`);
        }
    }

    async checkGradleDependencies(buildPath: string, config: BuildConfig, system: BuildSystem): Promise<void> {
        try {
            const buildContent = await FileUtils.readFile(buildPath);
            
            const existingDeps = new Set<string>();
            const depPatterns = [
                /testImplementation\s*[\(\']([^)'\n]+)[\)\']/g,
                /testCompile\s*[\(\']([^)'\n]+)[\)\']/g,
                /implementation\s*[\(\']([^)'\n]+)[\)\']/g
            ];

            for (const pattern of depPatterns) {
                let match;
                while ((match = pattern.exec(buildContent)) !== null) {
                    existingDeps.add(match[1]);
                }
            }

            const missingDeps: string[] = [];
            for (const [artifact, version] of config.dependencies) {
                const found = Array.from(existingDeps).some(dep => dep.includes(artifact.split(':').pop()!));
                if (!found) {
                    missingDeps.push(`${artifact}:${version}`);
                }
            }

            if (missingDeps.length > 0 && vscode.workspace.getConfiguration('domGenerator').get('autoAddDependencies')) {
                const add = await vscode.window.showInformationMessage(
                    `Missing dependencies detected. Add them to ${path.basename(buildPath)}?`,
                    'Yes', 'No'
                );
                
                if (add === 'Yes') {
                    await this.addGradleDependencies(buildPath, missingDeps, system);
                }
            }

            this.outputChannel.appendLine(`Gradle dependencies check complete. Missing: ${missingDeps.length}`);
        } catch (error) {
            this.outputChannel.appendLine(`Error checking Gradle dependencies: ${error}`);
        }
    }

    private async addMavenDependencies(pomPath: string, missingDeps: string[], config: BuildConfig): Promise<void> {
        try {
            const pomContent = await FileUtils.readFile(pomPath);
            const parser = new xml2js.Parser();
            const builder = new xml2js.Builder({ 
                xmldec: { version: '1.0', encoding: 'UTF-8' },
                renderOpts: { pretty: true, indent: '    ' }
            });
            
            const result = await parser.parseStringPromise(pomContent);
            
            if (!result.project.dependencies) {
                result.project.dependencies = [{ dependency: [] }];
            }
            
            const dependencies = result.project.dependencies[0];
            if (!dependencies.dependency) {
                dependencies.dependency = [];
            }

            for (const artifact of missingDeps) {
                const version = config.dependencies.get(artifact);
                
                let groupId = '';
                let artifactId = artifact;
                
                switch (artifact) {
                    case 'selenium-java':
                        groupId = 'org.seleniumhq.selenium';
                        break;
                    case 'testng':
                        groupId = 'org.testng';
                        break;
                    case 'commons-io':
                        groupId = 'commons-io';
                        break;
                    case 'gson':
                        groupId = 'com.google.code.gson';
                        break;
                }

                dependencies.dependency.push({
                    groupId: [groupId],
                    artifactId: [artifactId],
                    version: [version],
                    scope: ['test']
                });

                this.outputChannel.appendLine(`Added dependency: ${groupId}:${artifactId}:${version}`);
            }

            const xml = builder.buildObject(result);
            await FileUtils.writeFile(pomPath, xml);
            
            vscode.window.showInformationMessage(`Added ${missingDeps.length} dependencies to pom.xml`);
        } catch (error) {
            this.outputChannel.appendLine(`Error adding Maven dependencies: ${error}`);
            vscode.window.showErrorMessage('Failed to add dependencies to pom.xml');
        }
    }

    private async addGradleDependencies(buildPath: string, missingDeps: string[], system: BuildSystem): Promise<void> {
        try {
            let buildContent = await FileUtils.readFile(buildPath);
            
            let dependenciesBlock = '';
            const isKotlinDsl = system === BuildSystem.GRADLE_KOTLIN;
            
            if (isKotlinDsl) {
                dependenciesBlock = missingDeps.map(dep => `    testImplementation("${dep}")`).join('\n');
            } else {
                dependenciesBlock = missingDeps.map(dep => `    testImplementation '${dep}'`).join('\n');
            }

            const depBlockRegex = /dependencies\s*\{[^}]*\}/s;
            if (depBlockRegex.test(buildContent)) {
                buildContent = buildContent.replace(depBlockRegex, (match) => {
                    const lastBrace = match.lastIndexOf('}');
                    return match.slice(0, lastBrace) + '\n' + dependenciesBlock + '\n' + match.slice(lastBrace);
                });
            } else {
                buildContent += `\n\ndependencies {\n${dependenciesBlock}\n}\n`;
            }

            await FileUtils.writeFile(buildPath, buildContent);
            
            this.outputChannel.appendLine(`Added ${missingDeps.length} dependencies to ${path.basename(buildPath)}`);
            vscode.window.showInformationMessage(`Added ${missingDeps.length} dependencies to ${path.basename(buildPath)}`);
        } catch (error) {
            this.outputChannel.appendLine(`Error adding Gradle dependencies: ${error}`);
            vscode.window.showErrorMessage('Failed to add dependencies to build file');
        }
    }

    async runTests(testClass?: string, testMethod?: string): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }

        let command = config.testCommand;
        
        if (config.system === BuildSystem.MAVEN) {
            if (testClass) {
                command += ` -Dtest=${testClass}`;
                if (testMethod) {
                    command += `#${testMethod}`;
                }
            }
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            if (testClass) {
                command += ` --tests ${testClass}`;
                if (testMethod) {
                    command += `.${testMethod}`;
                }
            }
        }

        const terminal = vscode.window.createTerminal('DOM Generator Tests');
        terminal.show();
        terminal.sendText(command);
        
        this.outputChannel.appendLine(`Running tests: ${command}`);
    }

    async getTestConfigPath(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return path.join(this.workspaceRoot, 'config');
        }

        if (config.system === BuildSystem.MAVEN) {
            return path.join(this.workspaceRoot, config.resourcePath);
        } else {
            const resourcePath = path.join(this.workspaceRoot, config.resourcePath);
            const configPath = path.join(this.workspaceRoot, 'config');
            
            if (await FileUtils.exists(configPath)) {
                return configPath;
            }
            return resourcePath;
        }
    }

    async getJavaSourcePath(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return path.join(this.workspaceRoot, 'src/test/java');
        }
        return path.join(this.workspaceRoot, config.testSourcePath);
    }

    async cleanBuild(): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return;
        }

        let command = '';
        if (config.system === BuildSystem.MAVEN) {
            command = 'mvn clean';
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            command = await FileUtils.exists(gradlewPath) ? './gradlew clean' : 'gradle clean';
        }

        if (command) {
            const terminal = vscode.window.createTerminal('Clean Build');
            terminal.show();
            terminal.sendText(command);
            this.outputChannel.appendLine(`Cleaning build: ${command}`);
        }
    }

    createBuildFileWatcher(): vscode.FileSystemWatcher {
        const pattern = new vscode.RelativePattern(this.workspaceRoot, '**/+(pom.xml|build.gradle|build.gradle.kts)');
        const watcher = vscode.workspace.createFileSystemWatcher(pattern);
        
        watcher.onDidChange(async (uri) => {
            this.outputChannel.appendLine(`Build file changed: ${uri.fsPath}`);
            const response = await vscode.window.showInformationMessage(
                'Build file changed. Re-check dependencies?',
                'Yes', 'No'
            );
            
            if (response === 'Yes') {
                const config = await this.detectBuildSystem();
                if (config) {
                    if (config.system === BuildSystem.MAVEN) {
                        await this.checkMavenDependencies(config.buildFile, config);
                    } else {
                        await this.checkGradleDependencies(config.buildFile, config, config.system);
                    }
                }
            }
        });
        
        return watcher;
    }

    async getBuildSystemInfo(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return 'No Build System';
        }
        return `$(tools) ${config.system}`;
    }

    async generateTestNGConfig(outputPath?: string): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }

        const configPath = outputPath || await this.getTestConfigPath();
        await FileUtils.ensureDir(configPath);

        const testXmlPath = path.join(configPath, 'test.xml');
        
        const testXmlContent = `<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd">
<suite name="DOM Generator Test Suite" verbose="1">
    <!-- DOM Generator Configuration -->
    <parameter name="dom.generator.driver.strategy" value="REFLECTION_FIELD"/>
    
    <listeners>
        <listener class-name="com.wellsfargo.automation.appid.listeners.DOMCaptureListener"/>
    </listeners>
    
    <test name="Selenium Tests">
        <packages>
            <package name="com.wellsfargo.automation.appid.tests.*"/>
        </packages>
    </test>
</suite>`;

        await FileUtils.writeFile(testXmlPath, testXmlContent);
        this.outputChannel.appendLine(`Generated TestNG configuration: ${testXmlPath}`);
        vscode.window.showInformationMessage('TestNG configuration generated successfully');
    }

    async compileBuild(): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }

        let command = '';
        if (config.system === BuildSystem.MAVEN) {
            command = 'mvn compile test-compile';
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            command = await FileUtils.exists(gradlewPath) ? './gradlew compileJava compileTestJava' : 'gradle compileJava compileTestJava';
        }

        if (command) {
            const terminal = vscode.window.createTerminal('Compile Build');
            terminal.show();
            terminal.sendText(command);
            this.outputChannel.appendLine(`Compiling project: ${command}`);
        }
    }

    async hasTestFramework(): Promise<boolean> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return false;
        }

        if (config.system === BuildSystem.MAVEN) {
            const pomContent = await FileUtils.readFile(config.buildFile);
            return pomContent.includes('testng') || pomContent.includes('junit');
        } else {
            const buildContent = await FileUtils.readFile(config.buildFile);
            return buildContent.includes('testng') || buildContent.includes('junit');
        }
    }

    async getBuildOutputPath(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return path.join(this.workspaceRoot, 'target');
        }
        return path.join(this.workspaceRoot, config.outputPath);
    }

    async installBuildWrapper(): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return;
        }

        if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            
            if (!await FileUtils.exists(gradlewPath)) {
                const install = await vscode.window.showInformationMessage(
                    'Gradle wrapper not found. Install it?',
                    'Yes', 'No'
                );
                
                if (install === 'Yes') {
                    const terminal = vscode.window.createTerminal('Install Gradle Wrapper');
                    terminal.show();
                    terminal.sendText('gradle wrapper');
                    this.outputChannel.appendLine('Installing Gradle wrapper...');
                }
            }
        }
    }

    async getProjectModules(): Promise<string[]> {
        const modules: string[] = [];
        const config = await this.detectBuildSystem();
        
        if (!config) {
            return modules;
        }

        if (config.system === BuildSystem.MAVEN) {
            try {
                const pomContent = await FileUtils.readFile(config.buildFile);
                const parser = new xml2js.Parser();
                const result = await parser.parseStringPromise(pomContent);
                
                if (result.project?.modules?.[0]?.module) {
                    for (const module of result.project.modules[0].module) {
                        modules.push(module);
                    }
                }
            } catch (error) {
                this.outputChannel.appendLine(`Error parsing Maven modules: ${error}`);
            }
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const settingsFile = config.system === BuildSystem.GRADLE_KOTLIN 
                ? 'settings.gradle.kts' 
                : 'settings.gradle';
            const settingsPath = path.join(this.workspaceRoot, settingsFile);
            
            if (await FileUtils.exists(settingsPath)) {
                try {
                    const content = await FileUtils.readFile(settingsPath);
                    const includePattern = /include\s*\(?\s*['"]([^'"]+)['"]/g;
                    let match;
                    
                    while ((match = includePattern.exec(content)) !== null) {
                        modules.push(match[1]);
                    }
                } catch (error) {
                    this.outputChannel.appendLine(`Error parsing Gradle modules: ${error}`);
                }
            }
        }

        return modules;
    }

    async getProjectPackaging(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config || config.system !== BuildSystem.MAVEN) {
            return 'jar';
        }

        try {
            const pomContent = await FileUtils.readFile(config.buildFile);
            const parser = new xml2js.Parser();
            const result = await parser.parseStringPromise(pomContent);
            
            return result.project?.packaging?.[0] || 'jar';
        } catch (error) {
            this.outputChannel.appendLine(`Error getting project packaging: ${error}`);
            return 'jar';
        }
    }

    async getTestReportsPath(): Promise<string> {
        const config = await this.detectBuildSystem();
        if (!config) {
            return path.join(this.workspaceRoot, 'target/surefire-reports');
        }

        if (config.system === BuildSystem.MAVEN) {
            return path.join(this.workspaceRoot, 'target/surefire-reports');
        } else {
            return path.join(this.workspaceRoot, 'build/reports/tests');
        }
    }

    async runTestSuite(suiteXmlPath: string): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }

        let command = '';
        
        if (config.system === BuildSystem.MAVEN) {
            command = `mvn test -DsuiteXmlFile=${suiteXmlPath}`;
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            command = await FileUtils.exists(gradlewPath) 
                ? `./gradlew test -PtestSuite=${suiteXmlPath}`
                : `gradle test -PtestSuite=${suiteXmlPath}`;
        }

        if (command) {
            const terminal = vscode.window.createTerminal('DOM Generator Test Suite');
            terminal.show();
            terminal.sendText(command);
            this.outputChannel.appendLine(`Running test suite: ${command}`);
        }
    }

    async getProjectProperties(): Promise<Map<string, string>> {
        const properties = new Map<string, string>();
        const config = await this.detectBuildSystem();
        
        if (!config) {
            return properties;
        }

        if (config.system === BuildSystem.MAVEN) {
            try {
                const pomContent = await FileUtils.readFile(config.buildFile);
                const parser = new xml2js.Parser();
                const result = await parser.parseStringPromise(pomContent);
                
                if (result.project) {
                    properties.set('name', result.project.name?.[0] || result.project.artifactId?.[0] || 'Unknown');
                    properties.set('version', result.project.version?.[0] || '1.0.0');
                    properties.set('groupId', result.project.groupId?.[0] || '');
                    properties.set('artifactId', result.project.artifactId?.[0] || '');
                }
            } catch (error) {
                this.outputChannel.appendLine(`Error getting Maven properties: ${error}`);
            }
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            try {
                const buildContent = await FileUtils.readFile(config.buildFile);
                
                const versionMatch = buildContent.match(/version\s*=?\s*['"]([^'"]+)['"]/);
                if (versionMatch) {
                    properties.set('version', versionMatch[1]);
                }
                
                const groupMatch = buildContent.match(/group\s*=?\s*['"]([^'"]+)['"]/);
                if (groupMatch) {
                    properties.set('group', groupMatch[1]);
                }
                
                const settingsFile = config.system === BuildSystem.GRADLE_KOTLIN 
                    ? 'settings.gradle.kts' 
                    : 'settings.gradle';
                const settingsPath = path.join(this.workspaceRoot, settingsFile);
                
                if (await FileUtils.exists(settingsPath)) {
                    const settingsContent = await FileUtils.readFile(settingsPath);
                    const nameMatch = settingsContent.match(/rootProject\.name\s*=\s*['"]([^'"]+)['"]/);
                    if (nameMatch) {
                        properties.set('name', nameMatch[1]);
                    }
                }
            } catch (error) {
                this.outputChannel.appendLine(`Error getting Gradle properties: ${error}`);
            }
        }

        return properties;
    }

    async getTestClasses(): Promise<string[]> {
        const testClasses: string[] = [];
        const javaSourcePath = await this.getJavaSourcePath();
        
        const pattern = path.join(javaSourcePath, '**/*Test.java');
        const testFiles = await glob(pattern, { 
            cwd: this.workspaceRoot,
            ignore: ['**/node_modules/**', '**/target/**', '**/build/**']
        });
        
        for (const file of testFiles) {
            const content = await FileUtils.readFile(path.join(this.workspaceRoot, file));
            const packageMatch = content.match(/package\s+([\w.]+);/);
            const classMatch = content.match(/public\s+class\s+(\w+)/);
            
            if (packageMatch && classMatch) {
                testClasses.push(`${packageMatch[1]}.${classMatch[1]}`);
            }
        }
        
        return testClasses;
    }

    async runCoverage(): Promise<void> {
        const config = await this.detectBuildSystem();
        if (!config) {
            vscode.window.showErrorMessage('No build system detected');
            return;
        }

        let command = '';
        
        if (config.system === BuildSystem.MAVEN) {
            const pomContent = await FileUtils.readFile(config.buildFile);
            if (!pomContent.includes('jacoco-maven-plugin')) {
                const add = await vscode.window.showInformationMessage(
                    'JaCoCo plugin not found. Add it for coverage analysis?',
                    'Yes', 'No'
                );
                
                if (add === 'Yes') {
                    await this.addMavenJaCoCoPlugin(config.buildFile);
                }
            }
            command = 'mvn clean test jacoco:report';
        } else if (config.system === BuildSystem.GRADLE || config.system === BuildSystem.GRADLE_KOTLIN) {
            const buildContent = await FileUtils.readFile(config.buildFile);
            if (!buildContent.includes('jacoco')) {
                const add = await vscode.window.showInformationMessage(
                    'JaCoCo plugin not found. Add it for coverage analysis?',
                    'Yes', 'No'
                );
                
                if (add === 'Yes') {
                    await this.addGradleJaCoCoPlugin(config.buildFile, config.system);
                }
            }
            
            const gradlewPath = path.join(this.workspaceRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            command = await FileUtils.exists(gradlewPath) 
                ? './gradlew test jacocoTestReport' 
                : 'gradle test jacocoTestReport';
        }

        if (command) {
            const terminal = vscode.window.createTerminal('Coverage Analysis');
            terminal.show();
            terminal.sendText(command);
            this.outputChannel.appendLine(`Running coverage analysis: ${command}`);
        }
    }

    private async addMavenJaCoCoPlugin(pomPath: string): Promise<void> {
        try {
            const pomContent = await FileUtils.readFile(pomPath);
            const parser = new xml2js.Parser();
            const builder = new xml2js.Builder({ 
                xmldec: { version: '1.0', encoding: 'UTF-8' },
                renderOpts: { pretty: true, indent: '    ' }
            });
            
            const result = await parser.parseStringPromise(pomContent);
            
            if (!result.project.build) {
                result.project.build = [{ plugins: [{ plugin: [] }] }];
            }
            if (!result.project.build[0].plugins) {
                result.project.build[0].plugins = [{ plugin: [] }];
            }
            if (!result.project.build[0].plugins[0].plugin) {
                result.project.build[0].plugins[0].plugin = [];
            }

            const jacocoPlugin = {
                groupId: ['org.jacoco'],
                artifactId: ['jacoco-maven-plugin'],
                version: ['0.8.10'],
                executions: [{
                    execution: [
                        {
                            goals: [{ goal: ['prepare-agent'] }],
                            id: ['default-prepare-agent']
                        },
                        {
                            goals: [{ goal: ['report'] }],
                            id: ['default-report'],
                            phase: ['test']
                        }
                    ]
                }]
            };

            result.project.build[0].plugins[0].plugin.push(jacocoPlugin);

            const xml = builder.buildObject(result);
            await FileUtils.writeFile(pomPath, xml);
            
            this.outputChannel.appendLine('Added JaCoCo plugin to pom.xml');
            vscode.window.showInformationMessage('JaCoCo coverage plugin added successfully');
        } catch (error) {
            this.outputChannel.appendLine(`Error adding JaCoCo plugin: ${error}`);
        }
    }

    private async addGradleJaCoCoPlugin(buildPath: string, system: BuildSystem): Promise<void> {
        try {
            let buildContent = await FileUtils.readFile(buildPath);
            const isKotlinDsl = system === BuildSystem.GRADLE_KOTLIN;
            
            let pluginLine = '';
            let configBlock = '';
            
            if (isKotlinDsl) {
                pluginLine = "    id(\"jacoco\")";
                configBlock = `
jacoco {
    toolVersion = "0.8.10"
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}`;
            } else {
                pluginLine = "    id 'jacoco'";
                configBlock = `
jacoco {
    toolVersion = '0.8.10'
}

jacocoTestReport {
    reports {
        xml.required = true
        html.required = true
    }
}`;
            }

            const pluginsMatch = buildContent.match(/plugins\s*\{([^}]*)\}/);
            if (pluginsMatch) {
                const updatedPlugins = pluginsMatch[0].replace('}', `${pluginLine}\n}`);
                buildContent = buildContent.replace(pluginsMatch[0], updatedPlugins);
            }

            buildContent += '\n' + configBlock + '\n';
            
            await FileUtils.writeFile(buildPath, buildContent);
            
            this.outputChannel.appendLine('Added JaCoCo plugin to build file');
            vscode.window.showInformationMessage('JaCoCo coverage plugin added successfully');
        } catch (error) {
            this.outputChannel.appendLine(`Error adding JaCoCo plugin: ${error}`);
        }
    }

    dispose(): void {
        this.outputChannel.dispose();
    }
}