/**
 * WebDriver Strategy Validator for Cross-Framework Support
 * Validates and manages WebDriver strategies across different testing frameworks
 */

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { TestFramework } from '../adapters/FrameworkDetector';

/**
 * WebDriver Strategy Validator
 */
export class WebDriverStrategyValidator {
    private strategies: Map<string, WebDriverStrategy> = new Map();
    private frameworkStrategies: Map<TestFramework, string[]> = new Map();
    private validationCache: Map<string, ValidationResult> = new Map();

    constructor() {
        this.initializeStrategies();
        this.mapFrameworkStrategies();
    }

    /**
     * Initialize all WebDriver strategies
     */
    private initializeStrategies(): void {
        // Reflection Field Strategy
        this.strategies.set('REFLECTION_FIELD', {
            name: 'REFLECTION_FIELD',
            description: 'Access WebDriver through reflection on class field',
            frameworks: ['selenium_testng', 'selenium_junit'],
            requirements: {
                annotations: ['@Test', '@BeforeClass'],
                imports: ['java.lang.reflect.Field'],
                fieldTypes: ['WebDriver', 'RemoteWebDriver', 'ChromeDriver', 'FirefoxDriver']
            },
            implementation: this.getReflectionFieldImplementation(),
            validation: this.validateReflectionField.bind(this),
            priority: 1
        });

        // Test Context Strategy
        this.strategies.set('TEST_CONTEXT', {
            name: 'TEST_CONTEXT',
            description: 'Get WebDriver from TestNG ITestContext',
            frameworks: ['selenium_testng'],
            requirements: {
                annotations: ['@Test'],
                imports: ['org.testng.ITestContext'],
                contextMethods: ['getAttribute', 'getSuite']
            },
            implementation: this.getTestContextImplementation(),
            validation: this.validateTestContext.bind(this),
            priority: 2
        });

        // Thread Local Strategy
        this.strategies.set('THREAD_LOCAL', {
            name: 'THREAD_LOCAL',
            description: 'Access WebDriver from ThreadLocal storage',
            frameworks: ['selenium_testng', 'selenium_junit', 'cucumber'],
            requirements: {
                annotations: [],
                imports: ['java.lang.ThreadLocal'],
                staticFields: ['ThreadLocal<WebDriver>']
            },
            implementation: this.getThreadLocalImplementation(),
            validation: this.validateThreadLocal.bind(this),
            priority: 3
        });

        // Getter Method Strategy
        this.strategies.set('GETTER_METHOD', {
            name: 'GETTER_METHOD',
            description: 'Call getter method to obtain WebDriver',
            frameworks: ['selenium_testng', 'selenium_junit'],
            requirements: {
                annotations: [],
                imports: [],
                methods: ['getDriver', 'getWebDriver', 'driver']
            },
            implementation: this.getGetterMethodImplementation(),
            validation: this.validateGetterMethod.bind(this),
            priority: 4
        });

        // Suite Attribute Strategy
        this.strategies.set('SUITE_ATTRIBUTE', {
            name: 'SUITE_ATTRIBUTE',
            description: 'Get WebDriver from TestNG Suite attributes',
            frameworks: ['selenium_testng'],
            requirements: {
                annotations: ['@Test'],
                imports: ['org.testng.ISuite'],
                suiteAttributes: ['driver', 'webdriver']
            },
            implementation: this.getSuiteAttributeImplementation(),
            validation: this.validateSuiteAttribute.bind(this),
            priority: 5
        });

        // Custom Provider Strategy
        this.strategies.set('CUSTOM_PROVIDER', {
            name: 'CUSTOM_PROVIDER',
            description: 'Use custom WebDriver provider interface',
            frameworks: ['selenium_testng', 'selenium_junit', 'cucumber', 'playwright'],
            requirements: {
                annotations: [],
                imports: [],
                interfaces: ['WebDriverProvider', 'DriverFactory']
            },
            implementation: this.getCustomProviderImplementation(),
            validation: this.validateCustomProvider.bind(this),
            priority: 6
        });

        // Playwright Strategy
        this.strategies.set('PLAYWRIGHT_PAGE', {
            name: 'PLAYWRIGHT_PAGE',
            description: 'Access Playwright Page object',
            frameworks: ['playwright'],
            requirements: {
                annotations: ['@test'],
                imports: ['@playwright/test', 'playwright'],
                fieldTypes: ['Page', 'Browser', 'BrowserContext']
            },
            implementation: this.getPlaywrightImplementation(),
            validation: this.validatePlaywright.bind(this),
            priority: 1
        });

        // Cypress Strategy
        this.strategies.set('CYPRESS_CY', {
            name: 'CYPRESS_CY',
            description: 'Access Cypress cy object',
            frameworks: ['cypress'],
            requirements: {
                annotations: [],
                imports: [],
                globalObjects: ['cy', 'Cypress']
            },
            implementation: this.getCypressImplementation(),
            validation: this.validateCypress.bind(this),
            priority: 1
        });

        // WebdriverIO Strategy
        this.strategies.set('WDIO_BROWSER', {
            name: 'WDIO_BROWSER',
            description: 'Access WebdriverIO browser object',
            frameworks: ['webdriverio'],
            requirements: {
                annotations: [],
                imports: ['@wdio/globals', 'webdriverio'],
                globalObjects: ['browser', '$', '$$']
            },
            implementation: this.getWebdriverIOImplementation(),
            validation: this.validateWebdriverIO.bind(this),
            priority: 1
        });

        // Puppeteer Strategy
        this.strategies.set('PUPPETEER_PAGE', {
            name: 'PUPPETEER_PAGE',
            description: 'Access Puppeteer Page object',
            frameworks: ['puppeteer'],
            requirements: {
                annotations: [],
                imports: ['puppeteer'],
                fieldTypes: ['Page', 'Browser']
            },
            implementation: this.getPuppeteerImplementation(),
            validation: this.validatePuppeteer.bind(this),
            priority: 1
        });
    }

    /**
     * Map frameworks to their supported strategies
     */
    private mapFrameworkStrategies(): void {
        this.frameworkStrategies.set(TestFramework.SELENIUM_TESTNG, [
            'REFLECTION_FIELD',
            'TEST_CONTEXT',
            'THREAD_LOCAL',
            'GETTER_METHOD',
            'SUITE_ATTRIBUTE',
            'CUSTOM_PROVIDER'
        ]);

        this.frameworkStrategies.set(TestFramework.SELENIUM_JUNIT, [
            'REFLECTION_FIELD',
            'THREAD_LOCAL',
            'GETTER_METHOD',
            'CUSTOM_PROVIDER'
        ]);

        this.frameworkStrategies.set(TestFramework.PLAYWRIGHT, [
            'PLAYWRIGHT_PAGE'
        ]);

        this.frameworkStrategies.set(TestFramework.CYPRESS, [
            'CYPRESS_CY'
        ]);

        this.frameworkStrategies.set(TestFramework.WEBDRIVERIO, [
            'WDIO_BROWSER'
        ]);

        this.frameworkStrategies.set(TestFramework.PUPPETEER, [
            'PUPPETEER_PAGE'
        ]);

        this.frameworkStrategies.set(TestFramework.PROTRACTOR, [
            'PROTRACTOR_BROWSER'
        ]);

        this.frameworkStrategies.set(TestFramework.JEST_TESTING_LIBRARY, [
            'JEST_DOM'
        ]);
    }

    /**
     * Validate WebDriver strategy for a specific framework and code context
     */
    async validateStrategy(
        framework: TestFramework,
        codeContext: CodeContext,
        strategyName?: string
    ): Promise<ValidationResult> {
        const cacheKey = `${framework}-${strategyName || 'auto'}-${JSON.stringify(codeContext)}`;
        
        if (this.validationCache.has(cacheKey)) {
            return this.validationCache.get(cacheKey)!;
        }

        const result: ValidationResult = {
            valid: false,
            recommendedStrategy: null,
            availableStrategies: [],
            issues: [],
            suggestions: []
        };

        // Get strategies for framework
        const frameworkStrategies = this.frameworkStrategies.get(framework);
        if (!frameworkStrategies) {
            result.issues.push(`Framework ${framework} not supported`);
            this.validationCache.set(cacheKey, result);
            return result;
        }

        // If specific strategy requested, validate it
        if (strategyName) {
            const strategy = this.strategies.get(strategyName);
            if (!strategy) {
                result.issues.push(`Strategy ${strategyName} not found`);
            } else if (!frameworkStrategies.includes(strategyName)) {
                result.issues.push(`Strategy ${strategyName} not supported for ${framework}`);
            } else {
                const strategyValid = await strategy.validation(codeContext);
                if (strategyValid) {
                    result.valid = true;
                    result.recommendedStrategy = strategyName;
                    result.availableStrategies.push(strategyName);
                } else {
                    result.issues.push(`Strategy ${strategyName} validation failed for current context`);
                }
            }
        } else {
            // Auto-detect best strategy
            const validStrategies: Array<{name: string; priority: number}> = [];

            for (const strategyName of frameworkStrategies) {
                const strategy = this.strategies.get(strategyName);
                if (strategy) {
                    const isValid = await strategy.validation(codeContext);
                    if (isValid) {
                        validStrategies.push({
                            name: strategyName,
                            priority: strategy.priority
                        });
                        result.availableStrategies.push(strategyName);
                    }
                }
            }

            if (validStrategies.length > 0) {
                // Sort by priority (lower is better)
                validStrategies.sort((a, b) => a.priority - b.priority);
                result.valid = true;
                result.recommendedStrategy = validStrategies[0].name;
            } else {
                result.issues.push('No valid WebDriver strategy found for current context');
                result.suggestions.push('Ensure WebDriver is properly initialized in your test class');
            }
        }

        // Add suggestions based on issues
        if (!result.valid) {
            result.suggestions.push(...this.generateSuggestions(framework, codeContext));
        }

        this.validationCache.set(cacheKey, result);
        return result;
    }

    /**
     * Generate implementation code for a strategy
     */
    getImplementation(strategyName: string, framework: TestFramework): string {
        const strategy = this.strategies.get(strategyName);
        if (!strategy) {
            throw new Error(`Strategy ${strategyName} not found`);
        }

        if (!strategy.frameworks.includes(framework as any)) {
            throw new Error(`Strategy ${strategyName} not supported for ${framework}`);
        }

        return strategy.implementation;
    }

    /**
     * Validate all strategies for a framework
     */
    async validateAllStrategies(
        framework: TestFramework,
        codeContext: CodeContext
    ): Promise<Map<string, boolean>> {
        const results = new Map<string, boolean>();
        const strategies = this.frameworkStrategies.get(framework) || [];

        for (const strategyName of strategies) {
            const strategy = this.strategies.get(strategyName);
            if (strategy) {
                const isValid = await strategy.validation(codeContext);
                results.set(strategyName, isValid);
            }
        }

        return results;
    }

    /**
     * Get strategy requirements
     */
    getStrategyRequirements(strategyName: string): StrategyRequirements | null {
        const strategy = this.strategies.get(strategyName);
        return strategy ? strategy.requirements : null;
    }

    /**
     * Validation methods for each strategy
     */
    private async validateReflectionField(context: CodeContext): Promise<boolean> {
        return context.fields.some(field => 
            field.type.includes('WebDriver') || 
            field.type.includes('Driver')
        );
    }

    private async validateTestContext(context: CodeContext): Promise<boolean> {
        return context.imports.some(imp => imp.includes('ITestContext')) &&
               context.methods.some(m => m.parameters.includes('ITestContext'));
    }

    private async validateThreadLocal(context: CodeContext): Promise<boolean> {
        return context.fields.some(field => 
            field.type.includes('ThreadLocal') && 
            field.type.includes('WebDriver')
        );
    }

    private async validateGetterMethod(context: CodeContext): Promise<boolean> {
        return context.methods.some(method => 
            (method.name === 'getDriver' || 
             method.name === 'getWebDriver' || 
             method.name === 'driver') &&
            method.returnType.includes('WebDriver')
        );
    }

    private async validateSuiteAttribute(context: CodeContext): Promise<boolean> {
        return context.imports.some(imp => imp.includes('ISuite'));
    }

    private async validateCustomProvider(context: CodeContext): Promise<boolean> {
        return context.interfaces.some(intf => 
            intf.includes('Provider') || 
            intf.includes('Factory')
        );
    }

    private async validatePlaywright(context: CodeContext): Promise<boolean> {
        return context.imports.some(imp => imp.includes('playwright'));
    }

    private async validateCypress(context: CodeContext): Promise<boolean> {
        // Cypress is global, check file extension
        return context.filePath.includes('.cy.') || 
               context.filePath.includes('.spec.');
    }

    private async validateWebdriverIO(context: CodeContext): Promise<boolean> {
        return context.imports.some(imp => imp.includes('wdio'));
    }

    private async validatePuppeteer(context: CodeContext): Promise<boolean> {
        return context.imports.some(imp => imp.includes('puppeteer'));
    }

    /**
     * Implementation generators
     */
    private getReflectionFieldImplementation(): string {
        return `
private WebDriver getWebDriverByReflection() throws Exception {
    Field[] fields = this.getClass().getDeclaredFields();
    for (Field field : fields) {
        if (WebDriver.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);
            return (WebDriver) field.get(this);
        }
    }
    throw new RuntimeException("No WebDriver field found");
}`;
    }

    private getTestContextImplementation(): string {
        return `
private WebDriver getWebDriverFromContext(ITestContext context) {
    return (WebDriver) context.getAttribute("driver");
}`;
    }

    private getThreadLocalImplementation(): string {
        return `
private static ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

public static WebDriver getDriver() {
    return driverThreadLocal.get();
}

public static void setDriver(WebDriver driver) {
    driverThreadLocal.set(driver);
}`;
    }

    private getGetterMethodImplementation(): string {
        return `
protected WebDriver getDriver() {
    if (driver == null) {
        throw new IllegalStateException("WebDriver not initialized");
    }
    return driver;
}`;
    }

    private getSuiteAttributeImplementation(): string {
        return `
private WebDriver getWebDriverFromSuite(ISuite suite) {
    return (WebDriver) suite.getAttribute("driver");
}`;
    }

    private getCustomProviderImplementation(): string {
        return `
public interface WebDriverProvider {
    WebDriver getWebDriver();
}

private WebDriver getWebDriverFromProvider(WebDriverProvider provider) {
    return provider.getWebDriver();
}`;
    }

    private getPlaywrightImplementation(): string {
        return `
import { Page } from '@playwright/test';

export function getPage(page: Page): Page {
    return page;
}`;
    }

    private getCypressImplementation(): string {
        return `
// Cypress cy object is globally available
cy.window().then((win) => {
    // Access window for DOM operations
    return win;
});`;
    }

    private getWebdriverIOImplementation(): string {
        return `
import { browser } from '@wdio/globals';

export async function getBrowser() {
    return browser;
}`;
    }

    private getPuppeteerImplementation(): string {
        return `
import { Page } from 'puppeteer';

export function getPage(page: Page): Page {
    return page;
}`;
    }

    /**
     * Generate suggestions based on issues
     */
    private generateSuggestions(framework: TestFramework, context: CodeContext): string[] {
        const suggestions: string[] = [];

        if (!context.fields.some(f => f.type.includes('Driver'))) {
            suggestions.push('Add a WebDriver field to your test class');
        }

        if (framework === TestFramework.SELENIUM_TESTNG) {
            if (!context.imports.some(i => i.includes('testng'))) {
                suggestions.push('Import TestNG annotations and classes');
            }
            suggestions.push('Consider using @BeforeClass to initialize WebDriver');
        }

        if (framework === TestFramework.SELENIUM_JUNIT) {
            if (!context.imports.some(i => i.includes('junit'))) {
                suggestions.push('Import JUnit annotations and classes');
            }
            suggestions.push('Consider using @Before or @BeforeClass to initialize WebDriver');
        }

        return suggestions;
    }

    /**
     * Export validation report
     */
    async exportValidationReport(
        framework: TestFramework,
        context: CodeContext,
        outputPath: string
    ): Promise<void> {
        const allStrategies = await this.validateAllStrategies(framework, context);
        const validation = await this.validateStrategy(framework, context);

        const report = {
            timestamp: new Date().toISOString(),
            framework,
            context: {
                filePath: context.filePath,
                className: context.className,
                hasWebDriver: context.fields.some(f => f.type.includes('Driver'))
            },
            validation,
            allStrategies: Array.from(allStrategies.entries()).map(([name, valid]) => ({
                name,
                valid,
                strategy: this.strategies.get(name)
            }))
        };

        await fs.promises.writeFile(
            outputPath,
            JSON.stringify(report, null, 2),
            'utf-8'
        );
    }
}

// Interfaces
interface WebDriverStrategy {
    name: string;
    description: string;
    frameworks: string[];
    requirements: StrategyRequirements;
    implementation: string;
    validation: (context: CodeContext) => Promise<boolean>;
    priority: number;
}

interface StrategyRequirements {
    annotations: string[];
    imports: string[];
    fieldTypes?: string[];
    methods?: string[];
    contextMethods?: string[];
    staticFields?: string[];
    suiteAttributes?: string[];
    interfaces?: string[];
    globalObjects?: string[];
}

interface CodeContext {
    filePath: string;
    className: string;
    imports: string[];
    annotations: string[];
    fields: Array<{ name: string; type: string; modifiers: string[] }>;
    methods: Array<{ name: string; returnType: string; parameters: string }>;
    interfaces: string[];
    parentClass?: string;
}

interface ValidationResult {
    valid: boolean;
    recommendedStrategy: string | null;
    availableStrategies: string[];
    issues: string[];
    suggestions: string[];
}

export default WebDriverStrategyValidator;
export type {
    WebDriverStrategy,
    CodeContext,
    ValidationResult,
    StrategyRequirements
};