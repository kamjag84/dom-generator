/**
 * Unified WebDriver Manager for Cross-Framework Support
 * Provides a unified interface for WebDriver operations across all testing frameworks
 */

import * as vscode from 'vscode';
import * as path from 'path';
import { TestFramework } from '../adapters/FrameworkDetector';
import FrameworkDetector from '../adapters/FrameworkDetector';
import WebDriverStrategyValidator from './WebDriverStrategyValidator';
import type { CodeContext } from './WebDriverStrategyValidator';
import { DOMSnapshot } from '../capture/AdvancedDOMCapture';

/**
 * Unified WebDriver Manager
 */
export class UnifiedWebDriverManager {
    private strategyValidator: WebDriverStrategyValidator;
    private frameworkDetector: FrameworkDetector;
    private driverConfigs: Map<string, DriverConfiguration> = new Map();
    private activeSessions: Map<string, DriverSession> = new Map();
    private sessionPool: DriverSessionPool;

    constructor(workspace: string) {
        this.strategyValidator = new WebDriverStrategyValidator();
        this.frameworkDetector = new FrameworkDetector(workspace);
        this.sessionPool = new DriverSessionPool();
        this.initializeConfigurations();
    }

    /**
     * Initialize driver configurations for all frameworks
     */
    private initializeConfigurations(): void {
        // Selenium WebDriver configurations
        this.driverConfigs.set('selenium-chrome', {
            framework: TestFramework.SELENIUM_TESTNG,
            browserType: 'chrome',
            version: '4.15.0',
            capabilities: {
                browserName: 'chrome',
                'goog:chromeOptions': {
                    args: ['--disable-gpu', '--no-sandbox', '--disable-dev-shm-usage'],
                    prefs: {
                        'download.default_directory': '/tmp/downloads'
                    }
                }
            },
            initCode: this.getSeleniumChromeInit(),
            captureCode: this.getSeleniumCaptureCode()
        });

        this.driverConfigs.set('selenium-firefox', {
            framework: TestFramework.SELENIUM_TESTNG,
            browserType: 'firefox',
            version: '4.15.0',
            capabilities: {
                browserName: 'firefox',
                'moz:firefoxOptions': {
                    args: ['--headless'],
                    prefs: {
                        'browser.download.dir': '/tmp/downloads'
                    }
                }
            },
            initCode: this.getSeleniumFirefoxInit(),
            captureCode: this.getSeleniumCaptureCode()
        });

        this.driverConfigs.set('selenium-edge', {
            framework: TestFramework.SELENIUM_TESTNG,
            browserType: 'edge',
            version: '4.15.0',
            capabilities: {
                browserName: 'MicrosoftEdge',
                'ms:edgeOptions': {
                    args: ['--headless', '--disable-gpu']
                }
            },
            initCode: this.getSeleniumEdgeInit(),
            captureCode: this.getSeleniumCaptureCode()
        });

        this.driverConfigs.set('selenium-safari', {
            framework: TestFramework.SELENIUM_TESTNG,
            browserType: 'safari',
            version: '4.15.0',
            capabilities: {
                browserName: 'safari',
                'safari.options': {
                    technologyPreview: false
                }
            },
            initCode: this.getSeleniumSafariInit(),
            captureCode: this.getSeleniumCaptureCode()
        });

        // Playwright configurations
        this.driverConfigs.set('playwright-chromium', {
            framework: TestFramework.PLAYWRIGHT,
            browserType: 'chromium',
            version: '1.40.0',
            capabilities: {
                headless: false,
                slowMo: 0,
                devtools: true
            },
            initCode: this.getPlaywrightChromiumInit(),
            captureCode: this.getPlaywrightCaptureCode()
        });

        this.driverConfigs.set('playwright-firefox', {
            framework: TestFramework.PLAYWRIGHT,
            browserType: 'firefox',
            version: '1.40.0',
            capabilities: {
                headless: false,
                firefoxUserPrefs: {}
            },
            initCode: this.getPlaywrightFirefoxInit(),
            captureCode: this.getPlaywrightCaptureCode()
        });

        this.driverConfigs.set('playwright-webkit', {
            framework: TestFramework.PLAYWRIGHT,
            browserType: 'webkit',
            version: '1.40.0',
            capabilities: {
                headless: false
            },
            initCode: this.getPlaywrightWebkitInit(),
            captureCode: this.getPlaywrightCaptureCode()
        });

        // Cypress configuration
        this.driverConfigs.set('cypress-electron', {
            framework: TestFramework.CYPRESS,
            browserType: 'electron',
            version: '13.6.0',
            capabilities: {
                browser: 'electron',
                viewportWidth: 1280,
                viewportHeight: 720
            },
            initCode: this.getCypressInit(),
            captureCode: this.getCypressCaptureCode()
        });

        // WebdriverIO configurations
        this.driverConfigs.set('wdio-chrome', {
            framework: TestFramework.WEBDRIVERIO,
            browserType: 'chrome',
            version: '8.24.0',
            capabilities: {
                browserName: 'chrome',
                'goog:chromeOptions': {
                    args: ['--headless', '--disable-gpu']
                }
            },
            initCode: this.getWebdriverIOInit(),
            captureCode: this.getWebdriverIOCaptureCode()
        });

        // Puppeteer configuration
        this.driverConfigs.set('puppeteer-chrome', {
            framework: TestFramework.PUPPETEER,
            browserType: 'chrome',
            version: '21.5.0',
            capabilities: {
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            },
            initCode: this.getPuppeteerInit(),
            captureCode: this.getPuppeteerCaptureCode()
        });
    }

    /**
     * Validate WebDriver configuration for a specific framework
     */
    async validateConfiguration(
        framework: TestFramework,
        browserType: string,
        codeContext: CodeContext
    ): Promise<ConfigurationValidation> {
        const configKey = `${framework}-${browserType}`.toLowerCase();
        const config = this.driverConfigs.get(configKey);

        const validation: ConfigurationValidation = {
            valid: false,
            config: config || null,
            issues: [],
            suggestions: [],
            requiredDependencies: []
        };

        if (!config) {
            validation.issues.push(`No configuration found for ${framework} with ${browserType}`);
            validation.suggestions.push(`Available configurations: ${Array.from(this.driverConfigs.keys()).join(', ')}`);
            return validation;
        }

        // Validate strategy
        const strategyValidation = await this.strategyValidator.validateStrategy(framework, codeContext);
        if (!strategyValidation.valid) {
            validation.issues.push(...strategyValidation.issues);
            validation.suggestions.push(...strategyValidation.suggestions);
        }

        // Check dependencies
        validation.requiredDependencies = this.getRequiredDependencies(framework, browserType);

        // Check version compatibility
        const versionCheck = await this.checkVersionCompatibility(config);
        if (!versionCheck.compatible) {
            validation.issues.push(versionCheck.issue);
            validation.suggestions.push(versionCheck.suggestion);
        }

        validation.valid = validation.issues.length === 0;
        return validation;
    }

    /**
     * Get unified WebDriver initialization code
     */
    getUnifiedInitCode(
        framework: TestFramework,
        browserType: string,
        options: DriverOptions = {}
    ): string {
        const configKey = `${framework}-${browserType}`.toLowerCase();
        const config = this.driverConfigs.get(configKey);

        if (!config) {
            throw new Error(`No configuration found for ${framework} with ${browserType}`);
        }

        // Merge options with default capabilities
        const mergedCapabilities = {
            ...config.capabilities,
            ...options.capabilities
        };

        return config.initCode.replace('${CAPABILITIES}', JSON.stringify(mergedCapabilities, null, 2));
    }

    /**
     * Get unified capture code
     */
    getUnifiedCaptureCode(framework: TestFramework): string {
        const configs = Array.from(this.driverConfigs.values())
            .filter(c => c.framework === framework);
        
        if (configs.length === 0) {
            throw new Error(`No configuration found for framework ${framework}`);
        }

        return configs[0].captureCode;
    }

    /**
     * Create a new driver session
     */
    async createSession(
        sessionId: string,
        framework: TestFramework,
        browserType: string,
        options: DriverOptions = {}
    ): Promise<DriverSession> {
        const configKey = `${framework}-${browserType}`.toLowerCase();
        const config = this.driverConfigs.get(configKey);

        if (!config) {
            throw new Error(`No configuration found for ${framework} with ${browserType}`);
        }

        const session: DriverSession = {
            id: sessionId,
            framework,
            browserType,
            config,
            status: 'initializing',
            createdAt: Date.now(),
            lastUsed: Date.now(),
            capabilities: { ...config.capabilities, ...options.capabilities }
        };

        this.activeSessions.set(sessionId, session);
        
        // Add to pool if pooling is enabled
        if (options.enablePooling) {
            await this.sessionPool.addSession(session);
        }

        session.status = 'active';
        return session;
    }

    /**
     * Get an active session
     */
    getSession(sessionId: string): DriverSession | null {
        return this.activeSessions.get(sessionId) || null;
    }

    /**
     * Close a session
     */
    async closeSession(sessionId: string): Promise<void> {
        const session = this.activeSessions.get(sessionId);
        if (session) {
            session.status = 'closing';
            await this.sessionPool.removeSession(sessionId);
            this.activeSessions.delete(sessionId);
        }
    }

    /**
     * Get all active sessions
     */
    getAllSessions(): DriverSession[] {
        return Array.from(this.activeSessions.values());
    }

    /**
     * Initialize code generators
     */
    private getSeleniumChromeInit(): string {
        return `
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

ChromeOptions options = new ChromeOptions();
options.addArguments("--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage");
WebDriver driver = new ChromeDriver(options);`;
    }

    private getSeleniumFirefoxInit(): string {
        return `
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

FirefoxOptions options = new FirefoxOptions();
options.addArguments("--headless");
WebDriver driver = new FirefoxDriver(options);`;
    }

    private getSeleniumEdgeInit(): string {
        return `
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

EdgeOptions options = new EdgeOptions();
options.addArguments("--headless", "--disable-gpu");
WebDriver driver = new EdgeDriver(options);`;
    }

    private getSeleniumSafariInit(): string {
        return `
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

SafariOptions options = new SafariOptions();
WebDriver driver = new SafariDriver(options);`;
    }

    private getSeleniumCaptureCode(): string {
        return `
// DOM Capture for Selenium
DOMCaptureHelper captureHelper = new DOMCaptureHelper(driver);
Map<String, Object> snapshot = captureHelper.captureDOM();`;
    }

    private getPlaywrightChromiumInit(): string {
        return `
import { chromium } from '@playwright/test';

const browser = await chromium.launch({
    headless: false,
    devtools: true
});
const context = await browser.newContext();
const page = await context.newPage();`;
    }

    private getPlaywrightFirefoxInit(): string {
        return `
import { firefox } from '@playwright/test';

const browser = await firefox.launch({
    headless: false
});
const context = await browser.newContext();
const page = await context.newPage();`;
    }

    private getPlaywrightWebkitInit(): string {
        return `
import { webkit } from '@playwright/test';

const browser = await webkit.launch({
    headless: false
});
const context = await browser.newContext();
const page = await context.newPage();`;
    }

    private getPlaywrightCaptureCode(): string {
        return `
// DOM Capture for Playwright
const domCapture = new PlaywrightDOMAdapter();
const snapshot = await domCapture.captureDOM(page);`;
    }

    private getCypressInit(): string {
        return `
// Cypress initialization happens automatically
// Configure in cypress.config.js
module.exports = {
    e2e: {
        viewportWidth: 1280,
        viewportHeight: 720
    }
};`;
    }

    private getCypressCaptureCode(): string {
        return `
// DOM Capture for Cypress
cy.captureDOM().then((snapshot) => {
    // Process snapshot
});`;
    }

    private getWebdriverIOInit(): string {
        return `
import { remote } from 'webdriverio';

const browser = await remote({
    capabilities: {
        browserName: 'chrome',
        'goog:chromeOptions': {
            args: ['--headless', '--disable-gpu']
        }
    }
});`;
    }

    private getWebdriverIOCaptureCode(): string {
        return `
// DOM Capture for WebdriverIO
const domCapture = new WebdriverIODOMCapture();
const snapshot = await domCapture.captureDOM();`;
    }

    private getPuppeteerInit(): string {
        return `
import puppeteer from 'puppeteer';

const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
});
const page = await browser.newPage();`;
    }

    private getPuppeteerCaptureCode(): string {
        return `
// DOM Capture for Puppeteer
const domCapture = new PuppeteerDOMCapture(page);
const snapshot = await domCapture.captureDOM();`;
    }

    /**
     * Get required dependencies for a framework/browser combination
     */
    private getRequiredDependencies(framework: TestFramework, browserType: string): Dependency[] {
        const dependencies: Dependency[] = [];

        switch (framework) {
            case TestFramework.SELENIUM_TESTNG:
            case TestFramework.SELENIUM_JUNIT:
                dependencies.push(
                    { name: 'selenium-java', version: '4.15.0', type: 'maven' },
                    { name: 'testng', version: '7.8.0', type: 'maven' }
                );
                
                if (browserType === 'chrome') {
                    dependencies.push({ name: 'webdrivermanager', version: '5.5.3', type: 'maven' });
                }
                break;

            case TestFramework.PLAYWRIGHT:
                dependencies.push(
                    { name: '@playwright/test', version: '^1.40.0', type: 'npm' }
                );
                break;

            case TestFramework.CYPRESS:
                dependencies.push(
                    { name: 'cypress', version: '^13.6.0', type: 'npm' }
                );
                break;

            case TestFramework.WEBDRIVERIO:
                dependencies.push(
                    { name: '@wdio/cli', version: '^8.24.0', type: 'npm' },
                    { name: 'webdriverio', version: '^8.24.0', type: 'npm' }
                );
                break;

            case TestFramework.PUPPETEER:
                dependencies.push(
                    { name: 'puppeteer', version: '^21.5.0', type: 'npm' }
                );
                break;
        }

        return dependencies;
    }

    /**
     * Check version compatibility
     */
    private async checkVersionCompatibility(
        config: DriverConfiguration
    ): Promise<{ compatible: boolean; issue: string; suggestion: string }> {
        // This would check actual installed versions vs required versions
        // For now, return a simple check
        return {
            compatible: true,
            issue: '',
            suggestion: ''
        };
    }

    /**
     * Export configuration report
     */
    async exportConfigurationReport(outputPath: string): Promise<void> {
        const report = {
            timestamp: new Date().toISOString(),
            configurations: Array.from(this.driverConfigs.entries()).map(([key, config]) => ({
                key,
                framework: config.framework,
                browserType: config.browserType,
                version: config.version,
                capabilities: config.capabilities
            })),
            activeSessions: Array.from(this.activeSessions.entries()).map(([id, session]) => ({
                id,
                framework: session.framework,
                browserType: session.browserType,
                status: session.status,
                createdAt: session.createdAt
            })),
            poolStatus: this.sessionPool.getStatus()
        };

        const fs = require('fs').promises;
        await fs.writeFile(outputPath, JSON.stringify(report, null, 2), 'utf-8');
    }
}

/**
 * Driver Session Pool for managing multiple sessions
 */
class DriverSessionPool {
    private pool: Map<string, DriverSession> = new Map();
    private maxPoolSize: number = 5;
    private sessionTimeout: number = 30 * 60 * 1000; // 30 minutes

    async addSession(session: DriverSession): Promise<void> {
        // Clean up old sessions
        await this.cleanupOldSessions();

        if (this.pool.size >= this.maxPoolSize) {
            // Remove oldest session
            const oldest = this.getOldestSession();
            if (oldest) {
                await this.removeSession(oldest.id);
            }
        }

        this.pool.set(session.id, session);
    }

    async removeSession(sessionId: string): Promise<void> {
        this.pool.delete(sessionId);
    }

    getSession(criteria: { framework?: TestFramework; browserType?: string }): DriverSession | null {
        for (const session of this.pool.values()) {
            if (session.status === 'active' &&
                (!criteria.framework || session.framework === criteria.framework) &&
                (!criteria.browserType || session.browserType === criteria.browserType)) {
                session.lastUsed = Date.now();
                return session;
            }
        }
        return null;
    }

    private async cleanupOldSessions(): Promise<void> {
        const now = Date.now();
        const toRemove: string[] = [];

        for (const [id, session] of this.pool.entries()) {
            if (now - session.lastUsed > this.sessionTimeout) {
                toRemove.push(id);
            }
        }

        for (const id of toRemove) {
            await this.removeSession(id);
        }
    }

    private getOldestSession(): DriverSession | null {
        let oldest: DriverSession | null = null;
        
        for (const session of this.pool.values()) {
            if (!oldest || session.lastUsed < oldest.lastUsed) {
                oldest = session;
            }
        }
        
        return oldest;
    }

    getStatus(): PoolStatus {
        return {
            size: this.pool.size,
            maxSize: this.maxPoolSize,
            sessions: Array.from(this.pool.values()).map(s => ({
                id: s.id,
                framework: s.framework,
                browserType: s.browserType,
                status: s.status,
                age: Date.now() - s.createdAt
            }))
        };
    }
}

// Interfaces
interface DriverConfiguration {
    framework: TestFramework;
    browserType: string;
    version: string;
    capabilities: any;
    initCode: string;
    captureCode: string;
}

interface DriverSession {
    id: string;
    framework: TestFramework;
    browserType: string;
    config: DriverConfiguration;
    status: 'initializing' | 'active' | 'idle' | 'closing';
    createdAt: number;
    lastUsed: number;
    capabilities: any;
}

interface DriverOptions {
    capabilities?: any;
    enablePooling?: boolean;
    timeout?: number;
}

interface ConfigurationValidation {
    valid: boolean;
    config: DriverConfiguration | null;
    issues: string[];
    suggestions: string[];
    requiredDependencies: Dependency[];
}

interface Dependency {
    name: string;
    version: string;
    type: 'npm' | 'maven' | 'gradle';
}

interface PoolStatus {
    size: number;
    maxSize: number;
    sessions: Array<{
        id: string;
        framework: TestFramework;
        browserType: string;
        status: string;
        age: number;
    }>;
}

export default UnifiedWebDriverManager;
export type {
    DriverConfiguration,
    DriverSession,
    DriverOptions,
    ConfigurationValidation
};