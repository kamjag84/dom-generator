/**
 * WebDriver Capability Detector
 * Detects and validates WebDriver capabilities across different browsers and frameworks
 */

import * as vscode from 'vscode';
import * as os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * WebDriver Capability Detector
 */
export class WebDriverCapabilityDetector {
    private detectedCapabilities: Map<string, BrowserCapabilities> = new Map();
    private systemInfo: SystemInfo;

    constructor() {
        this.systemInfo = this.detectSystemInfo();
    }

    /**
     * Detect all available browser capabilities
     */
    async detectAllCapabilities(): Promise<DetectionReport> {
        const report: DetectionReport = {
            timestamp: new Date().toISOString(),
            system: this.systemInfo,
            browsers: [],
            webdrivers: [],
            frameworks: [],
            issues: [],
            recommendations: []
        };

        // Detect installed browsers
        report.browsers = await this.detectInstalledBrowsers();

        // Detect WebDriver binaries
        report.webdrivers = await this.detectWebDrivers();

        // Detect testing frameworks
        report.frameworks = await this.detectTestFrameworks();

        // Validate compatibility
        const compatibility = this.validateCompatibility(
            report.browsers,
            report.webdrivers,
            report.frameworks
        );

        report.issues = compatibility.issues;
        report.recommendations = compatibility.recommendations;

        return report;
    }

    /**
     * Detect system information
     */
    private detectSystemInfo(): SystemInfo {
        return {
            platform: os.platform(),
            arch: os.arch(),
            release: os.release(),
            nodeVersion: process.version,
            memory: Math.round(os.totalmem() / (1024 * 1024 * 1024)), // GB
            cpus: os.cpus().length
        };
    }

    /**
     * Detect installed browsers
     */
    private async detectInstalledBrowsers(): Promise<BrowserInfo[]> {
        const browsers: BrowserInfo[] = [];

        // Chrome detection
        const chrome = await this.detectChrome();
        if (chrome) browsers.push(chrome);

        // Firefox detection
        const firefox = await this.detectFirefox();
        if (firefox) browsers.push(firefox);

        // Edge detection
        const edge = await this.detectEdge();
        if (edge) browsers.push(edge);

        // Safari detection (macOS only)
        if (this.systemInfo.platform === 'darwin') {
            const safari = await this.detectSafari();
            if (safari) browsers.push(safari);
        }

        return browsers;
    }

    /**
     * Detect Chrome/Chromium
     */
    private async detectChrome(): Promise<BrowserInfo | null> {
        const commands = this.getPlatformCommands('chrome');
        
        for (const cmd of commands) {
            try {
                const { stdout } = await execAsync(cmd.version);
                const version = this.parseVersion(stdout);
                
                return {
                    name: 'Chrome',
                    type: 'chrome',
                    version,
                    path: cmd.path,
                    capabilities: this.getChromeCapabilities(version),
                    supported: true
                };
            } catch (error) {
                // Browser not found or command failed
            }
        }
        
        return null;
    }

    /**
     * Detect Firefox
     */
    private async detectFirefox(): Promise<BrowserInfo | null> {
        const commands = this.getPlatformCommands('firefox');
        
        for (const cmd of commands) {
            try {
                const { stdout } = await execAsync(cmd.version);
                const version = this.parseVersion(stdout);
                
                return {
                    name: 'Firefox',
                    type: 'firefox',
                    version,
                    path: cmd.path,
                    capabilities: this.getFirefoxCapabilities(version),
                    supported: true
                };
            } catch (error) {
                // Browser not found
            }
        }
        
        return null;
    }

    /**
     * Detect Microsoft Edge
     */
    private async detectEdge(): Promise<BrowserInfo | null> {
        const commands = this.getPlatformCommands('edge');
        
        for (const cmd of commands) {
            try {
                const { stdout } = await execAsync(cmd.version);
                const version = this.parseVersion(stdout);
                
                return {
                    name: 'Microsoft Edge',
                    type: 'edge',
                    version,
                    path: cmd.path,
                    capabilities: this.getEdgeCapabilities(version),
                    supported: true
                };
            } catch (error) {
                // Browser not found
            }
        }
        
        return null;
    }

    /**
     * Detect Safari (macOS only)
     */
    private async detectSafari(): Promise<BrowserInfo | null> {
        try {
            const { stdout } = await execAsync('defaults read /Applications/Safari.app/Contents/Info CFBundleShortVersionString');
            const version = stdout.trim();
            
            return {
                name: 'Safari',
                type: 'safari',
                version,
                path: '/Applications/Safari.app',
                capabilities: this.getSafariCapabilities(version),
                supported: true
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Detect WebDriver binaries
     */
    private async detectWebDrivers(): Promise<WebDriverInfo[]> {
        const drivers: WebDriverInfo[] = [];

        // ChromeDriver
        const chromeDriver = await this.detectChromeDriver();
        if (chromeDriver) drivers.push(chromeDriver);

        // GeckoDriver (Firefox)
        const geckoDriver = await this.detectGeckoDriver();
        if (geckoDriver) drivers.push(geckoDriver);

        // EdgeDriver
        const edgeDriver = await this.detectEdgeDriver();
        if (edgeDriver) drivers.push(edgeDriver);

        // SafariDriver
        if (this.systemInfo.platform === 'darwin') {
            const safariDriver = await this.detectSafariDriver();
            if (safariDriver) drivers.push(safariDriver);
        }

        return drivers;
    }

    /**
     * Detect ChromeDriver
     */
    private async detectChromeDriver(): Promise<WebDriverInfo | null> {
        try {
            const { stdout } = await execAsync('chromedriver --version');
            const version = this.parseVersion(stdout);
            
            return {
                name: 'ChromeDriver',
                type: 'chromedriver',
                version,
                path: 'chromedriver',
                browserType: 'chrome',
                compatible: true
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Detect GeckoDriver
     */
    private async detectGeckoDriver(): Promise<WebDriverInfo | null> {
        try {
            const { stdout } = await execAsync('geckodriver --version');
            const version = this.parseVersion(stdout);
            
            return {
                name: 'GeckoDriver',
                type: 'geckodriver',
                version,
                path: 'geckodriver',
                browserType: 'firefox',
                compatible: true
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Detect EdgeDriver
     */
    private async detectEdgeDriver(): Promise<WebDriverInfo | null> {
        try {
            const { stdout } = await execAsync('msedgedriver --version');
            const version = this.parseVersion(stdout);
            
            return {
                name: 'EdgeDriver',
                type: 'edgedriver',
                version,
                path: 'msedgedriver',
                browserType: 'edge',
                compatible: true
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Detect SafariDriver
     */
    private async detectSafariDriver(): Promise<WebDriverInfo | null> {
        try {
            const { stdout } = await execAsync('safaridriver --version');
            const version = this.parseVersion(stdout);
            
            return {
                name: 'SafariDriver',
                type: 'safaridriver',
                version,
                path: '/usr/bin/safaridriver',
                browserType: 'safari',
                compatible: true
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Detect testing frameworks
     */
    private async detectTestFrameworks(): Promise<FrameworkInfo[]> {
        const frameworks: FrameworkInfo[] = [];
        const workspace = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;

        if (!workspace) {
            return frameworks;
        }

        // Check for package.json (Node.js frameworks)
        try {
            const packageJson = require(`${workspace}/package.json`);
            const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };

            if (deps['@playwright/test']) {
                frameworks.push({
                    name: 'Playwright',
                    type: 'playwright',
                    version: deps['@playwright/test'],
                    installed: true
                });
            }

            if (deps['cypress']) {
                frameworks.push({
                    name: 'Cypress',
                    type: 'cypress',
                    version: deps['cypress'],
                    installed: true
                });
            }

            if (deps['webdriverio']) {
                frameworks.push({
                    name: 'WebdriverIO',
                    type: 'webdriverio',
                    version: deps['webdriverio'],
                    installed: true
                });
            }

            if (deps['puppeteer']) {
                frameworks.push({
                    name: 'Puppeteer',
                    type: 'puppeteer',
                    version: deps['puppeteer'],
                    installed: true
                });
            }
        } catch (error) {
            // No package.json or error reading it
        }

        // Check for pom.xml (Java frameworks)
        try {
            const fs = require('fs').promises;
            const pomContent = await fs.readFile(`${workspace}/pom.xml`, 'utf-8');
            
            if (pomContent.includes('selenium-java')) {
                frameworks.push({
                    name: 'Selenium',
                    type: 'selenium',
                    version: this.extractMavenVersion(pomContent, 'selenium-java'),
                    installed: true
                });
            }

            if (pomContent.includes('testng')) {
                frameworks.push({
                    name: 'TestNG',
                    type: 'testng',
                    version: this.extractMavenVersion(pomContent, 'testng'),
                    installed: true
                });
            }
        } catch (error) {
            // No pom.xml or error reading it
        }

        return frameworks;
    }

    /**
     * Get platform-specific commands
     */
    private getPlatformCommands(browser: string): Array<{ path: string; version: string }> {
        const platform = this.systemInfo.platform;

        switch (browser) {
            case 'chrome':
                if (platform === 'win32') {
                    return [
                        { 
                            path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
                            version: '"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" --version'
                        },
                        {
                            path: 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
                            version: '"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe" --version'
                        }
                    ];
                } else if (platform === 'darwin') {
                    return [{
                        path: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                        version: '"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --version'
                    }];
                } else {
                    return [{
                        path: 'google-chrome',
                        version: 'google-chrome --version'
                    }];
                }

            case 'firefox':
                if (platform === 'win32') {
                    return [{
                        path: 'C:\\Program Files\\Mozilla Firefox\\firefox.exe',
                        version: '"C:\\Program Files\\Mozilla Firefox\\firefox.exe" --version'
                    }];
                } else if (platform === 'darwin') {
                    return [{
                        path: '/Applications/Firefox.app/Contents/MacOS/firefox',
                        version: '"/Applications/Firefox.app/Contents/MacOS/firefox" --version'
                    }];
                } else {
                    return [{
                        path: 'firefox',
                        version: 'firefox --version'
                    }];
                }

            case 'edge':
                if (platform === 'win32') {
                    return [{
                        path: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
                        version: '"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe" --version'
                    }];
                } else if (platform === 'darwin') {
                    return [{
                        path: '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
                        version: '"/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" --version'
                    }];
                } else {
                    return [{
                        path: 'microsoft-edge',
                        version: 'microsoft-edge --version'
                    }];
                }

            default:
                return [];
        }
    }

    /**
     * Parse version from command output
     */
    private parseVersion(output: string): string {
        const match = output.match(/(\d+\.[\d.]+)/);
        return match ? match[1] : 'unknown';
    }

    /**
     * Extract Maven dependency version
     */
    private extractMavenVersion(pomContent: string, artifactId: string): string {
        const regex = new RegExp(`<artifactId>${artifactId}</artifactId>\\s*<version>([^<]+)</version>`, 's');
        const match = pomContent.match(regex);
        return match ? match[1] : 'unknown';
    }

    /**
     * Get Chrome capabilities
     */
    private getChromeCapabilities(version: string): BrowserCapabilities {
        const majorVersion = parseInt(version.split('.')[0]);
        
        return {
            headless: majorVersion >= 59,
            mobileEmulation: majorVersion >= 62,
            networkThrottling: majorVersion >= 64,
            webAuthn: majorVersion >= 70,
            clipboardAPI: majorVersion >= 76,
            webBluetooth: majorVersion >= 56,
            webUSB: majorVersion >= 61,
            webXR: majorVersion >= 79,
            options: [
                '--disable-gpu',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-web-security',
                '--disable-features=VizDisplayCompositor',
                '--disable-setuid-sandbox'
            ]
        };
    }

    /**
     * Get Firefox capabilities
     */
    private getFirefoxCapabilities(version: string): BrowserCapabilities {
        const majorVersion = parseInt(version.split('.')[0]);
        
        return {
            headless: majorVersion >= 56,
            mobileEmulation: false,
            networkThrottling: majorVersion >= 71,
            webAuthn: majorVersion >= 60,
            clipboardAPI: majorVersion >= 63,
            webBluetooth: false,
            webUSB: false,
            webXR: majorVersion >= 85,
            options: [
                '--headless',
                '--width=1920',
                '--height=1080'
            ]
        };
    }

    /**
     * Get Edge capabilities
     */
    private getEdgeCapabilities(version: string): BrowserCapabilities {
        const majorVersion = parseInt(version.split('.')[0]);
        
        return {
            headless: majorVersion >= 79,
            mobileEmulation: majorVersion >= 79,
            networkThrottling: majorVersion >= 79,
            webAuthn: majorVersion >= 79,
            clipboardAPI: majorVersion >= 79,
            webBluetooth: majorVersion >= 79,
            webUSB: majorVersion >= 79,
            webXR: majorVersion >= 87,
            options: [
                '--headless',
                '--disable-gpu',
                '--no-sandbox'
            ]
        };
    }

    /**
     * Get Safari capabilities
     */
    private getSafariCapabilities(version: string): BrowserCapabilities {
        const majorVersion = parseInt(version.split('.')[0]);
        
        return {
            headless: false,
            mobileEmulation: false,
            networkThrottling: false,
            webAuthn: majorVersion >= 14,
            clipboardAPI: majorVersion >= 13,
            webBluetooth: false,
            webUSB: false,
            webXR: false,
            options: []
        };
    }

    /**
     * Validate compatibility between browsers, drivers, and frameworks
     */
    private validateCompatibility(
        browsers: BrowserInfo[],
        drivers: WebDriverInfo[],
        frameworks: FrameworkInfo[]
    ): { issues: string[]; recommendations: string[] } {
        const issues: string[] = [];
        const recommendations: string[] = [];

        // Check browser-driver compatibility
        for (const browser of browsers) {
            const matchingDriver = drivers.find(d => d.browserType === browser.type);
            if (!matchingDriver) {
                issues.push(`No WebDriver found for ${browser.name}`);
                recommendations.push(`Install ${browser.type}driver for ${browser.name}`);
            } else {
                // Check version compatibility
                const browserMajor = parseInt(browser.version.split('.')[0]);
                const driverMajor = parseInt(matchingDriver.version.split('.')[0]);
                
                if (Math.abs(browserMajor - driverMajor) > 2) {
                    issues.push(`Version mismatch: ${browser.name} ${browser.version} vs ${matchingDriver.name} ${matchingDriver.version}`);
                    recommendations.push(`Update ${matchingDriver.name} to match ${browser.name} version`);
                }
            }
        }

        // Check framework requirements
        for (const framework of frameworks) {
            if (framework.type === 'selenium' && drivers.length === 0) {
                issues.push('Selenium requires WebDriver binaries to be installed');
                recommendations.push('Install WebDriver binaries using WebDriverManager');
            }
        }

        return { issues, recommendations };
    }

    /**
     * Generate capability report
     */
    async generateReport(format: 'json' | 'html' = 'json'): Promise<string> {
        const report = await this.detectAllCapabilities();

        if (format === 'json') {
            return JSON.stringify(report, null, 2);
        } else {
            return this.generateHTMLReport(report);
        }
    }

    /**
     * Generate HTML report
     */
    private generateHTMLReport(report: DetectionReport): string {
        return `
<!DOCTYPE html>
<html>
<head>
    <title>WebDriver Capability Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        h2 { color: #666; border-bottom: 1px solid #ddd; padding-bottom: 5px; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .success { color: green; }
        .warning { color: orange; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>WebDriver Capability Detection Report</h1>
    <p>Generated: ${report.timestamp}</p>
    
    <h2>System Information</h2>
    <table>
        <tr><th>Platform</th><td>${report.system.platform}</td></tr>
        <tr><th>Architecture</th><td>${report.system.arch}</td></tr>
        <tr><th>Node Version</th><td>${report.system.nodeVersion}</td></tr>
        <tr><th>Memory</th><td>${report.system.memory} GB</td></tr>
        <tr><th>CPUs</th><td>${report.system.cpus}</td></tr>
    </table>
    
    <h2>Installed Browsers</h2>
    <table>
        <tr><th>Browser</th><th>Version</th><th>Path</th><th>Status</th></tr>
        ${report.browsers.map(b => `
        <tr>
            <td>${b.name}</td>
            <td>${b.version}</td>
            <td>${b.path}</td>
            <td class="success">✓ Installed</td>
        </tr>`).join('')}
    </table>
    
    <h2>WebDriver Binaries</h2>
    <table>
        <tr><th>Driver</th><th>Version</th><th>Browser</th><th>Status</th></tr>
        ${report.webdrivers.map(d => `
        <tr>
            <td>${d.name}</td>
            <td>${d.version}</td>
            <td>${d.browserType}</td>
            <td class="success">✓ Installed</td>
        </tr>`).join('')}
    </table>
    
    <h2>Testing Frameworks</h2>
    <table>
        <tr><th>Framework</th><th>Version</th><th>Status</th></tr>
        ${report.frameworks.map(f => `
        <tr>
            <td>${f.name}</td>
            <td>${f.version}</td>
            <td class="success">✓ Installed</td>
        </tr>`).join('')}
    </table>
    
    ${report.issues.length > 0 ? `
    <h2>Issues</h2>
    <ul>
        ${report.issues.map(i => `<li class="error">${i}</li>`).join('')}
    </ul>` : ''}
    
    ${report.recommendations.length > 0 ? `
    <h2>Recommendations</h2>
    <ul>
        ${report.recommendations.map(r => `<li class="warning">${r}</li>`).join('')}
    </ul>` : ''}
</body>
</html>`;
    }
}

// Interfaces
interface SystemInfo {
    platform: NodeJS.Platform;
    arch: string;
    release: string;
    nodeVersion: string;
    memory: number;
    cpus: number;
}

interface BrowserInfo {
    name: string;
    type: string;
    version: string;
    path: string;
    capabilities: BrowserCapabilities;
    supported: boolean;
}

interface BrowserCapabilities {
    headless: boolean;
    mobileEmulation: boolean;
    networkThrottling: boolean;
    webAuthn: boolean;
    clipboardAPI: boolean;
    webBluetooth: boolean;
    webUSB: boolean;
    webXR: boolean;
    options: string[];
}

interface WebDriverInfo {
    name: string;
    type: string;
    version: string;
    path: string;
    browserType: string;
    compatible: boolean;
}

interface FrameworkInfo {
    name: string;
    type: string;
    version: string;
    installed: boolean;
}

interface DetectionReport {
    timestamp: string;
    system: SystemInfo;
    browsers: BrowserInfo[];
    webdrivers: WebDriverInfo[];
    frameworks: FrameworkInfo[];
    issues: string[];
    recommendations: string[];
}

export default WebDriverCapabilityDetector;
export type {
    DetectionReport,
    BrowserInfo,
    WebDriverInfo,
    FrameworkInfo
};