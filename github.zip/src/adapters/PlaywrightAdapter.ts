/**
 * Playwright Integration Adapter for DOM Generator
 * Provides seamless integration with Playwright test framework
 */

import { Page, Browser, BrowserContext, TestInfo } from '@playwright/test';
import { AdvancedDOMCapture, DOMSnapshot, CaptureOptions } from '../capture/AdvancedDOMCapture';

export interface PlaywrightCaptureConfig {
    enabled: boolean;
    captureOnFailure: boolean;
    captureOnSuccess: boolean;
    captureBeforeAction: boolean;
    captureAfterAction: boolean;
    includeVideo: boolean;
    includeTrace: boolean;
    customOptions?: Partial<CaptureOptions>;
}

export interface PlaywrightTestContext {
    page: Page;
    browser: Browser;
    context: BrowserContext;
    testInfo: TestInfo;
}

/**
 * Playwright DOM Capture Adapter
 */
export class PlaywrightDOMAdapter {
    private config: PlaywrightCaptureConfig;
    private captureHistory: Map<string, DOMSnapshot[]> = new Map();

    constructor(config: Partial<PlaywrightCaptureConfig> = {}) {
        this.config = {
            enabled: true,
            captureOnFailure: true,
            captureOnSuccess: false,
            captureBeforeAction: false,
            captureAfterAction: true,
            includeVideo: true,
            includeTrace: true,
            ...config
        };
    }

    /**
     * Initialize Playwright hooks for automatic capture
     */
    async initialize(page: Page, testInfo: TestInfo): Promise<void> {
        if (!this.config.enabled) return;

        // Set up test metadata
        await page.addInitScript((testData: any) => {
            (window as any)['__currentTestName__'] = testData.title;
            (window as any)['__currentTestSuite__'] = testData.titlePath.join(' > ');
            (window as any)['__playwright__'] = true;
        }, {
            title: testInfo.title,
            titlePath: testInfo.titlePath
        });

        // Inject Advanced DOM Capture library
        await this.injectCaptureLibrary(page);

        // Set up automatic capture on navigation
        page.on('load', async () => {
            if (this.config.captureAfterAction) {
                await this.captureDOM(page, 'page-load');
            }
        });

        // Capture on console errors
        page.on('console', async (msg) => {
            if (msg.type() === 'error' && this.config.captureOnFailure) {
                await this.captureDOM(page, 'console-error');
            }
        });

        // Capture on page errors
        page.on('pageerror', async (error) => {
            if (this.config.captureOnFailure) {
                await this.captureDOM(page, 'page-error', { error: error.message });
            }
        });
    }

    /**
     * Inject the Advanced DOM Capture library into the page
     */
    private async injectCaptureLibrary(page: Page): Promise<void> {
        await page.addScriptTag({
            content: `
                // Injected capture library
                (window as any).DOMCapture = {}; // Placeholder for actual capture
            `
        });
    }

    /**
     * Capture DOM with Playwright-specific enhancements
     */
    async captureDOM(
        page: Page, 
        trigger: string = 'manual',
        metadata: Record<string, any> = {}
    ): Promise<DOMSnapshot> {
        try {
            // Execute capture in page context
            const snapshot = await page.evaluate(async () => {
                if (!(window as any)['DOMCapture']) {
                    throw new Error('DOM Capture library not initialized');
                }
                return await (window as any)['DOMCapture'].captureFullState();
            });

            // Enhance with Playwright-specific data
            const enhancedSnapshot = await this.enhanceWithPlaywrightData(page, snapshot, metadata);
            
            // Store in history
            const testName = await page.evaluate(() => (window as any)['__currentTestName__'] || 'unknown');
            if (!this.captureHistory.has(testName)) {
                this.captureHistory.set(testName, []);
            }
            this.captureHistory.get(testName)!.push(enhancedSnapshot);

            // Add trigger information
            enhancedSnapshot.metadata = {
                ...enhancedSnapshot.metadata,
                trigger,
                ...metadata
            };

            return enhancedSnapshot;
        } catch (error) {
            console.error('Failed to capture DOM:', error);
            throw error;
        }
    }

    /**
     * Enhance snapshot with Playwright-specific data
     */
    private async enhanceWithPlaywrightData(
        page: Page,
        snapshot: DOMSnapshot,
        metadata: Record<string, any>
    ): Promise<DOMSnapshot> {
        // Add Playwright viewport info
        const viewport = page.viewportSize();
        if (viewport) {
            snapshot.viewport = {
                ...snapshot.viewport,
                width: viewport.width,
                height: viewport.height
            };
        }

        // Add accessibility tree
        try {
            const accessibilityTree = await page.accessibility.snapshot();
            (snapshot as any).accessibilityTree = accessibilityTree;
        } catch (error) {
            console.warn('Could not capture accessibility tree:', error);
        }

        // Add coverage data if available
        try {
            const coverage = await page.coverage.stopJSCoverage();
            (snapshot as any).coverage = coverage;
            await page.coverage.startJSCoverage();
        } catch {
            // Coverage might not be started
        }

        // Add current URL and title
        snapshot.url = page.url();
        (snapshot as any).title = await page.title();

        // Add cookies
        const cookies = await page.context().cookies();
        (snapshot.jsState as any).cookies = cookies;

        // Add localStorage from all origins
        const localStorage = await page.evaluate(() => {
            const storage: Record<string, any> = {};
            for (let i = 0; i < window.localStorage.length; i++) {
                const key = window.localStorage.key(i);
                if (key) {
                    storage[key] = window.localStorage.getItem(key);
                }
            }
            return storage;
        });
        snapshot.jsState.localStorage = localStorage;

        return snapshot;
    }

    /**
     * Create a fixture for Playwright tests
     */
    createFixture() {
        return async ({ page, testInfo }: PlaywrightTestContext, use: any) => {
            // Initialize adapter
            await this.initialize(page, testInfo);

            // Provide capture function to tests
            const capture = async (trigger?: string) => {
                return await this.captureDOM(page, trigger || 'test-capture');
            };

            // Run the test
            await use({ capture });

            // Capture on test completion
            if (testInfo.status === 'failed' && this.config.captureOnFailure) {
                await this.captureDOM(page, 'test-failure', {
                    error: testInfo.error?.message,
                    stack: testInfo.error?.stack
                });
            } else if (testInfo.status === 'passed' && this.config.captureOnSuccess) {
                await this.captureDOM(page, 'test-success');
            }

            // Save captures to test results
            await this.saveCaptures(testInfo);
        };
    }

    /**
     * Wrap Playwright page actions with capture
     */
    wrapPageActions(page: Page): Page {
        const originalClick = page.click.bind(page);
        const originalFill = page.fill.bind(page);
        const originalType = page.type.bind(page);
        const originalSelectOption = page.selectOption.bind(page);

        // Wrap click action
        page.click = async (selector: string, options?: any) => {
            if (this.config.captureBeforeAction) {
                await this.captureDOM(page, 'before-click', { selector });
            }
            const result = await originalClick(selector, options);
            if (this.config.captureAfterAction) {
                await this.captureDOM(page, 'after-click', { selector });
            }
            return result;
        };

        // Wrap fill action
        page.fill = async (selector: string, value: string, options?: any) => {
            if (this.config.captureBeforeAction) {
                await this.captureDOM(page, 'before-fill', { selector, value });
            }
            const result = await originalFill(selector, value, options);
            if (this.config.captureAfterAction) {
                await this.captureDOM(page, 'after-fill', { selector, value });
            }
            return result;
        };

        // Wrap type action
        page.type = async (selector: string, text: string, options?: any) => {
            if (this.config.captureBeforeAction) {
                await this.captureDOM(page, 'before-type', { selector, text });
            }
            const result = await originalType(selector, text, options);
            if (this.config.captureAfterAction) {
                await this.captureDOM(page, 'after-type', { selector, text });
            }
            return result;
        };

        // Wrap select action
        page.selectOption = async (selector: string, values: any, options?: any) => {
            if (this.config.captureBeforeAction) {
                await this.captureDOM(page, 'before-select', { selector, values });
            }
            const result = await originalSelectOption(selector, values, options);
            if (this.config.captureAfterAction) {
                await this.captureDOM(page, 'after-select', { selector, values });
            }
            return result;
        };

        return page;
    }

    /**
     * Compare two DOM snapshots for differences
     */
    async compareSnapshots(before: DOMSnapshot, after: DOMSnapshot): Promise<DiffResult> {
        const differences: Difference[] = [];

        // Compare HTML structure
        if (before.html !== after.html) {
            differences.push({
                type: 'html',
                path: 'root',
                before: before.html.substring(0, 100),
                after: after.html.substring(0, 100)
            });
        }

        // Compare form data
        before.formData.inputs.forEach((input, index) => {
            const afterInput = after.formData.inputs[index];
            if (afterInput && input.value !== afterInput.value) {
                differences.push({
                    type: 'form-input',
                    path: input.selector,
                    before: input.value,
                    after: afterInput.value
                });
            }
        });

        // Compare network activity
        const newRequests = after.networkActivity.filter(
            req => !before.networkActivity.some(r => r.url === req.url && r.timestamp === req.timestamp)
        );
        
        newRequests.forEach(req => {
            differences.push({
                type: 'network',
                path: req.url,
                before: null,
                after: req
            });
        });

        // Compare console output
        const newConsoleEntries = after.consoleOutput.slice(before.consoleOutput.length);
        newConsoleEntries.forEach(entry => {
            differences.push({
                type: 'console',
                path: entry.type,
                before: null,
                after: entry.message
            });
        });

        return {
            hasDifferences: differences.length > 0,
            differences,
            summary: this.generateDiffSummary(differences)
        };
    }

    /**
     * Generate summary of differences
     */
    private generateDiffSummary(differences: Difference[]): string {
        const summary: string[] = [];
        const typeCount: Record<string, number> = {};

        differences.forEach(diff => {
            typeCount[diff.type] = (typeCount[diff.type] || 0) + 1;
        });

        Object.entries(typeCount).forEach(([type, count]) => {
            summary.push(`${count} ${type} changes`);
        });

        return summary.join(', ');
    }

    /**
     * Save captures to test results
     */
    private async saveCaptures(testInfo: TestInfo): Promise<void> {
        const testCaptures = this.captureHistory.get(testInfo.title);
        if (!testCaptures || testCaptures.length === 0) return;

        // Create output directory
        const outputDir = testInfo.outputPath('dom-captures');
        const fs = require('fs').promises;
        const path = require('path');
        
        await fs.mkdir(outputDir, { recursive: true });

        // Save each capture
        for (let i = 0; i < testCaptures.length; i++) {
            const capture = testCaptures[i];
            const filename = `capture-${i}-${capture.metadata?.trigger || 'unknown'}.json`;
            const filepath = path.join(outputDir, filename);
            
            await fs.writeFile(filepath, JSON.stringify(capture, null, 2));
            
            // Attach to test results
            await testInfo.attach(filename, {
                body: Buffer.from(JSON.stringify(capture)),
                contentType: 'application/json'
            });
        }

        // Generate HTML report
        const htmlReport = this.generateHTMLReport(testCaptures, testInfo);
        const reportPath = path.join(outputDir, 'capture-report.html');
        await fs.writeFile(reportPath, htmlReport);
        
        await testInfo.attach('DOM Capture Report', {
            path: reportPath,
            contentType: 'text/html'
        });
    }

    /**
     * Generate HTML report from captures
     */
    private generateHTMLReport(captures: DOMSnapshot[], testInfo: TestInfo): string {
        const capturesJson = JSON.stringify(captures);
        
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOM Capture Report - ${testInfo.title}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 { margin: 0 0 10px 0; color: #333; }
        .status { 
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            font-weight: 500;
        }
        .status.passed { background: #d4edda; color: #155724; }
        .status.failed { background: #f8d7da; color: #721c24; }
        .captures {
            display: grid;
            gap: 20px;
        }
        .capture {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .capture-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        .trigger {
            background: #e3f2fd;
            color: #1565c0;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .metric {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        .metric-label {
            color: #666;
            font-size: 12px;
            margin-bottom: 4px;
        }
        .metric-value {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        .tabs {
            display: flex;
            gap: 10px;
            margin: 15px 0;
            border-bottom: 2px solid #e0e0e0;
        }
        .tab {
            padding: 10px 20px;
            background: none;
            border: none;
            cursor: pointer;
            color: #666;
            font-weight: 500;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
        }
        .tab.active {
            color: #1976d2;
            border-bottom-color: #1976d2;
        }
        .tab-content {
            display: none;
            margin-top: 15px;
        }
        .tab-content.active {
            display: block;
        }
        pre {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 4px;
            overflow-x: auto;
            font-size: 12px;
        }
        .network-table {
            width: 100%;
            border-collapse: collapse;
        }
        .network-table th {
            background: #f5f5f5;
            padding: 8px;
            text-align: left;
            font-weight: 500;
            font-size: 12px;
        }
        .network-table td {
            padding: 8px;
            border-top: 1px solid #e0e0e0;
            font-size: 12px;
        }
        .console-entry {
            padding: 8px;
            margin: 4px 0;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
        }
        .console-entry.error {
            background: #ffebee;
            color: #c62828;
        }
        .console-entry.warn {
            background: #fff3e0;
            color: #ef6c00;
        }
        .console-entry.log {
            background: #f5f5f5;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>${testInfo.title}</h1>
        <div>
            <span class="status ${testInfo.status}">${testInfo.status?.toUpperCase()}</span>
            <span style="margin-left: 20px; color: #666;">
                Duration: ${testInfo.duration}ms | 
                ${new Date().toLocaleString()}
            </span>
        </div>
    </div>

    <div class="captures" id="captures"></div>

    <script>
        const captures = ${capturesJson};
        const capturesContainer = document.getElementById('captures');

        captures.forEach((capture, index) => {
            const captureEl = document.createElement('div');
            captureEl.className = 'capture';
            
            captureEl.innerHTML = \`
                <div class="capture-header">
                    <h3>Capture #\${index + 1}</h3>
                    <span class="trigger">\${capture.metadata?.trigger || 'unknown'}</span>
                </div>
                
                <div class="metrics">
                    <div class="metric">
                        <div class="metric-label">DOM Nodes</div>
                        <div class="metric-value">\${capture.html ? capture.html.split('<').length - 1 : 0}</div>
                    </div>
                    <div class="metric">
                        <div class="metric-label">Network Requests</div>
                        <div class="metric-value">\${capture.networkActivity?.length || 0}</div>
                    </div>
                    <div class="metric">
                        <div class="metric-label">Console Entries</div>
                        <div class="metric-value">\${capture.consoleOutput?.length || 0}</div>
                    </div>
                    <div class="metric">
                        <div class="metric-label">Mutations</div>
                        <div class="metric-value">\${capture.mutations?.length || 0}</div>
                    </div>
                </div>

                <div class="tabs">
                    <button class="tab active" onclick="showTab(this, 'perf-\${index}')">Performance</button>
                    <button class="tab" onclick="showTab(this, 'network-\${index}')">Network</button>
                    <button class="tab" onclick="showTab(this, 'console-\${index}')">Console</button>
                    <button class="tab" onclick="showTab(this, 'state-\${index}')">State</button>
                </div>

                <div id="perf-\${index}" class="tab-content active">
                    <div class="metrics">
                        <div class="metric">
                            <div class="metric-label">First Contentful Paint</div>
                            <div class="metric-value">\${capture.performanceMetrics?.metrics?.firstContentfulPaint?.toFixed(2) || 0}ms</div>
                        </div>
                        <div class="metric">
                            <div class="metric-label">Largest Contentful Paint</div>
                            <div class="metric-value">\${capture.performanceMetrics?.metrics?.largestContentfulPaint?.toFixed(2) || 0}ms</div>
                        </div>
                        <div class="metric">
                            <div class="metric-label">Cumulative Layout Shift</div>
                            <div class="metric-value">\${capture.performanceMetrics?.metrics?.cumulativeLayoutShift?.toFixed(3) || 0}</div>
                        </div>
                        <div class="metric">
                            <div class="metric-label">Total Blocking Time</div>
                            <div class="metric-value">\${capture.performanceMetrics?.metrics?.totalBlockingTime?.toFixed(2) || 0}ms</div>
                        </div>
                    </div>
                </div>

                <div id="network-\${index}" class="tab-content">
                    <table class="network-table">
                        <thead>
                            <tr>
                                <th>URL</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Duration</th>
                                <th>Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            \${(capture.networkActivity || []).map(req => \`
                                <tr>
                                    <td>\${req.url.substring(0, 50)}</td>
                                    <td>\${req.method}</td>
                                    <td>\${req.status}</td>
                                    <td>\${req.duration}ms</td>
                                    <td>\${req.size}B</td>
                                </tr>
                            \`).join('')}
                        </tbody>
                    </table>
                </div>

                <div id="console-\${index}" class="tab-content">
                    \${(capture.consoleOutput || []).map(entry => \`
                        <div class="console-entry \${entry.type}">
                            [\${entry.type.toUpperCase()}] \${entry.message}
                        </div>
                    \`).join('')}
                </div>

                <div id="state-\${index}" class="tab-content">
                    <h4>JavaScript State</h4>
                    <pre>\${JSON.stringify(capture.jsState, null, 2)}</pre>
                    <h4>Form Data</h4>
                    <pre>\${JSON.stringify(capture.formData, null, 2)}</pre>
                </div>
            \`;
            
            capturesContainer.appendChild(captureEl);
        });

        function showTab(button, contentId) {
            // Remove active from all tabs in this capture
            button.parentElement.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            button.classList.add('active');

            // Hide all tab contents in this capture
            button.parentElement.parentElement.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(contentId).classList.add('active');
        }
    </script>
</body>
</html>`;
    }

    /**
     * Get capture history for a test
     */
    getCaptureHistory(testName: string): DOMSnapshot[] {
        return this.captureHistory.get(testName) || [];
    }

    /**
     * Clear capture history
     */
    clearHistory(): void {
        this.captureHistory.clear();
    }
}

// Type definitions
interface Difference {
    type: string;
    path: string;
    before: any;
    after: any;
}

interface DiffResult {
    hasDifferences: boolean;
    differences: Difference[];
    summary: string;
}

// Augment window object
declare global {
    interface Window {
        DOMCapture: AdvancedDOMCapture;
        __currentTestName__: string;
        __currentTestSuite__: string;
        __playwright__: boolean;
    }
}

