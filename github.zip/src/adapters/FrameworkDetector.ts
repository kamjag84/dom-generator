import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { glob } from 'glob';

/**
 * Cross-Framework Test Detection and Adaptation
 * Automatically detects test frameworks and adapts DOM capture integration
 */
export class FrameworkDetector {
    private workspace: string;
    private detectedFrameworks: Set<TestFramework> = new Set();
    private frameworkConfigs: Map<TestFramework, FrameworkConfig> = new Map();

    constructor(workspace: string) {
        this.workspace = workspace;
        this.initializeFrameworkConfigs();
    }

    /**
     * Initialize framework configurations
     */
    private initializeFrameworkConfigs(): void {
        // Selenium + TestNG
        this.frameworkConfigs.set(TestFramework.SELENIUM_TESTNG, {
            name: 'Selenium + TestNG',
            configFiles: ['testng.xml', 'pom.xml', 'build.gradle'],
            dependencies: ['selenium-java', 'testng'],
            testPatterns: ['**/*Test.java', '**/*Tests.java', '**/test/*.java'],
            captureIntegration: 'SeleniumInjector',
            setupInstructions: this.getSeleniumTestNGSetup()
        });

        // Selenium + JUnit
        this.frameworkConfigs.set(TestFramework.SELENIUM_JUNIT, {
            name: 'Selenium + JUnit',
            configFiles: ['pom.xml', 'build.gradle'],
            dependencies: ['selenium-java', 'junit'],
            testPatterns: ['**/*Test.java', '**/*Tests.java', '**/test/*.java'],
            captureIntegration: 'SeleniumInjector',
            setupInstructions: this.getSeleniumJUnitSetup()
        });

        // Playwright (JavaScript/TypeScript)
        this.frameworkConfigs.set(TestFramework.PLAYWRIGHT, {
            name: 'Playwright',
            configFiles: ['playwright.config.ts', 'playwright.config.js', 'package.json'],
            dependencies: ['@playwright/test', 'playwright'],
            testPatterns: ['**/*.spec.ts', '**/*.spec.js', '**/*.test.ts', '**/*.test.js'],
            captureIntegration: 'PlaywrightAdapter',
            setupInstructions: this.getPlaywrightSetup()
        });

        // Cypress
        this.frameworkConfigs.set(TestFramework.CYPRESS, {
            name: 'Cypress',
            configFiles: ['cypress.config.ts', 'cypress.config.js', 'cypress.json'],
            dependencies: ['cypress'],
            testPatterns: ['**/cypress/**/*.cy.ts', '**/cypress/**/*.cy.js', '**/*.spec.ts'],
            captureIntegration: 'CypressAdapter',
            setupInstructions: this.getCypressSetup()
        });

        // WebdriverIO
        this.frameworkConfigs.set(TestFramework.WEBDRIVERIO, {
            name: 'WebdriverIO',
            configFiles: ['wdio.conf.js', 'wdio.conf.ts'],
            dependencies: ['@wdio/cli', 'webdriverio'],
            testPatterns: ['**/*.spec.ts', '**/*.spec.js', '**/test/**/*.js'],
            captureIntegration: 'WebdriverIOAdapter',
            setupInstructions: this.getWebdriverIOSetup()
        });

        // Puppeteer
        this.frameworkConfigs.set(TestFramework.PUPPETEER, {
            name: 'Puppeteer',
            configFiles: ['package.json'],
            dependencies: ['puppeteer', 'puppeteer-core'],
            testPatterns: ['**/*.test.js', '**/*.spec.js', '**/test/**/*.js'],
            captureIntegration: 'PuppeteerAdapter',
            setupInstructions: this.getPuppeteerSetup()
        });

        // Protractor (Angular)
        this.frameworkConfigs.set(TestFramework.PROTRACTOR, {
            name: 'Protractor',
            configFiles: ['protractor.conf.js', 'protractor.conf.ts'],
            dependencies: ['protractor'],
            testPatterns: ['**/*.e2e-spec.ts', '**/*.e2e.ts', '**/e2e/**/*.ts'],
            captureIntegration: 'ProtractorAdapter',
            setupInstructions: this.getProtractorSetup()
        });

        // Jest + Testing Library
        this.frameworkConfigs.set(TestFramework.JEST_TESTING_LIBRARY, {
            name: 'Jest + Testing Library',
            configFiles: ['jest.config.js', 'jest.config.ts', 'package.json'],
            dependencies: ['@testing-library/react', '@testing-library/dom', 'jest'],
            testPatterns: ['**/*.test.tsx', '**/*.test.ts', '**/*.spec.tsx'],
            captureIntegration: 'JestAdapter',
            setupInstructions: this.getJestSetup()
        });
    }

    /**
     * Detect test frameworks in the workspace
     */
    async detectFrameworks(): Promise<DetectionResult> {
        const result: DetectionResult = {
            frameworks: [],
            primaryFramework: null,
            suggestions: [],
            configurationNeeded: []
        };

        try {
            // Check for configuration files
            for (const [framework, config] of this.frameworkConfigs) {
                const detected = await this.checkFramework(framework, config);
                if (detected) {
                    this.detectedFrameworks.add(framework);
                    result.frameworks.push({
                        framework,
                        confidence: detected.confidence,
                        configFiles: detected.configFiles,
                        testFiles: detected.testFiles
                    });
                }
            }

            // Determine primary framework
            if (result.frameworks.length > 0) {
                result.primaryFramework = result.frameworks.sort((a, b) => 
                    b.confidence - a.confidence
                )[0].framework;
            }

            // Generate suggestions
            result.suggestions = this.generateSuggestions(result.frameworks);

            // Check what needs configuration
            result.configurationNeeded = await this.checkConfiguration(result.frameworks);

        } catch (error) {
            console.error('Framework detection failed:', error);
        }

        return result;
    }

    /**
     * Check for specific framework
     */
    private async checkFramework(
        framework: TestFramework, 
        config: FrameworkConfig
    ): Promise<FrameworkDetection | null> {
        const detection: FrameworkDetection = {
            confidence: 0,
            configFiles: [],
            testFiles: []
        };

        // Check for configuration files
        for (const configFile of config.configFiles) {
            const files = await glob(path.join(this.workspace, '**', configFile), {
                ignore: ['**/node_modules/**', '**/dist/**', '**/build/**']
            });
            
            if (files.length > 0) {
                detection.configFiles.push(...files);
                detection.confidence += 30;
            }
        }

        // Check for dependencies in package.json or pom.xml
        const hasDependencies = await this.checkDependencies(config.dependencies);
        if (hasDependencies) {
            detection.confidence += 40;
        }

        // Check for test files
        for (const pattern of config.testPatterns) {
            const files = await glob(path.join(this.workspace, pattern), {
                ignore: ['**/node_modules/**', '**/dist/**', '**/build/**']
            });
            
            if (files.length > 0) {
                detection.testFiles.push(...files.slice(0, 5)); // Sample files
                detection.confidence += 30;
            }
        }

        return detection.confidence > 0 ? detection : null;
    }

    /**
     * Check for dependencies
     */
    private async checkDependencies(dependencies: string[]): Promise<boolean> {
        // Check package.json
        const packageJsonPath = path.join(this.workspace, 'package.json');
        if (await this.fileExists(packageJsonPath)) {
            try {
                const content = await fs.promises.readFile(packageJsonPath, 'utf-8');
                const pkg = JSON.parse(content);
                const allDeps = {
                    ...pkg.dependencies,
                    ...pkg.devDependencies
                };
                
                return dependencies.some(dep => dep in allDeps);
            } catch (error) {
                console.error('Error reading package.json:', error);
            }
        }

        // Check pom.xml
        const pomPath = path.join(this.workspace, 'pom.xml');
        if (await this.fileExists(pomPath)) {
            try {
                const content = await fs.promises.readFile(pomPath, 'utf-8');
                return dependencies.some(dep => content.includes(dep));
            } catch (error) {
                console.error('Error reading pom.xml:', error);
            }
        }

        // Check build.gradle
        const gradlePath = path.join(this.workspace, 'build.gradle');
        if (await this.fileExists(gradlePath)) {
            try {
                const content = await fs.promises.readFile(gradlePath, 'utf-8');
                return dependencies.some(dep => content.includes(dep));
            } catch (error) {
                console.error('Error reading build.gradle:', error);
            }
        }

        return false;
    }

    /**
     * Generate framework-specific adapter
     */
    async generateAdapter(framework: TestFramework): Promise<string> {
        const config = this.frameworkConfigs.get(framework);
        if (!config) {
            throw new Error(`Unknown framework: ${framework}`);
        }

        switch (framework) {
            case TestFramework.CYPRESS:
                return this.generateCypressAdapter();
            case TestFramework.WEBDRIVERIO:
                return this.generateWebdriverIOAdapter();
            case TestFramework.PUPPETEER:
                return this.generatePuppeteerAdapter();
            case TestFramework.PROTRACTOR:
                return this.generateProtractorAdapter();
            case TestFramework.JEST_TESTING_LIBRARY:
                return this.generateJestAdapter();
            default:
                return `// Adapter for ${config.name} - Use existing ${config.captureIntegration}`;
        }
    }

    /**
     * Generate Cypress adapter
     */
    private generateCypressAdapter(): string {
        return `/// <reference types="cypress" />

/**
 * Cypress DOM Capture Adapter
 * Integrates advanced DOM capture with Cypress tests
 */

// Add custom commands
Cypress.Commands.add('captureDOM', (options = {}) => {
    return cy.window().then((win) => {
        // Inject capture script if not already present
        if (!win.__DOMCapture) {
            cy.readFile('node_modules/dom-capture/dist/injection.js').then((script) => {
                cy.window().then((w) => {
                    const scriptEl = w.document.createElement('script');
                    scriptEl.textContent = script;
                    w.document.head.appendChild(scriptEl);
                });
            });
        }
        
        // Capture DOM
        return cy.window().then((w) => {
            return w.__DOMCapture.captureFullState();
        });
    });
});

Cypress.Commands.add('captureBeforeAction', (actionName) => {
    return cy.captureDOM().then((capture) => {
        capture.captureType = 'before';
        capture.action = actionName;
        return capture;
    });
});

Cypress.Commands.add('captureAfterAction', (actionName) => {
    return cy.captureDOM().then((capture) => {
        capture.captureType = 'after';
        capture.action = actionName;
        return capture;
    });
});

// Auto-capture on failure
Cypress.on('fail', (error, runnable) => {
    cy.captureDOM().then((capture) => {
        capture.error = error.message;
        capture.testName = runnable.title;
        
        // Save capture
        const fileName = \`dom-capture-\${Date.now()}.json\`;
        cy.writeFile(\`cypress/dom-captures/\${fileName}\`, capture);
        
        console.log('DOM capture saved:', fileName);
    });
    
    throw error;
});

// Type definitions
declare global {
    namespace Cypress {
        interface Chainable {
            captureDOM(options?: any): Chainable<any>;
            captureBeforeAction(actionName: string): Chainable<any>;
            captureAfterAction(actionName: string): Chainable<any>;
        }
    }
}

export {};`;
    }

    /**
     * Generate WebdriverIO adapter
     */
    private generateWebdriverIOAdapter(): string {
        return `import { browser } from '@wdio/globals';

/**
 * WebdriverIO DOM Capture Adapter
 */
export class WebdriverIODOMCapture {
    private initialized = false;
    
    async init() {
        if (this.initialized) return;
        
        const script = await this.loadInjectionScript();
        await browser.execute(script);
        this.initialized = true;
    }
    
    async captureDOM(options = {}) {
        await this.init();
        return await browser.execute(() => {
            return window.__DOMCapture.captureFullState();
        });
    }
    
    async captureOnFailure(test) {
        if (test.state === 'failed') {
            const capture = await this.captureDOM();
            capture.testName = test.title;
            capture.error = test.error.message;
            
            // Save capture
            const fs = require('fs');
            const fileName = \`dom-capture-\${Date.now()}.json\`;
            fs.writeFileSync(
                \`./test-results/dom-captures/\${fileName}\`,
                JSON.stringify(capture, null, 2)
            );
        }
    }
    
    private async loadInjectionScript() {
        const fs = require('fs').promises;
        return await fs.readFile(
            require.resolve('dom-capture/dist/injection.js'),
            'utf-8'
        );
    }
}

// Hook integration
export const domCapture = new WebdriverIODOMCapture();

// Add to wdio.conf.js hooks:
// afterTest: async function(test) {
//     await domCapture.captureOnFailure(test);
// }`;
    }

    /**
     * Generate Puppeteer adapter
     */
    private generatePuppeteerAdapter(): string {
        return `const fs = require('fs').promises;
const path = require('path');

/**
 * Puppeteer DOM Capture Adapter
 */
class PuppeteerDOMCapture {
    constructor(page) {
        this.page = page;
        this.initialized = false;
    }
    
    async init() {
        if (this.initialized) return;
        
        const scriptPath = require.resolve('dom-capture/dist/injection.js');
        const script = await fs.readFile(scriptPath, 'utf-8');
        await this.page.evaluateOnNewDocument(script);
        this.initialized = true;
    }
    
    async captureDOM(options = {}) {
        await this.init();
        return await this.page.evaluate(() => {
            return window.__DOMCapture.captureFullState();
        });
    }
    
    async captureBeforeAction(actionName) {
        const capture = await this.captureDOM();
        capture.captureType = 'before';
        capture.action = actionName;
        return capture;
    }
    
    async captureAfterAction(actionName) {
        const capture = await this.captureDOM();
        capture.captureType = 'after';
        capture.action = actionName;
        return capture;
    }
    
    async compareCaptures(before, after) {
        return {
            urlChanged: before.url !== after.url,
            domChanged: JSON.stringify(before.dom) !== JSON.stringify(after.dom),
            newErrors: after.errors.length - before.errors.length,
            performanceChange: {
                memory: after.performance.memory.usedJSHeapSize - 
                        before.performance.memory.usedJSHeapSize
            }
        };
    }
    
    async saveCapture(capture, fileName) {
        const dir = path.join(process.cwd(), 'test-results', 'dom-captures');
        await fs.mkdir(dir, { recursive: true });
        await fs.writeFile(
            path.join(dir, fileName),
            JSON.stringify(capture, null, 2)
        );
    }
}

module.exports = PuppeteerDOMCapture;`;
    }

    /**
     * Generate Protractor adapter
     */
    private generateProtractorAdapter(): string {
        return `import { browser, by, element } from 'protractor';

/**
 * Protractor DOM Capture Adapter
 */
export class ProtractorDOMCapture {
    private initialized = false;
    
    async init() {
        if (this.initialized) return;
        
        const script = await this.loadInjectionScript();
        await browser.executeScript(script);
        this.initialized = true;
    }
    
    async captureDOM(options = {}) {
        await this.init();
        return await browser.executeScript(() => {
            return window.__DOMCapture.captureFullState();
        });
    }
    
    async captureOnFailure(testInfo) {
        const capture = await this.captureDOM();
        capture.testName = testInfo.name;
        capture.error = testInfo.error;
        
        // Save capture
        const fs = require('fs');
        const fileName = \`dom-capture-\${Date.now()}.json\`;
        fs.writeFileSync(
            \`./test-results/dom-captures/\${fileName}\`,
            JSON.stringify(capture, null, 2)
        );
    }
    
    private async loadInjectionScript() {
        const fs = require('fs').promises;
        return await fs.readFile(
            require.resolve('dom-capture/dist/injection.js'),
            'utf-8'
        );
    }
}

// Jasmine reporter integration
export class DOMCaptureReporter {
    private domCapture = new ProtractorDOMCapture();
    
    specDone(result) {
        if (result.status === 'failed') {
            this.domCapture.captureOnFailure(result);
        }
    }
}`;
    }

    /**
     * Generate Jest adapter
     */
    private generateJestAdapter(): string {
        return `import { JSDOM } from 'jsdom';
import fs from 'fs/promises';
import path from 'path';

/**
 * Jest + Testing Library DOM Capture Adapter
 */
export class JestDOMCapture {
    private dom: JSDOM;
    private captures: Map<string, any> = new Map();
    
    constructor() {
        this.setupJSDOM();
    }
    
    private setupJSDOM() {
        this.dom = new JSDOM('<!DOCTYPE html><html><body></body></html>', {
            url: 'http://localhost',
            pretendToBeVisual: true,
            resources: 'usable'
        });
        
        global.window = this.dom.window as any;
        global.document = this.dom.window.document;
    }
    
    async captureDOM(container = document.body) {
        const snapshot = {
            timestamp: new Date().toISOString(),
            html: container.innerHTML,
            text: container.textContent,
            elements: this.analyzeElements(container),
            forms: this.captureFormData(container),
            accessibility: this.captureAccessibility(container)
        };
        
        return snapshot;
    }
    
    private analyzeElements(container: HTMLElement) {
        const analysis = {
            totalElements: container.getElementsByTagName('*').length,
            interactiveElements: {
                buttons: container.querySelectorAll('button, [role="button"]').length,
                links: container.querySelectorAll('a, [role="link"]').length,
                inputs: container.querySelectorAll('input, textarea, select').length
            },
            visibility: this.checkVisibility(container)
        };
        
        return analysis;
    }
    
    private captureFormData(container: HTMLElement) {
        const forms: any[] = [];
        container.querySelectorAll('form').forEach((form, index) => {
            const formData = {
                index,
                name: form.name,
                id: form.id,
                fields: {}
            };
            
            form.querySelectorAll('input, select, textarea').forEach((field: any) => {
                const key = field.name || field.id || field.type;
                formData.fields[key] = {
                    type: field.type,
                    value: field.value,
                    checked: field.checked,
                    required: field.required,
                    disabled: field.disabled
                };
            });
            
            forms.push(formData);
        });
        
        return forms;
    }
    
    private captureAccessibility(container: HTMLElement) {
        return {
            hasAriaLabels: container.querySelectorAll('[aria-label]').length,
            hasRoles: container.querySelectorAll('[role]').length,
            hasAltText: container.querySelectorAll('img[alt]').length,
            totalImages: container.querySelectorAll('img').length,
            headingStructure: {
                h1: container.querySelectorAll('h1').length,
                h2: container.querySelectorAll('h2').length,
                h3: container.querySelectorAll('h3').length
            }
        };
    }
    
    private checkVisibility(element: HTMLElement) {
        const style = window.getComputedStyle(element);
        return {
            display: style.display !== 'none',
            visibility: style.visibility !== 'hidden',
            opacity: parseFloat(style.opacity) > 0
        };
    }
    
    async saveCapture(testName: string, capture: any) {
        const fileName = \`dom-capture-\${testName}-\${Date.now()}.json\`;
        const filePath = path.join(process.cwd(), 'test-results', 'dom-captures', fileName);
        
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        await fs.writeFile(filePath, JSON.stringify(capture, null, 2));
        
        return fileName;
    }
}

// Jest custom matchers
expect.extend({
    toHaveValidDOM(received) {
        const domCapture = new JestDOMCapture();
        const capture = domCapture.captureDOM(received);
        
        const pass = capture.elements.totalElements > 0;
        
        return {
            pass,
            message: () => 
                pass 
                    ? \`Expected DOM to be invalid but found \${capture.elements.totalElements} elements\`
                    : \`Expected DOM to be valid but found no elements\`
        };
    }
});`;
    }

    /**
     * Generate suggestions based on detected frameworks
     */
    private generateSuggestions(frameworks: any[]): string[] {
        const suggestions: string[] = [];

        if (frameworks.length === 0) {
            suggestions.push('No test frameworks detected. Consider adding a test framework to enable DOM capture.');
            suggestions.push('Popular options: Playwright, Cypress, Selenium + TestNG');
        } else if (frameworks.length === 1) {
            const framework = frameworks[0].framework;
            const config = this.frameworkConfigs.get(framework);
            suggestions.push(`Detected ${config?.name}. DOM capture can be integrated automatically.`);
            suggestions.push(`Run "Setup DOM Capture for ${config?.name}" command to configure.`);
        } else {
            suggestions.push('Multiple test frameworks detected. Select primary framework for DOM capture.');
            frameworks.forEach(f => {
                const config = this.frameworkConfigs.get(f.framework);
                suggestions.push(`- ${config?.name} (confidence: ${f.confidence}%)`);
            });
        }

        return suggestions;
    }

    /**
     * Check what configuration is needed
     */
    private async checkConfiguration(frameworks: any[]): Promise<string[]> {
        const needed: string[] = [];

        for (const f of frameworks) {
            const config = this.frameworkConfigs.get(f.framework);
            if (!config) continue;

            // Check if adapter exists
            const adapterPath = path.join(
                this.workspace,
                'node_modules',
                'dom-capture',
                'adapters',
                `${config.captureIntegration}.js`
            );

            if (!await this.fileExists(adapterPath)) {
                needed.push(`Install DOM capture adapter for ${config.name}`);
            }

            // Check if injection script exists
            const injectionPath = path.join(
                this.workspace,
                'node_modules',
                'dom-capture',
                'dist',
                'injection.js'
            );

            if (!await this.fileExists(injectionPath)) {
                needed.push('Generate DOM capture injection script');
            }
        }

        return needed;
    }

    /**
     * Setup instructions getters
     */
    private getSeleniumTestNGSetup(): string {
        return `
1. Add DOMCaptureHelper to your test base class
2. Initialize in @BeforeClass: domCapture = new DOMCaptureHelper(driver);
3. Add @Listeners annotation: @Listeners({DOMCaptureHelper.class})
4. Use domCapture.captureDOM() in your tests
5. Captures auto-save on test failure`;
    }

    private getSeleniumJUnitSetup(): string {
        return `
1. Add DOMCaptureHelper to your test class
2. Initialize in @Before: domCapture = new DOMCaptureHelper(driver);
3. Add @Rule for failure capture
4. Use domCapture.captureDOM() in your tests`;
    }

    private getPlaywrightSetup(): string {
        return `
1. Import PlaywrightAdapter in your test file
2. Initialize: const domCapture = new PlaywrightAdapter(page);
3. Use await domCapture.captureDOM() in tests
4. Auto-captures on test failure with proper configuration`;
    }

    private getCypressSetup(): string {
        return `
1. Add to cypress/support/commands.js
2. Use cy.captureDOM() in your tests
3. Auto-captures on test failure
4. Saves to cypress/dom-captures/`;
    }

    private getWebdriverIOSetup(): string {
        return `
1. Import WebdriverIODOMCapture
2. Add to wdio.conf.js hooks
3. Use domCapture.captureDOM() in tests
4. Auto-saves on test failure`;
    }

    private getPuppeteerSetup(): string {
        return `
1. Import PuppeteerDOMCapture
2. Initialize: const domCapture = new PuppeteerDOMCapture(page);
3. Use await domCapture.captureDOM() in tests`;
    }

    private getProtractorSetup(): string {
        return `
1. Import ProtractorDOMCapture
2. Add DOMCaptureReporter to jasmine reporters
3. Use domCapture.captureDOM() in tests`;
    }

    private getJestSetup(): string {
        return `
1. Import JestDOMCapture
2. Initialize in beforeEach
3. Use custom matchers like expect(container).toHaveValidDOM()
4. Captures save to test-results/dom-captures/`;
    }

    /**
     * Check if file exists
     */
    private async fileExists(filePath: string): Promise<boolean> {
        try {
            await fs.promises.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    /**
     * Auto-configure framework
     */
    async autoConfigureFramework(framework: TestFramework): Promise<ConfigurationResult> {
        const config = this.frameworkConfigs.get(framework);
        if (!config) {
            throw new Error(`Unknown framework: ${framework}`);
        }

        const result: ConfigurationResult = {
            success: false,
            framework,
            filesCreated: [],
            filesModified: [],
            instructions: []
        };

        try {
            // Generate and save adapter
            const adapterCode = await this.generateAdapter(framework);
            const adapterPath = path.join(
                this.workspace,
                'test',
                'support',
                `domCaptureAdapter.${this.getFileExtension(framework)}`
            );
            
            await fs.promises.mkdir(path.dirname(adapterPath), { recursive: true });
            await fs.promises.writeFile(adapterPath, adapterCode, 'utf-8');
            result.filesCreated.push(adapterPath);

            // Add setup instructions
            result.instructions = config.setupInstructions.split('\n').filter(line => line.trim());

            result.success = true;
        } catch (error) {
            console.error('Auto-configuration failed:', error);
            result.error = error instanceof Error ? error.message : String(error);
        }

        return result;
    }

    /**
     * Get file extension for framework
     */
    private getFileExtension(framework: TestFramework): string {
        switch (framework) {
            case TestFramework.SELENIUM_TESTNG:
            case TestFramework.SELENIUM_JUNIT:
                return 'java';
            case TestFramework.PLAYWRIGHT:
            case TestFramework.CYPRESS:
            case TestFramework.PROTRACTOR:
            case TestFramework.JEST_TESTING_LIBRARY:
                return 'ts';
            default:
                return 'js';
        }
    }
}

// Enums and interfaces
export enum TestFramework {
    SELENIUM_TESTNG = 'selenium_testng',
    SELENIUM_JUNIT = 'selenium_junit',
    PLAYWRIGHT = 'playwright',
    CYPRESS = 'cypress',
    WEBDRIVERIO = 'webdriverio',
    PUPPETEER = 'puppeteer',
    PROTRACTOR = 'protractor',
    JEST_TESTING_LIBRARY = 'jest_testing_library'
}

interface FrameworkConfig {
    name: string;
    configFiles: string[];
    dependencies: string[];
    testPatterns: string[];
    captureIntegration: string;
    setupInstructions: string;
}

interface FrameworkDetection {
    confidence: number;
    configFiles: string[];
    testFiles: string[];
}

interface DetectionResult {
    frameworks: Array<{
        framework: TestFramework;
        confidence: number;
        configFiles: string[];
        testFiles: string[];
    }>;
    primaryFramework: TestFramework | null;
    suggestions: string[];
    configurationNeeded: string[];
}

interface ConfigurationResult {
    success: boolean;
    framework: TestFramework;
    filesCreated: string[];
    filesModified: string[];
    instructions: string[];
    error?: string;
}

export default FrameworkDetector;