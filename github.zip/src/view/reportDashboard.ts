import * as vscode from 'vscode';
import { DOMCapture } from '../managers/domCaptureManager';

export class ReportDashboard {
    public static async show(context: vscode.ExtensionContext, captures: DOMCapture[]) {
        const panel = vscode.window.createWebviewPanel(
            'domReportDashboard',
            'DOM Capture Dashboard',
            vscode.ViewColumn.One,
            {
                enableScripts: true,
                retainContextWhenHidden: true
            }
        );
        
        panel.webview.html = this.getWebviewContent(captures);
        
        panel.webview.onDidReceiveMessage(
            async message => {
                switch (message.command) {
                    case 'openCapture':
                        const capture = captures.find(c => c.domPath === message.path);
                        if (capture) {
                            await vscode.commands.executeCommand('domGenerator.openCapture', capture);
                        }
                        break;
                }
            },
            undefined,
            context.subscriptions
        );
    }
    
    private static getWebviewContent(captures: DOMCapture[]): string {
        const stats = this.calculateStats(captures);
        
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOM Capture Dashboard</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        h1 {
            margin: 0 0 20px 0;
            color: #333;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            color: #666;
            margin-top: 5px;
        }
        .captures-list {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .capture-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background 0.2s;
        }
        .capture-item:hover {
            background: #f5f5f5;
        }
        .capture-name {
            font-weight: 500;
            color: #333;
        }
        .capture-time {
            color: #999;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>DOM Capture Dashboard</h1>
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">${stats.total}</div>
                    <div class="stat-label">Total Captures</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.today}</div>
                    <div class="stat-label">Today</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.thisWeek}</div>
                    <div class="stat-label">This Week</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.uniqueTests}</div>
                    <div class="stat-label">Unique Tests</div>
                </div>
            </div>
        </div>
        
        <div class="captures-list">
            <h2>Recent Captures</h2>
            ${captures.slice(0, 20).map(capture => `
                <div class="capture-item" onclick="openCapture('${capture.domPath}')">
                    <div class="capture-name">${capture.testName}</div>
                    <div class="capture-time">${capture.timestamp.toLocaleString()}</div>
                </div>
            `).join('')}
        </div>
    </div>
    
    <script>
        const vscode = acquireVsCodeApi();
        
        function openCapture(path) {
            vscode.postMessage({
                command: 'openCapture',
                path: path
            });
        }
    </script>
</body>
</html>`;
    }
    
    private static calculateStats(captures: DOMCapture[]) {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        
        return {
            total: captures.length,
            today: captures.filter(c => c.timestamp >= today).length,
            thisWeek: captures.filter(c => c.timestamp >= weekAgo).length,
            uniqueTests: new Set(captures.map(c => c.testName)).size
        };
    }
}