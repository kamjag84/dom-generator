import * as vscode from 'vscode';
import { DOMCaptureManager } from './managers/domCaptureManager';
import { TestConfigManager } from './managers/testConfigManager';
import { BuildSystemDetector } from './managers/buildSystemDetector';
import { DOMViewProvider } from './providers/domViewProvider';
import { CopilotIntegration } from './providers/copilotIntegration';
import { ReportDashboard } from './view/reportDashboard';
import { EXTENSION_NAME } from './utils/constants';
import { AutoConfigureCommand } from './commands/AutoConfigureCommand';

let domCaptureManager: DOMCaptureManager;
let testConfigManager: TestConfigManager;
let buildSystemDetector: BuildSystemDetector;
let domViewProvider: DOMViewProvider;
let copilotIntegration: CopilotIntegration;
let statusBarItem: vscode.StatusBarItem;
let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
    console.log(`${EXTENSION_NAME} is now active!`);
    
    outputChannel = vscode.window.createOutputChannel(EXTENSION_NAME);
    outputChannel.appendLine(`${EXTENSION_NAME} activated at ${new Date().toISOString()}`);
    
    const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
    if (!workspaceRoot) {
        vscode.window.showErrorMessage('No workspace folder open. Please open a Java project.');
        return;
    }

    // Initialize managers
    domCaptureManager = new DOMCaptureManager(context);
    testConfigManager = new TestConfigManager(context);
    buildSystemDetector = new BuildSystemDetector(workspaceRoot);
    domViewProvider = new DOMViewProvider(context);
    copilotIntegration = new CopilotIntegration(context, domCaptureManager);

    // Register tree data provider
    vscode.window.registerTreeDataProvider('domCaptureExplorer', domViewProvider);

    // Auto-setup and build detection
    initializeProject(context);

    // Register all commands
    registerCommands(context);

    // Setup watchers
    setupWatchers(context);

    // Create status bar
    createStatusBar(context);

    // Register Copilot integration
    const copilotHandler = vscode.chat.createChatParticipant('domgenerate', async (request, context, response, token) => {
        await copilotIntegration.handleChatRequest(request, context, response, token);
    });
    
    context.subscriptions.push(copilotHandler, outputChannel);
}

async function initializeProject(context: vscode.ExtensionContext) {
    const config = vscode.workspace.getConfiguration('domGenerator');
    
    if (config.get('autoDetectBuildSystem')) {
        await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "DOM Generator: Detecting build system...",
            cancellable: false
        }, async (progress) => {
            progress.report({ increment: 0 });
            const buildConfig = await buildSystemDetector.detectBuildSystem();
            progress.report({ increment: 100 });
            
            if (buildConfig) {
                updateStatusBar(`$(tools) ${buildConfig.system}`);
                if (config.get('showNotifications')) {
                    vscode.window.showInformationMessage(`Detected ${buildConfig.system} project`);
                }
                
                if (config.get('autoSetup')) {
                    await testConfigManager.autoSetup();
                }
            }
            return buildConfig;
        });
    }
}

function registerCommands(context: vscode.ExtensionContext) {
    const commands = [
        {
            id: 'domGenerator.setup',
            handler: async () => {
                try {
                    await testConfigManager.setupProject();
                    vscode.window.showInformationMessage('DOM Generator setup completed successfully!');
                } catch (error: any) {
                    vscode.window.showErrorMessage(`Setup failed: ${error.message}`);
                    outputChannel.appendLine(`Setup error: ${error.stack}`);
                }
            }
        },
        {
            id: 'domGenerator.detectBuildSystem',
            handler: async () => {
                const config = await buildSystemDetector.detectBuildSystem();
                if (config) {
                    vscode.window.showInformationMessage(`Detected: ${config.system} at ${config.buildFile}`);
                    updateStatusBar(`$(tools) ${config.system}`);
                } else {
                    vscode.window.showWarningMessage('No build system detected');
                }
            }
        },
        {
            id: 'domGenerator.runTests',
            handler: async () => {
                await testConfigManager.runTestsWithBuildSystem();
            }
        },
        {
            id: 'domGenerator.validateSetup',
            handler: async () => {
                await testConfigManager.validateSetup();
            }
        },
        {
            id: 'domGenerator.exportCI',
            handler: async () => {
                await testConfigManager.exportCIConfiguration();
            }
        },
        {
            id: 'domGenerator.openCaptureFolder',
            handler: async () => {
                const folderPath = await domCaptureManager.getCaptureFolder();
                if (folderPath) {
                    const uri = vscode.Uri.file(folderPath);
                    vscode.commands.executeCommand('revealInExplorer', uri);
                } else {
                    vscode.window.showWarningMessage('No DOM captures folder found. Run a test first.');
                }
            }
        },
        {
            id: 'domGenerator.showLatestCapture',
            handler: async () => {
                const capture = await domCaptureManager.getLatestCapture();
                if (capture) {
                    await domCaptureManager.displayCapture(capture);
                } else {
                    vscode.window.showInformationMessage('No DOM captures found.');
                }
            }
        },
        {
            id: 'domGenerator.searchCaptures',
            handler: async () => {
                const query = await vscode.window.showInputBox({
                    prompt: 'Search captures by test name or date',
                    placeHolder: 'e.g., login or 2024-01-15'
                });
                
                if (query) {
                    const results = await domCaptureManager.searchCaptures(query);
                    if (results.length > 0) {
                        const selected = await vscode.window.showQuickPick(
                            results.map(r => ({
                                label: r.testName,
                                description: r.timestamp.toLocaleString(),
                                capture: r
                            })),
                            { placeHolder: 'Select a capture to view' }
                        );
                        
                        if (selected) {
                            await domCaptureManager.displayCapture(selected.capture);
                        }
                    } else {
                        vscode.window.showInformationMessage('No captures found matching your search.');
                    }
                }
            }
        },
        {
            id: 'domGenerator.showDashboard',
            handler: async () => {
                const captures = await domCaptureManager.getAllCaptures();
                await ReportDashboard.show(context, captures);
            }
        },
        {
            id: 'domGenerator.selectDriverStrategy',
            handler: async () => {
                await testConfigManager.selectDriverStrategy();
            }
        },
        {
            id: 'domGenerator.cleanBuild',
            handler: async () => {
                await buildSystemDetector.cleanBuild();
            }
        },
        {
            id: 'domGenerator.runCoverage',
            handler: async () => {
                await buildSystemDetector.runCoverage();
            }
        },
        {
            id: 'domGenerator.autoConfigureProject',
            handler: async () => {
                const autoConfig = new AutoConfigureCommand();
                await autoConfig.execute();
            }
        },
        {
            id: 'domGenerator.verifySetup',
            handler: async () => {
                const autoConfig = new AutoConfigureCommand();
                await autoConfig.verifySetup();
            }
        }
    ];

    commands.forEach(cmd => {
        const disposable = vscode.commands.registerCommand(cmd.id, cmd.handler);
        context.subscriptions.push(disposable);
    });

    // Register open capture command (for tree view clicks)
    const openCaptureCommand = vscode.commands.registerCommand('domGenerator.openCapture', async (capture) => {
        await domCaptureManager.displayCapture(capture);
    });
    context.subscriptions.push(openCaptureCommand);
}

function setupWatchers(context: vscode.ExtensionContext) {
    // Watch for test failures in terminal
    const terminalWatcher = vscode.window.onDidChangeActiveTerminal(async (terminal) => {
        if (terminal) {
            await watchTerminalForTestFailures(terminal);
        }
    });

    // Watch for new DOM captures
    const fileWatcher = vscode.workspace.createFileSystemWatcher('**/test-results/dom-captures/**/*.html');
    fileWatcher.onDidCreate((uri) => {
        domViewProvider.refresh();
        if (vscode.workspace.getConfiguration('domGenerator').get('showNotifications')) {
            vscode.window.showInformationMessage(`New DOM capture: ${uri.fsPath}`, 'View').then(selection => {
                if (selection === 'View') {
                    vscode.commands.executeCommand('domGenerator.showLatestCapture');
                }
            });
        }
    });

    // Watch for build file changes
    const buildFileWatcher = buildSystemDetector.createBuildFileWatcher();

    // Watch for test file changes
    const testWatcher = testConfigManager.createTestWatcher();

    context.subscriptions.push(terminalWatcher, fileWatcher, buildFileWatcher, testWatcher);
}

function createStatusBar(context: vscode.ExtensionContext) {
    statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    statusBarItem.command = 'domGenerator.showDashboard';
    updateStatusBar('$(tools) DOM Generator');
    statusBarItem.show();
    context.subscriptions.push(statusBarItem);
}

function updateStatusBar(text: string) {
    if (statusBarItem) {
        statusBarItem.text = text;
        statusBarItem.tooltip = 'Click to show DOM Generator dashboard';
    }
}

async function watchTerminalForTestFailures(terminal: vscode.Terminal) {
    // Note: Terminal data monitoring is not directly available in VS Code API
    // This would require using the proposed API or alternative approach
    // For now, we'll rely on file watchers to detect new captures
    
    // Alternative: Set up periodic refresh when terminal is active
    const intervalId = setInterval(() => {
        if (vscode.window.activeTerminal === terminal) {
            domViewProvider.refresh();
        }
    }, 5000); // Check every 5 seconds
    
    // Return a disposable that clears the interval
    return new vscode.Disposable(() => {
        clearInterval(intervalId);
    });
}

export function deactivate() {
    outputChannel.appendLine(`${EXTENSION_NAME} deactivated at ${new Date().toISOString()}`);
    outputChannel.dispose();
}