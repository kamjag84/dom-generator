import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

/**
 * Selenium DOM Capture Injector
 * Provides injection scripts and utilities for capturing DOM in Selenium tests
 */
export class SeleniumInjector {
    private static readonly INJECTION_SCRIPT_NAME = 'domCaptureInjection.js';
    private captureScriptCache: Map<string, string> = new Map();

    /**
     * Generate the complete injection script for Selenium
     */
    async generateInjectionScript(options: InjectionOptions = {}): Promise<string> {
        const cacheKey = JSON.stringify(options);
        if (this.captureScriptCache.has(cacheKey)) {
            return this.captureScriptCache.get(cacheKey)!;
        }

        const script = `
(function() {
    // Advanced DOM Capture for Selenium
    window.__DOMCapture = {
        version: '2.0.0',
        options: ${JSON.stringify(options)},
        
        // Capture complete DOM state
        captureFullState: function() {
            const startTime = performance.now();
            const snapshot = {
                timestamp: new Date().toISOString(),
                url: window.location.href,
                title: document.title,
                viewport: {
                    width: window.innerWidth,
                    height: window.innerHeight,
                    devicePixelRatio: window.devicePixelRatio
                },
                dom: null,
                shadowDoms: [],
                iframes: [],
                styles: {},
                jsState: {},
                forms: {},
                scroll: {},
                animations: [],
                performance: {},
                network: [],
                console: [],
                errors: [],
                mutations: []
            };

            try {
                // Capture main DOM
                snapshot.dom = this.captureDOM(document.documentElement);
                
                // Capture Shadow DOMs
                snapshot.shadowDoms = this.captureShadowDOMs();
                
                // Capture iframes
                snapshot.iframes = this.captureIframes();
                
                // Capture computed styles
                snapshot.styles = this.captureStyles();
                
                // Capture JavaScript state
                snapshot.jsState = this.captureJSState();
                
                // Capture form data
                snapshot.forms = this.captureFormData();
                
                // Capture scroll positions
                snapshot.scroll = this.captureScrollPositions();
                
                // Capture animations
                snapshot.animations = this.captureAnimations();
                
                // Capture performance metrics
                snapshot.performance = this.capturePerformance();
                
                // Capture network activity
                snapshot.network = this.captureNetworkActivity();
                
                // Capture console logs
                snapshot.console = this.captureConsoleLogs();
                
                // Capture errors
                snapshot.errors = this.captureErrors();
                
                snapshot.captureTime = performance.now() - startTime;
            } catch (error) {
                snapshot.errors.push({
                    type: 'capture_error',
                    message: error.message,
                    stack: error.stack
                });
            }

            return snapshot;
        },

        // Capture DOM structure
        captureDOM: function(element, depth = 0, maxDepth = 100) {
            if (depth > maxDepth) return null;
            
            const node = {
                tagName: element.tagName,
                attributes: {},
                children: [],
                textContent: null,
                shadowRoot: null,
                computedStyle: null,
                boundingBox: null,
                visibility: null
            };

            // Capture attributes
            if (element.attributes) {
                for (let attr of element.attributes) {
                    node.attributes[attr.name] = attr.value;
                }
            }

            // Capture bounding box
            try {
                const rect = element.getBoundingClientRect();
                node.boundingBox = {
                    x: rect.x,
                    y: rect.y,
                    width: rect.width,
                    height: rect.height,
                    top: rect.top,
                    right: rect.right,
                    bottom: rect.bottom,
                    left: rect.left
                };
            } catch (e) {}

            // Check visibility
            node.visibility = this.checkVisibility(element);

            // Capture text content for leaf nodes
            if (element.childNodes.length === 1 && element.childNodes[0].nodeType === 3) {
                node.textContent = element.textContent;
            }

            // Check for Shadow DOM
            if (element.shadowRoot) {
                node.shadowRoot = this.captureDOM(element.shadowRoot, depth + 1, maxDepth);
            }

            // Capture children
            for (let child of element.children) {
                const childNode = this.captureDOM(child, depth + 1, maxDepth);
                if (childNode) {
                    node.children.push(childNode);
                }
            }

            // Capture computed styles for important elements
            if (this.options.captureStyles !== false && this.isImportantElement(element)) {
                node.computedStyle = this.getComputedStyles(element);
            }

            return node;
        },

        // Capture all Shadow DOMs in the page
        captureShadowDOMs: function() {
            const shadowDoms = [];
            const walker = document.createTreeWalker(
                document.body,
                NodeFilter.SHOW_ELEMENT,
                null,
                false
            );

            let node;
            while (node = walker.nextNode()) {
                if (node.shadowRoot) {
                    shadowDoms.push({
                        hostElement: {
                            tagName: node.tagName,
                            id: node.id,
                            className: node.className,
                            xpath: this.getXPath(node)
                        },
                        content: this.captureDOM(node.shadowRoot)
                    });
                }
            }

            return shadowDoms;
        },

        // Capture iframe contents
        captureIframes: function() {
            const iframes = [];
            const iframeElements = document.querySelectorAll('iframe, frame');

            iframeElements.forEach((iframe, index) => {
                const iframeData = {
                    index: index,
                    src: iframe.src,
                    id: iframe.id,
                    className: iframe.className,
                    xpath: this.getXPath(iframe),
                    content: null,
                    error: null
                };

                try {
                    // Try to access iframe content (same-origin only)
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                    if (iframeDoc) {
                        iframeData.content = this.captureDOM(iframeDoc.documentElement);
                    }
                } catch (e) {
                    iframeData.error = 'Cross-origin iframe - cannot access content';
                }

                iframes.push(iframeData);
            });

            return iframes;
        },

        // Capture computed styles for critical elements
        captureStyles: function() {
            const styles = {};
            const criticalSelectors = [
                'button', 'input', 'select', 'textarea', 'a', 
                '[role="button"]', '[role="link"]', '[role="navigation"]',
                '.btn', '.button', '.link', 'nav', 'header', 'footer'
            ];

            criticalSelectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach((element, index) => {
                    const key = \`\${selector}[\${index}]\`;
                    styles[key] = this.getComputedStyles(element);
                });
            });

            return styles;
        },

        // Get computed styles for an element
        getComputedStyles: function(element) {
            const computed = window.getComputedStyle(element);
            const styles = {};
            const importantProps = [
                'display', 'visibility', 'opacity', 'position',
                'top', 'left', 'right', 'bottom', 'z-index',
                'width', 'height', 'margin', 'padding',
                'background-color', 'color', 'font-size',
                'transform', 'transition', 'animation',
                'pointer-events', 'cursor', 'overflow'
            ];

            importantProps.forEach(prop => {
                styles[prop] = computed.getPropertyValue(prop);
            });

            return styles;
        },

        // Capture JavaScript state
        captureJSState: function() {
            const state = {
                localStorage: {},
                sessionStorage: {},
                cookies: document.cookie,
                windowProperties: {},
                documentProperties: {},
                customDataAttributes: []
            };

            // Capture storage
            try {
                for (let key in localStorage) {
                    state.localStorage[key] = localStorage.getItem(key);
                }
                for (let key in sessionStorage) {
                    state.sessionStorage[key] = sessionStorage.getItem(key);
                }
            } catch (e) {}

            // Capture important window properties
            ['scrollX', 'scrollY', 'innerWidth', 'innerHeight'].forEach(prop => {
                state.windowProperties[prop] = window[prop];
            });

            // Capture document properties
            ['readyState', 'documentMode', 'compatMode'].forEach(prop => {
                state.documentProperties[prop] = document[prop];
            });

            // Capture data attributes
            document.querySelectorAll('[data-test-id], [data-testid], [data-qa], [data-automation-id]').forEach(element => {
                state.customDataAttributes.push({
                    xpath: this.getXPath(element),
                    attributes: Array.from(element.attributes)
                        .filter(attr => attr.name.startsWith('data-'))
                        .reduce((obj, attr) => {
                            obj[attr.name] = attr.value;
                            return obj;
                        }, {})
                });
            });

            return state;
        },

        // Capture form data
        captureFormData: function() {
            const formData = {};
            const forms = document.querySelectorAll('form');

            forms.forEach((form, formIndex) => {
                const formKey = form.name || form.id || \`form_\${formIndex}\`;
                formData[formKey] = {
                    action: form.action,
                    method: form.method,
                    fields: {}
                };

                // Capture all form fields
                const inputs = form.querySelectorAll('input, select, textarea');
                inputs.forEach(input => {
                    const fieldKey = input.name || input.id || this.getXPath(input);
                    formData[formKey].fields[fieldKey] = {
                        type: input.type,
                        value: input.value,
                        checked: input.checked,
                        selectedIndex: input.selectedIndex,
                        disabled: input.disabled,
                        required: input.required,
                        validity: input.validity ? {
                            valid: input.validity.valid,
                            valueMissing: input.validity.valueMissing,
                            typeMismatch: input.validity.typeMismatch,
                            patternMismatch: input.validity.patternMismatch,
                            tooLong: input.validity.tooLong,
                            tooShort: input.validity.tooShort,
                            rangeUnderflow: input.validity.rangeUnderflow,
                            rangeOverflow: input.validity.rangeOverflow,
                            stepMismatch: input.validity.stepMismatch,
                            customError: input.validity.customError
                        } : null
                    };
                });
            });

            return formData;
        },

        // Capture scroll positions
        captureScrollPositions: function() {
            const scrollData = {
                window: {
                    x: window.scrollX,
                    y: window.scrollY,
                    maxX: document.documentElement.scrollWidth - window.innerWidth,
                    maxY: document.documentElement.scrollHeight - window.innerHeight
                },
                elements: []
            };

            // Find all scrollable elements
            document.querySelectorAll('*').forEach(element => {
                if (element.scrollHeight > element.clientHeight || 
                    element.scrollWidth > element.clientWidth) {
                    scrollData.elements.push({
                        xpath: this.getXPath(element),
                        scrollTop: element.scrollTop,
                        scrollLeft: element.scrollLeft,
                        scrollHeight: element.scrollHeight,
                        scrollWidth: element.scrollWidth,
                        clientHeight: element.clientHeight,
                        clientWidth: element.clientWidth
                    });
                }
            });

            return scrollData;
        },

        // Capture running animations
        captureAnimations: function() {
            const animations = [];
            
            document.getAnimations?.().forEach(animation => {
                animations.push({
                    id: animation.id,
                    effect: {
                        target: animation.effect?.target ? this.getXPath(animation.effect.target) : null,
                        pseudoElement: animation.effect?.pseudoElement
                    },
                    currentTime: animation.currentTime,
                    playState: animation.playState,
                    playbackRate: animation.playbackRate,
                    startTime: animation.startTime,
                    timeline: animation.timeline?.currentTime
                });
            });

            return animations;
        },

        // Capture performance metrics
        capturePerformance: function() {
            const metrics = {
                timing: {},
                resources: [],
                memory: {},
                fps: null
            };

            // Navigation timing
            if (performance.timing) {
                const timing = performance.timing;
                metrics.timing = {
                    loadTime: timing.loadEventEnd - timing.navigationStart,
                    domContentLoaded: timing.domContentLoadedEventEnd - timing.navigationStart,
                    firstByte: timing.responseStart - timing.navigationStart,
                    dnsTime: timing.domainLookupEnd - timing.domainLookupStart,
                    connectTime: timing.connectEnd - timing.connectStart,
                    responseTime: timing.responseEnd - timing.responseStart,
                    domProcessing: timing.domComplete - timing.domLoading
                };
            }

            // Resource timing
            if (performance.getEntriesByType) {
                metrics.resources = performance.getEntriesByType('resource').slice(-50).map(resource => ({
                    name: resource.name,
                    type: resource.initiatorType,
                    duration: resource.duration,
                    size: resource.transferSize
                }));
            }

            // Memory usage
            if (performance.memory) {
                metrics.memory = {
                    usedJSHeapSize: performance.memory.usedJSHeapSize,
                    totalJSHeapSize: performance.memory.totalJSHeapSize,
                    jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
                };
            }

            return metrics;
        },

        // Capture network activity
        captureNetworkActivity: function() {
            return window.__capturedNetworkActivity || [];
        },

        // Capture console logs
        captureConsoleLogs: function() {
            return window.__capturedConsoleLogs || [];
        },

        // Capture errors
        captureErrors: function() {
            return window.__capturedErrors || [];
        },

        // Check element visibility
        checkVisibility: function(element) {
            const rect = element.getBoundingClientRect();
            const style = window.getComputedStyle(element);
            
            return {
                inViewport: rect.top < window.innerHeight && rect.bottom > 0 &&
                           rect.left < window.innerWidth && rect.right > 0,
                displayed: style.display !== 'none',
                visible: style.visibility !== 'hidden',
                opacity: parseFloat(style.opacity),
                hasSize: rect.width > 0 && rect.height > 0,
                zIndex: style.zIndex,
                covered: this.isElementCovered(element)
            };
        },

        // Check if element is covered by another element
        isElementCovered: function(element) {
            const rect = element.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const topElement = document.elementFromPoint(centerX, centerY);
            
            return topElement !== element && !element.contains(topElement);
        },

        // Check if element is important for capture
        isImportantElement: function(element) {
            const importantTags = ['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'A', 'FORM'];
            const importantRoles = ['button', 'link', 'navigation', 'textbox', 'combobox'];
            const importantClasses = ['btn', 'button', 'link', 'nav', 'menu'];
            
            return importantTags.includes(element.tagName) ||
                   importantRoles.includes(element.getAttribute('role')) ||
                   importantClasses.some(cls => element.classList.contains(cls));
        },

        // Get XPath for element
        getXPath: function(element) {
            if (element.id) {
                return \`//*[@id="\${element.id}"]\`;
            }
            
            const segments = [];
            while (element && element.nodeType === 1) {
                let index = 1;
                let sibling = element.previousSibling;
                
                while (sibling) {
                    if (sibling.nodeType === 1 && sibling.tagName === element.tagName) {
                        index++;
                    }
                    sibling = sibling.previousSibling;
                }
                
                segments.unshift(\`\${element.tagName.toLowerCase()}[\${index}]\`);
                element = element.parentNode;
            }
            
            return segments.length ? \`/\${segments.join('/')}\` : null;
        },

        // Wait for element to be ready
        waitForElement: function(selector, timeout = 10000) {
            return new Promise((resolve, reject) => {
                const startTime = Date.now();
                
                const checkElement = () => {
                    const element = document.querySelector(selector);
                    if (element) {
                        resolve(element);
                    } else if (Date.now() - startTime > timeout) {
                        reject(new Error(\`Element \${selector} not found within \${timeout}ms\`));
                    } else {
                        setTimeout(checkElement, 100);
                    }
                };
                
                checkElement();
            });
        },

        // Setup network interception
        setupNetworkInterception: function() {
            window.__capturedNetworkActivity = window.__capturedNetworkActivity || [];
            
            // Intercept fetch
            const originalFetch = window.fetch;
            window.fetch = function(...args) {
                const request = {
                    url: args[0],
                    method: args[1]?.method || 'GET',
                    timestamp: Date.now()
                };
                
                return originalFetch.apply(this, args).then(response => {
                    window.__capturedNetworkActivity.push({
                        ...request,
                        status: response.status,
                        statusText: response.statusText,
                        responseTime: Date.now() - request.timestamp
                    });
                    return response;
                }).catch(error => {
                    window.__capturedNetworkActivity.push({
                        ...request,
                        error: error.message,
                        responseTime: Date.now() - request.timestamp
                    });
                    throw error;
                });
            };
            
            // Intercept XHR
            const XHR = XMLHttpRequest.prototype;
            const originalOpen = XHR.open;
            const originalSend = XHR.send;
            
            XHR.open = function(method, url) {
                this.__requestData = { method, url, timestamp: Date.now() };
                return originalOpen.apply(this, arguments);
            };
            
            XHR.send = function() {
                const request = this.__requestData;
                
                this.addEventListener('load', function() {
                    window.__capturedNetworkActivity.push({
                        ...request,
                        status: this.status,
                        statusText: this.statusText,
                        responseTime: Date.now() - request.timestamp
                    });
                });
                
                this.addEventListener('error', function() {
                    window.__capturedNetworkActivity.push({
                        ...request,
                        error: 'XHR request failed',
                        responseTime: Date.now() - request.timestamp
                    });
                });
                
                return originalSend.apply(this, arguments);
            };
        },

        // Setup console interception
        setupConsoleInterception: function() {
            window.__capturedConsoleLogs = window.__capturedConsoleLogs || [];
            const methods = ['log', 'info', 'warn', 'error', 'debug'];
            
            methods.forEach(method => {
                const original = console[method];
                console[method] = function(...args) {
                    window.__capturedConsoleLogs.push({
                        type: method,
                        message: args.map(arg => {
                            try {
                                return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
                            } catch (e) {
                                return '[Object]';
                            }
                        }).join(' '),
                        timestamp: Date.now(),
                        stack: new Error().stack
                    });
                    return original.apply(console, args);
                };
            });
        },

        // Setup error interception
        setupErrorInterception: function() {
            window.__capturedErrors = window.__capturedErrors || [];
            
            window.addEventListener('error', function(event) {
                window.__capturedErrors.push({
                    type: 'error',
                    message: event.message,
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno,
                    stack: event.error?.stack,
                    timestamp: Date.now()
                });
            });
            
            window.addEventListener('unhandledrejection', function(event) {
                window.__capturedErrors.push({
                    type: 'unhandledRejection',
                    message: event.reason?.message || String(event.reason),
                    stack: event.reason?.stack,
                    timestamp: Date.now()
                });
            });
        },

        // Initialize capture system
        init: function() {
            this.setupNetworkInterception();
            this.setupConsoleInterception();
            this.setupErrorInterception();
            
            // Setup mutation observer if requested
            if (this.options.trackMutations) {
                this.setupMutationObserver();
            }
            
            return this;
        },

        // Setup mutation observer
        setupMutationObserver: function() {
            window.__capturedMutations = [];
            const observer = new MutationObserver((mutations) => {
                mutations.forEach(mutation => {
                    window.__capturedMutations.push({
                        type: mutation.type,
                        target: this.getXPath(mutation.target),
                        timestamp: Date.now()
                    });
                });
            });
            
            observer.observe(document.body, {
                attributes: true,
                childList: true,
                subtree: true,
                characterData: true
            });
        }
    };

    // Initialize and return
    return window.__DOMCapture.init();
})();`;

        this.captureScriptCache.set(cacheKey, script);
        return script;
    }

    /**
     * Generate Java/TestNG helper class for Selenium integration
     */
    async generateSeleniumHelper(): Promise<string> {
        return `package com.example.automation.capture;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.ITestResult;
import org.testng.ITestListener;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.util.Map;
import java.util.HashMap;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 * DOM Capture Helper for Selenium WebDriver
 * Provides methods to capture DOM state during test execution
 */
public class DOMCaptureHelper implements ITestListener {
    private static final ObjectMapper mapper = new ObjectMapper();
    private WebDriver driver;
    private JavascriptExecutor jsExecutor;
    private String captureScript;
    private boolean initialized = false;
    
    public DOMCaptureHelper(WebDriver driver) {
        this.driver = driver;
        this.jsExecutor = (JavascriptExecutor) driver;
        initialize();
    }
    
    /**
     * Initialize the DOM capture system
     */
    private void initialize() {
        if (initialized) return;
        
        try {
            // Load the injection script
            captureScript = new String(Files.readAllBytes(
                Paths.get(getClass().getResource("/domCaptureInjection.js").toURI())
            ));
            
            // Inject the script into the page
            jsExecutor.executeScript(captureScript);
            initialized = true;
        } catch (Exception e) {
            System.err.println("Failed to initialize DOM Capture: " + e.getMessage());
        }
    }
    
    /**
     * Capture the current DOM state
     */
    public Map<String, Object> captureDOM() {
        return captureDOM(new HashMap<>());
    }
    
    /**
     * Capture DOM with custom options
     */
    public Map<String, Object> captureDOM(Map<String, Object> options) {
        try {
            // Ensure the capture system is initialized
            if (!initialized) {
                initialize();
            }
            
            // Execute capture
            Object result = jsExecutor.executeScript(
                "return window.__DOMCapture.captureFullState();"
            );
            
            return (Map<String, Object>) result;
        } catch (Exception e) {
            System.err.println("Failed to capture DOM: " + e.getMessage());
            return new HashMap<>();
        }
    }
    
    /**
     * Capture DOM before an action
     */
    public Map<String, Object> captureBeforeAction(String actionName) {
        Map<String, Object> capture = captureDOM();
        capture.put("captureType", "before");
        capture.put("action", actionName);
        return capture;
    }
    
    /**
     * Capture DOM after an action
     */
    public Map<String, Object> captureAfterAction(String actionName) {
        Map<String, Object> capture = captureDOM();
        capture.put("captureType", "after");
        capture.put("action", actionName);
        return capture;
    }
    
    /**
     * Wait for element and capture
     */
    public Map<String, Object> waitAndCapture(String selector, Duration timeout) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            WebElement element = wait.until(
                ExpectedConditions.presenceOfElementLocated(
                    org.openqa.selenium.By.cssSelector(selector)
                )
            );
            
            Map<String, Object> capture = captureDOM();
            capture.put("waitedFor", selector);
            capture.put("elementFound", element != null);
            return capture;
        } catch (Exception e) {
            Map<String, Object> capture = captureDOM();
            capture.put("waitedFor", selector);
            capture.put("elementFound", false);
            capture.put("error", e.getMessage());
            return capture;
        }
    }
    
    /**
     * Capture DOM on test failure (TestNG listener)
     */
    @Override
    public void onTestFailure(ITestResult result) {
        try {
            Map<String, Object> capture = captureDOM();
            capture.put("testName", result.getName());
            capture.put("testClass", result.getTestClass().getName());
            capture.put("error", result.getThrowable().getMessage());
            capture.put("stackTrace", result.getThrowable().getStackTrace());
            
            // Save capture to file
            String fileName = String.format(
                "dom-capture-%s-%s-%d.json",
                result.getTestClass().getName(),
                result.getName(),
                System.currentTimeMillis()
            );
            
            Files.write(
                Paths.get("test-results", "dom-captures", fileName),
                mapper.writeValueAsString(capture).getBytes(),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING
            );
            
            System.out.println("DOM capture saved: " + fileName);
        } catch (Exception e) {
            System.err.println("Failed to capture DOM on test failure: " + e.getMessage());
        }
    }
    
    /**
     * Compare two DOM captures
     */
    public Map<String, Object> compareCaptures(
        Map<String, Object> before, 
        Map<String, Object> after
    ) {
        Map<String, Object> diff = new HashMap<>();
        
        // Compare URLs
        if (!before.get("url").equals(after.get("url"))) {
            diff.put("urlChanged", true);
            diff.put("urlBefore", before.get("url"));
            diff.put("urlAfter", after.get("url"));
        }
        
        // Compare DOM structure
        // This would be more complex in practice
        diff.put("domChanged", !before.get("dom").equals(after.get("dom")));
        
        // Compare errors
        int errorsBefore = ((java.util.List) before.get("errors")).size();
        int errorsAfter = ((java.util.List) after.get("errors")).size();
        if (errorsAfter > errorsBefore) {
            diff.put("newErrors", errorsAfter - errorsBefore);
        }
        
        return diff;
    }
    
    /**
     * Get element visibility info
     */
    public Map<String, Object> getElementVisibility(String selector) {
        try {
            Object result = jsExecutor.executeScript(
                "const element = document.querySelector(arguments[0]);" +
                "return element ? window.__DOMCapture.checkVisibility(element) : null;",
                selector
            );
            return (Map<String, Object>) result;
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Analyze test failure with DOM capture
     */
    public Map<String, Object> analyzeFailure(Exception error) {
        Map<String, Object> analysis = new HashMap<>();
        Map<String, Object> capture = captureDOM();
        
        analysis.put("capture", capture);
        analysis.put("error", error.getMessage());
        analysis.put("errorType", error.getClass().getSimpleName());
        
        // Check for common issues
        if (error instanceof org.openqa.selenium.NoSuchElementException) {
            analysis.put("possibleCause", "Element not found in DOM");
            analysis.put("suggestion", "Check if element exists or wait for it to load");
        } else if (error instanceof org.openqa.selenium.ElementNotInteractableException) {
            analysis.put("possibleCause", "Element exists but not interactable");
            analysis.put("suggestion", "Check element visibility and z-index");
        } else if (error instanceof org.openqa.selenium.StaleElementReferenceException) {
            analysis.put("possibleCause", "Element reference is stale");
            analysis.put("suggestion", "Re-find element after DOM changes");
        }
        
        return analysis;
    }
}`;
    }

    /**
     * Generate TestNG test example
     */
    async generateTestExample(): Promise<string> {
        return `package com.example.tests;

import org.testng.annotations.*;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.example.automation.capture.DOMCaptureHelper;
import java.util.Map;

/**
 * Example TestNG test with DOM capture integration
 */
public class ExampleTestWithCapture {
    private WebDriver driver;
    private DOMCaptureHelper domCapture;
    
    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        domCapture = new DOMCaptureHelper(driver);
    }
    
    @Test
    public void testWithDOMCapture() {
        try {
            // Navigate to page
            driver.get("https://example.com");
            
            // Capture initial state
            Map<String, Object> initialCapture = domCapture.captureDOM();
            System.out.println("Initial DOM captured");
            
            // Capture before action
            Map<String, Object> beforeClick = domCapture.captureBeforeAction("clickButton");
            
            // Perform action
            WebElement button = driver.findElement(By.id("submit-button"));
            button.click();
            
            // Capture after action
            Map<String, Object> afterClick = domCapture.captureAfterAction("clickButton");
            
            // Compare captures
            Map<String, Object> diff = domCapture.compareCaptures(beforeClick, afterClick);
            System.out.println("DOM changes: " + diff);
            
            // Wait for element with capture
            Map<String, Object> waitCapture = domCapture.waitAndCapture(
                "#success-message", 
                java.time.Duration.ofSeconds(10)
            );
            
            Assert.assertTrue((Boolean) waitCapture.get("elementFound"), 
                "Success message should appear");
            
        } catch (Exception e) {
            // Analyze failure with DOM capture
            Map<String, Object> failureAnalysis = domCapture.analyzeFailure(e);
            System.err.println("Test failed. Analysis: " + failureAnalysis);
            throw e;
        }
    }
    
    @Test
    public void testElementVisibility() {
        driver.get("https://example.com");
        
        // Check element visibility
        Map<String, Object> visibility = domCapture.getElementVisibility("#login-form");
        
        Assert.assertNotNull(visibility, "Element should exist");
        Assert.assertTrue((Boolean) visibility.get("displayed"), "Element should be displayed");
        Assert.assertTrue((Boolean) visibility.get("inViewport"), "Element should be in viewport");
        Assert.assertFalse((Boolean) visibility.get("covered"), "Element should not be covered");
    }
    
    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}`;
    }

    /**
     * Save injection script to file for bundling
     */
    async saveInjectionScript(outputPath: string): Promise<void> {
        const script = await this.generateInjectionScript({
            captureStyles: true,
            trackMutations: true,
            waitForDynamicContent: true
        });

        await fs.promises.writeFile(outputPath, script, 'utf-8');
    }

    /**
     * Generate Maven POM configuration
     */
    generateMavenConfig(): string {
        return `<!-- Add to your pom.xml dependencies -->
<dependency>
    <groupId>org.seleniumhq.selenium</groupId>
    <artifactId>selenium-java</artifactId>
    <version>4.15.0</version>
</dependency>
<dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>7.8.0</version>
</dependency>
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.15.3</version>
</dependency>

<!-- Add to build/resources -->
<build>
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <includes>
                <include>domCaptureInjection.js</include>
            </includes>
        </resource>
    </resources>
</build>`;
    }
}

// Injection options interface
interface InjectionOptions {
    captureStyles?: boolean;
    trackMutations?: boolean;
    waitForDynamicContent?: boolean;
    maxDepth?: number;
    timeout?: number;
}

export default SeleniumInjector;