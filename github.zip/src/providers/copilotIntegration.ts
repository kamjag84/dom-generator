import * as vscode from 'vscode';
import { DOMCaptureManager, DOMCapture } from '../managers/domCaptureManager';
import { ERROR_MESSAGES } from '../utils/constants';

/**
 * Integration with GitHub Copilot chat
 */
export class CopilotIntegration {
    constructor(
        private context: vscode.ExtensionContext,
        private domCaptureManager: DOMCaptureManager
    ) {}

    /**
     * Handle chat requests from Copilot
     */
    async handleChatRequest(
        request: any,
        context: any,
        response: any,
        token: vscode.CancellationToken
    ): Promise<void> {
        try {
            const command = this.parseCommand(request.prompt);
            
            switch (command.action) {
                case 'show':
                    await this.handleShowCapture(command.params, response);
                    break;
                case 'search':
                    await this.handleSearchCaptures(command.params, response);
                    break;
                case 'analyze':
                    await this.handleAnalyzeCapture(command.params, response);
                    break;
                case 'summary':
                    await this.handleSummary(response);
                    break;
                default:
                    await this.handleHelp(response);
            }
        } catch (error: any) {
            response.markdown(`Error: ${error.message || 'Failed to process request'}`);
        }
    }

    /**
     * Parse command from user prompt
     */
    private parseCommand(prompt: string): { action: string; params: string[] } {
        const lowerPrompt = prompt.toLowerCase().trim();
        
        if (lowerPrompt.includes('show') || lowerPrompt.includes('display')) {
            return { action: 'show', params: this.extractParams(prompt) };
        }
        if (lowerPrompt.includes('search') || lowerPrompt.includes('find')) {
            return { action: 'search', params: this.extractParams(prompt) };
        }
        if (lowerPrompt.includes('analyze') || lowerPrompt.includes('explain')) {
            return { action: 'analyze', params: this.extractParams(prompt) };
        }
        if (lowerPrompt.includes('summary') || lowerPrompt.includes('overview')) {
            return { action: 'summary', params: [] };
        }
        
        return { action: 'help', params: [] };
    }

    /**
     * Extract parameters from prompt
     */
    private extractParams(prompt: string): string[] {
        // Extract quoted strings or words after keywords
        const quotedStrings = prompt.match(/["']([^"']+)["']/g) || [];
        const params = quotedStrings.map(s => s.replace(/["']/g, ''));
        
        // If no quoted strings, extract test name patterns
        if (params.length === 0) {
            const words = prompt.split(' ');
            const testIndex = words.findIndex(w => 
                w.toLowerCase() === 'test' || 
                w.toLowerCase() === 'capture' ||
                w.toLowerCase() === 'failure'
            );
            if (testIndex >= 0 && testIndex < words.length - 1) {
                params.push(words[testIndex + 1]);
            }
        }
        
        return params;
    }

    /**
     * Handle show capture command
     */
    private async handleShowCapture(params: string[], response: any): Promise<void> {
        const capture = params.length > 0 
            ? await this.findCaptureByName(params[0])
            : await this.domCaptureManager.getLatestCapture();
        
        if (!capture) {
            response.markdown('No captures found. Run a failing test to generate captures.');
            return;
        }
        
        await this.domCaptureManager.displayCapture(capture);
        response.markdown(`### DOM Capture Displayed

**Test:** ${capture.testName}  
**Time:** ${capture.timestamp.toLocaleString()}  
**Location:** ${capture.folder}

The capture has been opened in your editor.`);
    }

    /**
     * Handle search captures command
     */
    private async handleSearchCaptures(params: string[], response: any): Promise<void> {
        const query = params.join(' ') || '';
        const results = query 
            ? await this.domCaptureManager.searchCaptures(query)
            : await this.domCaptureManager.getAllCaptures();
        
        if (results.length === 0) {
            response.markdown('No captures found matching your search.');
            return;
        }
        
        const limited = results.slice(0, 10);
        let markdown = `### Search Results (${results.length} found)\n\n`;
        
        for (const capture of limited) {
            markdown += `- **${capture.testName}** - ${capture.timestamp.toLocaleString()}\n`;
        }
        
        if (results.length > 10) {
            markdown += `\n*Showing first 10 results. Use the DOM Captures view for more.*`;
        }
        
        response.markdown(markdown);
    }

    /**
     * Handle analyze capture command
     */
    private async handleAnalyzeCapture(params: string[], response: any): Promise<void> {
        const capture = params.length > 0 
            ? await this.findCaptureByName(params[0])
            : await this.domCaptureManager.getLatestCapture();
        
        if (!capture) {
            response.markdown('No captures found to analyze.');
            return;
        }
        
        // Provide analysis suggestions
        let markdown = `### DOM Capture Analysis\n\n`;
        markdown += `**Test:** ${capture.testName}\n\n`;
        markdown += `**Captured:** ${capture.timestamp.toLocaleString()}\n\n`;
        markdown += `**Available Files:**\n`;
        markdown += `- DOM: ${capture.domPath ? '' : 'L'}\n`;
        markdown += `- Screenshot: ${capture.screenshotPath ? '' : 'L'}\n`;
        markdown += `- Report: ${capture.reportPath ? '' : 'L'}\n`;
        markdown += `- Metadata: ${capture.metadataPath ? '' : 'L'}\n\n`;
        
        markdown += `**Analysis Tips:**\n`;
        markdown += `1. Check the DOM structure for missing or incorrect elements\n`;
        markdown += `2. Review the screenshot for visual issues\n`;
        markdown += `3. Examine the report for error details and stack traces\n`;
        markdown += `4. Look for timing issues or race conditions\n`;
        markdown += `5. Verify element selectors and locators\n`;
        
        response.markdown(markdown);
    }

    /**
     * Handle summary command
     */
    private async handleSummary(response: any): Promise<void> {
        const captures = await this.domCaptureManager.getAllCaptures();
        
        if (captures.length === 0) {
            response.markdown('No DOM captures available. Run failing tests to generate captures.');
            return;
        }
        
        // Calculate statistics
        const uniqueTests = new Set(captures.map(c => c.testName));
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayCaptures = captures.filter(c => c.timestamp >= today);
        
        const oldestCapture = captures.reduce((oldest, current) => 
            current.timestamp < oldest.timestamp ? current : oldest
        );
        const newestCapture = captures.reduce((newest, current) => 
            current.timestamp > newest.timestamp ? current : newest
        );
        
        let markdown = `### DOM Captures Summary\n\n`;
        markdown += `**Total Captures:** ${captures.length}\n`;
        markdown += `**Unique Tests:** ${uniqueTests.size}\n`;
        markdown += `**Today's Captures:** ${todayCaptures.length}\n\n`;
        markdown += `**Latest Capture:** ${newestCapture.testName} (${newestCapture.timestamp.toLocaleString()})\n`;
        markdown += `**Oldest Capture:** ${oldestCapture.testName} (${oldestCapture.timestamp.toLocaleString()})\n\n`;
        
        // Most failed tests
        const testCounts = new Map<string, number>();
        captures.forEach(c => {
            testCounts.set(c.testName, (testCounts.get(c.testName) || 0) + 1);
        });
        
        const topTests = Array.from(testCounts.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);
        
        if (topTests.length > 0) {
            markdown += `**Most Failed Tests:**\n`;
            topTests.forEach(([test, count]) => {
                markdown += `- ${test}: ${count} failures\n`;
            });
        }
        
        response.markdown(markdown);
    }

    /**
     * Handle help command
     */
    private async handleHelp(response: any): Promise<void> {
        const markdown = `### DOM Generator Copilot Commands

**Available Commands:**

- **Show/Display** - Show the latest capture or a specific test
  - Example: "Show latest capture"
  - Example: "Display loginTest failure"

- **Search/Find** - Search for captures
  - Example: "Search for login failures"
  - Example: "Find captures from today"

- **Analyze/Explain** - Analyze a capture
  - Example: "Analyze the latest failure"
  - Example: "Explain loginTest capture"

- **Summary/Overview** - Show capture statistics
  - Example: "Show summary"
  - Example: "Give me an overview"

**Tips:**
- Use quotes for exact test names: "Show 'testUserLogin' capture"
- Captures are automatically created when tests fail
- Access captures through the DOM Captures view in the Explorer`;
        
        response.markdown(markdown);
    }

    /**
     * Find capture by test name
     */
    private async findCaptureByName(name: string): Promise<DOMCapture | undefined> {
        const captures = await this.domCaptureManager.searchCaptures(name);
        return captures.length > 0 ? captures[0] : undefined;
    }
}