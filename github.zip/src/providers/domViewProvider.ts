import * as vscode from 'vscode';
import * as path from 'path';
import { DOMCapture, DOMCaptureManager } from '../managers/domCaptureManager';
import { FileUtils } from '../utils/fileUtils';
import { MAX_CAPTURES_IN_VIEW } from '../utils/constants';

/**
 * Tree data provider for DOM captures view
 */
export class DOMViewProvider implements vscode.TreeDataProvider<DOMCaptureItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<DOMCaptureItem | undefined | null | void> = new vscode.EventEmitter<DOMCaptureItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<DOMCaptureItem | undefined | null | void> = this._onDidChangeTreeData.event;
    
    private captureManager: DOMCaptureManager;
    private captures: DOMCapture[] = [];

    constructor(private context: vscode.ExtensionContext) {
        this.captureManager = new DOMCaptureManager(context);
        this.loadCaptures();
    }

    async loadCaptures(): Promise<void> {
        try {
            this.captures = await this.captureManager.getAllCaptures();
            // Limit to prevent performance issues
            if (this.captures.length > MAX_CAPTURES_IN_VIEW) {
                this.captures = this.captures.slice(0, MAX_CAPTURES_IN_VIEW);
            }
        } catch (error) {
            console.error('Failed to load captures:', error);
            this.captures = [];
        }
    }

    refresh(): void {
        this.loadCaptures().then(() => {
            this._onDidChangeTreeData.fire();
        });
    }

    getTreeItem(element: DOMCaptureItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: DOMCaptureItem): Promise<DOMCaptureItem[]> {
        if (!element) {
            // Root level - group by date
            await this.loadCaptures();
            const grouped = this.groupCapturesByDate();
            return Array.from(grouped.entries()).map(([date, captures]) => 
                new DOMCaptureItem(
                    date,
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'date-folder',
                    undefined,
                    captures
                )
            );
        } else if (element.type === 'date-folder') {
            // Date folder level - show captures
            return element.captures!.map(capture => 
                new DOMCaptureItem(
                    capture.testName,
                    vscode.TreeItemCollapsibleState.None,
                    'capture',
                    capture
                )
            );
        }
        
        return [];
    }

    private groupCapturesByDate(): Map<string, DOMCapture[]> {
        const grouped = new Map<string, DOMCapture[]>();
        
        for (const capture of this.captures) {
            const dateStr = capture.timestamp.toLocaleDateString();
            if (!grouped.has(dateStr)) {
                grouped.set(dateStr, []);
            }
            grouped.get(dateStr)!.push(capture);
        }
        
        // Sort dates descending
        return new Map([...grouped.entries()].sort((a, b) => 
            new Date(b[0]).getTime() - new Date(a[0]).getTime()
        ));
    }

    async getCapture(item: DOMCaptureItem): Promise<DOMCapture | undefined> {
        return item.capture;
    }
}

/**
 * Tree item for DOM capture view
 */
class DOMCaptureItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly type: 'date-folder' | 'capture',
        public readonly capture?: DOMCapture,
        public readonly captures?: DOMCapture[]
    ) {
        super(label, collapsibleState);
        
        this.tooltip = this.getTooltip();
        this.contextValue = type;
        
        if (type === 'capture' && capture) {
            this.command = {
                command: 'domGenerator.openCapture',
                title: 'Open Capture',
                arguments: [capture]
            };
            
            this.iconPath = new vscode.ThemeIcon('file-code');
            this.description = capture.timestamp.toLocaleTimeString();
        } else if (type === 'date-folder') {
            this.iconPath = new vscode.ThemeIcon('folder');
            this.description = `${captures?.length || 0} captures`;
        }
    }

    private getTooltip(): string {
        if (this.type === 'capture' && this.capture) {
            return `Test: ${this.capture.testName}
Time: ${this.capture.timestamp.toLocaleString()}
Path: ${this.capture.folder}`;
        } else if (this.type === 'date-folder') {
            return `Date: ${this.label}
Captures: ${this.captures?.length || 0}`;
        }
        return this.label;
    }
}

export { DOMCaptureItem };