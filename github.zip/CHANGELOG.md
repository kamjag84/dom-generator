# Changelog

All notable changes to the DOM Generator extension will be documented in this file.

## [2.0.0] - 2024-01-15

### Added
- Automatic build system detection for Maven and Gradle
- Support for Gradle Kotlin DSL
- Multi-module project support
- WebDriver strategy selection UI
- Test report dashboard
- CI/CD configuration export for 6 platforms
- Search functionality for captures
- Progress notifications
- Build status bar indicator
- Test coverage integration with JaCoCo

### Enhanced
- Improved error handling with recovery options
- Better terminal output parsing
- Enhanced screenshot viewer with zoom controls
- Metadata capture for all test failures

### Fixed
- Thread-safe WebDriver access
- Build file change detection
- Test configuration updates
- Memory leaks in file watchers

## [1.0.0] - 2024-01-01

### Initial Release
- Basic DOM capture functionality
- TestNG integration
- Screenshot capture
- Report generation
- VSCode tree view
- Copilot chat integration