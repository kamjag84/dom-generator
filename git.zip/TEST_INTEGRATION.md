# 🎯 Playwright Test Integration - Runtime DOM Capture

## ✨ The Solution to Your Pain Point

This integration allows you to **capture DOM at ANY point during test execution** by pressing **Ctrl+Shift+C**, maintaining all state, session, and context - perfect for debugging positive test cases!

## 🚀 Quick Start

### 1. Automatic Setup (Recommended)
```bash
node setupTestIntegration.js
```

### 2. Manual Setup
```typescript
// In your test file
import { test, expect } from './src/testIntegration/playwrightTestHelper';

test('your test', async ({ page, enableHotkeyCapture, domCapture }) => {
  // Enable Ctrl+Shift+C hotkey
  await enableHotkeyCapture();
  
  // Your test continues normally...
  await page.goto('https://example.com/login');
  
  // PRESS Ctrl+Shift+C ANYTIME TO CAPTURE DOM!
  
  // Or capture programmatically
  await domCapture({ stepName: 'After Login' });
});
```

## 🎮 How It Works

### During Test Execution:

1. **Press `Ctrl+Shift+C`** at ANY moment to capture current DOM
2. **Visual feedback** appears confirming capture
3. **All state preserved**: cookies, localStorage, form data, scroll positions
4. **Works across tabs**: Captures from active tab or all tabs
5. **Non-intrusive**: Doesn't interrupt test flow

### Your Use Case Solved:

```typescript
test('complex multi-step flow', async ({ page, enableHotkeyCapture }) => {
  await enableHotkeyCapture();
  
  // Step 1: Login
  await page.goto('https://app.com/login');
  await page.fill('#username', 'user@example.com');
  await page.fill('#password', 'password');
  await page.click('#login');
  
  // ➡️ PRESS Ctrl+Shift+C to capture after login!
  
  // Step 2: Opens new tab
  const newTab = await page.context().newPage();
  await newTab.goto('https://app.com/form');
  
  // Step 3: Fill form in new tab
  await newTab.fill('#field1', 'value1');
  await newTab.fill('#field2', 'value2');
  
  // ➡️ PRESS Ctrl+Shift+C to capture form state!
  
  // Step 4: Submit and redirect
  await newTab.click('#submit');
  await newTab.waitForURL('https://app.com/success');
  
  // ➡️ PRESS Ctrl+Shift+C to capture success page!
  
  // Step 5: More actions
  await page.bringToFront();
  await page.click('#logout');
  
  // ➡️ PRESS Ctrl+Shift+C to capture final state!
});
```

## 📸 Features

### 1. **Hotkey Capture** (Ctrl+Shift+C)
- Works instantly during test execution
- Visual notification when captured
- Floating capture button also available

### 2. **Programmatic Capture**
```typescript
await domCapture({
  stepName: 'Custom Step Name',
  includeScreenshot: true,
  redactSensitive: true,
  customMetadata: {
    testId: 'TEST-123',
    environment: 'staging'
  }
});
```

### 3. **Multi-Tab Capture**
```typescript
// Capture all open tabs at once
await captureAllTabs({
  stepName: 'All Tabs State',
  includeScreenshot: true
});
```

### 4. **State Preservation**
- ✅ Form data (inputs, selects, textareas)
- ✅ Scroll positions (window and elements)
- ✅ localStorage & sessionStorage
- ✅ Cookies
- ✅ Shadow DOM
- ✅ Iframes
- ✅ Canvas elements

### 5. **Automatic Capture Triggers**
```typescript
// Set up automatic captures
await page.evaluate(() => {
  // Capture on errors
  window.addEventListener('error', () => {
    (window as any).captureDom('Error occurred');
  });
  
  // Capture on specific events
  document.addEventListener('submit', () => {
    (window as any).captureDom('Form submitted');
  });
});
```

## 📁 Output Structure

Captures are saved in organized structure:
```
test-results/
└── dom-captures/
    └── 08-29-2025/                     # Date folder
        └── login_flow_test/            # Test name
            ├── capture_1_09-15-30.html # Timestamped captures
            ├── capture_1_screenshot.png
            ├── capture_1_metadata.json
            ├── capture_2_09-16-45.html # Next capture
            └── ...
```

## 🛠️ Configuration

### Global Setup (playwright.config.ts)
```typescript
import { defineConfig } from '@playwright/test';
import { domCaptureConfig } from './src/testIntegration/runtimeInjector';

export default defineConfig({
  use: {
    ...domCaptureConfig.use,
  },
  globalSetup: domCaptureConfig.globalSetup,
  globalTeardown: domCaptureConfig.globalTeardown,
});
```

### For Existing Tests (No Modification Needed!)
```typescript
test.beforeEach(async ({ enableHotkeyCapture }) => {
  await enableHotkeyCapture();
});

// All your existing tests now have capture capability!
```

## 🎯 Visual Indicators

When DOM Capture is active, you'll see:
1. **Floating button** (📸) in bottom-right corner
2. **Console message**: "🎯 DOM Capture injected - Press Ctrl+Shift+C to capture"
3. **Green notification** when capture succeeds
4. **Capture count** in test results

## 🔧 Advanced Usage

### Custom Capture Points
```typescript
// In your page object or helper
export async function captureAtCriticalPoint(page: Page, reason: string) {
  await page.evaluate((r) => {
    (window as any).captureDom(r);
  }, reason);
}
```

### Conditional Captures
```typescript
test('capture on condition', async ({ page, domCapture }) => {
  const response = await page.goto('https://example.com');
  
  if (response.status() !== 200) {
    await domCapture({
      stepName: `HTTP ${response.status()} Error`,
      includeScreenshot: true
    });
  }
});
```

### Capture with Retry
```typescript
for (let attempt = 1; attempt <= 3; attempt++) {
  try {
    await page.click('#flaky-button');
    break;
  } catch (error) {
    await domCapture({
      stepName: `Retry Attempt ${attempt}`,
      customMetadata: { error: error.message }
    });
    if (attempt === 3) throw error;
  }
}
```

## 📊 Captured Metadata

Each capture includes:
- Test name and file
- Step name and number
- Timestamp
- URL and page title
- Browser viewport
- Performance metrics
- Network requests count
- Memory usage
- Test duration
- Custom metadata

## 🔒 Security

- **PII Redaction**: Automatically redacts passwords, tokens, emails
- **Sensitive data masking**: Credit cards, SSNs, API keys
- **Configurable whitelist/blacklist**

## 🚦 Troubleshooting

### Ctrl+Shift+C not working?
1. Ensure `enableHotkeyCapture()` is called
2. Check browser has focus
3. Try clicking the floating 📸 button

### Captures not appearing?
- Check `test-results/dom-captures/` folder
- Look for console message: "✅ DOM Captured"
- Verify write permissions

### Performance impact?
- Minimal overhead (~10ms per page)
- Captures are async, don't block test
- Use `redactSensitive: false` for faster captures

## 📈 Best Practices

1. **Enable at test start**: Call `enableHotkeyCapture()` early
2. **Name your steps**: Use descriptive `stepName` values
3. **Capture before assertions**: Helps debug failures
4. **Use metadata**: Add context with `customMetadata`
5. **Clean old captures**: Set retention policy

## 🎉 Summary

You can now:
- ✅ Press **Ctrl+Shift+C** during ANY test to capture DOM
- ✅ Maintain all session state and context
- ✅ Capture from multiple tabs/windows
- ✅ Debug positive test cases effectively
- ✅ No test interruption or side effects

**Your pain point is solved!** 🎯