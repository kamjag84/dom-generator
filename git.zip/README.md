# 🎭 Playwright DOM Capture Extension for VS Code

A powerful VS Code extension that captures complete DOM trees during Playwright test execution, preserving all state, styles, and resources for debugging and analysis.

## ✨ Features

### 🚀 Automatic Capture on Test Failure
- Automatically captures full DOM when Playwright tests fail
- Preserves exact state at the moment of failure
- Includes all form data, styles, and dynamic content

### 📸 On-Demand Capture During Tests
- **Ctrl+Shift+C** - Capture DOM during test execution
- Capture at any point in your test flow
- Perfect for debugging multi-step test scenarios

### 🖱️ Manual DOM Capture
- **Ctrl+Alt+C** (Cmd+Alt+C on Mac) - Capture any webpage manually
- Works outside of test context
- Great for quick debugging and analysis

### 📁 Organized Folder Structure
All captures are automatically organized in a clean, navigable structure:

```
test-results/
└── dom-captures/
    ├── DD-MM-YYYY/                        # Date folders
    │   └── ClassName_MethodName/          # Test-specific folders
    │       ├── capture_1_HH-MM-SS.html    # DOM captures
    │       └── capture_1_HH-MM-SS_metadata.json
    └── manual-dom-captures/               # Manual captures
        └── DD-MM-YYYY/
            └── manual_capture_example_com_HH-MM-SS.html
```

## 📦 Installation

### From VSIX Package
1. Download the `playwright-dom-capture-1.0.0.vsix` file
2. Open VS Code
3. Press `Ctrl+Shift+P` and run "Extensions: Install from VSIX..."
4. Select the downloaded VSIX file

### From Source
```bash
# Clone the repository
git clone <repository-url>
cd Playwright-domCapture

# Install dependencies
npm install

# Build and package
npm run compile
npm run package
```

## 🚦 Getting Started

### 1. Auto-Configure Your Project
Press `Ctrl+Shift+P` and run:
```
DOM Capture: Auto-configure Project
```

This will:
- Install necessary dependencies
- Update your Playwright configuration
- Set up the DOM capture utilities

### 2. Add to Your Tests

#### Method 1: Automatic on Failure
Tests will automatically capture DOM on failure - no code changes needed!

#### Method 2: Manual Capture Points
Add capture points in your tests:

```typescript
import { test } from '@playwright/test';
import { captureDom } from './domCapture/testIntegration/playwrightTestHelper';

test('user login flow', async ({ page }) => {
    await page.goto('https://example.com/login');
    
    // Capture before login
    await captureDom(page, 'before-login');
    
    await page.fill('#username', 'testuser');
    await page.fill('#password', 'password');
    await page.click('#login-button');
    
    // Capture after login
    await captureDom(page, 'after-login');
});
```

#### Method 3: Runtime Capture
During test execution, press **Ctrl+Shift+C** at any moment to capture the current DOM state.


## 📋 Available Commands

Access these commands via `Ctrl+Shift+P`:

| Command | Description | Shortcut |
|---------|-------------|----------|
| `DOM Capture: Auto-configure Project` | Set up DOM capture in your project | - |
| `DOM Capture: Capture Current Page` | Manually capture any webpage | `Ctrl+Alt+C` |
| `DOM Capture: Show Dashboard` | View all captures in dashboard | - |
| `DOM Capture: Show Last Capture` | Open the most recent capture | - |
| `DOM Capture: Clean Old Captures` | Remove captures older than retention period | - |
| `DOM Capture: Toggle Auto-capture` | Enable/disable automatic capture on failure | - |
| `DOM Capture: Verify Configuration` | Check if DOM capture is properly configured | - |

## 🎯 Use Cases

### Debugging Test Failures
When a test fails, the extension automatically captures:
- Complete DOM structure with all nested elements
- All CSS styles (inline and external)
- Form field values and states
- JavaScript-rendered content
- Shadow DOM content
- Iframe contents

### Multi-Step Test Analysis
For complex user flows:
1. Add capture points at critical steps
2. Or use `Ctrl+Shift+C` during test execution
3. Review the exact state at each step
4. Compare DOM between steps to identify issues

### Manual Testing Support
Use `Ctrl+Alt+C` to capture any webpage:
- Quick debugging of production issues
- Capturing reference states
- Documentation and reporting

## ⚙️ Configuration

Configure via VS Code settings (`Ctrl+,`):

```json
{
  "playwright-dom-capture.autoCapture": true,
  "playwright-dom-capture.captureOnFailure": true,
  "playwright-dom-capture.retentionDays": 7,
  "playwright-dom-capture.compressionLevel": "medium",
  "playwright-dom-capture.enableDeduplication": true,
  "playwright-dom-capture.maxFileSize": 10
}
```

### Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| `autoCapture` | `true` | Enable automatic capture on test failure |
| `captureOnFailure` | `true` | Capture DOM when tests fail |
| `retentionDays` | `7` | Days to keep captures before cleanup |
| `compressionLevel` | `medium` | Compression level: none, low, medium, high |
| `enableDeduplication` | `true` | Avoid duplicate captures of identical DOM |
| `maxFileSize` | `10` | Maximum capture file size in MB |

## 🔍 What Gets Captured?

### Complete DOM Structure
- All HTML elements and attributes
- Shadow DOM components
- Web Components
- Iframes (including nested)

### Styles & Resources
- All CSS (inline, embedded, external)
- Images as base64
- Fonts as base64
- SVG elements

### Dynamic State
- Form field values
- Checkbox/radio states
- Dropdown selections
- LocalStorage data
- SessionStorage data
- Scroll positions

### Metadata
Each capture includes metadata:
- URL and timestamp
- Test name and status
- Browser viewport size
- Performance metrics
- Error messages (for failures)

## 🤝 GitHub Copilot Integration

The extension integrates with GitHub Copilot Chat:

```
@domcapture analyze last failure
@domcapture compare captures
@domcapture find form issues
```

## 🛡️ Advanced Features

### Compression & Optimization
- Smart HTML compression (configurable levels)
- Deduplication of identical captures
- Chunking for large files
- Incremental diff storage

### Multi-Tab Support
- Capture across multiple tabs/windows
- Preserve tab relationships
- Maintain navigation context

### State Preservation
- Complete form state
- Dynamic JavaScript state
- Storage API contents
- Cookie values (sanitized)

## 📊 Dashboard Features

Access via `DOM Capture: Show Dashboard`:
- Visual timeline of all captures
- Quick preview of captures
- Filtering by date/test/status
- Comparison tools
- Export capabilities

## 🔧 Troubleshooting

### Captures Not Appearing
1. Verify configuration: `DOM Capture: Verify Configuration`
2. Check folder permissions in `test-results/`
3. Ensure Playwright is properly installed

### Large File Sizes
1. Adjust compression level in settings
2. Enable deduplication
3. Configure retention period for automatic cleanup

### Keyboard Shortcuts Not Working
1. Check for conflicts in keyboard shortcuts (`Ctrl+K Ctrl+S`)
2. Ensure the extension is activated
3. Restart VS Code if needed

## 🚀 Best Practices

1. **Regular Cleanup**: Use `DOM Capture: Clean Old Captures` periodically
2. **Strategic Capture Points**: Place captures before and after critical operations
3. **Use Compression**: Enable compression for large applications
4. **Review Metadata**: Check metadata files for performance insights
5. **Leverage Comparisons**: Compare captures to identify changes

## 📝 Examples

### Basic Test with DOM Capture
```typescript
import { test, expect } from '@playwright/test';

test('checkout flow', async ({ page }) => {
    await page.goto('https://shop.example.com');
    
    // Product selection
    await page.click('[data-product-id="123"]');
    // Press Ctrl+Shift+C here to capture state
    
    // Add to cart
    await page.click('#add-to-cart');
    // Press Ctrl+Shift+C to capture cart state
    
    // Checkout
    await page.click('#checkout');
    // Automatic capture on any failure
});
```

### Manual Capture Workflow
1. Press `Ctrl+Alt+C`
2. Enter URL: `https://example.com`
3. View capture in `test-results/dom-captures/manual-dom-captures/`

## 📄 License

MIT

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues and pull requests.

## 📞 Support

- Report issues: [GitHub Issues](https://github.com/your-repo/issues)
- Documentation: [Wiki](https://github.com/your-repo/wiki)
- Discussions: [GitHub Discussions](https://github.com/your-repo/discussions)

---

**Made with ❤️ for Playwright testers and developers**