import { Page } from 'playwright';

export interface PageState {
  forms: FormState[];
  scrollPositions: ScrollPosition[];
  localStorage: Record<string, any>;
  sessionStorage: Record<string, any>;
  cookies: Cookie[];
  windowState: WindowState;
  interactions: UserInteraction[];
  customDataAttributes: Record<string, any>;
  ariaStates: AriaState[];
}

export interface FormState {
  selector: string;
  type: string;
  name?: string;
  id?: string;
  value: any;
  checked?: boolean;
  selectedIndex?: number;
  selectedOptions?: string[];
}

export interface ScrollPosition {
  selector: string;
  scrollTop: number;
  scrollLeft: number;
}

export interface Cookie {
  name: string;
  value: string;
  domain: string;
  path: string;
  expires?: number;
  httpOnly: boolean;
  secure: boolean;
  sameSite?: 'Strict' | 'Lax' | 'None';
}

export interface WindowState {
  width: number;
  height: number;
  scrollX: number;
  scrollY: number;
  devicePixelRatio: number;
  orientation?: string;
}

export interface UserInteraction {
  type: 'click' | 'input' | 'change' | 'focus' | 'blur' | 'hover';
  selector: string;
  timestamp: string;
  value?: any;
  coordinates?: { x: number; y: number };
}

export interface AriaState {
  selector: string;
  attributes: Record<string, string>;
}

export class StateCapture {
  private page: Page;
  private interactions: UserInteraction[] = [];

  constructor(page: Page) {
    this.page = page;
  }

  async captureFullState(): Promise<PageState> {
    // Set up interaction tracking
    await this.setupInteractionTracking();

    const state: PageState = {
      forms: await this.captureFormState(),
      scrollPositions: await this.captureScrollPositions(),
      localStorage: await this.captureLocalStorage(),
      sessionStorage: await this.captureSessionStorage(),
      cookies: await this.captureCookies(),
      windowState: await this.captureWindowState(),
      interactions: this.interactions,
      customDataAttributes: await this.captureCustomDataAttributes(),
      ariaStates: await this.captureAriaStates()
    };

    return state;
  }

  private async setupInteractionTracking(): Promise<void> {
    await this.page.addInitScript(() => {
      const interactions: any[] = [];
      
      // Track clicks
      document.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        interactions.push({
          type: 'click',
          selector: target.tagName + (target.id ? `#${target.id}` : ''),
          timestamp: new Date().toISOString(),
          coordinates: { x: e.clientX, y: e.clientY }
        });
      }, true);

      // Track inputs
      document.addEventListener('input', (e) => {
        const target = e.target as HTMLInputElement;
        interactions.push({
          type: 'input',
          selector: target.tagName + (target.id ? `#${target.id}` : ''),
          timestamp: new Date().toISOString(),
          value: target.value
        });
      }, true);

      // Track focus/blur
      document.addEventListener('focus', (e) => {
        const target = e.target as HTMLElement;
        interactions.push({
          type: 'focus',
          selector: target.tagName + (target.id ? `#${target.id}` : ''),
          timestamp: new Date().toISOString()
        });
      }, true);

      document.addEventListener('blur', (e) => {
        const target = e.target as HTMLElement;
        interactions.push({
          type: 'blur',
          selector: target.tagName + (target.id ? `#${target.id}` : ''),
          timestamp: new Date().toISOString()
        });
      }, true);

      // Store interactions globally
      (window as any).__interactions = interactions;
    });
  }

  private async captureFormState(): Promise<FormState[]> {
    return await this.page.evaluate(() => {
      const forms: FormState[] = [];
      
      // Capture all form elements
      const formElements = document.querySelectorAll('input, textarea, select');
      
      formElements.forEach((element, index) => {
        const el = element as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
        const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
        
        const state: FormState = {
          selector,
          type: el.type || el.tagName.toLowerCase(),
          name: el.name,
          id: el.id,
          value: null
        };

        if (el instanceof HTMLInputElement) {
          if (el.type === 'checkbox' || el.type === 'radio') {
            state.checked = el.checked;
            state.value = el.value;
          } else if (el.type === 'file') {
            state.value = el.files ? Array.from(el.files).map(f => f.name) : [];
          } else {
            state.value = el.value;
          }
        } else if (el instanceof HTMLTextAreaElement) {
          state.value = el.value;
        } else if (el instanceof HTMLSelectElement) {
          state.selectedIndex = el.selectedIndex;
          state.selectedOptions = Array.from(el.selectedOptions).map(opt => opt.value);
          state.value = el.value;
        }

        forms.push(state);
      });

      return forms;
    });
  }

  private async captureScrollPositions(): Promise<ScrollPosition[]> {
    return await this.page.evaluate(() => {
      const positions: ScrollPosition[] = [];
      
      // Capture window scroll
      positions.push({
        selector: 'window',
        scrollTop: window.scrollY || document.documentElement.scrollTop,
        scrollLeft: window.scrollX || document.documentElement.scrollLeft
      });

      // Capture all scrollable elements
      const elements = document.querySelectorAll('*');
      elements.forEach((element, index) => {
        const el = element as HTMLElement;
        if (el.scrollHeight > el.clientHeight || el.scrollWidth > el.clientWidth) {
          if (el.scrollTop > 0 || el.scrollLeft > 0) {
            positions.push({
              selector: `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`,
              scrollTop: el.scrollTop,
              scrollLeft: el.scrollLeft
            });
          }
        }
      });

      return positions;
    });
  }

  private async captureLocalStorage(): Promise<Record<string, any>> {
    return await this.page.evaluate(() => {
      const storage: Record<string, any> = {};
      
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const value = localStorage.getItem(key);
          try {
            // Try to parse JSON values
            storage[key] = JSON.parse(value || '');
          } catch {
            // Store as string if not JSON
            storage[key] = value;
          }
        }
      }
      
      return storage;
    });
  }

  private async captureSessionStorage(): Promise<Record<string, any>> {
    return await this.page.evaluate(() => {
      const storage: Record<string, any> = {};
      
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          const value = sessionStorage.getItem(key);
          try {
            // Try to parse JSON values
            storage[key] = JSON.parse(value || '');
          } catch {
            // Store as string if not JSON
            storage[key] = value;
          }
        }
      }
      
      return storage;
    });
  }

  private async captureCookies(): Promise<Cookie[]> {
    const cookies = await this.page.context().cookies();
    return cookies.map(cookie => ({
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path,
      expires: cookie.expires,
      httpOnly: cookie.httpOnly,
      secure: cookie.secure,
      sameSite: cookie.sameSite as 'Strict' | 'Lax' | 'None' | undefined
    }));
  }

  private async captureWindowState(): Promise<WindowState> {
    return await this.page.evaluate(() => {
      return {
        width: window.innerWidth,
        height: window.innerHeight,
        scrollX: window.scrollX,
        scrollY: window.scrollY,
        devicePixelRatio: window.devicePixelRatio,
        orientation: screen.orientation?.type
      };
    });
  }

  private async captureCustomDataAttributes(): Promise<Record<string, any>> {
    return await this.page.evaluate(() => {
      const dataAttributes: Record<string, any> = {};
      
      // Find all elements with data attributes
      const elements = document.querySelectorAll('[data-*]');
      
      elements.forEach((element, index) => {
        const el = element as HTMLElement;
        const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
        const attrs: Record<string, string> = {};
        
        // Get all data attributes
        for (const attr of el.attributes) {
          if (attr.name.startsWith('data-')) {
            attrs[attr.name] = attr.value;
          }
        }
        
        if (Object.keys(attrs).length > 0) {
          dataAttributes[selector] = attrs;
        }
      });
      
      return dataAttributes;
    });
  }

  private async captureAriaStates(): Promise<AriaState[]> {
    return await this.page.evaluate(() => {
      const ariaStates: AriaState[] = [];
      
      // Find all elements with ARIA attributes
      const elements = document.querySelectorAll('[aria-*], [role]');
      
      elements.forEach((element, index) => {
        const el = element as HTMLElement;
        const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
        const attributes: Record<string, string> = {};
        
        // Get all ARIA attributes
        for (const attr of el.attributes) {
          if (attr.name.startsWith('aria-') || attr.name === 'role') {
            attributes[attr.name] = attr.value;
          }
        }
        
        if (Object.keys(attributes).length > 0) {
          ariaStates.push({ selector, attributes });
        }
      });
      
      return ariaStates;
    });
  }

  async restoreState(state: PageState): Promise<void> {
    // Restore localStorage
    await this.page.evaluate((storage) => {
      localStorage.clear();
      for (const [key, value] of Object.entries(storage)) {
        localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
      }
    }, state.localStorage);

    // Restore sessionStorage
    await this.page.evaluate((storage) => {
      sessionStorage.clear();
      for (const [key, value] of Object.entries(storage)) {
        sessionStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
      }
    }, state.sessionStorage);

    // Restore form state
    for (const formState of state.forms) {
      await this.page.evaluate((state) => {
        const element = document.querySelector(state.selector) as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
        if (element) {
          if (element instanceof HTMLInputElement) {
            if (element.type === 'checkbox' || element.type === 'radio') {
              element.checked = state.checked || false;
            } else {
              element.value = state.value || '';
            }
          } else if (element instanceof HTMLTextAreaElement) {
            element.value = state.value || '';
          } else if (element instanceof HTMLSelectElement) {
            if (state.selectedIndex !== undefined) {
              element.selectedIndex = state.selectedIndex;
            }
          }
        }
      }, formState);
    }

    // Restore scroll positions
    for (const position of state.scrollPositions) {
      if (position.selector === 'window') {
        await this.page.evaluate((pos) => {
          window.scrollTo(pos.scrollLeft, pos.scrollTop);
        }, position);
      } else {
        await this.page.evaluate((pos) => {
          const element = document.querySelector(pos.selector) as HTMLElement;
          if (element) {
            element.scrollTop = pos.scrollTop;
            element.scrollLeft = pos.scrollLeft;
          }
        }, position);
      }
    }
  }
}