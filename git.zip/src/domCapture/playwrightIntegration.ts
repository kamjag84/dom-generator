import { Page, BrowserContext, Browser, chromium } from 'playwright';
import * as path from 'path';
import * as fs from 'fs-extra';

export interface PlaywrightIntegrationOptions {
  enableTracing: boolean;
  enableVideo: boolean;
  enableScreenshots: boolean;
  enableHar: boolean;
  enableCoverage: boolean;
  enableLighthouse: boolean;
  tracingOptions?: {
    screenshots: boolean;
    snapshots: boolean;
    sources: boolean;
  };
  videoOptions?: {
    size?: { width: number; height: number };
    
  };
}

export interface IntegrationResult {
  domCapture: string;
  trace?: string;
  video?: string;
  screenshots?: string[];
  har?: any;
  coverage?: any;
  lighthouse?: any;
  performance?: PerformanceReport;
}

export interface PerformanceReport {
  metrics: any;
  timing: any;
  resources: any[];
  userTimings: any[];
  paintTimings: any[];
}

export class PlaywrightIntegration {
  private options: PlaywrightIntegrationOptions;
  private browser: Browser | null = null;
  private context: BrowserContext | null = null;
  private page: Page | null = null;
  private outputDir: string;

  constructor(outputDir: string, options: Partial<PlaywrightIntegrationOptions> = {}) {
    this.outputDir = outputDir;
    this.options = {
      enableTracing: true,
      enableVideo: true,
      enableScreenshots: true,
      enableHar: true,
      enableCoverage: false,
      enableLighthouse: false,
      tracingOptions: {
        screenshots: true,
        snapshots: true,
        sources: true
      },
      videoOptions: {
        size: { width: 1280, height: 720 }
      },
      ...options
    };
  }

  async initialize(): Promise<void> {
    this.browser = await chromium.launch({
      headless: true,
      args: ['--enable-features=NetworkService']
    });

    const contextOptions: any = {
      viewport: { width: 1280, height: 720 },
      ignoreHTTPSErrors: true
    };

    if (this.options.enableVideo) {
      contextOptions.recordVideo = {
        dir: path.join(this.outputDir, 'videos'),
        size: this.options.videoOptions?.size
      };
    }

    if (this.options.enableHar) {
      contextOptions.recordHar = {
        path: path.join(this.outputDir, 'network.har'),
        mode: 'full'
      };
    }

    this.context = await this.browser.newContext(contextOptions);

    if (this.options.enableTracing) {
      await this.context.tracing.start({
        screenshots: this.options.tracingOptions?.screenshots,
        snapshots: this.options.tracingOptions?.snapshots,
        sources: this.options.tracingOptions?.sources
      });
    }

    this.page = await this.context.newPage();

    if (this.options.enableCoverage) {
      await this.page.coverage.startJSCoverage();
      await this.page.coverage.startCSSCoverage();
    }

    // Set up performance observer
    await this.setupPerformanceObserver();
  }

  private async setupPerformanceObserver(): Promise<void> {
    if (!this.page) return;

    await this.page.addInitScript(() => {
      // Capture performance metrics
      window.addEventListener('load', () => {
        (window as any).__performanceMetrics = {
          navigation: performance.getEntriesByType('navigation')[0],
          resources: performance.getEntriesByType('resource'),
          paints: performance.getEntriesByType('paint'),
          measures: performance.getEntriesByType('measure'),
          marks: performance.getEntriesByType('mark'),
          layoutShifts: performance.getEntriesByType('layout-shift'),
          largestContentfulPaint: performance.getEntriesByType('largest-contentful-paint'),
          firstInput: performance.getEntriesByType('first-input'),
          memory: (performance as any).memory,
          timing: performance.timing
        };
      });

      // Track user interactions
      const interactions: any[] = [];
      ['click', 'input', 'scroll', 'keydown'].forEach(eventType => {
        document.addEventListener(eventType, (e) => {
          interactions.push({
            type: eventType,
            timestamp: performance.now(),
            target: e.target ? (e.target as HTMLElement).tagName : null
          });
        }, { passive: true, capture: true });
      });
      (window as any).__userInteractions = interactions;

      // Track errors
      const errors: any[] = [];
      window.addEventListener('error', (e) => {
        errors.push({
          message: e.message,
          filename: e.filename,
          lineno: e.lineno,
          colno: e.colno,
          timestamp: performance.now()
        });
      });
      (window as any).__pageErrors = errors;
    });
  }

  async captureWithIntegration(url: string): Promise<IntegrationResult> {
    if (!this.page || !this.context) {
      throw new Error('PlaywrightIntegration not initialized');
    }

    const result: IntegrationResult = {
      domCapture: ''
    };

    // Navigate to the page
    await this.page.goto(url, { waitUntil: 'networkidle' });

    // Take screenshots at different points
    if (this.options.enableScreenshots) {
      result.screenshots = await this.captureScreenshots();
    }

    // Capture the DOM
    result.domCapture = await this.page.content();

    // Get performance metrics
    result.performance = await this.capturePerformance();

    // Get coverage if enabled
    if (this.options.enableCoverage) {
      result.coverage = await this.captureCoverage();
    }

    // Run Lighthouse audit if enabled
    if (this.options.enableLighthouse) {
      result.lighthouse = await this.runLighthouseAudit(url);
    }

    // Stop tracing and save
    if (this.options.enableTracing) {
      const tracePath = path.join(this.outputDir, 'trace.zip');
      await this.context.tracing.stop({ path: tracePath });
      result.trace = tracePath;
    }

    // Save video
    if (this.options.enableVideo) {
      await this.page.close();
      const video = this.page.video();
      if (video) {
        const videoPath = await video.path();
        result.video = videoPath;
      }
    }

    // Save HAR file
    if (this.options.enableHar) {
      await this.context.close();
      result.har = path.join(this.outputDir, 'network.har');
    }

    return result;
  }

  private async captureScreenshots(): Promise<string[]> {
    if (!this.page) return [];

    const screenshots: string[] = [];
    const screenshotDir = path.join(this.outputDir, 'screenshots');
    await fs.ensureDir(screenshotDir);

    // Initial screenshot
    const initialPath = path.join(screenshotDir, 'initial.png');
    await this.page.screenshot({ path: initialPath, fullPage: false });
    screenshots.push(initialPath);

    // Full page screenshot
    const fullPath = path.join(screenshotDir, 'fullpage.png');
    await this.page.screenshot({ path: fullPath, fullPage: true });
    screenshots.push(fullPath);

    // Viewport screenshot after scroll
    await this.page.evaluate(() => window.scrollTo(0, document.body.scrollHeight / 2));
    const midPath = path.join(screenshotDir, 'mid-scroll.png');
    await this.page.screenshot({ path: midPath });
    screenshots.push(midPath);

    return screenshots;
  }

  private async capturePerformance(): Promise<PerformanceReport> {
    if (!this.page) {
      return {
        metrics: {},
        timing: {},
        resources: [],
        userTimings: [],
        paintTimings: []
      };
    }

    // Skip browser metrics - not available in current Playwright version
    const metrics = {};

    // Get performance data from page
    const performanceData = await this.page.evaluate(() => {
      return {
        metrics: (window as any).__performanceMetrics || {},
        interactions: (window as any).__userInteractions || [],
        errors: (window as any).__pageErrors || []
      };
    });

    // Get additional timing information
    const timing = await this.page.evaluate(() => {
      const perf = window.performance;
      const navigation = perf.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      
      return {
        // Navigation timing
        navigationStart: navigation?.startTime || 0,
        domContentLoaded: navigation?.domContentLoadedEventEnd || 0,
        loadComplete: navigation?.loadEventEnd || 0,
        
        // Core Web Vitals
        FCP: perf.getEntriesByName('first-contentful-paint')[0]?.startTime || 0,
        LCP: perf.getEntriesByType('largest-contentful-paint')[0]?.startTime || 0,
        FID: (perf.getEntriesByType('first-input')[0] as any)?.processingStart || 0,
        CLS: perf.getEntriesByType('layout-shift')
          .filter((entry: any) => !entry.hadRecentInput)
          .reduce((sum: number, entry: any) => sum + entry.value, 0),
        TTFB: navigation?.responseStart - navigation?.requestStart || 0
      };
    });

    return {
      metrics,
      timing,
      resources: performanceData.metrics.resources || [],
      userTimings: performanceData.metrics.measures || [],
      paintTimings: performanceData.metrics.paints || []
    };
  }

  private async captureCoverage(): Promise<any> {
    if (!this.page) return null;

    const [jsCoverage, cssCoverage] = await Promise.all([
      this.page.coverage.stopJSCoverage(),
      this.page.coverage.stopCSSCoverage()
    ]);

    // Calculate coverage percentages
    const calculateCoverage = (entries: any[]) => {
      let totalBytes = 0;
      let usedBytes = 0;

      for (const entry of entries) {
        totalBytes += entry.text.length;
        for (const range of entry.ranges) {
          usedBytes += range.end - range.start;
        }
      }

      return {
        totalBytes,
        usedBytes,
        percentage: totalBytes > 0 ? (usedBytes / totalBytes) * 100 : 0
      };
    };

    return {
      js: {
        entries: jsCoverage,
        summary: calculateCoverage(jsCoverage)
      },
      css: {
        entries: cssCoverage,
        summary: calculateCoverage(cssCoverage)
      }
    };
  }

  private async runLighthouseAudit(url: string): Promise<any> {
    // This would integrate with Lighthouse
    // For now, return a placeholder
    return {
      performance: 0,
      accessibility: 0,
      bestPractices: 0,
      seo: 0,
      pwa: 0
    };
  }

  async generateComparisonReport(
    capture1: IntegrationResult,
    capture2: IntegrationResult
  ): Promise<any> {
    const report = {
      domChanges: this.compareDom(capture1.domCapture, capture2.domCapture),
      performanceChanges: this.comparePerformance(capture1.performance, capture2.performance),
      coverageChanges: this.compareCoverage(capture1.coverage, capture2.coverage)
    };

    return report;
  }

  private compareDom(dom1: string, dom2: string): any {
    // Simple comparison - in production, use a proper diff algorithm
    const lines1 = dom1.split('\n');
    const lines2 = dom2.split('\n');
    
    let additions = 0;
    let deletions = 0;
    let modifications = 0;

    const maxLines = Math.max(lines1.length, lines2.length);
    for (let i = 0; i < maxLines; i++) {
      if (i >= lines1.length) {
        additions++;
      } else if (i >= lines2.length) {
        deletions++;
      } else if (lines1[i] !== lines2[i]) {
        modifications++;
      }
    }

    return {
      additions,
      deletions,
      modifications,
      totalChanges: additions + deletions + modifications
    };
  }

  private comparePerformance(perf1?: PerformanceReport, perf2?: PerformanceReport): any {
    if (!perf1 || !perf2) return null;

    return {
      loadTimeDiff: (perf2.timing.loadComplete || 0) - (perf1.timing.loadComplete || 0),
      FCPDiff: (perf2.timing.FCP || 0) - (perf1.timing.FCP || 0),
      LCPDiff: (perf2.timing.LCP || 0) - (perf1.timing.LCP || 0),
      CLSDiff: (perf2.timing.CLS || 0) - (perf1.timing.CLS || 0),
      resourceCountDiff: (perf2.resources?.length || 0) - (perf1.resources?.length || 0)
    };
  }

  private compareCoverage(cov1: any, cov2: any): any {
    if (!cov1 || !cov2) return null;

    return {
      jsCoverageDiff: (cov2.js?.summary.percentage || 0) - (cov1.js?.summary.percentage || 0),
      cssCoverageDiff: (cov2.css?.summary.percentage || 0) - (cov1.css?.summary.percentage || 0)
    };
  }

  async exportReport(result: IntegrationResult, format: 'html' | 'json' | 'pdf' = 'html'): Promise<string> {
    const reportPath = path.join(this.outputDir, `report.${format}`);

    switch (format) {
      case 'json':
        await fs.writeJson(reportPath, result, { spaces: 2 });
        break;
      
      case 'html':
        const htmlReport = this.generateHtmlReport(result);
        await fs.writeFile(reportPath, htmlReport, 'utf-8');
        break;
      
      case 'pdf':
        // Would need a PDF generation library
        break;
    }

    return reportPath;
  }

  private generateHtmlReport(result: IntegrationResult): string {
    return `<!DOCTYPE html>
<html>
<head>
    <title>DOM Capture Integration Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .metric { display: flex; justify-content: space-between; padding: 5px 0; }
        .metric-label { font-weight: bold; }
        .metric-value { color: #007ACC; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>DOM Capture Integration Report</h1>
    
    <div class="section">
        <h2>Capture Summary</h2>
        <div class="metric">
            <span class="metric-label">DOM Size:</span>
            <span class="metric-value">${result.domCapture.length} bytes</span>
        </div>
        ${result.trace ? `
        <div class="metric">
            <span class="metric-label">Trace File:</span>
            <span class="metric-value">${result.trace}</span>
        </div>` : ''}
        ${result.video ? `
        <div class="metric">
            <span class="metric-label">Video Recording:</span>
            <span class="metric-value">${result.video}</span>
        </div>` : ''}
    </div>
    
    ${result.performance ? `
    <div class="section">
        <h2>Performance Metrics</h2>
        <div class="metric">
            <span class="metric-label">First Contentful Paint:</span>
            <span class="metric-value">${result.performance.timing.FCP}ms</span>
        </div>
        <div class="metric">
            <span class="metric-label">Largest Contentful Paint:</span>
            <span class="metric-value">${result.performance.timing.LCP}ms</span>
        </div>
        <div class="metric">
            <span class="metric-label">Cumulative Layout Shift:</span>
            <span class="metric-value">${result.performance.timing.CLS}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Time to First Byte:</span>
            <span class="metric-value">${result.performance.timing.TTFB}ms</span>
        </div>
    </div>` : ''}
    
    ${result.coverage ? `
    <div class="section">
        <h2>Code Coverage</h2>
        <div class="metric">
            <span class="metric-label">JavaScript Coverage:</span>
            <span class="metric-value">${result.coverage.js.summary.percentage.toFixed(2)}%</span>
        </div>
        <div class="metric">
            <span class="metric-label">CSS Coverage:</span>
            <span class="metric-value">${result.coverage.css.summary.percentage.toFixed(2)}%</span>
        </div>
    </div>` : ''}
    
    ${result.screenshots ? `
    <div class="section">
        <h2>Screenshots</h2>
        ${result.screenshots.map(s => `<p>📸 ${path.basename(s)}</p>`).join('')}
    </div>` : ''}
</body>
</html>`;
  }

  async cleanup(): Promise<void> {
    if (this.page) await this.page.close();
    if (this.context) await this.context.close();
    if (this.browser) await this.browser.close();
  }
}