import { Page, BrowserContext } from 'playwright';

export interface EnhancedMetadata {
  // Basic Information
  timestamp: string;
  url: string;
  title: string;
  description?: string;
  keywords?: string[];
  
  // Browser & Device
  viewport: ViewportInfo;
  userAgent: string;
  platform: string;
  devicePixelRatio: number;
  colorDepth: number;
  screenResolution: { width: number; height: number };
  availableScreenSize: { width: number; height: number };
  deviceMemory?: number;
  hardwareConcurrency?: number;
  
  // Performance Metrics
  performance: PerformanceMetrics;
  resourceTimings: ResourceTiming[];
  
  // Network Activity
  networkRequests: NetworkRequest[];
  failedRequests: NetworkRequest[];
  totalRequests: number;
  totalTransferSize: number;
  
  // Console Activity
  consoleLogs: ConsoleLog[];
  errors: ErrorLog[];
  warnings: ConsoleLog[];
  
  // Page Resources
  resources: PageResources;
  
  // Security & Privacy
  security: SecurityInfo;
  
  // Accessibility
  accessibility: AccessibilityInfo;
  
  // Custom Metrics
  customMetrics?: Record<string, any>;
}

export interface ViewportInfo {
  width: number;
  height: number;
  orientation: 'portrait' | 'landscape';
  isFullscreen: boolean;
}

export interface PerformanceMetrics {
  loadTime: number;
  domContentLoaded: number;
  firstPaint?: number;
  firstContentfulPaint?: number;
  largestContentfulPaint?: number;
  firstInputDelay?: number;
  cumulativeLayoutShift?: number;
  timeToInteractive?: number;
  totalBlockingTime?: number;
  speedIndex?: number;
  memoryUsage?: {
    usedJSHeapSize: number;
    totalJSHeapSize: number;
    jsHeapSizeLimit: number;
  };
}

export interface ResourceTiming {
  name: string;
  entryType: string;
  startTime: number;
  duration: number;
  transferSize: number;
  encodedBodySize: number;
  decodedBodySize: number;
  serverTiming?: any[];
}

export interface NetworkRequest {
  url: string;
  method: string;
  status?: number;
  statusText?: string;
  requestHeaders: Record<string, string>;
  responseHeaders?: Record<string, string>;
  mimeType?: string;
  resourceType: string;
  transferSize?: number;
  responseTime?: number;
  startTime: string;
  endTime?: string;
  failure?: string;
}

export interface ConsoleLog {
  type: 'log' | 'info' | 'warn' | 'error' | 'debug' | 'trace';
  message: string;
  timestamp: string;
  args?: any[];
  location?: string;
}

export interface ErrorLog extends ConsoleLog {
  stack?: string;
  name?: string;
}

export interface PageResources {
  scripts: number;
  stylesheets: number;
  images: number;
  fonts: number;
  videos: number;
  audios: number;
  iframes: number;
  totalSize: number;
  externalResources: number;
  inlineResources: number;
}

export interface SecurityInfo {
  protocol: string;
  isSecure: boolean;
  hasMixedContent: boolean;
  certificateInfo?: {
    issuer?: string;
    validFrom?: string;
    validTo?: string;
  };
  cspPolicy?: string;
  permissions?: string[];
}

export interface AccessibilityInfo {
  hasLandmarks: boolean;
  hasHeadings: boolean;
  hasAriaLabels: boolean;
  imagesWithAlt: number;
  imagesWithoutAlt: number;
  formLabels: number;
  contrastIssues?: number;
  wcagLevel?: 'A' | 'AA' | 'AAA';
}

export class MetadataCollector {
  private page: Page;
  private context: BrowserContext;
  private networkRequests: NetworkRequest[] = [];
  private consoleLogs: ConsoleLog[] = [];
  private errors: ErrorLog[] = [];

  constructor(page: Page, context: BrowserContext) {
    this.page = page;
    this.context = context;
  }

  async collectFullMetadata(): Promise<EnhancedMetadata> {
    // Set up listeners
    await this.setupListeners();

    // Collect all metadata
    const [
      basicInfo,
      deviceInfo,
      performance,
      resources,
      security,
      accessibility
    ] = await Promise.all([
      this.collectBasicInfo(),
      this.collectDeviceInfo(),
      this.collectPerformanceMetrics(),
      this.collectPageResources(),
      this.collectSecurityInfo(),
      this.collectAccessibilityInfo()
    ]);

    return {
      timestamp: new Date().toISOString(),
      url: this.page.url(),
      title: '',
      viewport: { width: 0, height: 0, orientation: 'landscape', isFullscreen: false }, // Default viewport
      userAgent: deviceInfo.userAgent || navigator.userAgent,
      platform: deviceInfo.platform || navigator.platform,
      devicePixelRatio: window.devicePixelRatio || 1,
      colorDepth: window.screen.colorDepth || 24,
      screenResolution: { width: window.screen.width, height: window.screen.height },
      availableScreenSize: { width: window.screen.availWidth, height: window.screen.availHeight },
      ...basicInfo,
      ...deviceInfo,
      performance,
      resourceTimings: await this.collectResourceTimings(),
      networkRequests: this.networkRequests,
      failedRequests: this.networkRequests.filter(r => r.failure || (r.status && r.status >= 400)),
      totalRequests: this.networkRequests.length,
      totalTransferSize: this.networkRequests.reduce((sum, r) => sum + (r.transferSize || 0), 0),
      consoleLogs: this.consoleLogs,
      errors: this.errors,
      warnings: this.consoleLogs.filter(log => log.type === 'warn'),
      resources,
      security,
      accessibility
    };
  }

  private async setupListeners(): Promise<void> {
    // Listen to console events
    this.page.on('console', async msg => {
      const log: ConsoleLog = {
        type: msg.type() as any,
        message: msg.text(),
        timestamp: new Date().toISOString(),
        location: msg.location().url
      };

      if (msg.type() === 'error') {
        this.errors.push(log as ErrorLog);
      } else {
        this.consoleLogs.push(log);
      }
    });

    // Listen to page errors
    this.page.on('pageerror', error => {
      this.errors.push({
        type: 'error',
        message: error.message,
        stack: error.stack,
        name: error.name,
        timestamp: new Date().toISOString()
      });
    });

    // Listen to network requests
    this.page.on('request', request => {
      this.networkRequests.push({
        url: request.url(),
        method: request.method(),
        requestHeaders: request.headers(),
        resourceType: request.resourceType(),
        startTime: new Date().toISOString()
      });
    });

    this.page.on('response', response => {
      const request = this.networkRequests.find(r => r.url === response.url());
      if (request) {
        request.status = response.status();
        request.statusText = response.statusText();
        request.responseHeaders = response.headers();
        request.endTime = new Date().toISOString();
      }
    });

    this.page.on('requestfailed', request => {
      const req = this.networkRequests.find(r => r.url === request.url());
      if (req) {
        req.failure = request.failure()?.errorText || 'Unknown error';
      }
    });
  }

  private async collectBasicInfo(): Promise<Partial<EnhancedMetadata>> {
    return await this.page.evaluate(() => {
      const getMeta = (name: string): string | undefined => {
        const meta = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
        return meta?.getAttribute('content') || undefined;
      };

      return {
        timestamp: new Date().toISOString(),
        url: window.location.href,
        title: document.title,
        description: getMeta('description'),
        keywords: getMeta('keywords')?.split(',').map(k => k.trim())
      };
    });
  }

  private async collectDeviceInfo(): Promise<Partial<EnhancedMetadata>> {
    return await this.page.evaluate(() => {
      return {
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
          orientation: window.innerWidth > window.innerHeight ? 'landscape' : 'portrait',
          isFullscreen: document.fullscreenElement !== null
        },
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        devicePixelRatio: window.devicePixelRatio,
        colorDepth: screen.colorDepth,
        screenResolution: {
          width: screen.width,
          height: screen.height
        },
        availableScreenSize: {
          width: screen.availWidth,
          height: screen.availHeight
        },
        deviceMemory: (navigator as any).deviceMemory,
        hardwareConcurrency: navigator.hardwareConcurrency
      };
    });
  }

  private async collectPerformanceMetrics(): Promise<PerformanceMetrics> {
    return await this.page.evaluate(() => {
      const perf = performance.timing;
      const paintMetrics = performance.getEntriesByType('paint');
      
      const getFCP = () => {
        const fcp = paintMetrics.find(p => p.name === 'first-contentful-paint');
        return fcp?.startTime;
      };

      const getFP = () => {
        const fp = paintMetrics.find(p => p.name === 'first-paint');
        return fp?.startTime;
      };

      const getLCP = () => {
        const entries = performance.getEntriesByType('largest-contentful-paint');
        const lastEntry = entries[entries.length - 1];
        return lastEntry?.startTime;
      };

      const getCLS = () => {
        let clsScore = 0;
        let sessionValue = 0;
        let sessionEntries: any[] = [];
        
        const entries = performance.getEntriesByType('layout-shift');
        entries.forEach((entry: any) => {
          if (!entry.hadRecentInput) {
            sessionValue += entry.value;
            sessionEntries.push(entry);
          }
        });
        
        return sessionValue;
      };

      const memoryUsage = (performance as any).memory ? {
        usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
        totalJSHeapSize: (performance as any).memory.totalJSHeapSize,
        jsHeapSizeLimit: (performance as any).memory.jsHeapSizeLimit
      } : undefined;

      return {
        loadTime: perf.loadEventEnd - perf.navigationStart,
        domContentLoaded: perf.domContentLoadedEventEnd - perf.navigationStart,
        firstPaint: getFP(),
        firstContentfulPaint: getFCP(),
        largestContentfulPaint: getLCP(),
        cumulativeLayoutShift: getCLS(),
        memoryUsage
      };
    });
  }

  private async collectResourceTimings(): Promise<ResourceTiming[]> {
    return await this.page.evaluate(() => {
      const entries = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
      
      return entries.map(entry => ({
        name: entry.name,
        entryType: entry.entryType,
        startTime: entry.startTime,
        duration: entry.duration,
        transferSize: entry.transferSize || 0,
        encodedBodySize: entry.encodedBodySize || 0,
        decodedBodySize: entry.decodedBodySize || 0,
        serverTiming: entry.serverTiming ? Array.from(entry.serverTiming) : []
      }));
    });
  }

  private async collectPageResources(): Promise<PageResources> {
    return await this.page.evaluate(() => {
      const resources = {
        scripts: document.querySelectorAll('script').length,
        stylesheets: document.querySelectorAll('link[rel="stylesheet"], style').length,
        images: document.querySelectorAll('img').length,
        fonts: document.querySelectorAll('link[rel="preload"][as="font"], link[rel="prefetch"][as="font"]').length,
        videos: document.querySelectorAll('video').length,
        audios: document.querySelectorAll('audio').length,
        iframes: document.querySelectorAll('iframe').length,
        totalSize: 0,
        externalResources: 0,
        inlineResources: 0
      };

      // Count external vs inline resources
      document.querySelectorAll('script').forEach(script => {
        if (script.src) {
          resources.externalResources++;
        } else {
          resources.inlineResources++;
        }
      });

      document.querySelectorAll('link[rel="stylesheet"], style').forEach(style => {
        if ((style as HTMLLinkElement).href) {
          resources.externalResources++;
        } else {
          resources.inlineResources++;
        }
      });

      // Calculate approximate total size from resource timings
      const timings = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
      resources.totalSize = timings.reduce((sum, t) => sum + (t.transferSize || 0), 0);

      return resources;
    });
  }

  private async collectSecurityInfo(): Promise<SecurityInfo> {
    return await this.page.evaluate(() => {
      const getCSP = (): string | undefined => {
        const meta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
        return meta?.getAttribute('content') || undefined;
      };

      const checkMixedContent = (): boolean => {
        const insecureResources = document.querySelectorAll(
          'img[src^="http:"], script[src^="http:"], link[href^="http:"], iframe[src^="http:"]'
        );
        return insecureResources.length > 0;
      };

      return {
        protocol: window.location.protocol,
        isSecure: window.location.protocol === 'https:',
        hasMixedContent: window.location.protocol === 'https:' && checkMixedContent(),
        cspPolicy: getCSP(),
        permissions: (navigator as any).permissions ? [] : undefined
      };
    });
  }

  private async collectAccessibilityInfo(): Promise<AccessibilityInfo> {
    return await this.page.evaluate(() => {
      const images = document.querySelectorAll('img');
      let imagesWithAlt = 0;
      let imagesWithoutAlt = 0;
      
      images.forEach(img => {
        if (img.alt) {
          imagesWithAlt++;
        } else {
          imagesWithoutAlt++;
        }
      });

      const formLabels = document.querySelectorAll('label').length;
      const hasLandmarks = document.querySelector('[role="main"], [role="navigation"], [role="banner"]') !== null;
      const hasHeadings = document.querySelector('h1, h2, h3, h4, h5, h6') !== null;
      const hasAriaLabels = document.querySelector('[aria-label], [aria-labelledby]') !== null;

      return {
        hasLandmarks,
        hasHeadings,
        hasAriaLabels,
        imagesWithAlt,
        imagesWithoutAlt,
        formLabels
      };
    });
  }
}