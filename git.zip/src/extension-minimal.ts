console.log('[MINIMAL-TEST] Extension file loading...');

import * as vscode from 'vscode';

console.log('[MINIMAL-TEST] VS Code imported');

export function activate(context: vscode.ExtensionContext) {
    console.log('[MINIMAL-TEST] Activate function called');
    
    // Show immediate feedback
    vscode.window.showInformationMessage('Playwright DOM Capture: Extension is activating...');
    
    // Register a simple test command
    const testCommand = vscode.commands.registerCommand('playwright-dom-capture.test', () => {
        vscode.window.showInformationMessage('Test command works!');
        console.log('[MINIMAL-TEST] Test command executed');
    });
    
    // Register the actual command with minimal implementation
    const autoConfigCommand = vscode.commands.registerCommand('playwright-dom-capture.autoConfigureProject', () => {
        vscode.window.showInformationMessage('Auto-configure command is working! Full implementation coming soon.');
        console.log('[MINIMAL-TEST] autoConfigureProject command executed');
    });
    
    context.subscriptions.push(testCommand);
    context.subscriptions.push(autoConfigCommand);
    
    // Register all other commands with placeholder implementations
    const commands = [
        'verifyConfig',
        'showLastCapture', 
        'rollbackConfig',
        'showDashboard',
        'addCapturePoint',
        'toggleAutoCapture',
        'cleanCaptures',
        'captureCurrentPage'
    ];
    
    commands.forEach(cmdName => {
        const cmd = vscode.commands.registerCommand(`playwright-dom-capture.${cmdName}`, () => {
            vscode.window.showInformationMessage(`Command ${cmdName} is registered and working!`);
            console.log(`[MINIMAL-TEST] ${cmdName} command executed`);
        });
        context.subscriptions.push(cmd);
    });
    
    console.log('[MINIMAL-TEST] All commands registered successfully');
    vscode.window.showInformationMessage('Playwright DOM Capture: Ready! All commands registered.');
}

export function deactivate() {
    console.log('[MINIMAL-TEST] Extension deactivated');
}