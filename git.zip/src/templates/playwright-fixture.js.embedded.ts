// Embedded playwright-fixture.js content for packaged extension
export = `/**
 * Playwright Test Fixture with DOM Capture Integration
 * Automatically installed by Playwright DOM Capture VS Code Extension
 * 
 * This fixture adds DOM capture capabilities to your Playwright tests:
 * - Automatic capture on test failure
 * - Manual capture via captureDom() function
 * - Runtime capture via Ctrl+Shift+C hotkey
 */

const base = require('@playwright/test');
const { captureDom } = require('./capture');
const path = require('path');
const fs = require('fs').promises;

// Global flag to track if runtime capture is enabled
let runtimeCaptureEnabled = false;

/**
 * Extended test fixture with DOM capture capabilities
 */
exports.test = base.test.extend({
    // Auto-inject DOM capture capability into page
    page: async ({ page, browserName }, use, testInfo) => {
        // Store test info for capture context
        process.env.CURRENT_TEST_NAME = testInfo.title;
        process.env.CURRENT_TEST_FILE = path.basename(testInfo.file || 'unknown');
        
        // Enable runtime capture hotkey (Ctrl+Shift+C)
        if (!runtimeCaptureEnabled) {
            await enableRuntimeCapture(page);
        }
        
        // Add capture method to page
        page.captureDom = async (label) => {
            return await captureDom(page, label);
        };
        
        try {
            // Use the page in the test
            await use(page);
        } catch (error) {
            // Automatic capture on test failure
            if (testInfo.status === 'failed' || testInfo.status === 'timedOut') {
                try {
                    console.log('Test failed - capturing DOM...');
                    await captureDom(page, 'test-failure', { 
                        isFailure: true,
                        error: error.message 
                    });
                } catch (captureError) {
                    console.error('Failed to capture DOM on test failure:', captureError);
                }
            }
            throw error; // Re-throw the original error
        }
    },
    
    // Provide captureDom as a fixture
    captureDom: async ({ page }, use) => {
        const capture = async (label) => {
            return await captureDom(page, label);
        };
        await use(capture);
    }
});

/**
 * Enable runtime capture with Ctrl+Shift+C hotkey
 */
async function enableRuntimeCapture(page) {
    try {
        // Inject hotkey listener into the page
        await page.evaluateOnNewDocument(() => {
            let captureCounter = 0;
            
            document.addEventListener('keydown', async (event) => {
                // Check for Ctrl+Shift+C (or Cmd+Shift+C on Mac)
                if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'C') {
                    event.preventDefault();
                    event.stopPropagation();
                    
                    captureCounter++;
                    
                    // Show visual feedback
                    const feedback = document.createElement('div');
                    feedback.textContent = \`📸 DOM Capture #\${captureCounter} triggered!\`;
                    feedback.style.cssText = \`
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: #4CAF50;
                        color: white;
                        padding: 15px 20px;
                        border-radius: 5px;
                        font-family: system-ui, -apple-system, sans-serif;
                        font-size: 14px;
                        font-weight: 500;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                        z-index: 999999;
                        animation: slideIn 0.3s ease-out;
                    \`;
                    
                    // Add animation
                    const style = document.createElement('style');
                    style.textContent = \`
                        @keyframes slideIn {
                            from { transform: translateX(100%); opacity: 0; }
                            to { transform: translateX(0); opacity: 1; }
                        }
                        @keyframes slideOut {
                            from { transform: translateX(0); opacity: 1; }
                            to { transform: translateX(100%); opacity: 0; }
                        }
                    \`;
                    document.head.appendChild(style);
                    document.body.appendChild(feedback);
                    
                    // Signal to Playwright that capture was triggered
                    window.__domCaptureTriggered = {
                        timestamp: new Date().toISOString(),
                        count: captureCounter
                    };
                    
                    // Remove feedback after 3 seconds
                    setTimeout(() => {
                        feedback.style.animation = 'slideOut 0.3s ease-out';
                        setTimeout(() => feedback.remove(), 300);
                    }, 3000);
                }
            });
            
            console.log('🎯 DOM Capture hotkey (Ctrl+Shift+C) enabled for this page');
        });
        
        // Set up polling to detect when capture is triggered
        page.on('framenavigated', async () => {
            // Re-enable on navigation
            await enableRuntimeCapture(page);
        });
        
        // Poll for capture trigger
        const checkInterval = setInterval(async () => {
            try {
                const triggered = await page.evaluate(() => {
                    const capture = window.__domCaptureTriggered;
                    if (capture) {
                        window.__domCaptureTriggered = null; // Reset
                        return capture;
                    }
                    return null;
                });
                
                if (triggered) {
                    console.log(\`📸 Runtime capture triggered at \${triggered.timestamp}\`);
                    await captureDom(page, \`runtime-capture-\${triggered.count}\`);
                }
            } catch (e) {
                // Page might be closed or navigated away
                clearInterval(checkInterval);
            }
        }, 500); // Check every 500ms
        
        // Clean up interval when page closes
        page.once('close', () => {
            clearInterval(checkInterval);
        });
        
        runtimeCaptureEnabled = true;
    } catch (error) {
        console.warn('Failed to enable runtime capture:', error);
    }
}

// Re-export expect for convenience
exports.expect = base.expect;`;