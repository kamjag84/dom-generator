# PGAFX PDC Integration

**Spring Boot application that polls Pega PDC Notification API and forwards alerts to BigPanda AIOps in real-time.**

## Architecture

```
┌────────────────────┐     REST/OAuth2      ┌──────────────────────┐
│   Pega PDC         │◄────── GET ──────────│                      │
│   Notification API │──── JSON Response ──►│   Spring Boot App    │
│  (Multiple Systems)│                      │   (This Application) │
└────────────────────┘                      │                      │
                                            │  ┌────────────────┐  │
                                            │  │ Scheduled Poll │  │
                                            │  │ (1 min default)│  │
                                            │  └───────┬────────┘  │
                                            │          │           │
                                            │  ┌───────▼────────┐  │
                                            │  │ ResultsMapper  │  │
                                            │  │ PDC → BigPanda │  │
                                            │  └───────┬────────┘  │
                                            │          │           │
                                            └──────────┼───────────┘
                                                       │
                                              REST POST (JSON)
                                                       │
                                            ┌──────────▼───────────┐
                                            │   BigPanda AIOps     │
                                            │   REST API           │
                                            │   /api/v2/alert      │
                                            └──────────────────────┘
                                                       │
                                              (Already handled by
                                               your company)
                                                       ▼
                                            ┌──────────────────────┐
                                            │   ServiceNow         │
                                            └──────────────────────┘
```

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Language | Java 17 |
| Framework | Spring Boot 3.2.5 |
| PDC Polling | RestTemplate + Apache HttpClient 5 |
| BigPanda Send | WebClient (reactive, non-blocking) |
| Auth | OAuth2 client_credentials |
| SSL | JKS keystore + truststore |
| Secrets | HashiCorp Vault via Harness |
| Scheduling | Spring `@Scheduled` with configurable interval |
| Retry | Resilience4j (exponential backoff) |
| Metrics | Micrometer + Prometheus |
| Deployment | Helm 3 + OpenShift |
| Build | Gradle 8.7 + Docker multi-stage |

## Project Structure

```
pgafx-pdc-integration/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/gradle-wrapper.properties
├── Dockerfile
├── src/main/java/com/wellsfargo/pgafx/pdc/integrationapp/
│   ├── IntegrationappApplication.java       # Main entry point
│   ├── config/
│   │   ├── PdcIntegrationProperties.java    # All config properties (YAML list approach)
│   │   ├── RestTemplateConfig.java          # RestTemplate with SSL, proxy, pooling
│   │   └── WebClientConfig.java             # WebClient for BigPanda
│   ├── model/
│   │   ├── pdc/
│   │   │   ├── PdcNotificationResponse.java # PDC API response wrapper
│   │   │   └── PdcResult.java               # Individual PDC notification
│   │   └── bigpanda/
│   │       ├── AIOpsAlertRequest.java        # BigPanda request {"alerts": [...]}
│   │       ├── AIOpsAlert.java               # Individual alert fields
│   │       └── AIOpsAlertResponse.java       # BigPanda response
│   ├── mapper/
│   │   └── ResultsMapper.java               # PDC → BigPanda field mapping
│   ├── service/
│   │   ├── PdcPollingService.java           # Core: scheduled poll + orchestration
│   │   └── AIOpsService.java                # Sends alerts to BigPanda (with retry)
│   ├── security/
│   │   └── OAuth2TokenService.java          # Token cache + refresh for Pega OAuth2
│   ├── health/
│   │   └── AppHealthIndicator.java          # Custom actuator health check
│   └── exception/
│       ├── PdcApiException.java
│       ├── AIOpsApiException.java
│       └── MappingException.java
├── src/main/resources/
│   ├── application.yml                      # Default config with all settings
│   └── application-cloud.yml                # Cloud/OpenShift overrides
└── k8s-cd/charts/
    ├── Chart.yaml
    ├── templates/
    │   ├── _helpers.tpl
    │   ├── configmap.yaml
    │   ├── deployment.yaml
    │   ├── service.yaml
    │   ├── route.yaml
    │   ├── hpa.yaml
    │   └── secret.yaml
    └── releases/
        ├── dev/values.yaml
        ├── sit/values.yaml
        ├── uat/values.yaml
        └── prod/values.yaml
```

## Configuration

### Polling Interval (Configurable)

Default: **1 minute (60000ms)**

Change via environment variable or values.yaml:
```yaml
pdcintegration:
  polling:
    fixed-delay-ms: 60000      # Change to desired interval in ms
    initial-delay-ms: 10000    # Delay before first poll after startup
```

Or via environment variable:
```
PDCINTEGRATION_POLLING_FIXED_DELAY_MS=30000   # 30 seconds
```

### Endpoints (Clean YAML List)

```yaml
pdcintegration:
  endpoints:
    - name: "PEGA-DEVB"
      url: "https://pdck-na2.pega.net/prweb/api1/PDCNotificationAPI/v2/..."
      enabled: true                          # Toggle per endpoint
      environment: "DEVELOPMENT"
      ci-name: "PGAFX-PEGA SMART INVESTIGATE-DEVELOPMENT"
      event-ticket: "WHLSTECHPEGASI"         # Configurable per endpoint

    - name: "PEGA-UATB"
      url: "https://pdck-na2.pega.net/prweb/api1/PDCNotificationAPI/v2/..."
      enabled: true
      environment: "UAT"
      ci-name: "PGAFX-Wires"
      event-ticket: "PLATPEGASI Support"     # Different ticket for UAT
```

### Field Mapping (PDC → BigPanda)

| PDC Field | BigPanda Alert Field | Source |
|-----------|---------------------|--------|
| `CorrelationID` | `event_unique_key` | PDC response |
| — | `event_severity` | Always "ERROR" |
| `MsgID` | `event_name` | PDC response |
| `LineInfo` | `event_description` | PDC response |
| `eventSource` | `event_source` | Config (default: "pgafx") |
| `snService` | `sn_service` | Config |
| `snCategory` | `sn_category` | Config |
| `snSubcategory` | `sn_subcategory` | Config |
| `snImpact` | `sn_impact` | Config (default: "3") |
| `snUrgency` | `sn_urgency` | Config (default: "3") |
| `eventTargetTicket` | `event_target_ticket` | Config (default: "managed by") |
| `eventTicket` | `event_ticket` | **Per endpoint** |
| `ciWfAppid` | `ci_wf_appid` | Config (default: "PGAFX") |
| `ciName` | `ci_name` | **Per endpoint** |
| `environment` | `ci_environment` | **Per endpoint** |
| `ciBasicType` | `ci_basic_type` | Config (default: "application") |

## Build & Run

### Local Development
```bash
./gradlew bootWar
java -jar build/libs/pgafx-pdc-integration.war \
  --PEGA_OAUTH_CLIENT_ID=your_client_id \
  --PEGA_OAUTH_CLIENT_SECRET=your_secret \
  --AIOPS_APP_KEY=your_app_key
```

### Run Directly with Gradle
```bash
./gradlew bootRun \
  --args='--PEGA_OAUTH_CLIENT_ID=your_client_id --PEGA_OAUTH_CLIENT_SECRET=your_secret --AIOPS_APP_KEY=your_app_key'
```

### Docker Build
```bash
docker build -t pgafx-pdc-integration:latest .
docker run -p 8080:8080 \
  -e PEGA_OAUTH_CLIENT_ID=xxx \
  -e PEGA_OAUTH_CLIENT_SECRET=xxx \
  -e AIOPS_APP_KEY=xxx \
  pgafx-pdc-integration:latest
```

### Helm Deploy to OpenShift
```bash
helm upgrade --install pgafx-pdc-integration \
  ./k8s-cd/charts \
  -f ./k8s-cd/charts/releases/dev/values.yaml \
  -n pgafx-dev
```

## Health & Monitoring

- **Health endpoint**: `GET /actuator/health`
- **Metrics**: `GET /actuator/prometheus`
- **Custom metrics**:
  - `pdc.poll.success` — successful PDC API calls
  - `pdc.poll.failure` — failed PDC API calls
  - `pdc.poll.duration` — polling cycle duration
  - `aiops.alerts.sent` — alerts sent to BigPanda
  - `aiops.alerts.failed` — failed BigPanda sends

## Vault Integration

Secrets are referenced in Helm values using Harness Vault expressions:
```yaml
secrets:
  pegaOAuthClientSecret: "<+secrets.getValue('hashicorpvault://apppgafx_hehv_np/PGAFX/non-prod/dev#PegaOAuthClient.secret')>"
```

**Before deployment, validate all Vault paths are correct for your environment.**
