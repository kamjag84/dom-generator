# PHASE 1: COMPLETE CODE INVENTORY

## 📁 Project Structure Overview

### Total Files: 37 TypeScript files

## 🗂️ Core Files Categorization

### **1. Extension Entry & Core (3 files)**
- `src/extension.ts` - Main extension entry point
- `src/core/ExtensionCore.ts` - Central extension manager
- `src/core/CommandManager.ts` - Command management
- `src/core/CommandDefinitions.ts` - Command definitions

### **2. Test Integration (3 files)** - CRITICAL FOR DOM CAPTURE
- `src/testIntegration/playwrightIntegration.ts` - Main Playwright integration
- `src/testIntegration/playwrightTestHelper.ts` - Test capture manager
- `src/testIntegration/playwrightFixtures.ts` - Test fixtures
- `src/testIntegration/runtimeInjector.ts` - Runtime injection

### **3. Project Configuration (2 files)** - CRITICAL FOR AUTO-CONFIG
- `src/projectConfigurator.ts` - Basic project configuration
- `src/enhancedProjectConfigurator.ts` - Enhanced auto-configuration with rollback

### **4. DOM Capture Core (11 files)**
- `src/domCapture/advancedSerializer.ts` - DOM serialization
- `src/domCapture/asyncDomSerializer.ts` - Async DOM serialization
- `src/domCapture/compressionManager.ts` - Compression utilities
- `src/domCapture/diffVisualizer.ts` - DOM diff visualization
- `src/domCapture/domViewer.ts` - DOM viewing utilities
- `src/domCapture/metadataCollector.ts` - Metadata collection
- `src/domCapture/multiTabCapture.ts` - Multi-tab support
- `src/domCapture/playwrightIntegration.ts` - Playwright-specific integration
- `src/domCapture/resourceInliner.ts` - Resource inlining
- `src/domCapture/securityManager.ts` - Security management
- `src/domCapture/stateCapture.ts` - State capture

### **5. Capture Management (2 files)**
- `src/captureManager.ts` - Basic capture manager
- `src/advancedCaptureManager.ts` - Advanced capture features

### **6. UI Components (3 files)**
- `src/domCaptureProvider.ts` - Tree view provider
- `src/dashboardPanel.ts` - Dashboard webview
- `src/chatParticipant.ts` - Chat integration

### **7. Utilities (4 files)**
- `src/utils/logger.ts` - Logging utilities
- `src/utils/errorHandler.ts` - Error handling
- `src/utils/security.ts` - Security utilities
- `src/utils/securityUtils.ts` - Additional security utilities

### **8. Templates (3 files)**
- `src/templates/capture.js.embedded.ts` - Capture template
- `src/templates/example.spec.ts.embedded.ts` - Example test template
- `src/templates/playwright-fixture.js.embedded.ts` - Fixture template

### **9. Other (1 file)**
- `src/gitIntegration.ts` - Git integration

### **10. Tests (3 files)**
- `src/test/suite/extension.test.ts` - Extension tests
- `src/test/suite/index.ts` - Test suite index
- `src/test/runTest.ts` - Test runner

## 🔗 Key Integration Points

### **A. DOM Capture Flow**
1. **Entry Points:**
   - User: Ctrl+Shift+C → `playwrightTestHelper.ts:enableHotkeyCapture()`
   - Test Failure → `playwrightIntegration.ts:test.autoCapture`
   - Manual → `captureDOM()` functions

2. **Core Processing:**
   - `TestCaptureManager.captureFromPage()` → Main capture logic
   - `advancedSerializer.ts` → DOM serialization
   - `compressionManager.ts` → Compression
   - `metadataCollector.ts` → Metadata

3. **Output:**
   - File System: `test-results/dom-captures/DD-MM-YYYY/ClassName_MethodName/`

### **B. Auto-Configuration Flow**
1. **Entry:**
   - Command: "DOM Capture: Auto-configure Project"
   - Handler: `ExtensionCore.handleAutoConfiguration()`

2. **Processing:**
   - `enhancedProjectConfigurator.autoConfigureProject()`
   - Creates stub files with `createStubContent()`
   - Copies integration files

3. **Output:**
   - Creates `dom-capture/` folder with all files
   - Creates manifest for rollback

### **C. Function/Method Exposure**
- **Browser → Node.js Bridge:** `exposeFunction('__captureDOM')`
- **Event System:** `dom-capture-requested` event (deprecated path)
- **Direct Calls:** `window.__captureDOM()`

## 📊 Data Flow Dependencies

```mermaid
graph TD
    A[extension.ts] --> B[ExtensionCore.ts]
    B --> C[CommandManager.ts]
    B --> D[enhancedProjectConfigurator.ts]
    B --> E[captureManager.ts]
    
    F[playwrightIntegration.ts] --> G[playwrightTestHelper.ts]
    G --> H[TestCaptureManager]
    H --> I[captureFromPage]
    I --> J[File System]
    
    D --> K[createStubContent]
    K --> L[Generated Files]
    
    M[User Ctrl+Shift+C] --> N[Browser Context]
    N --> O[window.__captureDOM]
    O --> H
```

## 🔍 Critical Functions to Verify

### **playwrightIntegration.ts:**
- `installHotkeyListener()` - DEPRECATED
- `setupPageCaptureListener()` - DEPRECATED
- `test.autoCapture` - Main test fixture
- `setupDOMCapture()` - Setup function
- `captureDOM()` - Manual capture

### **playwrightTestHelper.ts:**
- `TestCaptureManager.getInstance()` - Singleton
- `enableHotkeyCapture()` - Installs Ctrl+Shift+C
- `captureFromPage()` - Main capture logic
- `captureAllTabs()` - Multi-tab capture
- `saveCapture()` - File saving

### **enhancedProjectConfigurator.ts:**
- `autoConfigureProject()` - Auto-configuration
- `createStubContent()` - Generates stub files
- `copyIntegrationFiles()` - Copies files
- `rollbackConfiguration()` - Rollback

## ⚠️ Initial Observations

1. **Duplicate Files:** 
   - `security.ts` and `securityUtils.ts` in utils
   - `captureManager.ts` and `advancedCaptureManager.ts`
   - `projectConfigurator.ts` and `enhancedProjectConfigurator.ts`

2. **Deprecated Functions:**
   - `installHotkeyListener()` marked deprecated but has old implementation
   - `setupPageCaptureListener()` marked deprecated

3. **Multiple Integration Files:**
   - `domCapture/playwrightIntegration.ts` 
   - `testIntegration/playwrightIntegration.ts`
   - Potential confusion/duplication

## Next: PHASE 2 - End-to-End Flow Tracing