import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { Logger } from './utils/logger';

/**
 * Enhanced Project Configurator for DOM Capture
 * Handles complete setup and rollback of DOM capture in Playwright projects
 */
export class EnhancedProjectConfigurator {
    private logger: Logger;
    private readonly BACKUP_DIR = '.dom-capture-backup';
    private readonly DOM_CAPTURE_DIR = 'dom-capture';
    private readonly CONFIG_MANIFEST_FILE = '.dom-capture-manifest.json';
    
    constructor(private context: vscode.ExtensionContext) {
        this.logger = Logger.getInstance();
    }

    /**
     * Complete auto-configuration of a Playwright project
     */
    async autoConfigureProject(workspacePath: string): Promise<void> {
        this.logger.info(`Starting auto-configuration for: ${workspacePath}`);
        
        // Track all created files/folders for rollback
        const manifest: ConfigurationManifest = {
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            workspacePath,
            createdFiles: [],
            createdFolders: [],
            modifiedFiles: [],
            backupLocation: path.join(workspacePath, this.BACKUP_DIR)
        };

        try {
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Configuring Playwright DOM Capture',
                cancellable: false
            }, async (progress) => {
                
                // Step 1: Validate environment
                progress.report({ increment: 10, message: 'Validating Playwright project...' });
                await this.validateProject(workspacePath);
                
                // Step 2: Create backup
                progress.report({ increment: 10, message: 'Creating backup...' });
                await this.createBackup(workspacePath, manifest);
                
                // Step 3: Create dom-capture directory structure
                progress.report({ increment: 20, message: 'Setting up DOM capture utilities...' });
                await this.setupDomCaptureDirectory(workspacePath, manifest);
                
                // Step 4: Copy integration files
                progress.report({ increment: 20, message: 'Installing integration files...' });
                await this.copyIntegrationFiles(workspacePath, manifest);
                
                // Step 5: Create example tests
                progress.report({ increment: 10, message: 'Creating example tests...' });
                await this.createExampleTests(workspacePath, manifest);
                
                // Step 6: Update Playwright config if needed
                progress.report({ increment: 10, message: 'Updating configuration...' });
                await this.updatePlaywrightConfig(workspacePath, manifest);
                
                // Step 7: Create documentation
                progress.report({ increment: 10, message: 'Creating documentation...' });
                await this.createDocumentation(workspacePath, manifest);
                
                // Step 8: Save manifest for rollback (MUST be last to include all files)
                progress.report({ increment: 10, message: 'Saving configuration manifest...' });
                await this.saveManifest(workspacePath, manifest);
                
                progress.report({ increment: 100, message: 'Configuration complete!' });
            });

            // First, prompt for dependency installation
            const installDeps = await vscode.window.showWarningMessage(
                '⚠️ CRITICAL: fs-extra must be installed for DOM Capture to work!',
                'Install Now',
                'I\'ll do it manually'
            );

            if (installDeps === 'Install Now') {
                const terminal = vscode.window.createTerminal('Install Dependencies');
                terminal.show();
                terminal.sendText(`cd "${workspacePath}"`);
                terminal.sendText('npm install --save-dev fs-extra @types/fs-extra');
                await new Promise(resolve => setTimeout(resolve, 3000));
            }

            // Offer to automatically update test imports
            const updateImports = await vscode.window.showInformationMessage(
                '📝 Would you like to automatically update test file imports for DOM Capture?',
                'Yes, select files',
                'No, I\'ll do it manually'
            );
            
            if (updateImports === 'Yes, select files') {
                const importUpdateResult = await this.autoUpdateTestImports(workspacePath);
                
                // Update manifest with test files that were modified
                if (importUpdateResult.updatedFiles.length > 0) {
                    manifest.testFilesWithUpdatedImports = importUpdateResult.updatedFiles;
                    manifest.testFilesBackupLocation = importUpdateResult.backupPath;
                    
                    // Re-save the manifest with the updated test file information
                    await this.saveManifest(workspacePath, manifest);
                }
            } else {
                // Show manual update reminder
                await vscode.window.showWarningMessage(
                    '⚠️ Remember: Update test imports from "@playwright/test" to "./dom-capture/playwrightIntegration" for DOM capture to work!',
                    'OK'
                );
            }

            // Show success message with next steps
            const selection = await vscode.window.showInformationMessage(
                '✅ DOM Capture configured! Remember to update test imports!',
                'View Instructions',
                'Run Example Test',
                'Close'
            );

            if (selection === 'View Instructions') {
                const docPath = path.join(workspacePath, 'DOM_CAPTURE_GUIDE.md');
                const doc = await vscode.workspace.openTextDocument(docPath);
                await vscode.window.showTextDocument(doc);
            } else if (selection === 'Run Example Test') {
                const terminal = vscode.window.createTerminal('DOM Capture Test');
                terminal.show();
                terminal.sendText(`cd "${workspacePath}"`);
                terminal.sendText('npx playwright test dom-capture-example.spec.ts --headed');
            }

        } catch (error) {
            this.logger.error('Auto-configuration failed:', error);
            
            // Attempt rollback on failure
            try {
                await this.rollbackConfiguration(workspacePath);
            } catch (rollbackError) {
                this.logger.error('Rollback failed:', rollbackError);
            }
            
            throw error;
        }
    }

    /**
     * Validate that this is a Playwright project
     */
    private async validateProject(workspacePath: string): Promise<void> {
        const packageJsonPath = path.join(workspacePath, 'package.json');
        
        if (!await fs.pathExists(packageJsonPath)) {
            throw new Error('No package.json found. Is this a Node.js project?');
        }

        const packageJson = await fs.readJson(packageJsonPath);
        const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
        
        if (!deps['@playwright/test'] && !deps['playwright']) {
            const install = await vscode.window.showWarningMessage(
                'Playwright is not installed. Would you like to install it?',
                'Install Playwright',
                'Cancel'
            );
            
            if (install === 'Install Playwright') {
                await this.installPlaywright(workspacePath);
            } else {
                throw new Error('Playwright is required for DOM Capture');
            }
        }

        // Check for Playwright config
        const configFiles = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs'];
        const hasConfig = await Promise.all(configFiles.map(f => fs.pathExists(path.join(workspacePath, f))));
        
        if (!hasConfig.some(exists => exists)) {
            this.logger.warn('No Playwright config found. Will create one.');
        }
    }

    /**
     * Create backup of existing configuration
     */
    private async createBackup(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const backupDir = path.join(workspacePath, this.BACKUP_DIR);
        await fs.ensureDir(backupDir);
        manifest.createdFolders.push(this.BACKUP_DIR);

        const filesToBackup = [
            'playwright.config.ts',
            'playwright.config.js',
            'playwright.config.mjs',
            'package.json',
            'tsconfig.json'
        ];

        for (const file of filesToBackup) {
            const filePath = path.join(workspacePath, file);
            if (await fs.pathExists(filePath)) {
                const backupPath = path.join(backupDir, `${file}.backup`);
                await fs.copy(filePath, backupPath);
                manifest.modifiedFiles.push(file);
            }
        }

        // Save backup metadata
        const metadata = {
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            files: manifest.modifiedFiles
        };
        await fs.writeJson(path.join(backupDir, 'metadata.json'), metadata, { spaces: 2 });
    }

    /**
     * Setup dom-capture directory with all necessary files
     */
    private async setupDomCaptureDirectory(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const domCapturePath = path.join(workspacePath, this.DOM_CAPTURE_DIR);
        await fs.ensureDir(domCapturePath);
        manifest.createdFolders.push(this.DOM_CAPTURE_DIR);

        // Create subdirectories with new structure
        const subdirs = ['core', 'helpers', 'utils', 'config'];
        for (const subdir of subdirs) {
            const subdirPath = path.join(domCapturePath, subdir);
            await fs.ensureDir(subdirPath);
            manifest.createdFolders.push(path.join(this.DOM_CAPTURE_DIR, subdir));
        }
    }

    /**
     * Copy all integration files from extension to project
     */
    private async copyIntegrationFiles(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const domCapturePath = path.join(workspacePath, this.DOM_CAPTURE_DIR);
        const extensionPath = this.context.extensionPath;

        // Try multiple source locations (compiled output first, then source)
        const sourceLocations = ['out', 'dist', 'src'];
        
        // Complete list of files to copy with new structure
        const filesToCopy = [
            // Main integration file
            {
                source: 'testIntegration/playwrightIntegration',
                dest: 'playwrightIntegration'
            },
            
            // Core DOM capture files
            {
                source: 'domCapture/advancedSerializer',
                dest: 'core/advancedSerializer'
            },
            {
                source: 'domCapture/asyncDomSerializer',
                dest: 'core/asyncDomSerializer'
            },
            {
                source: 'domCapture/diffVisualizer',
                dest: 'core/diffVisualizer'
            },
            {
                source: 'domCapture/multiTabCapture',
                dest: 'core/multiTabCapture'
            },
            
            // Main test helper file - copy to root for proper imports
            {
                source: 'testIntegration/playwrightTestHelper',
                dest: 'playwrightTestHelper'
            },
            {
                source: 'domCapture/captureHelper',
                dest: 'helpers/captureHelper'
            },
            {
                source: 'domCapture/hotkeyHelper',
                dest: 'helpers/hotkeyHelper'
            },
            
            // Utilities
            {
                source: 'domCapture/compressionManager',
                dest: 'utils/compressionManager'
            },
            {
                source: 'domCapture/securityManager',
                dest: 'utils/securityManager'
            },
            {
                source: 'domCapture/stateCapture',
                dest: 'utils/stateCapture'
            },
            {
                source: 'domCapture/resourceInliner',
                dest: 'utils/resourceInliner'
            },
            {
                source: 'domCapture/metadataCollector',
                dest: 'utils/metadataCollector'
            }
        ];

        for (const file of filesToCopy) {
            let copied = false;
            
            // Try to find and copy the file from various locations (TypeScript only)
            for (const location of sourceLocations) {
                const sourcePath = path.join(extensionPath, location, file.source + '.ts');
                const destPath = path.join(domCapturePath, file.dest + '.ts');
                
                if (await fs.pathExists(sourcePath)) {
                    await fs.ensureDir(path.dirname(destPath));
                    await fs.copy(sourcePath, destPath);
                    manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, file.dest + '.ts'));
                    this.logger.info(`Copied: ${file.dest}.ts from ${location}`);
                    copied = true;
                    break;
                }
            }
            
            if (!copied) {
                this.logger.warn(`Could not find source file for: ${file.source}`);
                // Create a working stub file with full implementation
                const stubPath = path.join(domCapturePath, file.dest + '.ts');
                await fs.ensureDir(path.dirname(stubPath));
                await fs.writeFile(stubPath, this.createStubContent(file.dest));
                manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, file.dest + '.ts'));
                this.logger.info(`Created stub: ${file.dest}.ts`);
            }
        }

        // Create configuration file
        const configPath = path.join(domCapturePath, 'config', 'dom-capture.config.json');
        const config = {
            version: '1.0.0',
            autoCapture: true,
            captureOnFailure: true,
            hotkey: 'Ctrl+Shift+C',
            outputPath: '../test-results/dom-captures',
            compressionLevel: 'medium',
            includeMetadata: true,
            includeScreenshot: true,
            retentionDays: 7
        };
        await fs.writeJson(configPath, config, { spaces: 2 });
        manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, 'config', 'dom-capture.config.json'));

        // Create index file for easier imports with new structure
        const indexContent = `/**
 * DOM Capture Integration for Playwright
 * Auto-generated by Playwright DOM Capture Extension
 */

// Main test integration
export { test, captureDOM, setupDOMCapture } from './playwrightIntegration';

// Helpers
export { TestCaptureManager } from './helpers/testHelper';
export { CaptureHelper } from './helpers/captureHelper';
export { installHotkeyListener } from './helpers/hotkeyHelper';

// Core functionality
export { AdvancedDOMSerializer } from './core/advancedSerializer';
export { AsyncDOMSerializer } from './core/asyncDomSerializer';
export { DiffVisualizer } from './core/diffVisualizer';
export { MultiTabCapture } from './core/multiTabCapture';

// Utilities
export { CompressionManager } from './utils/compressionManager';
export { StateCapture } from './utils/stateCapture';
export { ResourceInliner } from './utils/resourceInliner';

// Types
export type { TestCaptureOptions, CaptureResult } from './helpers/testHelper';

// Re-export Playwright expect for convenience
export { expect } from '@playwright/test';
`;
        await fs.writeFile(path.join(domCapturePath, 'index.ts'), indexContent);
        manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, 'index.ts'));
    }

    /**
     * Create example test files
     */
    private async createExampleTests(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const exampleContent = `/**
 * Example test with DOM Capture enabled
 * Press Ctrl+Shift+C during test execution to capture DOM
 */

import { test, expect } from './dom-capture/playwrightIntegration';

test.describe('DOM Capture Example Tests', () => {
    test('basic navigation with capture', async ({ page }) => {
        // DOM capture is automatically enabled
        await page.goto('https://example.com');
        
        // The page title should contain "Example"
        await expect(page).toHaveTitle(/Example/);
        
        // Press Ctrl+Shift+C in the browser to capture DOM at any point!
    });

    test('capture on failure (intentional)', async ({ page }) => {
        await page.goto('https://example.com');
        
        // This will fail and automatically capture DOM
        await expect(page.locator('#non-existent')).toBeVisible();
    });

    test('manual capture example', async ({ page }) => {
        await page.goto('https://example.com');
        
        // Trigger manual capture
        await page.evaluate(() => {
            window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                detail: { trigger: 'manual', timestamp: Date.now() }
            }));
        });
        
        // Continue with test...
        await expect(page).toHaveTitle(/Example/);
    });
});
`;

        const examplePath = path.join(workspacePath, 'dom-capture-example.spec.ts');
        await fs.writeFile(examplePath, exampleContent);
        manifest.createdFiles.push('dom-capture-example.spec.ts');
    }

    /**
     * Update Playwright configuration to include DOM capture
     */
    private async updatePlaywrightConfig(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        // Find existing config
        const configFiles = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs'];
        let configPath = '';
        
        for (const file of configFiles) {
            const filePath = path.join(workspacePath, file);
            if (await fs.pathExists(filePath)) {
                configPath = filePath;
                break;
            }
        }

        if (!configPath) {
            // Create a new config
            configPath = path.join(workspacePath, 'playwright.config.ts');
            const configContent = `import { defineConfig } from '@playwright/test';

export default defineConfig({
    testDir: './tests',
    timeout: 30000,
    fullyParallel: true,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: process.env.CI ? 1 : undefined,
    reporter: 'html',
    use: {
        actionTimeout: 0,
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
        video: 'retain-on-failure',
    },
    projects: [
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'] },
        },
    ],
});
`;
            await fs.writeFile(configPath, configContent);
            manifest.createdFiles.push('playwright.config.ts');
        }

        // Note: We don't modify existing configs to avoid breaking user setup
        this.logger.info('Playwright config checked/created');
    }

    /**
     * Create documentation for the user
     */
    private async createDocumentation(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const docContent = `# 🎭 DOM Capture - Setup Complete!

## ✅ Installation Successful

Your Playwright project has been configured with DOM Capture capabilities.

## 🚨 CRITICAL SETUP STEPS - DOM CAPTURE WILL NOT WORK WITHOUT THESE! 🚨

### ⚠️ Step 1: Install Required Dependencies (MANDATORY)
**DOM Capture requires fs-extra to function:**
\`\`\`bash
npm install --save-dev fs-extra @types/fs-extra
\`\`\`
If you skip this step, you'll get: **"Cannot find module 'fs-extra'"**

### ⚠️ Step 2: Update ALL Test Imports (MANDATORY)
**DOM capture is DISABLED by default! You MUST update your imports in EVERY test file:**

#### In EVERY test file, change:
\`\`\`typescript
// ❌ WRONG - DOM Capture is DISABLED with this import
import { test, expect } from '@playwright/test';
\`\`\`

#### To:
\`\`\`typescript
// ✅ CORRECT - DOM Capture is ENABLED with this import
import { test, expect } from './dom-capture/playwrightIntegration';
\`\`\`

**🔴 IF YOU DON'T CHANGE THE IMPORTS:**
- No DOM captures will be created
- Ctrl+Shift+C hotkey won't work
- No automatic capture on test failure
- The autoCapture fixture won't activate

### Step 3: Run Tests with DOM Capture

\`\`\`bash
# Run the example test
npx playwright test dom-capture-example.spec.ts --headed

# Run your updated tests
npx playwright test --headed
\`\`\`

### Using DOM Capture in Your Tests

1. **Import the enhanced test fixture:**
\`\`\`typescript
import { test, expect } from './dom-capture';
\`\`\`

2. **Write your tests normally - DOM capture is automatic!**

### 📸 Capture Methods

#### Method 1: Hotkey Capture (Recommended)
- Run tests in headed mode: \`--headed\`
- Press **Ctrl+Shift+C** in the browser at any point
- You'll see a visual flash confirming capture

#### Method 2: Automatic on Failure
- Tests automatically capture DOM when they fail
- No code changes needed!

#### Method 3: Programmatic Capture
\`\`\`typescript
await page.evaluate(() => {
    window.dispatchEvent(new CustomEvent('dom-capture-requested', {
        detail: { trigger: 'manual', timestamp: Date.now() }
    }));
});
\`\`\`

## 📁 Capture Location

\`\`\`
test-results/
└── dom-captures/
    └── [date]/
        └── [test-name]/
            ├── capture_*.html
            └── capture_*_metadata.json
\`\`\`

## 🔧 Configuration

Edit \`dom-capture/config/dom-capture.config.json\` to customize:
- Auto-capture settings
- Compression level
- Retention period
- Output directory

## 🔄 Rollback

To remove DOM Capture from your project:
1. Press \`Ctrl+Shift+P\`
2. Run: "DOM Capture: Rollback Configuration"

## 📚 Files Created

The following files were added to your project:
${manifest.createdFiles.map(f => `- ${f}`).join('\n')}

## 🆘 Troubleshooting

- **Captures not appearing?** Check \`test-results/dom-captures/\`
- **Hotkey not working?** Ensure tests run in headed mode
- **Need help?** Run: "DOM Capture: Show Diagnostics"

---
*Created by Playwright DOM Capture Extension v1.0.0*
`;

        const docPath = path.join(workspacePath, 'DOM_CAPTURE_GUIDE.md');
        await fs.writeFile(docPath, docContent);
        manifest.createdFiles.push('DOM_CAPTURE_GUIDE.md');
    }

    /**
     * Save manifest for rollback purposes
     */
    private async saveManifest(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const manifestPath = path.join(workspacePath, this.CONFIG_MANIFEST_FILE);
        await fs.writeJson(manifestPath, manifest, { spaces: 2 });
        // Don't add to manifest.createdFiles as it should persist for rollback
    }

    /**
     * Create stub content for missing files
     */
    private createStubContent(moduleName: string): string {
        const baseModule = moduleName.split('/').pop() || moduleName;
        
        // Create appropriate stub based on module path and name
        if (moduleName.includes('playwrightIntegration')) {
            return `/**
 * Playwright DOM Capture Integration
 * Auto-generated stub that uses TestCaptureManager for consistency
 */

import { test as base, expect } from '@playwright/test';
import { TestCaptureManager } from './playwrightTestHelper';
import type { Page, TestInfo } from '@playwright/test';
import type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

/**
 * Global type declaration for DOM capture function
 * This extends the Window interface to include our injected capture function
 */
declare global {
    interface Window {
        __captureDom?: (captureId: string) => void;
        __captureState?: () => any;
    }
}

// Type definitions for custom fixtures
type CustomFixtures = {
    autoCapture: void;
    captureManager: TestCaptureManager;
    domCapture: (options?: TestCaptureOptions) => Promise<string>;
    enableHotkeyCapture: () => Promise<void>;
};

// Enhanced test fixture with DOM capture using TestCaptureManager
export const test = base.extend<CustomFixtures>({
    autoCapture: [async ({ page }, use, testInfo) => {
        console.log('🔧 Setting up DOM Capture for test:', testInfo.title);
        
        // Use TestCaptureManager for all capture operations
        const captureManager = TestCaptureManager.getInstance();
        captureManager.setCurrentTest(testInfo);
        
        // Enable hotkey capture (Ctrl+Shift+C)
        await captureManager.enableHotkeyCapture(page);
        
        // Run the test
        await use();
        
        // Capture on failure - matching main implementation exactly
        if (testInfo.status === 'failed') {
            console.log('❌ Test failed, capturing DOM...');
            try {
                const result = await captureManager.captureFromPage(page, {
                    captureId: \`failure_\${Date.now()}\`,
                    customMetadata: {
                        status: 'failed',
                        error: testInfo.error?.message || 'Unknown error'
                    }
                });
                
                // Attach to test report
                testInfo.attachments.push({
                    name: 'dom-capture-on-failure',
                    contentType: 'text/html',
                    path: result.path
                });
                
                console.log(\`📸 Failure DOM captured: \${result.path}\`);
            } catch (error) {
                console.error('Failed to capture DOM on test failure:', error);
            }
        }
    }, { auto: true }],
    
    captureManager: async ({}, use) => {
        const manager = TestCaptureManager.getInstance();
        await use(manager);
    },
    
    domCapture: async ({ page, captureManager }, use, testInfo) => {
        captureManager.setCurrentTest(testInfo);
        
        const captureFunction = async (options?: TestCaptureOptions) => {
            const result = await captureManager.captureFromPage(page, options || {});
            return result.path;
        };
        
        await use(captureFunction);
    },
    
    enableHotkeyCapture: async ({ page, captureManager }, use, testInfo) => {
        captureManager.setCurrentTest(testInfo);
        
        const enableFunction = async () => {
            await captureManager.enableHotkeyCapture(page);
            console.log('🎯 Hotkey capture enabled! Press Ctrl+Shift+C to capture DOM');
        };
        
        await use(enableFunction);
    }
});

// Setup DOM capture using TestCaptureManager
export async function setupDOMCapture(page: Page, testInfo?: TestInfo): Promise<void> {
    const captureManager = TestCaptureManager.getInstance();
    if (testInfo) {
        captureManager.setCurrentTest(testInfo);
    }
    await captureManager.enableHotkeyCapture(page);
    console.log('✅ DOM Capture setup complete');
}

/**
 * Helper function to capture DOM at any point in the test
 * This provides a type-safe way to trigger manual DOM captures
 * 
 * @param page - The Playwright page object
 * @param captureId - Optional identifier for the capture (defaults to timestamp-based ID)
 * @returns Promise that resolves when capture is complete
 * 
 * @example
 * // Basic usage
 * await captureDOM(page);
 * 
 * // With custom ID
 * await captureDOM(page, 'after-login');
 */
export async function captureDOM(page: Page, captureId?: string): Promise<void> {
    const id = captureId || \`manual-capture-\${Date.now()}\`;
    
    await page.evaluate((captureId) => {
        // The type is now properly declared globally
        if (window.__captureDom) {
            window.__captureDom(captureId);
        } else {
            console.warn('DOM capture not available. Ensure the page has been set up with enableHotkeyCapture()');
        }
    }, id);
}

// Re-export TestCaptureManager and types for direct access
export { TestCaptureManager } from './playwrightTestHelper';
export type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

export { expect };

// TypeScript declarations already handled by TestCaptureManager
`;
        }
        
        // Core serializers
        if (moduleName.includes('advancedSerializer')) {
            return this.createAdvancedSerializerStub();
        }
        
        if (moduleName.includes('asyncDomSerializer')) {
            return this.createAsyncSerializerStub();
        }
        
        if (moduleName.includes('diffVisualizer')) {
            return this.createDiffVisualizerStub();
        }
        
        if (moduleName.includes('multiTabCapture')) {
            return this.createMultiTabCaptureStub();
        }
        
        // Main test helper - use complete implementation
        if (moduleName.includes('playwrightTestHelper')) {
            return this.createPlaywrightTestHelperStub();
        }
        
        // Legacy test helper reference
        if (moduleName.includes('testHelper')) {
            return `/**
 * Playwright Test Helper for DOM Capture
 * Auto-generated stub
 */

export interface TestCaptureOptions {
    autoCapture?: boolean;
    captureOnFailure?: boolean;
    outputPath?: string;
}

export interface CaptureResult {
    success: boolean;
    filePath?: string;
    error?: string;
}

export class TestCaptureManager {
    private options: TestCaptureOptions;
    
    constructor(options: TestCaptureOptions = {}) {
        this.options = {
            autoCapture: true,
            captureOnFailure: true,
            outputPath: 'test-results/dom-captures',
            ...options
        };
    }
    
    async capture(page: any, reason: string): Promise<CaptureResult> {
        try {
            const html = await page.content();
            const timestamp = Date.now();
            const fileName = 'capture_' + reason + '_' + timestamp + '.html';
            
            // Save capture
            const fs = require('fs');
            const path = require('path');
            const filePath = path.join(this.options.outputPath!, fileName);
            
            if (!fs.existsSync(this.options.outputPath!)) {
                fs.mkdirSync(this.options.outputPath!, { recursive: true });
            }
            
            fs.writeFileSync(filePath, html);
            
            return {
                success: true,
                filePath
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
`;
        }
        
        if (moduleName.includes('captureHelper')) {
            return this.createCaptureHelperStub();
        }
        
        if (moduleName.includes('hotkeyHelper')) {
            return this.createHotkeyHelperStub();
        }
        
        // Utilities
        if (moduleName.includes('compressionManager')) {
            return this.createCompressionManagerStub();
        }
        
        if (moduleName.includes('stateCapture')) {
            return this.createStateCaptureStub();
        }
        
        if (moduleName.includes('resourceInliner')) {
            return this.createResourceInlinerStub();
        }
        
        if (moduleName.includes('metadataCollector')) {
            return this.createMetadataCollectorStub();
        }
        
        if (moduleName.includes('securityManager')) {
            return this.createSecurityManagerStub();
        }
        
        // Default stub for unknown utilities
        return `/**
 * DOM Capture Utility
 * Auto-generated stub
 */

export class DOMCaptureUtility {
    constructor() {
        // Implementation needed
    }
}

export default DOMCaptureUtility;
`;
    }
    
    private createAdvancedSerializerStub(): string {
        return `/**
 * Advanced DOM Serializer
 * Handles complete DOM serialization with styles and resources
 */

import type { Page } from '@playwright/test';

export class AdvancedDOMSerializer {
    async serialize(page: Page): Promise<string> {
        return await page.evaluate(() => {
            const doctype = document.doctype ? 
                '<!DOCTYPE ' + document.doctype.name + '>' : '';
            
            // Clone the document
            const html = document.documentElement.cloneNode(true) as HTMLElement;
            
            // Inline styles
            const styles = Array.from(document.styleSheets).map(sheet => {
                try {
                    return Array.from(sheet.cssRules).map(rule => rule.cssText).join('\n');
                } catch (e) {
                    return '';
                }
            }).filter(Boolean).join('\n');
            
            if (styles) {
                const styleElement = document.createElement('style');
                styleElement.textContent = styles;
                html.querySelector('head')?.appendChild(styleElement);
            }
            
            return doctype + html.outerHTML;
        });
    }
    
    async serializeWithMetadata(page: Page): Promise<{ html: string; metadata: any }> {
        const html = await this.serialize(page);
        const metadata = {
            url: page.url(),
            timestamp: new Date().toISOString(),
            viewport: await page.viewportSize(),
            userAgent: await page.evaluate(() => navigator.userAgent)
        };
        return { html, metadata };
    }
}
`;
    }
    
    private createAsyncSerializerStub(): string {
        return `/**
 * Async DOM Serializer with chunking support
 */

import type { Page } from '@playwright/test';

export class AsyncDOMSerializer {
    private chunkSize = 1000;
    
    async serializeAsync(page: Page): Promise<string[]> {
        return await page.evaluate((chunkSize) => {
            const chunks: string[] = [];
            const elements = document.querySelectorAll('*');
            
            for (let i = 0; i < elements.length; i += chunkSize) {
                const chunk = Array.from(elements).slice(i, i + chunkSize)
                    .map(el => el.outerHTML).join('');
                chunks.push(chunk);
            }
            
            return chunks;
        }, this.chunkSize);
    }
    
    async combineChunks(chunks: string[]): Promise<string> {
        return chunks.join('');
    }
}
`;
    }
    
    private createDiffVisualizerStub(): string {
        return `/**
 * DOM Diff Visualizer
 * Compares two DOM captures and highlights differences
 */

export class DiffVisualizer {
    compare(dom1: string, dom2: string): string {
        // Simple diff implementation
        const lines1 = dom1.split('\n');
        const lines2 = dom2.split('\n');
        const diff: string[] = [];
        
        const maxLength = Math.max(lines1.length, lines2.length);
        
        for (let i = 0; i < maxLength; i++) {
            if (lines1[i] !== lines2[i]) {
                if (lines1[i]) diff.push('- ' + lines1[i]);
                if (lines2[i]) diff.push('+ ' + lines2[i]);
            } else if (lines1[i]) {
                diff.push('  ' + lines1[i]);
            }
        }
        
        return diff.join('\n');
    }
    
    generateHTMLDiff(dom1: string, dom2: string): string {
        const diff = this.compare(dom1, dom2);
        return '<html><head><style>' +
            '.added { background: #90EE90; }' +
            '.removed { background: #FFB6C1; }' +
            '</style></head><body>' +
            '<pre>' + diff.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</pre>' +
            '</body></html>';
    }
}
`;
    }
    
    private createMultiTabCaptureStub(): string {
        return `/**
 * Multi-Tab Capture Support
 */

import type { Browser, Page } from '@playwright/test';

export class MultiTabCapture {
    async captureAllTabs(browser: Browser): Promise<Map<string, string>> {
        const captures = new Map<string, string>();
        const contexts = browser.contexts();
        
        for (const context of contexts) {
            const pages = context.pages();
            for (const page of pages) {
                const url = page.url();
                const html = await page.content();
                captures.set(url, html);
            }
        }
        
        return captures;
    }
    
    async captureSpecificTabs(pages: Page[]): Promise<Map<string, string>> {
        const captures = new Map<string, string>();
        
        for (const page of pages) {
            const url = page.url();
            const html = await page.content();
            captures.set(url, html);
        }
        
        return captures;
    }
}
`;
    }
    
    private createCaptureHelperStub(): string {
        return `/**
 * Capture Helper Utilities
 */

import type { Page } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

export class CaptureHelper {
    private outputDir = 'test-results/dom-captures';
    
    async captureToFile(page: Page, fileName?: string): Promise<string> {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const name = fileName || 'capture_' + timestamp + '.html';
        const html = await page.content();
        
        // Create output directory
        const fullPath = path.join(process.cwd(), this.outputDir, name);
        const dir = path.dirname(fullPath);
        
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(fullPath, html);
        return fullPath;
    }
    
    async captureWithScreenshot(page: Page): Promise<{ html: string; screenshot: Buffer }> {
        const html = await page.content();
        const screenshot = await page.screenshot();
        return { html, screenshot };
    }
}

export const captureHelper = new CaptureHelper();
`;
    }
    
    private createHotkeyHelperStub(): string {
        return `/**
 * Hotkey Helper for DOM Capture
 */

import type { Page } from '@playwright/test';

export async function installHotkeyListener(page: Page): Promise<void> {
    await page.addInitScript(() => {
        let captureCount = 0;
        
        document.addEventListener('keydown', async (event) => {
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const modifier = isMac ? event.metaKey : event.ctrlKey;
            
            // Ctrl/Cmd + Shift + C
            if (modifier && event.shiftKey && event.key === 'C') {
                event.preventDefault();
                captureCount++;
                
                // Trigger capture event
                window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                    detail: { 
                        trigger: 'hotkey',
                        timestamp: Date.now(),
                        count: captureCount
                    }
                }));
                
                // Visual feedback
                const flash = document.createElement('div');
                flash.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; ' +
                    'background: rgba(0, 255, 0, 0.3); z-index: 999999; pointer-events: none; ' +
                    'animation: flash 0.3s ease-out;';
                
                const style = document.createElement('style');
                style.textContent = '@keyframes flash { 0% { opacity: 1; } 100% { opacity: 0; } }';
                
                document.head.appendChild(style);
                document.body.appendChild(flash);
                
                setTimeout(() => {
                    flash.remove();
                    style.remove();
                }, 300);
                
                console.log('📸 DOM Capture #' + captureCount + ' triggered via hotkey');
            }
        });
        
        console.log('🔥 DOM Capture hotkey listener installed (Ctrl/Cmd+Shift+C)');
    });
}

export function createHotkeyHandler(callback: (event: any) => void) {
    return async (page: Page) => {
        await page.evaluateHandle((cb) => {
            window.addEventListener('dom-capture-requested', cb);
        }, callback);
    };
}
`;
    }
    
    private createCompressionManagerStub(): string {
        return `/**
 * Compression Manager for DOM Captures
 */

export class CompressionManager {
    compress(html: string, level: 'none' | 'low' | 'medium' | 'high' = 'medium'): string {
        if (level === 'none') return html;
        
        let compressed = html;
        
        // Low: Remove extra whitespace
        if (level >= 'low') {
            compressed = compressed.replace(/\s+/g, ' ').trim();
        }
        
        // Medium: Remove comments
        if (level >= 'medium') {
            compressed = compressed.replace(/<!--[^>]*-->/g, '');
            compressed = compressed.replace(/\/\*[^*]*\*+(?:[^/*][^*]*\*+)*\//g, '');
        }
        
        // High: Minify attributes
        if (level === 'high') {
            compressed = compressed.replace(/="([^"]*)"/g, (match, value) => {
                return '="' + value.trim() + '"';
            });
        }
        
        return compressed;
    }
    
    decompress(compressed: string): string {
        // Add formatting back
        return compressed
            .replace(/></g, '>\n<')
            .replace(/([^>])\s*<\//g, '$1\n</');
    }
}
`;
    }
    
    private createStateCaptureStub(): string {
        return `/**
 * State Capture Utility
 */

import type { Page } from '@playwright/test';

export class StateCapture {
    async captureState(page: Page): Promise<any> {
        return await page.evaluate(() => {
            return {
                localStorage: { ...localStorage },
                sessionStorage: { ...sessionStorage },
                cookies: document.cookie,
                scrollPosition: {
                    x: window.scrollX,
                    y: window.scrollY
                },
                formData: this.captureFormData()
            };
        });
    }
    
    private captureFormData(): any {
        const forms = document.querySelectorAll('form');
        const formData: any = {};
        
        forms.forEach((form, index) => {
            const data: any = {};
            const inputs = form.querySelectorAll('input, select, textarea');
            
            inputs.forEach((input: any) => {
                if (input.name) {
                    data[input.name] = input.value;
                }
            });
            
            formData['form_' + index] = data;
        });
        
        return formData;
    }
    
    async restoreState(page: Page, state: any): Promise<void> {
        await page.evaluate((state) => {
            // Restore localStorage
            Object.entries(state.localStorage || {}).forEach(([key, value]) => {
                localStorage.setItem(key, value as string);
            });
            
            // Restore scroll position
            if (state.scrollPosition) {
                window.scrollTo(state.scrollPosition.x, state.scrollPosition.y);
            }
        }, state);
    }
}
`;
    }
    
    private createResourceInlinerStub(): string {
        return `/**
 * Resource Inliner for DOM Captures
 */

import type { Page } from '@playwright/test';

export class ResourceInliner {
    async inlineResources(page: Page): Promise<string> {
        return await page.evaluate(async () => {
            const inlineImages = async () => {
                const images = document.querySelectorAll('img');
                for (const img of Array.from(images)) {
                    if (img.src && !img.src.startsWith('data:')) {
                        try {
                            const response = await fetch(img.src);
                            const blob = await response.blob();
                            const reader = new FileReader();
                            const dataUrl = await new Promise<string>((resolve) => {
                                reader.onloadend = () => resolve(reader.result as string);
                                reader.readAsDataURL(blob);
                            });
                            img.src = dataUrl;
                        } catch (e) {
                            console.warn('Failed to inline image:', img.src);
                        }
                    }
                }
            };
            
            const inlineStyles = () => {
                const links = document.querySelectorAll('link[rel="stylesheet"]');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href) {
                        // Try to find matching stylesheet
                        const sheet = Array.from(document.styleSheets).find(
                            s => s.href === link.href
                        );
                        if (sheet) {
                            try {
                                const rules = Array.from(sheet.cssRules)
                                    .map(rule => rule.cssText)
                                    .join('\n');
                                const style = document.createElement('style');
                                style.textContent = rules;
                                link.parentNode?.replaceChild(style, link);
                            } catch (e) {
                                console.warn('Failed to inline stylesheet:', href);
                            }
                        }
                    }
                });
            };
            
            await inlineImages();
            inlineStyles();
            
            return document.documentElement.outerHTML;
        });
    }
}
`;
    }
    
    private createMetadataCollectorStub(): string {
        return `/**
 * Metadata Collector for DOM Captures
 */

import type { Page } from '@playwright/test';

export class MetadataCollector {
    async collectMetadata(page: Page): Promise<any> {
        const browserMetadata = await page.evaluate(() => {
            return {
                userAgent: navigator.userAgent,
                platform: navigator.platform,
                language: navigator.language,
                screenResolution: {
                    width: window.screen.width,
                    height: window.screen.height
                },
                windowSize: {
                    width: window.innerWidth,
                    height: window.innerHeight
                },
                pixelRatio: window.devicePixelRatio
            };
        });
        
        return {
            url: page.url(),
            title: await page.title(),
            timestamp: new Date().toISOString(),
            viewport: await page.viewportSize(),
            ...browserMetadata,
            testInfo: this.getTestInfo()
        };
    }
    
    private getTestInfo(): any {
        // Get test information if available
        const testInfo: any = {};
        
        if (typeof process !== 'undefined' && process.env) {
            testInfo.testFile = process.env.TEST_FILE;
            testInfo.testName = process.env.TEST_NAME;
            testInfo.testId = process.env.TEST_ID;
        }
        
        return testInfo;
    }
    
    formatMetadata(metadata: any): string {
        return JSON.stringify(metadata, null, 2);
    }
}
`;
    }
    
    private createSecurityManagerStub(): string {
        return `/**
 * Security Manager for DOM Captures
 */

export class SecurityManager {
    sanitizeHTML(html: string): string {
        // Remove sensitive data patterns
        let sanitized = html;
        
        // Remove potential passwords
        sanitized = sanitized.replace(/type="password"[^>]*value="[^"]*"/g, 'type="password"');
        
        // Remove auth tokens from URLs
        sanitized = sanitized.replace(/[?&](token|auth|key|secret|password)=[^&"']*/gi, '');
        
        // Remove common API keys patterns
        sanitized = sanitized.replace(/['"]?api[_-]?key['"]?\s*[:=]\s*['"][^'"]{20,}['"]/gi, '"api_key":"[REDACTED]"');
        
        // Remove bearer tokens
        sanitized = sanitized.replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/g, 'Bearer [REDACTED]');
        
        return sanitized;
    }
    
    redactSensitiveData(data: any): any {
        const sensitiveKeys = ['password', 'token', 'secret', 'key', 'auth', 'credential'];
        
        if (typeof data === 'string') {
            return this.sanitizeHTML(data);
        }
        
        if (typeof data === 'object' && data !== null) {
            const redacted: any = Array.isArray(data) ? [] : {};
            
            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    const lowerKey = key.toLowerCase();
                    if (sensitiveKeys.some(sensitive => lowerKey.includes(sensitive))) {
                        redacted[key] = '[REDACTED]';
                    } else {
                        redacted[key] = this.redactSensitiveData(data[key]);
                    }
                }
            }
            
            return redacted;
        }
        
        return data;
    }
}
`;
    }

    /**
     * Create Playwright Test Helper stub with complete TestCaptureManager implementation
     */
    private createPlaywrightTestHelperStub(): string {
        return `/**
 * Playwright Test Helper - Complete DOM Capture Manager
 * Auto-generated with full TestCaptureManager implementation
 */

import { Page, TestInfo, BrowserContext } from '@playwright/test';
import * as fs from 'fs-extra';
import * as path from 'path';

// Type definitions
export interface TestCaptureOptions {
    captureId?: string;
    stepName?: string;
    includeScreenshot?: boolean;
    customMetadata?: Record<string, any>;
    compressionLevel?: 'none' | 'low' | 'medium' | 'high';
}

export interface CaptureResult {
    path: string;
    timestamp: number;
    metadata: Record<string, any>;
    size: number;
}

export interface DOMCaptureConfig {
    outputDir?: string;
    enableAutoCapture?: boolean;
    captureOnFailure?: boolean;
    compressionLevel?: 'none' | 'low' | 'medium' | 'high';
    includeScreenshots?: boolean;
    sanitizeSensitiveData?: boolean;
}

/**
 * Singleton TestCaptureManager for consistent DOM capture across tests
 */
export class TestCaptureManager {
    private static instance: TestCaptureManager;
    private activeCaptures: Map<string, CaptureResult> = new Map();
    private outputDir: string;
    private currentTestInfo?: TestInfo;
    private captureCount: number = 0;
    private config: DOMCaptureConfig;

    private constructor() {
        this.outputDir = path.join(process.cwd(), 'test-results', 'dom-captures');
        this.config = {
            outputDir: this.outputDir,
            enableAutoCapture: true,
            captureOnFailure: true,
            compressionLevel: 'medium',
            includeScreenshots: true,
            sanitizeSensitiveData: true
        };
        this.ensureOutputDirectory();
    }

    static getInstance(): TestCaptureManager {
        if (!TestCaptureManager.instance) {
            TestCaptureManager.instance = new TestCaptureManager();
        }
        return TestCaptureManager.instance;
    }

    setCurrentTest(testInfo: TestInfo): void {
        this.currentTestInfo = testInfo;
        this.captureCount = 0;
    }

    private ensureOutputDirectory(): void {
        fs.ensureDirSync(this.outputDir);
    }

    private getTestName(): string {
        if (!this.currentTestInfo) return 'unknown-test';
        return this.currentTestInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    }

    private getOutputPath(captureId: string): string {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const testName = this.getTestName();
        const testDir = path.join(this.outputDir, timestamp, testName);
        fs.ensureDirSync(testDir);
        return path.join(testDir, \`\${captureId}.html\`);
    }

    async enableHotkeyCapture(page: Page): Promise<void> {
        // Install hotkey listener using addInitScript (more reliable than evaluateOnNewDocument)
        await page.addInitScript(() => {
            let captureCount = 0;
            
            // Create capture function
            window.__captureDOM = async (detail: any) => {
                captureCount++;
                console.log(\`📸 DOM Capture #\${captureCount} triggered\`, detail);
                
                // Get complete DOM with styles
                const doctype = document.doctype ? 
                    \`<!DOCTYPE \${document.doctype.name}>\` : '';
                
                // Clone document and inline all styles
                const clonedDoc = document.cloneNode(true) as Document;
                const allElements = clonedDoc.querySelectorAll('*');
                
                allElements.forEach((element) => {
                    const computedStyles = window.getComputedStyle(element as Element);
                    (element as HTMLElement).style.cssText = computedStyles.cssText;
                });
                
                const fullHtml = doctype + clonedDoc.documentElement.outerHTML;
                
                // Visual feedback
                const flash = document.createElement('div');
                flash.style.cssText = \`
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 255, 0, 0.3);
                    z-index: 999999;
                    pointer-events: none;
                    animation: flash 0.5s ease-out;
                \`;
                
                const style = document.createElement('style');
                style.textContent = \`
                    @keyframes flash {
                        0% { opacity: 1; }
                        100% { opacity: 0; }
                    }
                \`;
                
                document.head.appendChild(style);
                document.body.appendChild(flash);
                
                setTimeout(() => {
                    flash.remove();
                    style.remove();
                }, 500);
                
                return {
                    html: fullHtml,
                    url: window.location.href,
                    title: document.title,
                    timestamp: Date.now(),
                    captureCount: captureCount,
                    ...detail
                };
            };
            
            // Install keyboard listener
            document.addEventListener('keydown', async (event) => {
                // Ctrl+Shift+C
                if (event.ctrlKey && event.shiftKey && event.key === 'C') {
                    event.preventDefault();
                    event.stopPropagation();
                    
                    try {
                        await window.__captureDOM({
                            trigger: 'hotkey',
                            timestamp: Date.now(),
                            stepName: 'Hotkey Capture',
                            includeScreenshot: true
                        });
                    } catch (error) {
                        console.error('Failed to capture DOM:', error);
                    }
                }
            }, true);
            
            console.log('🎯 DOM Capture hotkey installed (Ctrl+Shift+C)');
        });

        // Expose the capture function to Node.js context
        await page.exposeFunction('__captureDOM', async (detail: any) => {
            return await this.performCapture(page, detail);
        });
    }

    private async performCapture(page: Page, detail: any): Promise<any> {
        this.captureCount++;
        
        try {
            // Get the DOM content that was already captured in browser
            const captureData = await page.evaluate(() => {
                const doctype = document.doctype ? 
                    \`<!DOCTYPE \${document.doctype.name}>\` : '';
                return {
                    html: doctype + document.documentElement.outerHTML,
                    url: window.location.href,
                    title: document.title,
                    viewport: {
                        width: window.innerWidth,
                        height: window.innerHeight
                    }
                };
            });

            // Take screenshot if requested
            let screenshot = null;
            if (detail.includeScreenshot) {
                const screenshotBuffer = await page.screenshot({ 
                    fullPage: true
                });
                screenshot = screenshotBuffer.toString('base64');
            }

            // Create enhanced HTML with metadata
            const enhancedHtml = this.createEnhancedHtml(
                captureData.html,
                {
                    ...detail,
                    ...captureData,
                    screenshot,
                    testName: this.getTestName(),
                    captureNumber: this.captureCount
                }
            );

            // Save to file
            const captureId = detail.captureId || \`capture_\${this.captureCount}\`;
            const outputPath = this.getOutputPath(captureId);
            await fs.writeFile(outputPath, enhancedHtml, 'utf-8');

            const result: CaptureResult = {
                path: outputPath,
                timestamp: Date.now(),
                metadata: detail,
                size: Buffer.byteLength(enhancedHtml, 'utf-8')
            };

            this.activeCaptures.set(captureId, result);
            
            console.log(\`✅ DOM captured: \${outputPath}\`);
            return result;
            
        } catch (error) {
            console.error('Failed to perform capture:', error);
            throw error;
        }
    }

    async captureFromPage(
        page: Page, 
        options: TestCaptureOptions = {}
    ): Promise<CaptureResult> {
        const captureId = options.captureId || \`manual_\${Date.now()}\`;
        
        // Get DOM content
        const domContent = await page.evaluate(() => {
            const doctype = document.doctype ? 
                \`<!DOCTYPE \${document.doctype.name}>\` : '';
            return doctype + document.documentElement.outerHTML;
        });

        // Take screenshot if requested
        let screenshot = null;
        if (options.includeScreenshot !== false) {
            const screenshotBuffer = await page.screenshot({ 
                fullPage: true
            });
            screenshot = screenshotBuffer.toString('base64');
        }

        // Create enhanced HTML
        const enhancedHtml = this.createEnhancedHtml(domContent, {
            ...options,
            screenshot,
            url: page.url(),
            timestamp: Date.now(),
            testName: this.getTestName()
        });

        // Save to file
        const outputPath = this.getOutputPath(captureId);
        await fs.writeFile(outputPath, enhancedHtml, 'utf-8');

        const result: CaptureResult = {
            path: outputPath,
            timestamp: Date.now(),
            metadata: options.customMetadata || {},
            size: Buffer.byteLength(enhancedHtml, 'utf-8')
        };

        this.activeCaptures.set(captureId, result);
        return result;
    }

    private createEnhancedHtml(
        html: string, 
        metadata: any
    ): string {
        const metaScript = \`
            <script id="dom-capture-metadata">
                window.__DOM_CAPTURE_METADATA__ = \${JSON.stringify(metadata, null, 2)};
            </script>
        \`;

        const screenshotSection = metadata.screenshot ? \`
            <div id="dom-capture-screenshot" style="display:none;">
                <img src="data:image/png;base64,\${metadata.screenshot}" />
            </div>
        \` : '';

        // Inject metadata and screenshot into HTML
        if (html.includes('</head>')) {
            html = html.replace('</head>', \`\${metaScript}</head>\`);
        }
        
        if (html.includes('</body>')) {
            html = html.replace('</body>', \`\${screenshotSection}</body>\`);
        }

        return html;
    }

    async captureMultipleTabs(
        context: BrowserContext,
        options: TestCaptureOptions = {}
    ): Promise<CaptureResult[]> {
        const pages = context.pages();
        const results: CaptureResult[] = [];

        for (let i = 0; i < pages.length; i++) {
            const page = pages[i];
            const tabOptions = {
                ...options,
                captureId: \`\${options.captureId || 'tab'}_\${i}\`
            };
            
            try {
                const result = await this.captureFromPage(page, tabOptions);
                results.push(result);
            } catch (error) {
                console.error(\`Failed to capture tab \${i}:\`, error);
            }
        }

        return results;
    }

    getActiveCaptures(): Map<string, CaptureResult> {
        return this.activeCaptures;
    }

    clearCaptures(): void {
        this.activeCaptures.clear();
    }

    getOutputDirectory(): string {
        return this.outputDir;
    }

    setOutputDirectory(dir: string): void {
        this.outputDir = dir;
        this.ensureOutputDirectory();
    }
}

// Global type declarations
declare global {
    interface Window {
        __captureDOM: (detail: any) => Promise<any>;
        __DOM_CAPTURE_METADATA__: any;
    }
}
`;
    }

    /**
     * Find all test files in the workspace
     */
    private async findTestFiles(workspacePath: string): Promise<string[]> {
        const pattern = new vscode.RelativePattern(workspacePath, '**/*.{spec,test}.{ts,js}');
        const files = await vscode.workspace.findFiles(pattern, '**/node_modules/**');
        return files.map(f => f.fsPath);
    }

    /**
     * Check which files need import updates
     */
    private async filterFilesNeedingUpdate(files: string[]): Promise<{path: string, relativePath: string}[]> {
        const filesNeedingUpdate: {path: string, relativePath: string}[] = [];
        
        for (const filePath of files) {
            try {
                const content = await fs.readFile(filePath, 'utf-8');
                // Check if file imports from @playwright/test and NOT already from dom-capture
                if (content.includes("from '@playwright/test'") && 
                    !content.includes('from "./dom-capture/') &&
                    !content.includes('from "../dom-capture/') &&
                    !content.includes('from "../../dom-capture/')) {
                    
                    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
                    const relativePath = workspaceFolder ? 
                        path.relative(workspaceFolder.uri.fsPath, filePath) : 
                        path.basename(filePath);
                    
                    filesNeedingUpdate.push({ path: filePath, relativePath });
                }
            } catch (error) {
                this.logger.warn(`Could not read file ${filePath}: ${error}`);
            }
        }
        
        return filesNeedingUpdate;
    }

    /**
     * Calculate the correct relative import path for each file
     */
    private calculateRelativeImportPath(filePath: string, workspacePath: string): string {
        const fileDir = path.dirname(filePath);
        const domCapturePath = path.join(workspacePath, 'dom-capture', 'playwrightIntegration');
        let relativePath = path.relative(fileDir, domCapturePath).replace(/\\/g, '/');
        
        // Ensure the path starts with ./ or ../
        if (!relativePath.startsWith('.')) {
            relativePath = './' + relativePath;
        }
        
        return relativePath;
    }

    /**
     * Update imports in selected files
     */
    private async updateImportsInFiles(
        files: {path: string, relativePath: string}[], 
        workspacePath: string
    ): Promise<{updated: string[], failed: string[], backupPath?: string}> {
        const updated: string[] = [];
        const failed: string[] = [];
        
        // Create backup directory
        const backupDir = path.join(workspacePath, '.dom-capture-backup', `import-update-${Date.now()}`);
        await fs.ensureDir(backupDir);
        
        for (const file of files) {
            try {
                // Read original content
                const originalContent = await fs.readFile(file.path, 'utf-8');
                
                // Backup original file
                const backupPath = path.join(backupDir, path.basename(file.path));
                await fs.writeFile(backupPath, originalContent, 'utf-8');
                
                // Calculate correct import path
                const importPath = this.calculateRelativeImportPath(file.path, workspacePath);
                
                // Replace imports - handle various import styles
                let updatedContent = originalContent;
                
                // Standard imports
                updatedContent = updatedContent.replace(
                    /from ['"]@playwright\/test['"]/g,
                    `from '${importPath}'`
                );
                
                // Type imports - keep them pointing to @playwright/test
                updatedContent = updatedContent.replace(
                    /import type (.*?) from ['"]@playwright\/test['"]/g,
                    "import type $1 from '@playwright/test'"
                );
                
                // Handle named type imports separately
                const typeOnlyImportRegex = /import {([^}]*)} from ['"]@playwright\/test['"]/g;
                updatedContent = updatedContent.replace(typeOnlyImportRegex, (match, imports) => {
                    // Check if it contains test or expect
                    if (imports.includes('test') || imports.includes('expect')) {
                        // This is a fixture import, update it
                        return `import {${imports}} from '${importPath}'`;
                    } else {
                        // This is likely just types, keep original
                        return match;
                    }
                });
                
                // Only write if content actually changed
                if (updatedContent !== originalContent) {
                    await fs.writeFile(file.path, updatedContent, 'utf-8');
                    updated.push(file.relativePath);
                    this.logger.info(`Updated imports in: ${file.relativePath}`);
                }
            } catch (error) {
                failed.push(file.relativePath);
                this.logger.error(`Failed to update ${file.relativePath}: ${error}`);
            }
        }
        
        return { updated, failed, backupPath: backupDir };
    }

    /**
     * Automatically update test imports with user selection
     * Returns an object with updated files and backup location
     */
    async autoUpdateTestImports(workspacePath: string): Promise<{ updatedFiles: string[], backupPath?: string }> {
        try {
            // Step 1: Find all test files
            const allTestFiles = await this.findTestFiles(workspacePath);
            
            if (allTestFiles.length === 0) {
                vscode.window.showInformationMessage('No test files found in the workspace.');
                return { updatedFiles: [], backupPath: undefined };
            }
            
            // Step 2: Filter files that need updating
            const filesNeedingUpdate = await this.filterFilesNeedingUpdate(allTestFiles);
            
            if (filesNeedingUpdate.length === 0) {
                vscode.window.showInformationMessage(
                    'All test files are already using DOM Capture imports or no Playwright tests found.'
                );
                return { updatedFiles: [], backupPath: undefined };
            }
            
            // Step 3: Create QuickPick items
            const quickPickItems = filesNeedingUpdate.map(file => ({
                label: `$(file) ${path.basename(file.path)}`,
                description: file.relativePath,
                detail: `Update: from '@playwright/test' → to './dom-capture/playwrightIntegration'`,
                picked: true, // Pre-select all by default
                filePath: file.path,
                relativePath: file.relativePath
            }));
            
            // Step 4: Show multi-select dialog
            const selectedItems = await vscode.window.showQuickPick(quickPickItems, {
                canPickMany: true,
                placeHolder: `Select test files to update imports (${filesNeedingUpdate.length} files need updating)`,
                title: 'Update Test Imports for DOM Capture'
            });
            
            if (!selectedItems || selectedItems.length === 0) {
                vscode.window.showInformationMessage('Import update cancelled.');
                return { updatedFiles: [], backupPath: undefined };
            }
            
            // Step 5: Confirm update
            const confirmMessage = `Update imports in ${selectedItems.length} file(s)? A backup will be created.`;
            const confirm = await vscode.window.showWarningMessage(
                confirmMessage,
                'Update Imports',
                'Cancel'
            );
            
            if (confirm !== 'Update Imports') {
                return { updatedFiles: [], backupPath: undefined };
            }
            
            // Step 6: Perform updates with progress
            const updateResult = await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Updating test imports',
                cancellable: false
            }, async (progress) => {
                progress.report({ message: `Updating ${selectedItems.length} files...` });
                
                const filesToUpdate = selectedItems.map(item => ({
                    path: item.filePath,
                    relativePath: item.relativePath
                }));
                
                const result = await this.updateImportsInFiles(filesToUpdate, workspacePath);
                
                // Step 7: Show results
                if (result.updated.length > 0) {
                    const message = `✅ Successfully updated ${result.updated.length} file(s).\nBackup saved to: ${result.backupPath}`;
                    vscode.window.showInformationMessage(message, 'OK');
                }
                
                if (result.failed.length > 0) {
                    const message = `⚠️ Failed to update ${result.failed.length} file(s):\n${result.failed.join('\n')}`;
                    vscode.window.showErrorMessage(message);
                }
                
                return result;
            });
            
            // Return the list of successfully updated files with full paths
            const updatedFilePaths = updateResult.updated.map(relativePath => 
                path.join(workspacePath, relativePath)
            );
            
            return { 
                updatedFiles: updatedFilePaths, 
                backupPath: updateResult.backupPath 
            };
            
        } catch (error) {
            this.logger.error('Auto-update imports failed:', error);
            vscode.window.showErrorMessage(`Failed to update imports: ${error}`);
            return { updatedFiles: [], backupPath: undefined };
        }
    }

    /**
     * Rollback test import changes with safety checks
     */
    async rollbackTestImports(
        testFiles: string[], 
        backupLocation: string | undefined,
        workspacePath: string
    ): Promise<{ reverted: string[], skipped: string[], failed: string[] }> {
        const reverted: string[] = [];
        const skipped: string[] = [];
        const failed: string[] = [];
        
        for (const filePath of testFiles) {
            try {
                // Safety check 1: Verify file exists
                if (!await fs.pathExists(filePath)) {
                    this.logger.warn(`Test file no longer exists: ${filePath}`);
                    skipped.push(filePath);
                    continue;
                }
                
                // Read current content
                const currentContent = await fs.readFile(filePath, 'utf-8');
                
                // Safety check 2: Check if file still has our integration imports
                const hasIntegrationImport = currentContent.includes('../dom-capture/playwrightIntegration') ||
                                           currentContent.includes('../dom-capture/playwrightintegration') ||
                                           currentContent.includes('./dom-capture/playwrightIntegration') ||
                                           currentContent.includes('./dom-capture/playwrightintegration');
                
                if (!hasIntegrationImport) {
                    this.logger.info(`File doesn't have integration imports, skipping: ${filePath}`);
                    skipped.push(filePath);
                    continue;
                }
                
                // Safety check 3: Check if file has been manually modified (optional - check timestamp)
                // For now, we'll proceed if it has integration imports
                
                // Revert the imports
                let revertedContent = currentContent;
                
                // Replace all variations of the integration import back to @playwright/test
                const importPatterns = [
                    // Handle various import styles
                    /from\s+['"]\.\.\/dom-capture\/playwrightIntegration['"]/g,
                    /from\s+['"]\.\.\/dom-capture\/playwrightintegration['"]/g,
                    /from\s+['"]\.\/dom-capture\/playwrightIntegration['"]/g,
                    /from\s+['"]\.\/dom-capture\/playwrightintegration['"]/g,
                ];
                
                for (const pattern of importPatterns) {
                    revertedContent = revertedContent.replace(pattern, `from '@playwright/test'`);
                }
                
                // Check if content actually changed
                if (revertedContent === currentContent) {
                    this.logger.warn(`No changes made to: ${filePath}`);
                    skipped.push(filePath);
                    continue;
                }
                
                // Create a safety backup before reverting
                const safetyBackupPath = `${filePath}.rollback-backup-${Date.now()}`;
                await fs.writeFile(safetyBackupPath, currentContent, 'utf-8');
                
                // Write the reverted content
                await fs.writeFile(filePath, revertedContent, 'utf-8');
                
                // Clean up the safety backup
                await fs.remove(safetyBackupPath);
                
                reverted.push(filePath);
                this.logger.info(`Reverted imports in: ${filePath}`);
                
            } catch (error) {
                this.logger.error(`Failed to revert ${filePath}: ${error}`);
                failed.push(filePath);
            }
        }
        
        // If we have a backup location and successfully reverted all files, we can clean it up
        if (backupLocation && failed.length === 0 && await fs.pathExists(backupLocation)) {
            try {
                await fs.remove(backupLocation);
                this.logger.info(`Cleaned up backup directory: ${backupLocation}`);
            } catch (error) {
                this.logger.warn(`Failed to clean up backup directory: ${error}`);
            }
        }
        
        return { reverted, skipped, failed };
    }

    /**
     * Check if test files are using correct imports
     */
    async validateTestImports(workspacePath: string): Promise<{valid: boolean, files: string[]}> {
        const testFiles = await vscode.workspace.findFiles('**/*.spec.ts', '**/node_modules/**');
        const incorrectFiles: string[] = [];
        
        for (const file of testFiles) {
            const content = await fs.readFile(file.fsPath, 'utf-8');
            if (content.includes("from '@playwright/test'") && 
                !content.includes("from './dom-capture/playwrightIntegration'") &&
                !content.includes("from '../dom-capture/playwrightIntegration'")) {
                incorrectFiles.push(path.relative(workspacePath, file.fsPath));
            }
        }
        
        if (incorrectFiles.length > 0) {
            const message = `⚠️ Found ${incorrectFiles.length} test file(s) using standard Playwright imports instead of DOM Capture integration:\n${incorrectFiles.join('\n')}`;
            vscode.window.showWarningMessage(message, 'Show Instructions').then(selection => {
                if (selection === 'Show Instructions') {
                    vscode.commands.executeCommand('playwright-dom-capture.showInstructions');
                }
            });
        }
        
        return {
            valid: incorrectFiles.length === 0,
            files: incorrectFiles
        };
    }
    
    /**
     * Install Playwright and required dependencies if not present
     */
    private async installPlaywright(workspacePath: string): Promise<void> {
        const terminal = vscode.window.createTerminal('Install Dependencies');
        terminal.show();
        terminal.sendText(`cd "${workspacePath}"`);
        
        // Install Playwright if needed
        terminal.sendText('npm install --save-dev @playwright/test');
        
        // Install fs-extra for DOM capture functionality
        terminal.sendText('npm install --save-dev fs-extra @types/fs-extra');
        
        // Install Playwright browsers
        terminal.sendText('npx playwright install');
        
        // Wait for installation
        await new Promise(resolve => setTimeout(resolve, 35000));
    }

    /**
     * Complete rollback of all DOM Capture configuration
     */
    async rollbackConfiguration(workspacePath: string): Promise<void> {
        this.logger.info(`Starting rollback for: ${workspacePath}`);
        
        try {
            // Load manifest
            const manifestPath = path.join(workspacePath, this.CONFIG_MANIFEST_FILE);
            if (!await fs.pathExists(manifestPath)) {
                throw new Error('No configuration manifest found. Cannot rollback.');
            }

            const manifest: ConfigurationManifest = await fs.readJson(manifestPath);
            
            let testImportRollbackResult: { reverted: string[], skipped: string[], failed: string[] } | null = null;
            
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Rolling back DOM Capture configuration',
                cancellable: false
            }, async (progress) => {
                
                // Step 1: Remove created files
                progress.report({ increment: 30, message: 'Removing created files...' });
                for (const file of manifest.createdFiles) {
                    const filePath = path.join(workspacePath, file);
                    if (await fs.pathExists(filePath)) {
                        await fs.remove(filePath);
                        this.logger.info(`Removed file: ${file}`);
                    }
                }

                // Step 2: Remove created folders (in reverse order to handle nested folders)
                progress.report({ increment: 30, message: 'Removing created folders...' });
                const foldersToRemove = manifest.createdFolders.sort().reverse();
                for (const folder of foldersToRemove) {
                    const folderPath = path.join(workspacePath, folder);
                    if (await fs.pathExists(folderPath)) {
                        // Only remove if empty or if it's the dom-capture folder
                        if (folder === this.DOM_CAPTURE_DIR || folder.startsWith(this.DOM_CAPTURE_DIR)) {
                            await fs.remove(folderPath);
                            this.logger.info(`Removed folder: ${folder}`);
                        } else {
                            // Check if folder is empty before removing
                            const contents = await fs.readdir(folderPath);
                            if (contents.length === 0) {
                                await fs.remove(folderPath);
                                this.logger.info(`Removed empty folder: ${folder}`);
                            }
                        }
                    }
                }

                // Step 3: Rollback test import changes
                progress.report({ increment: 20, message: 'Reverting test import changes...' });
                if (manifest.testFilesWithUpdatedImports && manifest.testFilesWithUpdatedImports.length > 0) {
                    testImportRollbackResult = await this.rollbackTestImports(
                        manifest.testFilesWithUpdatedImports,
                        manifest.testFilesBackupLocation,
                        workspacePath
                    );
                    
                    this.logger.info(`Test import rollback - Reverted: ${testImportRollbackResult!.reverted.length}, Skipped: ${testImportRollbackResult!.skipped.length}, Failed: ${testImportRollbackResult!.failed.length}`);
                }
                
                // Step 4: Restore backed up files
                progress.report({ increment: 20, message: 'Restoring original files...' });
                const backupDir = path.join(workspacePath, this.BACKUP_DIR);
                if (await fs.pathExists(backupDir)) {
                    for (const file of manifest.modifiedFiles) {
                        const backupPath = path.join(backupDir, `${file}.backup`);
                        const originalPath = path.join(workspacePath, file);
                        
                        if (await fs.pathExists(backupPath)) {
                            await fs.copy(backupPath, originalPath, { overwrite: true });
                            this.logger.info(`Restored: ${file}`);
                        }
                    }
                    
                    // Remove backup directory
                    await fs.remove(backupDir);
                }

                // Step 5: Remove manifest file
                progress.report({ increment: 10, message: 'Cleaning up...' });
                await fs.remove(manifestPath);
                
                progress.report({ increment: 100, message: 'Rollback complete!' });
            });

            // Show detailed rollback report
            let rollbackMessage = '✅ DOM Capture configuration has been rolled back successfully.\n\n';
            
            // Add test import rollback details if applicable
            if (testImportRollbackResult !== null) {
                const rollbackResult = testImportRollbackResult as { reverted: string[], skipped: string[], failed: string[] };
                rollbackMessage += '📝 Test Import Rollback Report:\n';
                
                if (rollbackResult.reverted.length > 0) {
                    rollbackMessage += `  • Reverted: ${rollbackResult.reverted.length} file(s)\n`;
                    // Show first few files for context
                    const filesToShow = rollbackResult.reverted.slice(0, 3);
                    filesToShow.forEach((file: string) => {
                        const relativePath = path.relative(workspacePath, file);
                        rollbackMessage += `    - ${relativePath}\n`;
                    });
                    if (rollbackResult.reverted.length > 3) {
                        rollbackMessage += `    ... and ${rollbackResult.reverted.length - 3} more\n`;
                    }
                }
                
                if (rollbackResult.skipped.length > 0) {
                    rollbackMessage += `  • Skipped: ${rollbackResult.skipped.length} file(s) (already reverted or manually modified)\n`;
                }
                
                if (rollbackResult.failed.length > 0) {
                    rollbackMessage += `  • ⚠️ Failed: ${rollbackResult.failed.length} file(s)\n`;
                    rollbackResult.failed.forEach((file: string) => {
                        const relativePath = path.relative(workspacePath, file);
                        rollbackMessage += `    - ${relativePath}\n`;
                    });
                }
            }
            
            // Show the report with options
            const selection = await vscode.window.showInformationMessage(
                rollbackMessage,
                'Show Logs',
                'OK'
            );
            
            if (selection === 'Show Logs') {
                this.logger.show();
            }
            
        } catch (error) {
            this.logger.error('Rollback failed:', error);
            vscode.window.showErrorMessage(`Rollback failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
            throw error;
        }
    }
}

/**
 * Configuration manifest for tracking changes
 */
interface ConfigurationManifest {
    version: string;
    timestamp: string;
    workspacePath: string;
    createdFiles: string[];
    createdFolders: string[];
    modifiedFiles: string[];
    backupLocation: string;
    // Track test files where imports were updated
    testFilesWithUpdatedImports?: string[];
    // Store the backup directory for test files (if different from main backup)
    testFilesBackupLocation?: string;
}