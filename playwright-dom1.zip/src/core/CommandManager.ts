import * as vscode from 'vscode';
import { ICommand, CommandIds } from './CommandDefinitions';
import { Logger } from '../utils/logger';

/**
 * Professional Command Manager
 * Handles all command registration, execution, and lifecycle
 */
export class CommandManager {
    private static instance: CommandManager;
    private commands: Map<string, ICommand> = new Map();
    private disposables: vscode.Disposable[] = [];
    private context: vscode.ExtensionContext | null = null;
    private logger: Logger;
    private isInitialized = false;

    private constructor() {
        this.logger = Logger.getInstance();
    }

    static getInstance(): CommandManager {
        if (!CommandManager.instance) {
            CommandManager.instance = new CommandManager();
        }
        return CommandManager.instance;
    }

    /**
     * Initialize the command manager with extension context
     */
    initialize(context: vscode.ExtensionContext): void {
        if (this.isInitialized) {
            this.logger.warn('CommandManager already initialized');
            return;
        }

        this.context = context;
        this.isInitialized = true;
        this.logger.info('CommandManager initialized');
    }

    /**
     * Register a command definition
     */
    registerCommand(command: ICommand): void {
        if (this.commands.has(command.id)) {
            this.logger.warn(`Command ${command.id} already registered, skipping`);
            return;
        }

        this.commands.set(command.id, command);
        
        // Create the VS Code command registration
        const disposable = vscode.commands.registerCommand(
            command.id,
            this.wrapCommandHandler(command)
        );

        this.disposables.push(disposable);
        
        if (this.context) {
            this.context.subscriptions.push(disposable);
        }

        this.logger.info(`Registered command: ${command.id}`);
    }

    /**
     * Register multiple commands at once
     */
    registerCommands(commands: ICommand[]): void {
        commands.forEach(cmd => this.registerCommand(cmd));
        this.logger.info(`Registered ${commands.length} commands`);
    }

    /**
     * Wrap command handler with error handling and logging
     */
    private wrapCommandHandler(command: ICommand): (...args: any[]) => Promise<any> {
        return async (...args: any[]) => {
            const startTime = Date.now();
            this.logger.info(`Executing command: ${command.id}`);

            try {
                // Check if extension is fully initialized
                if (!this.isInitialized) {
                    this.logger.warn(`Command ${command.id} called before initialization`);
                    
                    // For core commands, show a message
                    if (command.isCore) {
                        vscode.window.showWarningMessage(
                            'Extension is still initializing. Please try again in a moment.'
                        );
                        return;
                    }
                }

                // Execute the command handler
                const result = await command.handler(...args);
                
                const duration = Date.now() - startTime;
                this.logger.info(`Command ${command.id} completed in ${duration}ms`);
                
                return result;

            } catch (error) {
                this.logger.error(`Command ${command.id} failed:`, error);
                
                // Show user-friendly error message
                const errorMessage = error instanceof Error ? error.message : 'Unknown error';
                const selection = await vscode.window.showErrorMessage(
                    `Command failed: ${errorMessage}`,
                    'Show Logs',
                    'Report Issue'
                );

                if (selection === 'Show Logs') {
                    this.logger.show();
                } else if (selection === 'Report Issue') {
                    vscode.env.openExternal(
                        vscode.Uri.parse('https://github.com/your-repo/playwright-dom-capture/issues')
                    );
                }

                throw error;
            }
        };
    }

    /**
     * Execute a command by ID
     */
    async executeCommand(commandId: string, ...args: any[]): Promise<any> {
        const command = this.commands.get(commandId);
        
        if (!command) {
            this.logger.error(`Command not found: ${commandId}`);
            throw new Error(`Command not found: ${commandId}`);
        }

        return command.handler(...args);
    }

    /**
     * Check if a command is registered
     */
    isCommandRegistered(commandId: string): boolean {
        return this.commands.has(commandId);
    }

    /**
     * Get all registered command IDs
     */
    getRegisteredCommands(): string[] {
        return Array.from(this.commands.keys());
    }

    /**
     * Get command metadata
     */
    getCommand(commandId: string): ICommand | undefined {
        return this.commands.get(commandId);
    }

    /**
     * Dispose all commands
     */
    dispose(): void {
        this.disposables.forEach(d => d.dispose());
        this.disposables = [];
        this.commands.clear();
        this.isInitialized = false;
        this.logger.info('CommandManager disposed');
    }

    /**
     * Get diagnostic information
     */
    getDiagnostics(): Record<string, any> {
        return {
            initialized: this.isInitialized,
            registeredCommands: this.getRegisteredCommands(),
            commandCount: this.commands.size,
            hasContext: this.context !== null
        };
    }
}