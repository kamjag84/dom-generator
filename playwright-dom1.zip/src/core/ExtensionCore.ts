import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { CommandManager } from './CommandManager';
import { CommandIds, ICommand } from './CommandDefinitions';
import { CaptureManager } from '../captureManager';
import { ProjectConfigurator } from '../projectConfigurator';
import { EnhancedProjectConfigurator } from '../enhancedProjectConfigurator';
import { DomCaptureProvider } from '../domCaptureProvider';
import { DashboardPanel } from '../dashboardPanel';
import { DomCaptureChatParticipant } from '../chatParticipant';
import { GitIntegrationManager } from '../gitIntegration';
import { Logger } from '../utils/logger';
import { ErrorHandler } from '../utils/errorHandler';

/**
 * Core Extension Manager
 * Central control for all extension functionality
 */
export class ExtensionCore {
    private static instance: ExtensionCore;
    
    // Managers
    private commandManager: CommandManager;
    private captureManager: CaptureManager | null = null;
    private configurator: ProjectConfigurator | null = null;
    private enhancedConfigurator: EnhancedProjectConfigurator | null = null;
    private dashboardProvider: DomCaptureProvider | null = null;
    private chatParticipant: DomCaptureChatParticipant | null = null;
    private gitIntegration: GitIntegrationManager | null = null;
    
    // Core properties
    private context: vscode.ExtensionContext | null = null;
    private logger: Logger;
    private outputChannel: vscode.OutputChannel;
    private statusBarItem: vscode.StatusBarItem | null = null;
    private fileWatcher: vscode.FileSystemWatcher | null = null;
    private isActivated = false;
    private activationTime: number = 0;

    private constructor() {
        this.logger = Logger.getInstance();
        this.commandManager = CommandManager.getInstance();
        this.outputChannel = vscode.window.createOutputChannel('Playwright DOM Capture');
    }

    static getInstance(): ExtensionCore {
        if (!ExtensionCore.instance) {
            ExtensionCore.instance = new ExtensionCore();
        }
        return ExtensionCore.instance;
    }

    /**
     * Activate the extension
     */
    async activate(context: vscode.ExtensionContext): Promise<void> {
        this.activationTime = Date.now();
        this.context = context;
        
        this.logger.info('🚀 Playwright DOM Capture Extension Activating...');
        this.outputChannel.appendLine('Extension activation started');

        try {
            // Phase 1: Core initialization
            await this.initializeCore(context);
            
            // Phase 2: Initialize managers
            await this.initializeManagers(context);
            
            // Phase 3: Register commands
            await this.registerAllCommands();
            
            // Phase 4: Setup UI components
            await this.setupUIComponents();
            
            // Phase 5: Setup watchers and listeners
            await this.setupWatchers();
            
            // Phase 6: Finalize activation
            this.finalizeActivation();
            
        } catch (error) {
            this.logger.error('Extension activation failed:', error);
            this.outputChannel.appendLine(`Activation failed: ${error}`);
            
            // Show error to user
            vscode.window.showErrorMessage(
                'Playwright DOM Capture failed to activate. Check the output panel for details.',
                'Show Output'
            ).then(selection => {
                if (selection === 'Show Output') {
                    this.outputChannel.show();
                }
            });
            
            throw error;
        }
    }

    /**
     * Phase 1: Initialize core components
     */
    private async initializeCore(context: vscode.ExtensionContext): Promise<void> {
        this.logger.info('Phase 1: Initializing core components');
        
        // Initialize command manager
        this.commandManager.initialize(context);
        
        // Log environment info
        this.logEnvironmentInfo();
        
        // Check if this is a Playwright project
        const isPlaywright = await this.detectPlaywrightProject();
        if (isPlaywright) {
            this.logger.info('✅ Playwright project detected');
        }
    }

    /**
     * Phase 2: Initialize managers
     */
    private async initializeManagers(context: vscode.ExtensionContext): Promise<void> {
        this.logger.info('Phase 2: Initializing managers');
        
        // Initialize each manager with error handling
        try {
            this.captureManager = new CaptureManager(context);
            this.logger.info('✅ CaptureManager initialized');
        } catch (error) {
            this.logger.error('Failed to initialize CaptureManager:', error);
        }

        try {
            this.configurator = new ProjectConfigurator(context);
            this.enhancedConfigurator = new EnhancedProjectConfigurator(context);
            this.logger.info('✅ ProjectConfigurator initialized');
        } catch (error) {
            this.logger.error('Failed to initialize ProjectConfigurator:', error);
        }

        try {
            this.dashboardProvider = new DomCaptureProvider(context);
            this.logger.info('✅ DomCaptureProvider initialized');
        } catch (error) {
            this.logger.error('Failed to initialize DomCaptureProvider:', error);
        }

        try {
            this.chatParticipant = new DomCaptureChatParticipant(context);
            this.logger.info('✅ DomCaptureChatParticipant initialized');
        } catch (error) {
            this.logger.error('Failed to initialize DomCaptureChatParticipant:', error);
        }

        // Initialize Git integration if in a workspace
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (workspaceFolder) {
            try {
                this.gitIntegration = new GitIntegrationManager(workspaceFolder.uri.fsPath);
                await this.gitIntegration.initialize();
                this.logger.info('✅ GitIntegrationManager initialized');
            } catch (error) {
                this.logger.error('Failed to initialize GitIntegrationManager:', error);
            }
        }
    }

    /**
     * Phase 3: Register all commands
     */
    private async registerAllCommands(): Promise<void> {
        this.logger.info('Phase 3: Registering commands');
        
        const commands: ICommand[] = [
            // Core commands
            {
                id: CommandIds.AUTO_CONFIGURE,
                title: 'Auto-configure Project',
                category: 'DOM Capture',
                isCore: true,
                handler: () => this.handleAutoConfiguration()
            },
            {
                id: CommandIds.SHOW_DASHBOARD,
                title: 'Show Dashboard',
                category: 'DOM Capture',
                isCore: true,
                handler: () => this.handleShowDashboard()
            },
            {
                id: CommandIds.VIEW_LAST_CAPTURE,
                title: 'View Last Capture',
                category: 'DOM Capture',
                handler: () => this.handleViewLastCapture()
            },
            {
                id: CommandIds.VERIFY_CONFIG,
                title: 'Verify Configuration',
                category: 'DOM Capture',
                handler: () => this.handleVerifyConfiguration()
            },
            {
                id: CommandIds.ROLLBACK_CONFIG,
                title: 'Rollback Configuration',
                category: 'DOM Capture',
                handler: () => this.handleRollbackConfiguration()
            },
            
            // Capture commands
            {
                id: CommandIds.CAPTURE_CURRENT_PAGE,
                title: 'Capture Current Page',
                category: 'DOM Capture',
                handler: () => this.handleCaptureCurrentPage()
            },
            {
                id: CommandIds.ADD_CAPTURE_POINT,
                title: 'Add Capture Point',
                category: 'DOM Capture',
                handler: () => this.handleAddCapturePoint()
            },
            {
                id: CommandIds.TOGGLE_AUTO_CAPTURE,
                title: 'Toggle Auto Capture',
                category: 'DOM Capture',
                handler: () => this.handleToggleAutoCapture()
            },
            {
                id: CommandIds.CLEAN_CAPTURES,
                title: 'Clean Old Captures',
                category: 'DOM Capture',
                handler: () => this.handleCleanCaptures()
            },
            
            // Git commands
            {
                id: CommandIds.PREPARE_FOR_COMMIT,
                title: 'Prepare for Commit',
                category: 'DOM Capture',
                handler: () => this.handlePrepareForCommit()
            },
            {
                id: CommandIds.CHECK_GIT_SAFETY,
                title: 'Check Git Safety',
                category: 'DOM Capture',
                handler: () => this.handleCheckGitSafety()
            },
            {
                id: CommandIds.EMERGENCY_CLEANUP,
                title: 'Emergency Cleanup',
                category: 'DOM Capture',
                handler: () => this.handleEmergencyCleanup()
            },
            
            // Diagnostic commands
            {
                id: CommandIds.SHOW_DIAGNOSTICS,
                title: 'Show Diagnostics',
                category: 'DOM Capture',
                handler: () => this.handleShowDiagnostics()
            },
            {
                id: CommandIds.SHOW_LOGS,
                title: 'Show Logs',
                category: 'DOM Capture',
                handler: () => this.outputChannel.show()
            },
            
            // Test integration commands
            {
                id: CommandIds.UPDATE_TEST_IMPORTS,
                title: 'Update Test Imports',
                category: 'DOM Capture',
                handler: () => this.handleUpdateTestImports()
            },
            {
                id: CommandIds.MIGRATE_CAPTURE_POINTS,
                title: 'Migrate Capture Points',
                category: 'DOM Capture',
                handler: () => this.handleMigrateCapturePoints()
            }
        ];

        this.commandManager.registerCommands(commands);
        this.logger.info(`✅ Registered ${commands.length} commands`);
    }

    /**
     * Phase 4: Setup UI components
     */
    private async setupUIComponents(): Promise<void> {
        this.logger.info('Phase 4: Setting up UI components');
        
        // Register tree data provider
        if (this.dashboardProvider) {
            vscode.window.registerTreeDataProvider('domCaptures', this.dashboardProvider);
            this.logger.info('✅ Tree data provider registered');
            
            // Watch for workspace folder changes
            vscode.workspace.onDidChangeWorkspaceFolders(async () => {
                this.logger.info('Workspace folders changed, reinitializing dashboard watcher');
                await this.dashboardProvider!.reinitializeWatcher();
                this.dashboardProvider!.refresh();
            });
        }

        // Register chat participant
        if ((vscode as any).chat && this.chatParticipant) {
            try {
                const participant = (vscode as any).chat.createChatParticipant(
                    'domcapture',
                    async (request: any, context: any, stream: any, token: any) => {
                        await this.chatParticipant!.handleChatRequest(request, context, stream, token);
                    }
                );
                
                if (this.context) {
                    participant.iconPath = vscode.Uri.joinPath(this.context.extensionUri, 'resources', 'icon.png');
                    this.context.subscriptions.push(participant);
                }
                
                this.logger.info('✅ Chat participant registered');
            } catch (error) {
                this.logger.warn('Chat API not available:', error);
            }
        }

        // Create status bar item
        this.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
        this.statusBarItem.text = '$(beaker) DOM Capture';
        this.statusBarItem.command = CommandIds.SHOW_DASHBOARD;
        this.statusBarItem.tooltip = 'Click to open DOM Capture Dashboard';
        this.statusBarItem.show();
        
        if (this.context) {
            this.context.subscriptions.push(this.statusBarItem);
        }
        
        this.logger.info('✅ Status bar item created');
    }

    /**
     * Phase 5: Setup watchers
     */
    private async setupWatchers(): Promise<void> {
        this.logger.info('Phase 5: Setting up watchers');
        
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (workspaceFolder && this.captureManager) {
            try {
                this.fileWatcher = await this.setupTestResultsWatcher(this.captureManager);
                if (this.fileWatcher && this.context) {
                    this.context.subscriptions.push(this.fileWatcher);
                    this.logger.info('✅ File watcher setup');
                }
            } catch (error) {
                this.logger.error('Failed to setup file watcher:', error);
            }
        }
    }

    /**
     * Phase 6: Finalize activation
     */
    private finalizeActivation(): void {
        this.isActivated = true;
        const duration = Date.now() - this.activationTime;
        
        this.logger.info(`✅ Extension activated successfully in ${duration}ms`);
        this.outputChannel.appendLine(`Extension activated in ${duration}ms`);
        
        // Update status bar
        if (this.statusBarItem) {
            this.statusBarItem.text = '$(beaker) DOM Capture: Ready';
        }

        // Show welcome message on first activation
        if (this.context) {
            const hasShownWelcome = this.context.globalState.get('domCapture.welcomeShown', false);
            if (!hasShownWelcome) {
                vscode.window.showInformationMessage(
                    'Playwright DOM Capture is ready! Configure your project to start capturing.',
                    'Configure Now',
                    'Later'
                ).then(selection => {
                    if (selection === 'Configure Now') {
                        vscode.commands.executeCommand(CommandIds.AUTO_CONFIGURE);
                    }
                });
                this.context.globalState.update('domCapture.welcomeShown', true);
            }
        }
    }

    // Command Handlers
    private async handleAutoConfiguration(): Promise<void> {
        if (!this.enhancedConfigurator) {
            throw new Error('Enhanced project configurator not initialized');
        }
        
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            const openFolder = await vscode.window.showErrorMessage(
                'Please open a project folder first to configure DOM Capture.',
                'Open Folder'
            );
            
            if (openFolder === 'Open Folder') {
                await vscode.commands.executeCommand('vscode.openFolder');
            }
            return;
        }

        try {
            // Use the enhanced configurator for complete setup
            await this.enhancedConfigurator.autoConfigureProject(workspaceFolder.uri.fsPath);
        } catch (error) {
            this.logger.error('Auto-configuration failed:', error);
            vscode.window.showErrorMessage(
                `Failed to configure: ${error instanceof Error ? error.message : 'Unknown error'}`,
                'Show Logs'
            ).then(selection => {
                if (selection === 'Show Logs') {
                    this.outputChannel.show();
                }
            });
        }
    }

    private async handleShowDashboard(): Promise<void> {
        if (!this.captureManager) {
            this.captureManager = new CaptureManager(this.context!);
        }
        DashboardPanel.createOrShow(this.context!.extensionUri, this.captureManager);
    }

    private async handleViewLastCapture(): Promise<void> {
        if (!this.captureManager) {
            throw new Error('Capture manager not initialized');
        }
        
        const lastCapture = await this.captureManager.getLastCapture();
        if (!lastCapture) {
            vscode.window.showInformationMessage('No captures found. Run your tests to generate captures.');
            return;
        }

        const uri = vscode.Uri.file(lastCapture.path);
        await vscode.commands.executeCommand('vscode.open', uri);
    }

    // ... Additional handler implementations ...

    private async handleShowDiagnostics(): Promise<void> {
        this.outputChannel.clear();
        this.outputChannel.appendLine('=== Playwright DOM Capture Diagnostics ===');
        this.outputChannel.appendLine(`Activation Time: ${new Date(this.activationTime).toISOString()}`);
        this.outputChannel.appendLine(`Is Activated: ${this.isActivated}`);
        this.outputChannel.appendLine(`VS Code Version: ${vscode.version}`);
        this.outputChannel.appendLine('');
        
        this.outputChannel.appendLine('Command Manager:');
        const cmdDiagnostics = this.commandManager.getDiagnostics();
        Object.entries(cmdDiagnostics).forEach(([key, value]) => {
            this.outputChannel.appendLine(`  ${key}: ${JSON.stringify(value)}`);
        });
        
        this.outputChannel.appendLine('');
        this.outputChannel.appendLine('Managers Status:');
        this.outputChannel.appendLine(`  CaptureManager: ${this.captureManager ? '✅' : '❌'}`);
        this.outputChannel.appendLine(`  Configurator: ${this.configurator ? '✅' : '❌'}`);
        this.outputChannel.appendLine(`  DashboardProvider: ${this.dashboardProvider ? '✅' : '❌'}`);
        this.outputChannel.appendLine(`  ChatParticipant: ${this.chatParticipant ? '✅' : '❌'}`);
        this.outputChannel.appendLine(`  GitIntegration: ${this.gitIntegration ? '✅' : '❌'}`);
        
        this.outputChannel.show();
        vscode.window.showInformationMessage('Diagnostics displayed in Output panel');
    }

    // Helper methods
    private async detectPlaywrightProject(): Promise<boolean> {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) return false;

        for (const folder of workspaceFolders) {
            const configFiles = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs'];
            
            for (const configFile of configFiles) {
                if (await fs.pathExists(path.join(folder.uri.fsPath, configFile))) {
                    return true;
                }
            }

            const packageJsonPath = path.join(folder.uri.fsPath, 'package.json');
            if (await fs.pathExists(packageJsonPath)) {
                try {
                    const pkg = await fs.readJson(packageJsonPath);
                    const deps = { ...pkg.dependencies, ...pkg.devDependencies };
                    if (deps['@playwright/test'] || deps['playwright']) {
                        return true;
                    }
                } catch {}
            }
        }
        
        return false;
    }

    private logEnvironmentInfo(): void {
        this.outputChannel.appendLine('Environment Information:');
        this.outputChannel.appendLine(`  VS Code Version: ${vscode.version}`);
        this.outputChannel.appendLine(`  Extension Mode: ${this.context?.extensionMode}`);
        this.outputChannel.appendLine(`  Workspace: ${vscode.workspace.name || 'No workspace'}`);
        
        const folders = vscode.workspace.workspaceFolders;
        if (folders) {
            this.outputChannel.appendLine('  Workspace Folders:');
            folders.forEach(f => this.outputChannel.appendLine(`    - ${f.uri.fsPath}`));
        }
    }

    // Placeholder for existing implementations
    private async autoConfigureProject(configurator: ProjectConfigurator): Promise<void> {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            vscode.window.showErrorMessage('Please open a workspace folder first');
            return;
        }

        try {
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Configuring Playwright DOM Capture',
                cancellable: false
            }, async (progress) => {
                // Step 1: Check Playwright installation
                progress.report({ increment: 10, message: 'Checking Playwright installation...' });
                const hasPlaywright = await configurator.checkPlaywrightInstallation(workspaceFolder.uri.fsPath);
                
                if (!hasPlaywright) {
                    progress.report({ increment: 30, message: 'Installing Playwright...' });
                    await configurator.installPlaywright(workspaceFolder.uri.fsPath);
                }

                // Step 2: Backup existing config
                progress.report({ increment: 20, message: 'Backing up existing configuration...' });
                await configurator.backupExistingConfig(workspaceFolder.uri.fsPath);

                // Step 3: Install DOM capture utilities
                progress.report({ increment: 20, message: 'Installing DOM capture utilities...' });
                await configurator.installDomCaptureUtilities(workspaceFolder.uri.fsPath);

                // Step 4: Update test files with DOM capture
                progress.report({ increment: 20, message: 'Updating test files...' });
                await configurator.updateTestFiles(workspaceFolder.uri.fsPath);

                progress.report({ increment: 100, message: 'Configuration complete!' });
            });

            vscode.window.showInformationMessage(
                'Playwright DOM Capture configured successfully! 🎉',
                'View Instructions'
            ).then(selection => {
                if (selection === 'View Instructions') {
                    vscode.commands.executeCommand('playwright-dom-capture.showDashboard');
                }
            });

        } catch (error) {
            this.logger.error('Failed to configure project:', error);
            vscode.window.showErrorMessage(
                `Failed to configure: ${error instanceof Error ? error.message : 'Unknown error'}`,
                'Show Logs'
            ).then(selection => {
                if (selection === 'Show Logs') {
                    this.outputChannel.show();
                }
            });
        }
    }

    private async setupTestResultsWatcher(captureManager: CaptureManager): Promise<vscode.FileSystemWatcher> {
        // Existing implementation
        const pattern = '**/test-results/**/*.html';
        const watcher = vscode.workspace.createFileSystemWatcher(pattern);
        
        watcher.onDidCreate(async (uri) => {
            this.logger.info(`Test result created: ${uri.fsPath}`);
        });
        
        return watcher;
    }

    private async handleVerifyConfiguration(): Promise<void> {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            vscode.window.showErrorMessage('No workspace folder open');
            return;
        }

        try {
            const issues: string[] = [];
            const wsPath = workspaceFolder.uri.fsPath;

            // Check for dom-capture folder
            if (!await fs.pathExists(path.join(wsPath, 'dom-capture'))) {
                issues.push('❌ dom-capture folder not found');
            } else {
                issues.push('✅ dom-capture folder exists');
            }

            // Check for Playwright config
            const configFiles = ['playwright.config.ts', 'playwright.config.js'];
            const hasConfig = await Promise.all(configFiles.map(f => fs.pathExists(path.join(wsPath, f))));
            if (hasConfig.some(exists => exists)) {
                issues.push('✅ Playwright config found');
            } else {
                issues.push('❌ Playwright config not found');
            }

            // Check for test files
            const testPattern = '**/*.{spec,test}.{ts,js}';
            const testFiles = await vscode.workspace.findFiles(testPattern, '**/node_modules/**', 5);
            if (testFiles.length > 0) {
                issues.push(`✅ Found ${testFiles.length} test files`);
            } else {
                issues.push('⚠️ No test files found');
            }

            // Show verification results
            const message = issues.join('\n');
            const hasIssues = issues.some(i => i.startsWith('❌'));
            
            if (hasIssues) {
                const action = await vscode.window.showWarningMessage(
                    'Configuration issues detected:\n' + message,
                    'Auto-Configure',
                    'Ignore'
                );
                if (action === 'Auto-Configure') {
                    await vscode.commands.executeCommand('playwright-dom-capture.autoConfigureProject');
                }
            } else {
                vscode.window.showInformationMessage('Configuration verified successfully! ✅');
            }

        } catch (error) {
            this.logger.error('Verification failed:', error);
            vscode.window.showErrorMessage('Failed to verify configuration');
        }
    }

    private async handleRollbackConfiguration(): Promise<void> {
        if (!this.enhancedConfigurator) {
            throw new Error('Enhanced project configurator not initialized');
        }
        
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            vscode.window.showErrorMessage('No workspace folder open');
            return;
        }

        // Check if configuration manifest exists
        const manifestPath = path.join(workspaceFolder.uri.fsPath, '.dom-capture-manifest.json');
        if (!await fs.pathExists(manifestPath)) {
            // Try legacy backup
            const backupDir = path.join(workspaceFolder.uri.fsPath, '.dom-capture-backup');
            if (!await fs.pathExists(backupDir)) {
                vscode.window.showWarningMessage('No DOM Capture configuration found. Nothing to rollback.');
                return;
            }
        }

        const confirm = await vscode.window.showWarningMessage(
            'Are you sure you want to remove all DOM Capture configuration from this project?',
            'Yes, Remove Everything',
            'Cancel'
        );

        if (confirm !== 'Yes, Remove Everything') {
            return;
        }

        try {
            // Use the enhanced configurator for complete rollback
            await this.enhancedConfigurator.rollbackConfiguration(workspaceFolder.uri.fsPath);
            
            // Refresh file explorer
            vscode.commands.executeCommand('workbench.files.action.refreshFilesExplorer');
            
        } catch (error) {
            this.logger.error('Rollback failed:', error);
            vscode.window.showErrorMessage(
                `Failed to rollback: ${error instanceof Error ? error.message : 'Unknown error'}`,
                'Show Logs'
            ).then(selection => {
                if (selection === 'Show Logs') {
                    this.outputChannel.show();
                }
            });
        }
    }

    private async handleCaptureCurrentPage(): Promise<void> {
        try {
            // Provide instructions for capturing
            const message = `DOM Capture Instructions:

1. **During Test Execution**: Press Ctrl+Shift+C in the browser window
2. **Manual Capture**: Run a Playwright test with DOM capture enabled
3. **From VS Code**: Use the command while a test is running

Would you like to see the setup instructions?`;

            const selection = await vscode.window.showInformationMessage(
                message,
                'Show Setup',
                'Open Test File',
                'Cancel'
            );

            if (selection === 'Show Setup') {
                // Show setup instructions
                const panel = vscode.window.createWebviewPanel(
                    'domCaptureSetup',
                    'DOM Capture Setup',
                    vscode.ViewColumn.One,
                    {}
                );

                panel.webview.html = this.getSetupInstructionsHtml();
            } else if (selection === 'Open Test File') {
                // Help create a test file with DOM capture
                const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
                if (workspaceFolder) {
                    const testContent = `import { test } from './dom-capture/playwrightIntegration';
import { expect } from '@playwright/test';

test('capture DOM example', async ({ page }) => {
    // Navigate to your page
    await page.goto('https://example.com');
    
    // DOM capture is automatically enabled
    // Press Ctrl+Shift+C in the browser to capture at any point
    
    // Your test assertions
    await expect(page).toHaveTitle(/Example/);
    
    // Manual capture (optional)
    await page.evaluate(() => {
        window.dispatchEvent(new CustomEvent('dom-capture-requested', {
            detail: { trigger: 'manual', timestamp: Date.now() }
        }));
    });
});`;

                    const uri = vscode.Uri.file(
                        path.join(workspaceFolder.uri.fsPath, 'dom-capture-example.spec.ts')
                    );
                    
                    await vscode.workspace.fs.writeFile(uri, Buffer.from(testContent));
                    const doc = await vscode.workspace.openTextDocument(uri);
                    await vscode.window.showTextDocument(doc);
                    
                    vscode.window.showInformationMessage('Test file created! Run it with: npx playwright test dom-capture-example.spec.ts');
                }
            }

        } catch (error) {
            this.logger.error('Failed to handle capture command:', error);
            vscode.window.showErrorMessage('Failed to handle capture command');
        }
    }

    private getSetupInstructionsHtml(): string {
        return `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; padding: 20px; line-height: 1.6; }
        h1 { color: #007acc; }
        code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; }
        pre { background: #f0f0f0; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .step { margin: 20px 0; padding: 15px; border-left: 4px solid #007acc; background: #f8f8f8; }
        .hotkey { background: #fffacd; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>🎭 DOM Capture Setup Instructions</h1>
    
    <div class="hotkey">
        <strong>⌨️ Quick Capture:</strong> Press <code>Ctrl+Shift+C</code> during test execution to capture DOM instantly!
    </div>

    <div class="step">
        <h2>Step 1: Setup Your Test Project</h2>
        <p>Run this command in your test project root:</p>
        <pre>node node_modules/playwright-dom-capture/setupTestProject.js</pre>
    </div>

    <div class="step">
        <h2>Step 2: Import Enhanced Test</h2>
        <p>In your test files, replace the Playwright test import:</p>
        <pre>// Replace this:
import { test } from '@playwright/test';

// With this:
import { test } from './dom-capture/playwrightIntegration';</pre>
    </div>

    <div class="step">
        <h2>Step 3: Run Your Tests</h2>
        <p>Run tests normally - DOM capture is automatically enabled:</p>
        <pre>npx playwright test</pre>
        <p>During test execution, press <code>Ctrl+Shift+C</code> to capture DOM at any point!</p>
    </div>

    <div class="step">
        <h2>Features Available:</h2>
        <ul>
            <li>✅ Automatic capture on test failure</li>
            <li>✅ Manual capture with Ctrl+Shift+C during tests</li>
            <li>✅ Programmatic capture in test code</li>
            <li>✅ Full DOM state preservation</li>
            <li>✅ Organized folder structure</li>
        </ul>
    </div>

    <div class="step">
        <h2>Captured Files Location:</h2>
        <pre>test-results/
└── dom-captures/
    └── [date]/
        └── [test-name]/
            ├── capture_*.html
            └── capture_*_metadata.json</pre>
    </div>
</body>
</html>`;
    }

    private async handleAddCapturePoint(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showWarningMessage('No active editor');
            return;
        }

        const position = editor.selection.active;
        const line = position.line;
        
        // Check if the file looks like a Playwright test
        const document = editor.document;
        const text = document.getText();
        const hasPlaywrightImport = text.includes('@playwright/test') || text.includes('playwrightIntegration');
        
        // Determine if we should add import for captureDOM
        let captureCode = '';
        const needsImport = !text.includes('captureDOM') && !text.includes('from \'../dom-capture/playwrightIntegration\'') && !text.includes('from \'./dom-capture/playwrightIntegration\'');
        
        if (hasPlaywrightImport && needsImport) {
            // User is likely using our integration, suggest using the helper
            const useHelper = await vscode.window.showInformationMessage(
                'Use the type-safe captureDOM helper function?',
                'Yes (Recommended)',
                'No (Inline Code)'
            );
            
            if (useHelper === 'Yes (Recommended)') {
                // Add import if not present
                if (needsImport) {
                    // Find the right place to add import (after other imports)
                    const importMatch = text.match(/import .* from ['"].*['"];?/g);
                    if (importMatch) {
                        const lastImport = importMatch[importMatch.length - 1];
                        const lastImportIndex = text.lastIndexOf(lastImport);
                        const importLine = document.positionAt(lastImportIndex + lastImport.length).line;
                        
                        // Add import for captureDOM
                        await editor.edit(editBuilder => {
                            editBuilder.insert(new vscode.Position(importLine + 1, 0), 
                                `import { captureDOM } from '../dom-capture/playwrightIntegration';\n`);
                        });
                    }
                }
                
                // Use the helper function
                captureCode = `\n    // DOM Capture Point\n    await captureDOM(page, 'manual-capture-${Date.now()}');\n`;
            } else {
                // Use inline code with proper typing
                captureCode = `\n    // DOM Capture Point\n    await page.evaluate(() => {\n        // Type is declared globally in playwrightIntegration\n        if (window.__captureDom) {\n            window.__captureDom('manual-capture-${Date.now()}');\n        }\n    });\n`;
            }
        } else {
            // Default to helper function approach
            captureCode = `\n    // DOM Capture Point\n    await captureDOM(page, 'manual-capture-${Date.now()}');\n`;
        }

        await editor.edit(editBuilder => {
            editBuilder.insert(new vscode.Position(line + 1, 0), captureCode);
        });

        vscode.window.showInformationMessage('Capture point added at line ' + (line + 1));
    }

    private async handleToggleAutoCapture(): Promise<void> {
        const config = vscode.workspace.getConfiguration('playwright-dom-capture');
        const currentValue = config.get<boolean>('autoCapture', true);
        const newValue = !currentValue;
        
        await config.update('autoCapture', newValue, vscode.ConfigurationTarget.Workspace);
        
        const status = newValue ? 'enabled ✅' : 'disabled ❌';
        vscode.window.showInformationMessage(`Auto-capture on failure ${status}`);
        
        // Update status bar if exists
        if (this.statusBarItem) {
            this.statusBarItem.text = newValue ? '🔴 DOM Capture (Auto)' : '⏸ DOM Capture (Manual)';
        }
    }

    private async handleCleanCaptures(): Promise<void> {
        if (!this.captureManager) {
            this.captureManager = new CaptureManager(this.context!);
        }

        const captures = await this.captureManager.getCaptures();
        if (captures.length === 0) {
            vscode.window.showInformationMessage('No captures to clean');
            return;
        }

        const confirm = await vscode.window.showWarningMessage(
            `Delete ${captures.length} capture(s)?`,
            'Delete All',
            'Delete Old (7+ days)',
            'Cancel'
        );

        if (confirm === 'Cancel' || !confirm) {
            return;
        }

        try {
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Cleaning captures',
                cancellable: false
            }, async () => {
                if (confirm === 'Delete All') {
                    await this.captureManager!.cleanOldCaptures(0); // 0 days = all
                    vscode.window.showInformationMessage('All captures deleted');
                } else {
                    const deleted = await this.captureManager!.cleanOldCaptures(7);
                    vscode.window.showInformationMessage(`Deleted ${deleted} old captures`);
                }
            });
        } catch (error) {
            this.logger.error('Failed to clean captures:', error);
            vscode.window.showErrorMessage('Failed to clean captures');
        }
    }

    private async handlePrepareForCommit(): Promise<void> {
        // Implementation
    }

    private async handleCheckGitSafety(): Promise<void> {
        // Implementation
    }

    private async handleEmergencyCleanup(): Promise<void> {
        // Implementation
    }
    
    private async handleUpdateTestImports(): Promise<void> {
        try {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders || workspaceFolders.length === 0) {
                vscode.window.showWarningMessage('No workspace folder found');
                return;
            }
            
            if (!this.context) {
                vscode.window.showErrorMessage('Extension context not available');
                return;
            }
            
            const workspacePath = workspaceFolders[0].uri.fsPath;
            
            // Use the enhancedProjectConfigurator to update test imports
            const { EnhancedProjectConfigurator } = await import('../enhancedProjectConfigurator');
            const configurator = new EnhancedProjectConfigurator(this.context);
            
            await configurator.autoUpdateTestImports(workspacePath);
        } catch (error) {
            this.logger.error('Failed to update test imports:', error);
            vscode.window.showErrorMessage('Failed to update test imports');
        }
    }
    
    private async handleMigrateCapturePoints(): Promise<void> {
        try {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders || workspaceFolders.length === 0) {
                vscode.window.showWarningMessage('No workspace folder found');
                return;
            }
            
            const workspacePath = workspaceFolders[0].uri.fsPath;
            
            // Find all test files
            const testFiles = await vscode.workspace.findFiles('**/*.spec.ts', '**/node_modules/**');
            
            if (testFiles.length === 0) {
                vscode.window.showInformationMessage('No test files found');
                return;
            }
            
            // Check which files have old-style capture points
            const filesToMigrate: vscode.Uri[] = [];
            const fs = await import('fs-extra');
            
            for (const file of testFiles) {
                const content = await fs.readFile(file.fsPath, 'utf-8');
                
                // Look for old-style capture points
                if (content.includes('window.__captureDom') && 
                    content.includes('await page.evaluate(() => {')) {
                    filesToMigrate.push(file);
                }
            }
            
            if (filesToMigrate.length === 0) {
                vscode.window.showInformationMessage('No capture points found that need migration');
                return;
            }
            
            // Show selection dialog
            const items = filesToMigrate.map(file => ({
                label: `$(file) ${path.basename(file.fsPath)}`,
                description: vscode.workspace.asRelativePath(file),
                picked: true,
                file: file
            }));
            
            const selected = await vscode.window.showQuickPick(items, {
                canPickMany: true,
                placeHolder: `Found ${filesToMigrate.length} files with capture points to migrate`,
                title: 'Migrate Capture Points to Type-Safe Version'
            });
            
            if (!selected || selected.length === 0) {
                return;
            }
            
            // Confirm migration
            const confirm = await vscode.window.showWarningMessage(
                `Migrate capture points in ${selected.length} file(s) to type-safe version?`,
                'Migrate',
                'Cancel'
            );
            
            if (confirm !== 'Migrate') {
                return;
            }
            
            // Perform migration
            let migratedCount = 0;
            let failedCount = 0;
            
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Migrating capture points',
                cancellable: false
            }, async (progress) => {
                for (const item of selected) {
                    progress.report({ message: `Migrating ${path.basename(item.file.fsPath)}...` });
                    
                    try {
                        let content = await fs.readFile(item.file.fsPath, 'utf-8');
                        let modified = false;
                        
                        // Check if captureDOM is already imported
                        const hasCaptureImport = content.includes('captureDOM');
                        
                        // Add import if needed
                        if (!hasCaptureImport && content.includes('playwrightIntegration')) {
                            // Find where to add the import
                            const importMatch = content.match(/from ['"].*playwrightIntegration['"]/);
                            if (importMatch) {
                                // Check if it's a destructured import
                                const importLine = content.substring(0, content.indexOf(importMatch[0]));
                                const lastNewline = importLine.lastIndexOf('\n');
                                const fullImportLine = content.substring(lastNewline + 1, content.indexOf(importMatch[0]) + importMatch[0].length);
                                
                                if (fullImportLine.includes('{') && fullImportLine.includes('}')) {
                                    // Add captureDOM to existing import
                                    const newImport = fullImportLine.replace(/\{([^}]+)\}/, (match, group) => {
                                        const imports = group.split(',').map((s: string) => s.trim());
                                        if (!imports.includes('captureDOM')) {
                                            imports.push('captureDOM');
                                        }
                                        return `{ ${imports.join(', ')} }`;
                                    });
                                    content = content.replace(fullImportLine, newImport);
                                    modified = true;
                                }
                            }
                        }
                        
                        // Replace old-style capture points with new helper
                        const oldPattern = /await page\.evaluate\(\(\) => \{\s*if \(window\.__captureDom\) \{\s*window\.__captureDom\(['"]([^'"]+)['"]\);\s*\}\s*\}\);/g;
                        
                        if (oldPattern.test(content)) {
                            content = content.replace(oldPattern, (match, captureId) => {
                                return `await captureDOM(page, '${captureId}');`;
                            });
                            modified = true;
                        }
                        
                        // Also handle the variant with the warning message
                        const oldPatternWithWarning = /await page\.evaluate\(\(\) => \{\s*\/\/.*\s*if \(window\.__captureDom\) \{\s*window\.__captureDom\(['"]([^'"]+)['"]\);\s*\}(?:\s*else\s*\{[^}]*\})?\s*\}\);/g;
                        
                        if (oldPatternWithWarning.test(content)) {
                            content = content.replace(oldPatternWithWarning, (match, captureId) => {
                                return `await captureDOM(page, '${captureId}');`;
                            });
                            modified = true;
                        }
                        
                        if (modified) {
                            // Create backup
                            await fs.writeFile(`${item.file.fsPath}.backup`, await fs.readFile(item.file.fsPath));
                            
                            // Write updated content
                            await fs.writeFile(item.file.fsPath, content);
                            migratedCount++;
                        }
                    } catch (error) {
                        this.logger.error(`Failed to migrate ${item.file.fsPath}:`, error);
                        failedCount++;
                    }
                }
            });
            
            // Show results
            if (migratedCount > 0) {
                vscode.window.showInformationMessage(
                    `✅ Successfully migrated ${migratedCount} file(s) to use type-safe capture points`
                );
            }
            
            if (failedCount > 0) {
                vscode.window.showErrorMessage(
                    `⚠️ Failed to migrate ${failedCount} file(s)`
                );
            }
            
        } catch (error) {
            this.logger.error('Failed to migrate capture points:', error);
            vscode.window.showErrorMessage('Failed to migrate capture points');
        }
    }

    /**
     * Deactivate the extension
     */
    dispose(): void {
        this.logger.info('Extension deactivating...');
        
        // Dispose all resources
        this.commandManager.dispose();
        this.fileWatcher?.dispose();
        this.statusBarItem?.dispose();
        
        // Dispose dashboard provider if it exists
        if (this.dashboardProvider && typeof this.dashboardProvider.dispose === 'function') {
            this.dashboardProvider.dispose();
        }
        
        this.outputChannel.dispose();
        this.logger.dispose();
        
        this.isActivated = false;
        console.log('Playwright DOM Capture extension deactivated');
    }
    
    deactivate(): void {
        this.dispose();
    }
}