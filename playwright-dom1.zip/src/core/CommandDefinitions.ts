import * as vscode from 'vscode';

/**
 * Command definition interface
 */
export interface ICommand {
    id: string;
    title: string;
    category?: string;
    handler: (...args: any[]) => any | Promise<any>;
    icon?: string;
    enablement?: string;
    isCore?: boolean;  // Core commands that must always be available
}

/**
 * All command IDs as constants to avoid typos
 */
export const CommandIds = {
    // Core commands
    AUTO_CONFIGURE: 'playwright-dom-capture.autoConfigureProject',
    SHOW_DASHBOARD: 'playwright-dom-capture.showDashboard',
    VIEW_LAST_CAPTURE: 'playwright-dom-capture.viewLastCapture',
    VERIFY_CONFIG: 'playwright-dom-capture.verifyConfig',
    ROLLBACK_CONFIG: 'playwright-dom-capture.rollbackConfig',
    
    // Capture commands
    CAPTURE_CURRENT_PAGE: 'playwright-dom-capture.captureCurrentPage',
    ADD_CAPTURE_POINT: 'playwright-dom-capture.addCapturePoint',
    TOGGLE_AUTO_CAPTURE: 'playwright-dom-capture.toggleAutoCapture',
    CLEAN_CAPTURES: 'playwright-dom-capture.cleanCaptures',
    
    // Git commands
    PREPARE_FOR_COMMIT: 'playwright-dom-capture.prepareForCommit',
    CHECK_GIT_SAFETY: 'playwright-dom-capture.checkGitSafety',
    EMERGENCY_CLEANUP: 'playwright-dom-capture.emergencyCleanup',
    
    // Diagnostic commands
    SHOW_DIAGNOSTICS: 'playwright-dom-capture.showDiagnostics',
    SHOW_LOGS: 'playwright-dom-capture.showLogs',
    RELOAD_EXTENSION: 'playwright-dom-capture.reloadExtension',
    
    // Test integration commands
    UPDATE_TEST_IMPORTS: 'playwright-dom-capture.updateTestImports',
    MIGRATE_CAPTURE_POINTS: 'playwright-dom-capture.migrateCapturePoints'
} as const;

/**
 * Command metadata for package.json generation
 */
export const CommandMetadata: Record<string, {title: string, category: string, icon?: string}> = {
    [CommandIds.AUTO_CONFIGURE]: {
        title: 'Auto-configure Project',
        category: 'DOM Capture',
        icon: '$(tools)'
    },
    [CommandIds.SHOW_DASHBOARD]: {
        title: 'Show Dashboard',
        category: 'DOM Capture',
        icon: '$(dashboard)'
    },
    [CommandIds.VIEW_LAST_CAPTURE]: {
        title: 'View Last Capture',
        category: 'DOM Capture',
        icon: '$(eye)'
    },
    [CommandIds.VERIFY_CONFIG]: {
        title: 'Verify Configuration',
        category: 'DOM Capture',
        icon: '$(check)'
    },
    [CommandIds.ROLLBACK_CONFIG]: {
        title: 'Rollback Configuration',
        category: 'DOM Capture',
        icon: '$(discard)'
    },
    [CommandIds.CAPTURE_CURRENT_PAGE]: {
        title: 'Capture Current Page',
        category: 'DOM Capture',
        icon: '$(device-camera)'
    },
    [CommandIds.ADD_CAPTURE_POINT]: {
        title: 'Add Capture Point Here',
        category: 'DOM Capture',
        icon: '$(add)'
    },
    [CommandIds.TOGGLE_AUTO_CAPTURE]: {
        title: 'Toggle Auto-capture on Failure',
        category: 'DOM Capture',
        icon: '$(sync)'
    },
    [CommandIds.CLEAN_CAPTURES]: {
        title: 'Clean Old Captures',
        category: 'DOM Capture',
        icon: '$(trash)'
    },
    [CommandIds.PREPARE_FOR_COMMIT]: {
        title: 'Prepare for Commit',
        category: 'DOM Capture',
        icon: '$(git-commit)'
    },
    [CommandIds.CHECK_GIT_SAFETY]: {
        title: 'Check Git Safety',
        category: 'DOM Capture',
        icon: '$(shield)'
    },
    [CommandIds.EMERGENCY_CLEANUP]: {
        title: 'Emergency Cleanup',
        category: 'DOM Capture',
        icon: '$(warning)'
    },
    [CommandIds.SHOW_DIAGNOSTICS]: {
        title: 'Show Diagnostics',
        category: 'DOM Capture',
        icon: '$(info)'
    },
    [CommandIds.SHOW_LOGS]: {
        title: 'Show Logs',
        category: 'DOM Capture',
        icon: '$(output)'
    },
    [CommandIds.RELOAD_EXTENSION]: {
        title: 'Reload Extension',
        category: 'DOM Capture',
        icon: '$(refresh)'
    },
    [CommandIds.UPDATE_TEST_IMPORTS]: {
        title: 'Update Test Imports',
        category: 'DOM Capture',
        icon: '$(replace-all)'
    },
    [CommandIds.MIGRATE_CAPTURE_POINTS]: {
        title: 'Migrate Capture Points to Type-Safe Version',
        category: 'DOM Capture',
        icon: '$(sync)'
    }
};