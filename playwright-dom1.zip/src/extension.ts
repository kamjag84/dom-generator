import * as vscode from 'vscode';
import { ExtensionCore } from './core/ExtensionCore';
import { Logger } from './utils/logger';

let logger: Logger | null = null;
let extensionCore: ExtensionCore | null = null;

/**
 * Extension activation point
 * Uses the new architecture with ExtensionCore managing all functionality
 */
export async function activate(context: vscode.ExtensionContext): Promise<void> {
    try {
        // Initialize logger first
        logger = Logger.getInstance();
        logger.info('🚀 Playwright DOM Capture extension activating...');
        logger.info(`Extension Path: ${context.extensionPath}`);
        logger.info(`Extension Mode: ${context.extensionMode}`);
        
        // Show activation notification
        vscode.window.showInformationMessage('Playwright DOM Capture is starting...', 'Show Logs').then(selection => {
            if (selection === 'Show Logs' && logger) {
                logger.show();
            }
        });
        
        // Initialize the core extension manager
        extensionCore = ExtensionCore.getInstance();
        
        // Activate the extension with full error handling
        await extensionCore.activate(context);
        
        // Log successful activation
        logger.info('✅ Playwright DOM Capture extension activated successfully');
        
        // Show success notification
        vscode.window.showInformationMessage(
            'Playwright DOM Capture is ready! Press Ctrl+Shift+P and search for "DOM Capture"',
            'Show Commands',
            'View Dashboard'
        ).then(selection => {
            if (selection === 'Show Commands') {
                vscode.commands.executeCommand('workbench.action.showCommands', 'DOM Capture');
            } else if (selection === 'View Dashboard') {
                vscode.commands.executeCommand('playwright-dom-capture.showDashboard');
            }
        });
        
    } catch (error) {
        // Ensure logger exists for error reporting
        if (!logger) {
            logger = Logger.getInstance();
        }
        
        logger.error('Failed to activate Playwright DOM Capture extension:', error);
        
        // Show error to user with recovery options
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const selection = await vscode.window.showErrorMessage(
            `Failed to activate Playwright DOM Capture: ${errorMessage}`,
            'Show Logs',
            'Retry',
            'Dismiss'
        );
        
        if (selection === 'Show Logs') {
            logger.show();
        } else if (selection === 'Retry') {
            // Reload the window to retry activation
            await vscode.commands.executeCommand('workbench.action.reloadWindow');
        }
        
        // Re-throw to let VS Code know activation failed
        throw error;
    }
}

/**
 * Extension deactivation point
 */
export function deactivate(): void {
    try {
        if (logger) {
            logger.info('Playwright DOM Capture extension deactivating...');
        }
        
        // Dispose the core extension manager if it exists
        if (extensionCore) {
            extensionCore.dispose();
            extensionCore = null;
        }
        
        if (logger) {
            logger.info('Playwright DOM Capture extension deactivated');
            logger.dispose();
            logger = null;
        }
        
    } catch (error) {
        // Last attempt to log error
        console.error('Error during deactivation:', error);
        // Don't re-throw during deactivation to prevent issues
    }
}