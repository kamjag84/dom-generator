import { Page } from 'playwright';

export interface ChunkedDomOptions {
  maxChunkSize: number; // Max size per chunk in bytes
  compressionLevel: 'none' | 'low' | 'medium' | 'high';
  captureIframes: boolean;
  captureShadowDom: boolean;
  captureFormState: boolean;
  captureCanvas: boolean;
  captureScrollPositions: boolean;
  redactSensitive: boolean;
  timeout: number; // Timeout for serialization
}

export interface DomChunk {
  id: string;
  index: number;
  total: number;
  data: string;
  compressed: boolean;
  size: number;
}

export interface SerializationResult {
  chunks: DomChunk[];
  metadata: {
    totalSize: number;
    chunkCount: number;
    compressionRatio: number;
    serializationTime: number;
    url: string;
    timestamp: string;
  };
}

/**
 * Async DOM Serializer with chunking support for large DOMs
 */
export class AsyncDomSerializer {
  private readonly MAX_CHUNK_SIZE = 500 * 1024; // 500KB default
  private readonly BATCH_SIZE = 100; // Process 100 elements at a time
  
  constructor(private page: Page, private options: Partial<ChunkedDomOptions> = {}) {
    this.options = {
      maxChunkSize: this.MAX_CHUNK_SIZE,
      compressionLevel: 'medium',
      captureIframes: true,
      captureShadowDom: true,
      captureFormState: true,
      captureCanvas: true,
      captureScrollPositions: true,
      redactSensitive: true,
      timeout: 30000,
      ...options
    };
  }

  /**
   * Serialize DOM with chunking and async processing
   */
  async serialize(): Promise<SerializationResult> {
    const startTime = Date.now();
    const url = this.page.url();
    
    try {
      // Install serialization helper in page context
      await this.installSerializationHelper();
      
      // Perform chunked serialization
      const chunks = await this.performChunkedSerialization();
      
      const totalSize = chunks.reduce((sum, chunk) => sum + chunk.size, 0);
      const originalSize = chunks.reduce((sum, chunk) => sum + chunk.data.length, 0);
      
      return {
        chunks,
        metadata: {
          totalSize,
          chunkCount: chunks.length,
          compressionRatio: originalSize / totalSize,
          serializationTime: Date.now() - startTime,
          url,
          timestamp: new Date().toISOString()
        }
      };
    } catch (error) {
      throw new Error(`DOM serialization failed: ${error}`);
    }
  }

  /**
   * Install helper functions in the page context
   */
  private async installSerializationHelper(): Promise<void> {
    await this.page.addInitScript(() => {
      // @ts-ignore
      window.__domSerializerHelper = {
        // Get element count for progress tracking
        getElementCount: () => {
          return document.querySelectorAll('*').length;
        },
        
        // Serialize elements in batches
        serializeBatch: (startIndex: number, batchSize: number, options: any) => {
          const allElements = Array.from(document.querySelectorAll('*'));
          const batch = allElements.slice(startIndex, startIndex + batchSize);
          const serialized: any[] = [];
          
          for (const element of batch) {
            const data: any = {
              tagName: element.tagName,
              attributes: {},
              children: [],
              textContent: ''
            };
            
            // Capture attributes
            for (const attr of element.attributes) {
              // Redact sensitive attributes if needed
              if (options.redactSensitive && 
                  (attr.name.includes('password') || 
                   attr.name.includes('token') || 
                   attr.name.includes('secret'))) {
                data.attributes[attr.name] = '[REDACTED]';
              } else {
                data.attributes[attr.name] = attr.value;
              }
            }
            
            // Capture form state
            if (options.captureFormState) {
              if (element instanceof HTMLInputElement) {
                data.value = element.value;
                data.checked = element.checked;
              } else if (element instanceof HTMLTextAreaElement) {
                data.value = element.value;
              } else if (element instanceof HTMLSelectElement) {
                data.selectedIndex = element.selectedIndex;
              }
            }
            
            // Capture canvas
            if (options.captureCanvas && element instanceof HTMLCanvasElement) {
              try {
                data.canvasData = element.toDataURL();
              } catch (e) {
                data.canvasData = null;
              }
            }
            
            // Capture scroll position
            if (options.captureScrollPositions) {
              if (element.scrollTop > 0 || element.scrollLeft > 0) {
                data.scrollTop = element.scrollTop;
                data.scrollLeft = element.scrollLeft;
              }
            }
            
            // Capture shadow DOM
            if (options.captureShadowDom && element.shadowRoot) {
              data.shadowRoot = (window as any).__domSerializerHelper.serializeShadowRoot(element.shadowRoot, options);
            }
            
            serialized.push(data);
          }
          
          return serialized;
        },
        
        // Serialize shadow root
        serializeShadowRoot: (shadowRoot: ShadowRoot, options: any) => {
          const elements = Array.from(shadowRoot.querySelectorAll('*'));
          return elements.map(el => ({
            tagName: el.tagName,
            textContent: el.textContent || '',
            attributes: Array.from(el.attributes).reduce((acc: any, attr) => {
              acc[attr.name] = attr.value;
              return acc;
            }, {})
          }));
        },
        
        // Get full HTML with inline styles
        getFullHtml: () => {
          const clone = document.documentElement.cloneNode(true) as HTMLElement;
          
          // Inline all styles
          const styles = Array.from(document.styleSheets)
            .map(sheet => {
              try {
                return Array.from(sheet.cssRules)
                  .map(rule => rule.cssText)
                  .join('\n');
              } catch {
                return '';
              }
            })
            .join('\n');
          
          const styleElement = document.createElement('style');
          styleElement.textContent = styles;
          clone.querySelector('head')?.appendChild(styleElement);
          
          return '<!DOCTYPE html>' + clone.outerHTML;
        }
      };
    });
  }

  /**
   * Perform chunked serialization
   */
  private async performChunkedSerialization(): Promise<DomChunk[]> {
    const chunks: DomChunk[] = [];
    
    // Get total element count
    const elementCount = await this.page.evaluate(() => {
      return (window as any).__domSerializerHelper.getElementCount();
    });
    
    // Process in batches
    let processedCount = 0;
    let chunkData = '';
    let chunkIndex = 0;
    
    while (processedCount < elementCount) {
      const batchData = await this.page.evaluate(
        ({ startIndex, batchSize, options }) => {
          return JSON.stringify(
            (window as any).__domSerializerHelper.serializeBatch(startIndex, batchSize, options)
          );
        },
        {
          startIndex: processedCount,
          batchSize: this.BATCH_SIZE,
          options: this.options
        }
      );
      
      chunkData += batchData;
      processedCount += this.BATCH_SIZE;
      
      // Check if chunk size exceeded
      if (chunkData.length >= this.options.maxChunkSize! || processedCount >= elementCount) {
        const compressed = await this.compressChunk(chunkData);
        chunks.push({
          id: `chunk_${Date.now()}_${chunkIndex}`,
          index: chunkIndex,
          total: Math.ceil(elementCount / this.BATCH_SIZE),
          data: compressed.data,
          compressed: compressed.compressed,
          size: compressed.data.length
        });
        
        chunkData = '';
        chunkIndex++;
      }
    }
    
    // Also capture the full HTML as the last chunk for reconstruction
    const fullHtml = await this.page.evaluate(() => {
      return (window as any).__domSerializerHelper.getFullHtml();
    });
    
    const compressedHtml = await this.compressChunk(fullHtml);
    chunks.push({
      id: `chunk_${Date.now()}_html`,
      index: chunks.length,
      total: chunks.length + 1,
      data: compressedHtml.data,
      compressed: compressedHtml.compressed,
      size: compressedHtml.data.length
    });
    
    return chunks;
  }

  /**
   * Compress chunk based on compression level
   */
  private async compressChunk(data: string): Promise<{ data: string; compressed: boolean }> {
    const { compressionLevel } = this.options;
    
    if (compressionLevel === 'none') {
      return { data, compressed: false };
    }
    
    // Simple compression by removing unnecessary whitespace
    let compressed = data;
    
    if (compressionLevel === 'low') {
      compressed = data.replace(/\s+/g, ' ').trim();
    } else if (compressionLevel === 'medium') {
      compressed = data
        .replace(/\s+/g, ' ')
        .replace(/>\s+</g, '><')
        .replace(/:\s+/g, ':')
        .replace(/;\s+/g, ';')
        .trim();
    } else if (compressionLevel === 'high') {
      // More aggressive compression
      compressed = data
        .replace(/\s+/g, ' ')
        .replace(/>\s+</g, '><')
        .replace(/:\s+/g, ':')
        .replace(/;\s+/g, ';')
        .replace(/,\s+/g, ',')
        .replace(/{\s+/g, '{')
        .replace(/}\s+/g, '}')
        .replace(/\[\s+/g, '[')
        .replace(/\]\s+/g, ']')
        .trim();
    }
    
    // Base64 encode if significant compression achieved
    if (compressed.length < data.length * 0.7) {
      return {
        data: Buffer.from(compressed).toString('base64'),
        compressed: true
      };
    }
    
    return { data: compressed, compressed: false };
  }

  /**
   * Reconstruct DOM from chunks
   */
  static async reconstructFromChunks(chunks: DomChunk[]): Promise<string> {
    // Find the HTML chunk (last one)
    const htmlChunk = chunks.find(c => c.id.includes('_html'));
    if (!htmlChunk) {
      throw new Error('HTML chunk not found');
    }
    
    let html = htmlChunk.data;
    if (htmlChunk.compressed) {
      html = Buffer.from(html, 'base64').toString('utf-8');
    }
    
    return html;
  }
}

/**
 * Helper class for managing capture rate limiting
 */
export class CaptureRateLimiter {
  private captureTimestamps: number[] = [];
  private readonly maxCapturesPerMinute: number;
  private readonly maxCapturesPerHour: number;
  
  constructor(maxPerMinute = 10, maxPerHour = 100) {
    this.maxCapturesPerMinute = maxPerMinute;
    this.maxCapturesPerHour = maxPerHour;
  }
  
  /**
   * Check if capture is allowed based on rate limits
   */
  canCapture(): boolean {
    const now = Date.now();
    const oneMinuteAgo = now - 60 * 1000;
    const oneHourAgo = now - 60 * 60 * 1000;
    
    // Clean old timestamps
    this.captureTimestamps = this.captureTimestamps.filter(ts => ts > oneHourAgo);
    
    // Count captures in last minute and hour
    const capturesInLastMinute = this.captureTimestamps.filter(ts => ts > oneMinuteAgo).length;
    const capturesInLastHour = this.captureTimestamps.length;
    
    if (capturesInLastMinute >= this.maxCapturesPerMinute) {
      return false;
    }
    
    if (capturesInLastHour >= this.maxCapturesPerHour) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Record a capture
   */
  recordCapture(): void {
    this.captureTimestamps.push(Date.now());
  }
  
  /**
   * Get time until next capture is allowed
   */
  getWaitTime(): number {
    if (this.canCapture()) {
      return 0;
    }
    
    const now = Date.now();
    const oneMinuteAgo = now - 60 * 1000;
    const oldestInLastMinute = this.captureTimestamps
      .filter(ts => ts > oneMinuteAgo)
      .sort()[0];
    
    if (oldestInLastMinute) {
      return (oldestInLastMinute + 60 * 1000) - now;
    }
    
    return 60 * 1000; // Wait 1 minute by default
  }
}