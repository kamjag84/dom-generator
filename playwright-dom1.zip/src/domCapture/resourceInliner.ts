import { Page } from 'playwright';

export class ResourceInliner {
  private page: Page;
  private cache: Map<string, string> = new Map();

  constructor(page: Page) {
    this.page = page;
  }

  async inlineAllResources(html: string): Promise<string> {
    let processedHtml = html;
    
    // Inline images
    processedHtml = await this.inlineImages(processedHtml);
    
    // Inline stylesheets
    processedHtml = await this.inlineStylesheets(processedHtml);
    
    // Inline fonts
    processedHtml = await this.inlineFonts(processedHtml);
    
    // Inline background images in styles
    processedHtml = await this.inlineBackgroundImages(processedHtml);
    
    // Inline favicons
    processedHtml = await this.inlineFavicons(processedHtml);
    
    return processedHtml;
  }

  private async inlineImages(html: string): Promise<string> {
    const imageRegex = /<img[^>]*src=["']([^"']+)["'][^>]*>/gi;
    const matches = Array.from(html.matchAll(imageRegex));
    
    for (const match of matches) {
      const [fullMatch, src] = match;
      if (!src.startsWith('data:')) {
        const dataUrl = await this.fetchAsDataUrl(src, 'image');
        if (dataUrl) {
          html = html.replace(fullMatch, fullMatch.replace(src, dataUrl));
        }
      }
    }
    
    return html;
  }

  private async inlineStylesheets(html: string): Promise<string> {
    const linkRegex = /<link[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>/gi;
    const matches = Array.from(html.matchAll(linkRegex));
    
    for (const match of matches) {
      const [fullMatch, href] = match;
      if (!href.startsWith('data:')) {
        const css = await this.fetchStylesheet(href);
        if (css) {
          const styleTag = `<style data-original-href="${href}">\n${css}\n</style>`;
          html = html.replace(fullMatch, styleTag);
        }
      }
    }
    
    return html;
  }

  private async inlineFonts(html: string): Promise<string> {
    const fontFaceRegex = /@font-face\s*{[^}]*src:\s*url\(['"]?([^'")]+)['"]?\)[^}]*}/gi;
    const matches = Array.from(html.matchAll(fontFaceRegex));
    
    for (const match of matches) {
      const [fullMatch, fontUrl] = match;
      if (!fontUrl.startsWith('data:')) {
        const dataUrl = await this.fetchAsDataUrl(fontUrl, 'font');
        if (dataUrl) {
          html = html.replace(fontUrl, dataUrl);
        }
      }
    }
    
    return html;
  }

  private async inlineBackgroundImages(html: string): Promise<string> {
    const bgImageRegex = /background(?:-image)?:\s*url\(['"]?([^'")]+)['"]?\)/gi;
    const matches = Array.from(html.matchAll(bgImageRegex));
    
    for (const match of matches) {
      const [fullMatch, imageUrl] = match;
      if (!imageUrl.startsWith('data:')) {
        const dataUrl = await this.fetchAsDataUrl(imageUrl, 'image');
        if (dataUrl) {
          html = html.replace(imageUrl, dataUrl);
        }
      }
    }
    
    return html;
  }

  private async inlineFavicons(html: string): Promise<string> {
    const faviconRegex = /<link[^>]*rel=["'](?:icon|shortcut icon)["'][^>]*href=["']([^"']+)["'][^>]*>/gi;
    const matches = Array.from(html.matchAll(faviconRegex));
    
    for (const match of matches) {
      const [fullMatch, href] = match;
      if (!href.startsWith('data:')) {
        const dataUrl = await this.fetchAsDataUrl(href, 'image');
        if (dataUrl) {
          html = html.replace(href, dataUrl);
        }
      }
    }
    
    return html;
  }

  private async fetchAsDataUrl(url: string, type: 'image' | 'font'): Promise<string | null> {
    if (this.cache.has(url)) {
      return this.cache.get(url) || null;
    }

    try {
      const absoluteUrl = await this.page.evaluate((relativeUrl) => {
        return new URL(relativeUrl, window.location.href).href;
      }, url);

      const dataUrl = await this.page.evaluate(async ([url, type]) => {
        try {
          const response = await fetch(url);
          const blob = await response.blob();
          
          return new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        } catch (e) {
          console.error(`Failed to fetch ${type}: ${url}`, e);
          return null;
        }
      }, [absoluteUrl, type]);

      if (dataUrl) {
        this.cache.set(url, dataUrl);
      }
      
      return dataUrl;
    } catch (e) {
      console.error(`Failed to inline ${type}: ${url}`, e);
      return null;
    }
  }

  private async fetchStylesheet(href: string): Promise<string | null> {
    if (this.cache.has(href)) {
      return this.cache.get(href) || null;
    }

    try {
      const absoluteUrl = await this.page.evaluate((relativeUrl) => {
        return new URL(relativeUrl, window.location.href).href;
      }, href);

      const css = await this.page.evaluate(async (url) => {
        try {
          const response = await fetch(url);
          let cssText = await response.text();
          
          // Process @import statements
          const importRegex = /@import\s+(?:url\(['"]?([^'")]+)['"]?\)|['"]([^'"]+)['"]);?/gi;
          const imports = Array.from(cssText.matchAll(importRegex));
          
          for (const [fullImport, urlImport, stringImport] of imports) {
            const importUrl = urlImport || stringImport;
            const absoluteImportUrl = new URL(importUrl, url).href;
            
            try {
              const importResponse = await fetch(absoluteImportUrl);
              const importCss = await importResponse.text();
              cssText = cssText.replace(fullImport, importCss);
            } catch (e) {
              console.error(`Failed to fetch imported CSS: ${absoluteImportUrl}`, e);
            }
          }
          
          return cssText;
        } catch (e) {
          console.error(`Failed to fetch stylesheet: ${url}`, e);
          return null;
        }
      }, absoluteUrl);

      if (css) {
        this.cache.set(href, css);
      }
      
      return css;
    } catch (e) {
      console.error(`Failed to fetch stylesheet: ${href}`, e);
      return null;
    }
  }

  clearCache(): void {
    this.cache.clear();
  }
}