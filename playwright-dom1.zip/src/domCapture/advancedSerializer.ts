import { Page } from 'playwright';

export interface DomCaptureOptions {
  captureIframes?: boolean;
  captureShadowDom?: boolean;
  inlineResources?: boolean;
  captureCanvas?: boolean;
  captureFormState?: boolean;
  captureScrollPositions?: boolean;
  captureStorage?: boolean;
  captureConsole?: boolean;
  captureNetworkActivity?: boolean;
  capturePerformanceMetrics?: boolean;
  redactSensitiveData?: boolean;
  compressionLevel?: 'none' | 'low' | 'medium' | 'high';
  includeMetadata?: boolean;
  maxDepth?: number;
}

export interface CaptureMetadata {
  timestamp: string;
  url: string;
  title: string;
  viewport: { width: number; height: number };
  userAgent: string;
  platform: string;
  devicePixelRatio: number;
  cookiesCount: number;
  localStorageSize: number;
  sessionStorageSize: number;
  performanceMetrics?: any;
  networkRequests?: any[];
  consoleLogs?: any[];
  errors?: any[];
  customData?: Record<string, any>;
}

export class AdvancedDomSerializer {
  private options: Required<DomCaptureOptions>;
  private resourceCache: Map<string, string> = new Map();
  private page: Page;

  constructor(page: Page, options: DomCaptureOptions = {}) {
    this.page = page;
    this.options = {
      captureIframes: true,
      captureShadowDom: true,
      inlineResources: true,
      captureCanvas: true,
      captureFormState: true,
      captureScrollPositions: true,
      captureStorage: true,
      captureConsole: true,
      captureNetworkActivity: true,
      capturePerformanceMetrics: true,
      redactSensitiveData: true,
      compressionLevel: 'medium',
      includeMetadata: true,
      maxDepth: 10,
      ...options
    };
  }

  async captureFullDom(): Promise<{ html: string; metadata: CaptureMetadata }> {
    const metadata = await this.collectMetadata();
    
    if (this.options.captureConsole) {
      await this.setupConsoleCapture();
    }
    
    if (this.options.captureNetworkActivity) {
      await this.setupNetworkCapture();
    }

    const html = await this.page.evaluate(
      ([options]) => {
        const serializer = new (window as any).__DomSerializer(options);
        return serializer.serialize();
      },
      [this.options]
    );

    const processedHtml = await this.postProcessHtml(html, metadata);
    
    return { html: processedHtml, metadata };
  }

  private async setupConsoleCapture(): Promise<void> {
    await this.page.addInitScript(() => {
      const logs: any[] = [];
      const originalConsole = { ...console };
      
      ['log', 'info', 'warn', 'error', 'debug'].forEach(method => {
        (console as any)[method] = (...args: any[]) => {
          logs.push({
            type: method,
            message: args.map(arg => {
              try {
                return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
              } catch {
                return String(arg);
              }
            }).join(' '),
            timestamp: new Date().toISOString()
          });
          (originalConsole as any)[method](...args);
        };
      });
      
      (window as any).__consoleLogs = logs;
    });
  }

  private async setupNetworkCapture(): Promise<void> {
    const requests: any[] = [];
    
    this.page.on('request', request => {
      requests.push({
        url: request.url(),
        method: request.method(),
        headers: request.headers(),
        timestamp: new Date().toISOString()
      });
    });
    
    this.page.on('response', response => {
      const requestIndex = requests.findIndex(r => r.url === response.url());
      if (requestIndex !== -1) {
        requests[requestIndex].response = {
          status: response.status(),
          statusText: response.statusText(),
          headers: response.headers()
          // timing method not available in current Playwright version
        };
      }
    });
    
    (this.page as any).__networkRequests = requests;
  }

  private async collectMetadata(): Promise<CaptureMetadata> {
    const metadata = await this.page.evaluate(() => {
      const getStorageSize = (storage: Storage): number => {
        let size = 0;
        for (let i = 0; i < storage.length; i++) {
          const key = storage.key(i);
          if (key) {
            size += key.length + (storage.getItem(key)?.length || 0);
          }
        }
        return size;
      };

      return {
        timestamp: new Date().toISOString(),
        url: window.location.href,
        title: document.title,
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight
        },
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        devicePixelRatio: window.devicePixelRatio,
        cookiesCount: document.cookie.split(';').filter(c => c.trim()).length,
        localStorageSize: getStorageSize(localStorage),
        sessionStorageSize: getStorageSize(sessionStorage),
        performanceMetrics: performance.timing,
        consoleLogs: (window as any).__consoleLogs || [],
        errors: (window as any).__errors || []
      };
    });

    if (this.options.captureNetworkActivity && (this.page as any).__networkRequests) {
      (metadata as any).networkRequests = (this.page as any).__networkRequests;
    }

    return metadata;
  }

  private async postProcessHtml(html: string, metadata: CaptureMetadata): Promise<string> {
    let processed = html;
    
    if (this.options.inlineResources) {
      processed = await this.inlineResources(processed);
    }
    
    if (this.options.includeMetadata) {
      processed = this.embedMetadata(processed, metadata);
    }
    
    if (this.options.compressionLevel !== 'none') {
      processed = this.compressHtml(processed);
    }
    
    return processed;
  }

  private async inlineResources(html: string): Promise<string> {
    // This will be handled by the browser-side serializer
    return html;
  }

  private embedMetadata(html: string, metadata: CaptureMetadata): string {
    const metadataScript = `
<script type="application/json" id="dom-capture-metadata">
${JSON.stringify(metadata, null, 2)}
</script>
`;
    
    const metadataComment = `
<!-- 
DOM Capture Metadata
====================
Captured: ${metadata.timestamp}
URL: ${metadata.url}
Title: ${metadata.title}
Viewport: ${metadata.viewport.width}x${metadata.viewport.height}
User Agent: ${metadata.userAgent}
-->
`;
    
    return html.replace('</head>', `${metadataScript}\n</head>`)
               .replace('<html', `${metadataComment}\n<html`);
  }

  private compressHtml(html: string): string {
    switch (this.options.compressionLevel) {
      case 'low':
        return html.replace(/\s+/g, ' ').trim();
      case 'medium':
        return html.replace(/\s+/g, ' ')
                  .replace(/>\s+</g, '><')
                  .trim();
      case 'high':
        return html.replace(/\s+/g, ' ')
                  .replace(/>\s+</g, '><')
                  .replace(/<!--[\s\S]*?-->/g, '')
                  .trim();
      default:
        return html;
    }
  }
}

// Browser-side serializer that will be injected
export const browserSerializer = `
window.__DomSerializer = class DomSerializer {
  constructor(options) {
    this.options = options;
    this.visitedNodes = new WeakSet();
    this.shadowRoots = new WeakMap();
    this.canvasData = new Map();
    this.depth = 0;
  }

  serialize() {
    this.collectCanvasData();
    this.collectShadowRoots();
    
    const doctype = document.doctype 
      ? \`<!DOCTYPE \${document.doctype.name}>\`
      : '';
    
    const html = this.serializeNode(document.documentElement);
    return doctype + html;
  }

  serializeNode(node, isInShadow = false) {
    if (!node || this.depth > this.options.maxDepth) return '';
    if (this.visitedNodes.has(node)) return '';
    this.visitedNodes.add(node);
    
    this.depth++;
    let result = '';
    
    try {
      if (node.nodeType === Node.ELEMENT_NODE) {
        result = this.serializeElement(node, isInShadow);
      } else if (node.nodeType === Node.TEXT_NODE) {
        result = this.escapeHtml(node.textContent || '');
      } else if (node.nodeType === Node.COMMENT_NODE) {
        result = \`<!--\${node.textContent}-->\`;
      } else if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
        result = this.serializeChildren(node, isInShadow);
      }
    } finally {
      this.depth--;
    }
    
    return result;
  }

  serializeElement(element, isInShadow) {
    const tagName = element.tagName.toLowerCase();
    
    // Handle special elements
    if (tagName === 'script' && this.options.redactSensitiveData) {
      return '';
    }
    
    if (tagName === 'canvas' && this.options.captureCanvas) {
      return this.serializeCanvas(element);
    }
    
    if (tagName === 'iframe' && this.options.captureIframes) {
      return this.serializeIframe(element);
    }
    
    if (tagName === 'input' || tagName === 'textarea' || tagName === 'select') {
      return this.serializeFormElement(element);
    }
    
    if (tagName === 'img' && this.options.inlineResources) {
      return this.serializeImage(element);
    }
    
    let html = \`<\${tagName}\`;
    
    // Serialize attributes
    for (const attr of element.attributes) {
      const value = this.processAttributeValue(attr.name, attr.value, tagName);
      if (value !== null) {
        html += \` \${attr.name}="\${this.escapeAttribute(value)}"\`;
      }
    }
    
    // Capture scroll position
    if (this.options.captureScrollPositions) {
      if (element.scrollTop > 0) {
        html += \` data-scroll-top="\${element.scrollTop}"\`;
      }
      if (element.scrollLeft > 0) {
        html += \` data-scroll-left="\${element.scrollLeft}"\`;
      }
    }
    
    // Capture computed styles
    const styles = this.captureComputedStyles(element);
    if (styles) {
      html += \` style="\${this.escapeAttribute(styles)}"\`;
    }
    
    html += '>';
    
    // Serialize shadow DOM
    if (this.options.captureShadowDom && element.shadowRoot) {
      html += '<template shadowroot="open">';
      html += this.serializeChildren(element.shadowRoot, true);
      html += '</template>';
    }
    
    // Serialize children
    if (!['img', 'br', 'hr', 'input', 'meta', 'link'].includes(tagName)) {
      html += this.serializeChildren(element, isInShadow);
      html += \`</\${tagName}>\`;
    }
    
    return html;
  }

  serializeCanvas(canvas) {
    try {
      const dataUrl = canvas.toDataURL('image/png');
      return \`<img src="\${dataUrl}" width="\${canvas.width}" height="\${canvas.height}" data-original-canvas="true" />\`;
    } catch (e) {
      return \`<canvas width="\${canvas.width}" height="\${canvas.height}"><!-- Canvas capture failed: \${e.message} --></canvas>\`;
    }
  }

  serializeIframe(iframe) {
    let html = '<iframe';
    
    for (const attr of iframe.attributes) {
      html += \` \${attr.name}="\${this.escapeAttribute(attr.value)}"\`;
    }
    
    html += '>';
    
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
      if (iframeDoc) {
        const iframeSerializer = new DomSerializer(this.options);
        html += iframeSerializer.serialize();
      }
    } catch (e) {
      html += \`<!-- Cross-origin iframe: \${iframe.src} -->\`;
    }
    
    html += '</iframe>';
    return html;
  }

  serializeFormElement(element) {
    const tagName = element.tagName.toLowerCase();
    let html = \`<\${tagName}\`;
    
    for (const attr of element.attributes) {
      if (attr.name === 'value' && this.options.redactSensitiveData && element.type === 'password') {
        html += ' value="********"';
      } else {
        html += \` \${attr.name}="\${this.escapeAttribute(attr.value)}"\`;
      }
    }
    
    if (this.options.captureFormState) {
      if (tagName === 'input') {
        if (element.type === 'checkbox' || element.type === 'radio') {
          if (element.checked) {
            html += ' checked';
          }
        } else if (element.value && !element.hasAttribute('value')) {
          html += \` value="\${this.escapeAttribute(element.value)}"\`;
        }
      } else if (tagName === 'textarea') {
        // Value will be added as content
      } else if (tagName === 'select') {
        // Selected state will be captured in options
      }
    }
    
    html += '>';
    
    if (tagName === 'textarea') {
      html += this.escapeHtml(element.value);
      html += '</textarea>';
    } else if (tagName === 'select') {
      for (const option of element.options) {
        html += '<option';
        if (option.value) {
          html += \` value="\${this.escapeAttribute(option.value)}"\`;
        }
        if (option.selected) {
          html += ' selected';
        }
        html += '>';
        html += this.escapeHtml(option.text);
        html += '</option>';
      }
      html += '</select>';
    }
    
    return html;
  }

  serializeImage(img) {
    let html = '<img';
    
    for (const attr of img.attributes) {
      if (attr.name === 'src' && this.options.inlineResources) {
        const dataUrl = this.imageToDataUrl(img);
        if (dataUrl) {
          html += \` src="\${dataUrl}"\`;
        } else {
          html += \` src="\${this.escapeAttribute(attr.value)}"\`;
        }
      } else {
        html += \` \${attr.name}="\${this.escapeAttribute(attr.value)}"\`;
      }
    }
    
    html += ' />';
    return html;
  }

  imageToDataUrl(img) {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      return canvas.toDataURL('image/png');
    } catch (e) {
      return null;
    }
  }

  serializeChildren(node, isInShadow) {
    let html = '';
    for (const child of node.childNodes) {
      html += this.serializeNode(child, isInShadow);
    }
    return html;
  }

  captureComputedStyles(element) {
    const computed = window.getComputedStyle(element);
    const important = [
      'display', 'position', 'top', 'left', 'right', 'bottom',
      'width', 'height', 'margin', 'padding', 'border',
      'background', 'color', 'font', 'transform', 'opacity',
      'visibility', 'z-index', 'overflow'
    ];
    
    const styles = [];
    for (const prop of important) {
      const value = computed.getPropertyValue(prop);
      if (value && value !== 'initial' && value !== 'inherit') {
        styles.push(\`\${prop}: \${value}\`);
      }
    }
    
    return styles.length > 0 ? styles.join('; ') : null;
  }

  processAttributeValue(name, value, tagName) {
    if (this.options.redactSensitiveData) {
      // Redact sensitive attributes
      if (name.toLowerCase().includes('token') || 
          name.toLowerCase().includes('key') ||
          name.toLowerCase().includes('secret')) {
        return '***REDACTED***';
      }
      
      // Redact data attributes with sensitive patterns
      if (name.startsWith('data-') && /api|token|key|secret|password/i.test(value)) {
        return '***REDACTED***';
      }
    }
    
    if (this.options.inlineResources && name === 'href' && tagName === 'link') {
      // Inline stylesheets
      if (value && !value.startsWith('data:')) {
        const inlined = this.inlineStylesheet(value);
        if (inlined) return inlined;
      }
    }
    
    return value;
  }

  inlineStylesheet(href) {
    try {
      const link = document.querySelector(\`link[href="\${href}"]\`);
      if (link && link.sheet) {
        const rules = Array.from(link.sheet.cssRules);
        const css = rules.map(rule => rule.cssText).join('\\n');
        return \`data:text/css;base64,\${btoa(css)}\`;
      }
    } catch (e) {
      // Cross-origin or other error
    }
    return null;
  }

  collectCanvasData() {
    if (!this.options.captureCanvas) return;
    
    document.querySelectorAll('canvas').forEach(canvas => {
      try {
        this.canvasData.set(canvas, canvas.toDataURL());
      } catch (e) {
        // Security error or tainted canvas
      }
    });
  }

  collectShadowRoots() {
    if (!this.options.captureShadowDom) return;
    
    const collectFromNode = (node) => {
      if (node.shadowRoot) {
        this.shadowRoots.set(node, node.shadowRoot);
        this.collectShadowRootsInner(node.shadowRoot);
      }
      
      for (const child of node.children) {
        collectFromNode(child);
      }
    };
    
    collectFromNode(document.documentElement);
  }

  collectShadowRootsInner(shadowRoot) {
    for (const child of shadowRoot.children) {
      if (child.shadowRoot) {
        this.shadowRoots.set(child, child.shadowRoot);
        this.collectShadowRootsInner(child.shadowRoot);
      }
      this.collectShadowRootsInner(child);
    }
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  escapeAttribute(value) {
    return value.replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/&/g, '&amp;');
  }
};
`;