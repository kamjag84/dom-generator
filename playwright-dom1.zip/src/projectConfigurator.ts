import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { SecurityUtils } from './utils/securityUtils';

export class ProjectConfigurator {
    constructor(private context: vscode.ExtensionContext) {}

    async checkPlaywrightInstallation(workspacePath: string): Promise<boolean> {
        // Validate workspace path
        if (!SecurityUtils.isValidWorkspacePath(workspacePath)) {
            throw new Error('Invalid workspace path');
        }
        
        const packageJsonPath = path.join(workspacePath, 'package.json');
        
        if (!await fs.pathExists(packageJsonPath)) {
            return false;
        }

        const packageJson = await fs.readJson(packageJsonPath);
        const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
        
        return '@playwright/test' in deps || 'playwright' in deps;
    }

    async installPlaywright(workspacePath: string): Promise<void> {
        // Validate workspace path
        if (!SecurityUtils.isValidWorkspacePath(workspacePath)) {
            throw new Error('Invalid workspace path');
        }
        
        const terminal = vscode.window.createTerminal('Install Playwright');
        terminal.show();
        
        // Use secure path escaping
        const safePath = SecurityUtils.escapeShellArg(workspacePath);
        terminal.sendText(`cd ${safePath}`);
        terminal.sendText('npm install --save-dev @playwright/test playwright');
        terminal.sendText('npx playwright install');
        
        // Wait for installation to complete
        return new Promise((resolve) => {
            setTimeout(resolve, 30000); // Wait 30 seconds
        });
    }

    async backupExistingConfig(workspacePath: string): Promise<void> {
        const backupDir = path.join(workspacePath, '.dom-capture-backup');
        await fs.ensureDir(backupDir);

        const filesToBackup = [
            'playwright.config.ts',
            'playwright.config.js',
            'package.json',
            'tsconfig.json'
        ];

        for (const file of filesToBackup) {
            const filePath = path.join(workspacePath, file);
            if (await fs.pathExists(filePath)) {
                const backupPath = path.join(backupDir, `${file}.backup`);
                await fs.copy(filePath, backupPath);
            }
        }

        // Save backup metadata
        const metadata = {
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            files: filesToBackup
        };
        await fs.writeJson(path.join(backupDir, 'metadata.json'), metadata, { spaces: 2 });
    }

    async installDomCaptureUtilities(workspacePath: string): Promise<void> {
        // Create dom-capture folder in the project
        const domCapturePath = path.join(workspacePath, 'dom-capture');
        await fs.ensureDir(domCapturePath);

        // Create the capture.js utility file
        const captureJsContent = await this.getCaptureJsContent();
        await fs.writeFile(path.join(domCapturePath, 'capture.js'), captureJsContent, 'utf-8');
        
        // Create the Playwright fixture file
        const fixtureContent = await this.getPlaywrightFixtureContent();
        await fs.writeFile(path.join(domCapturePath, 'playwright-fixture.js'), fixtureContent, 'utf-8');

        // Create config.json with default settings
        const configContent = {
            autoCapture: true,
            captureOnFailure: true,
            includeScreenshot: true,
            outputPath: 'test-results/dom-captures',
            compressionLevel: 'medium',
            retentionDays: 7,
            enableRuntimeCapture: true,
            enableAutomaticFailureCapture: true
        };
        await fs.writeJson(path.join(domCapturePath, 'config.json'), configContent, { spaces: 2 });

        // Create README for the dom-capture folder
        const readmeContent = `# DOM Capture Utilities

This folder contains utilities for capturing DOM during Playwright tests.

## Usage

\`\`\`javascript
const { captureDom } = require('./dom-capture/capture');

test('example test', async ({ page }) => {
    await page.goto('https://example.com');
    await captureDom(page, 'after-navigation');
});
\`\`\`

## Files

- \`capture.js\` - Main capture utility
- \`config.json\` - Configuration settings
- \`README.md\` - This file

## More Information

See the VS Code extension documentation or press Ctrl+Shift+P and search for "DOM Capture".
`;
        await fs.writeFile(path.join(domCapturePath, 'README.md'), readmeContent, 'utf-8');

        // Create examples folder with example test
        const examplesPath = path.join(workspacePath, 'examples');
        await fs.ensureDir(examplesPath);
        
        const exampleTestContent = await this.getExampleTestContent();
        await fs.writeFile(path.join(examplesPath, 'example-with-capture.spec.ts'), exampleTestContent, 'utf-8');

        // Update package.json scripts
        const packageJsonPath = path.join(workspacePath, 'package.json');
        const packageJson = await fs.readJson(packageJsonPath);
        
        packageJson.scripts = packageJson.scripts || {};
        packageJson.scripts['test:dom-capture'] = 'playwright test --reporter=html,json';
        packageJson.scripts['dom-capture:clean'] = 'rm -rf test-results/dom-captures';
        packageJson.scripts['dom-capture:report'] = 'playwright show-report';
        packageJson.scripts['dom-capture:example'] = 'playwright test examples/example-with-capture.spec.ts';
        
        await fs.writeJson(packageJsonPath, packageJson, { spaces: 2 });
    }

    private async getCaptureJsContent(): Promise<string> {
        // Try to read from templates folder
        const templatesPath = path.join(this.context.extensionPath, 'templates', 'capture.js');
        if (await fs.pathExists(templatesPath)) {
            return await fs.readFile(templatesPath, 'utf-8');
        }
        
        // Try from out/templates folder (when packaged)
        const outTemplatesPath = path.join(this.context.extensionPath, 'out', 'templates', 'capture.js');
        if (await fs.pathExists(outTemplatesPath)) {
            return await fs.readFile(outTemplatesPath, 'utf-8');
        }
        
        // Fallback: return a basic capture function
        return this.getFallbackCaptureJs();
    }
    
    private getFallbackCaptureJs(): string {
        return `const fs = require('fs').promises;
const path = require('path');

async function captureDom(page, label = '', options = {}) {
    try {
        const dom = await page.content();
        const date = new Date();
        const dateFolder = \`\${date.getDate().toString().padStart(2, '0')}-\${(date.getMonth() + 1).toString().padStart(2, '0')}-\${date.getFullYear()}\`;
        const timestamp = \`\${date.getHours().toString().padStart(2, '0')}-\${date.getMinutes().toString().padStart(2, '0')}-\${date.getSeconds().toString().padStart(2, '0')}\`;
        
        const folderPath = path.join(process.cwd(), 'test-results', 'dom-captures', dateFolder, 'capture');
        await fs.mkdir(folderPath, { recursive: true });
        
        const filePath = path.join(folderPath, \`capture_\${timestamp}_\${label}.html\`);
        await fs.writeFile(filePath, dom, 'utf-8');
        
        console.log(\`✅ DOM captured: \${filePath}\`);
        return { path: filePath };
    } catch (error) {
        console.error('Failed to capture DOM:', error);
        throw error;
    }
}

module.exports = { captureDom };`;
    }

    private async getExampleTestContent(): Promise<string> {
        // Try to read from templates folder
        const templatesPath = path.join(this.context.extensionPath, 'templates', 'example-with-capture.spec.ts');
        if (await fs.pathExists(templatesPath)) {
            return await fs.readFile(templatesPath, 'utf-8');
        }
        
        // Try from out/templates folder (when packaged)
        const outTemplatesPath = path.join(this.context.extensionPath, 'out', 'templates', 'example-with-capture.spec.ts');
        if (await fs.pathExists(outTemplatesPath)) {
            return await fs.readFile(outTemplatesPath, 'utf-8');
        }
        
        // Fallback
        return this.getFallbackExampleTest();
    }
    
    private async getPlaywrightFixtureContent(): Promise<string> {
        // Try to read from templates folder
        const templatesPath = path.join(this.context.extensionPath, 'templates', 'playwright-fixture.js');
        if (await fs.pathExists(templatesPath)) {
            return await fs.readFile(templatesPath, 'utf-8');
        }
        
        // Try from out/templates folder (when packaged)
        const outTemplatesPath = path.join(this.context.extensionPath, 'out', 'templates', 'playwright-fixture.js');
        if (await fs.pathExists(outTemplatesPath)) {
            return await fs.readFile(outTemplatesPath, 'utf-8');
        }
        
        // Fallback
        return this.getFallbackFixture();
    }
    
    private getFallbackExampleTest(): string {
        return `import { test, expect } from '@playwright/test';
const { captureDom } = require('./dom-capture/capture');

test('example test', async ({ page }) => {
    await page.goto('https://example.com');
    await captureDom(page, 'after-navigation');
    await expect(page.locator('h1')).toBeVisible();
});`;
    }
    
    private getFallbackFixture(): string {
        return `const base = require('@playwright/test');
const { captureDom } = require('./capture');

// Enhanced test fixture with auto-capture
exports.test = base.test.extend({
    page: async ({ page }, use, testInfo) => {
        console.log('🎯 DOM Capture auto-enabled for:', testInfo.title);
        
        // Enable hotkey capture automatically
        await page.addInitScript(() => {
            // Keyboard listener for Ctrl+Shift+C
            document.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.shiftKey && e.key === 'C') {
                    e.preventDefault();
                    window.__triggerDomCapture = true;
                    console.log('DOM Capture triggered!');
                }
            }, true);
        });
        
        // Poll for capture triggers
        const interval = setInterval(async () => {
            const shouldCapture = await page.evaluate(() => {
                const trigger = window.__triggerDomCapture;
                if (trigger) {
                    window.__triggerDomCapture = false;
                    return true;
                }
                return false;
            }).catch(() => false);
            
            if (shouldCapture) {
                await captureDom(page, 'manual-capture');
            }
        }, 100);
        
        await use(page);
        clearInterval(interval);
        
        // Auto-capture on failure
        if (testInfo.status === 'failed') {
            await captureDom(page, 'test-failed');
        }
    }
});

exports.expect = base.expect;
exports.captureDom = captureDom;`;
    }

    async updateTestFiles(workspacePath: string): Promise<void> {
        // Ask user if they want to update test files
        const updateChoice = await vscode.window.showInformationMessage(
            'Would you like to update existing test files to use DOM capture?',
            'Yes, update my tests',
            'No, I\'ll do it manually',
            'Show me an example'
        );

        if (updateChoice === 'Show me an example') {
            // Open the example file
            const examplePath = path.join(workspacePath, 'examples', 'example-with-capture.spec.ts');
            const doc = await vscode.workspace.openTextDocument(examplePath);
            await vscode.window.showTextDocument(doc);
            return;
        }

        if (updateChoice !== 'Yes, update my tests') {
            // Don't update test files, just show instructions
            vscode.window.showInformationMessage(
                'To use DOM capture in your tests, add: const { captureDom } = require(\'./dom-capture/capture\');'
            );
            return;
        }

        // User chose to update tests
        const testFiles = await this.findTestFiles(workspacePath);
        let updatedCount = 0;
        
        for (const file of testFiles) {
            const content = await fs.readFile(file, 'utf-8');
            
            // Check if already using dom-capture
            if (content.includes('dom-capture')) {
                continue;
            }

            // Add import at the top of the file (after existing imports)
            let updatedContent = content;
            
            // Check if using TypeScript or JavaScript
            const isTypeScript = file.endsWith('.ts');
            
            // Find the right place to add the import
            const importRegex = /^(import\s+.*?from\s+['"].*?['"];?\s*\n)+/m;
            const requireRegex = /^(const\s+.*?=\s+require\(.*?\);?\s*\n)+/m;
            
            // Replace @playwright/test import with our fixture
            if (content.includes("from '@playwright/test'")) {
                updatedContent = content.replace(
                    /import\s*{\s*test\s*,\s*expect\s*}\s*from\s*['"]@playwright\/test['"]/g,
                    "// Using DOM Capture enhanced test fixture - added by VS Code extension\nimport { test, expect } from './dom-capture/playwright-fixture'"
                );
            } else if (content.includes("require('@playwright/test')")) {
                updatedContent = content.replace(
                    /const\s*{\s*test\s*,\s*expect\s*}\s*=\s*require\(['"]@playwright\/test['"]\)/g,
                    "// Using DOM Capture enhanced test fixture - added by VS Code extension\nconst { test, expect } = require('./dom-capture/playwright-fixture')"
                );
            } else if (importRegex.test(content)) {
                // Add after last import
                updatedContent = content.replace(importRegex, (match) => {
                    return match + "// DOM Capture utility - added by VS Code extension\nconst { captureDom } = require('./dom-capture/capture');\n\n";
                });
            } else if (requireRegex.test(content)) {
                // Add after last require
                updatedContent = content.replace(requireRegex, (match) => {
                    return match + "// DOM Capture utility - added by VS Code extension\nconst { captureDom } = require('./dom-capture/capture');\n\n";
                });
            } else {
                // Add at the very top
                updatedContent = "// DOM Capture utility - added by VS Code extension\nconst { captureDom } = require('./dom-capture/capture');\n\n" + content;
            }

            // Add helpful comment in first test
            const testRegex = /test\(['"]([^'"]+)['"]/;
            if (testRegex.test(updatedContent) && !updatedContent.includes('captureDom')) {
                updatedContent = updatedContent.replace(testRegex, (match) => {
                    return `${match}\n        // You can now use: await captureDom(page, 'label'); to capture DOM`;
                });
            }

            await fs.writeFile(file, updatedContent, 'utf-8');
            updatedCount++;
        }

        if (updatedCount > 0) {
            vscode.window.showInformationMessage(
                `Updated ${updatedCount} test file(s) with DOM capture import. See examples folder for usage.`
            );
        }
    }

    private async findTestFiles(workspacePath: string): Promise<string[]> {
        const testFiles: string[] = [];
        const patterns = ['**/*.spec.ts', '**/*.spec.js', '**/*.test.ts', '**/*.test.js'];
        
        for (const pattern of patterns) {
            const files = await vscode.workspace.findFiles(pattern, '**/node_modules/**');
            testFiles.push(...files.map(f => f.fsPath));
        }
        
        return testFiles;
    }

    async verifyConfiguration(workspacePath: string): Promise<string[]> {
        const issues: string[] = [];

        // Check if Playwright is installed
        if (!await this.checkPlaywrightInstallation(workspacePath)) {
            issues.push('Playwright is not installed');
        }

        // Check if dom-capture folder exists
        const domCapturePath = path.join(workspacePath, 'dom-capture');
        if (!await fs.pathExists(domCapturePath)) {
            issues.push('DOM capture folder not found');
        } else {
            // Check for capture.js
            const captureJsPath = path.join(domCapturePath, 'capture.js');
            if (!await fs.pathExists(captureJsPath)) {
                issues.push('capture.js not found in dom-capture folder');
            }

            // Check for config.json
            const configPath = path.join(domCapturePath, 'config.json');
            if (!await fs.pathExists(configPath)) {
                issues.push('config.json not found in dom-capture folder');
            }
        }

        // Check if examples exist
        const examplesPath = path.join(workspacePath, 'examples', 'example-with-capture.spec.ts');
        if (!await fs.pathExists(examplesPath)) {
            issues.push('Example test file not found');
        }

        // Check if any test uses DOM capture
        const testFiles = await this.findTestFiles(workspacePath);
        let hasConfiguredTests = false;
        
        for (const file of testFiles) {
            const content = await fs.readFile(file, 'utf-8');
            if (content.includes('dom-capture/capture')) {
                hasConfiguredTests = true;
                break;
            }
        }
        
        if (!hasConfiguredTests && testFiles.length > 0) {
            issues.push('No test files are using DOM capture (add: const { captureDom } = require(\'./dom-capture/capture\'))');
        }

        // Check if test-results folder is writable
        const testResultsPath = path.join(workspacePath, 'test-results');
        try {
            await fs.ensureDir(testResultsPath);
            await fs.access(testResultsPath, fs.constants.W_OK);
        } catch (error) {
            issues.push('Cannot write to test-results folder');
        }

        return issues;
    }

    async rollbackConfiguration(workspacePath: string): Promise<void> {
        const backupDir = path.join(workspacePath, '.dom-capture-backup');
        
        if (!await fs.pathExists(backupDir)) {
            throw new Error('No backup found to rollback');
        }

        const metadataPath = path.join(backupDir, 'metadata.json');
        const metadata = await fs.readJson(metadataPath);

        // Restore backed up files
        for (const file of metadata.files) {
            const backupPath = path.join(backupDir, `${file}.backup`);
            if (await fs.pathExists(backupPath)) {
                const originalPath = path.join(workspacePath, file);
                await fs.copy(backupPath, originalPath, { overwrite: true });
            }
        }

        // Remove added directories and files
        await fs.remove(path.join(workspacePath, 'dom-capture'));
        await fs.remove(path.join(workspacePath, 'examples', 'example-with-capture.spec.ts'));
        
        // Try to remove examples folder if empty
        try {
            const examplesPath = path.join(workspacePath, 'examples');
            const files = await fs.readdir(examplesPath);
            if (files.length === 0) {
                await fs.remove(examplesPath);
            }
        } catch (error) {
            // Ignore if examples folder doesn't exist or has other files
        }

        // Clean backup directory
        await fs.remove(backupDir);
    }
}