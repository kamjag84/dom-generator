import * as vscode from 'vscode';
import { CaptureManager } from './captureManager';

export class DashboardPanel {
    public static currentPanel: DashboardPanel | undefined;
    private readonly _panel: vscode.WebviewPanel;
    private readonly _extensionUri: vscode.Uri;
    private _disposables: vscode.Disposable[] = [];
    private captureManager: CaptureManager;

    public static createOrShow(extensionUri: vscode.Uri, captureManager: CaptureManager) {
        const column = vscode.window.activeTextEditor
            ? vscode.window.activeTextEditor.viewColumn
            : undefined;

        if (DashboardPanel.currentPanel) {
            DashboardPanel.currentPanel._panel.reveal(column);
            DashboardPanel.currentPanel.refresh();
            return;
        }

        const panel = vscode.window.createWebviewPanel(
            'domCaptureDashboard',
            'DOM Capture Dashboard',
            column || vscode.ViewColumn.One,
            {
                enableScripts: true,
                retainContextWhenHidden: true,
                localResourceRoots: [extensionUri]
            }
        );

        DashboardPanel.currentPanel = new DashboardPanel(panel, extensionUri, captureManager);
    }

    private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri, captureManager: CaptureManager) {
        this._panel = panel;
        this._extensionUri = extensionUri;
        this.captureManager = captureManager;

        this._update();

        this._panel.onDidDispose(() => this.dispose(), null, this._disposables);

        this._panel.webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'refresh':
                        this.refresh();
                        return;
                    case 'openCapture':
                        this.openCapture(message.path);
                        return;
                    case 'deleteCapture':
                        this.deleteCapture(message.path);
                        return;
                    case 'exportCaptures':
                        this.exportCaptures();
                        return;
                    case 'cleanOldCaptures':
                        this.cleanOldCaptures();
                        return;
                }
            },
            null,
            this._disposables
        );
    }

    public dispose() {
        DashboardPanel.currentPanel = undefined;
        this._panel.dispose();
        while (this._disposables.length) {
            const x = this._disposables.pop();
            if (x) {
                x.dispose();
            }
        }
    }

    private async _update() {
        const webview = this._panel.webview;
        this._panel.title = 'DOM Capture Dashboard';
        this._panel.webview.html = await this._getHtmlForWebview(webview);
    }

    private async refresh() {
        await this.captureManager.loadCaptures();
        this._update();
    }

    private async openCapture(path: string) {
        const captures = await this.captureManager.getCaptures();
        const capture = captures.find(c => c.path === path);
        if (capture) {
            await this.captureManager.openCapture(capture);
        }
    }

    private async deleteCapture(path: string) {
        const fs = require('fs-extra');
        await fs.remove(path);
        const screenshotPath = path.replace('.html', '_screenshot.png');
        if (await fs.pathExists(screenshotPath)) {
            await fs.remove(screenshotPath);
        }
        this.refresh();
    }

    private async exportCaptures() {
        const uri = await vscode.window.showSaveDialog({
            defaultUri: vscode.Uri.file('dom-captures-export'),
            filters: { 'All Files': ['*'] }
        });

        if (uri) {
            await this.captureManager.exportCaptures(uri.fsPath);
            vscode.window.showInformationMessage('Captures exported successfully!');
        }
    }

    private async cleanOldCaptures() {
        const config = vscode.workspace.getConfiguration('playwright-dom-capture');
        const retentionDays = config.get<number>('retentionDays', 7);
        const deletedCount = await this.captureManager.cleanOldCaptures(retentionDays);
        vscode.window.showInformationMessage(`Deleted ${deletedCount} old captures`);
        this.refresh();
    }

    private async _getHtmlForWebview(webview: vscode.Webview) {
        const captures = await this.captureManager.getCaptures();
        const stats = await this.captureManager.getStatistics();

        return `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>DOM Capture Dashboard</title>
            <style>
                body {
                    font-family: var(--vscode-font-family);
                    color: var(--vscode-foreground);
                    background-color: var(--vscode-editor-background);
                    padding: 20px;
                    margin: 0;
                }
                
                h1 {
                    color: var(--vscode-editor-foreground);
                    border-bottom: 2px solid var(--vscode-panel-border);
                    padding-bottom: 10px;
                }
                
                .stats {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 15px;
                    margin: 20px 0;
                }
                
                .stat-card {
                    background: var(--vscode-editor-background);
                    border: 1px solid var(--vscode-panel-border);
                    border-radius: 4px;
                    padding: 15px;
                }
                
                .stat-value {
                    font-size: 24px;
                    font-weight: bold;
                    color: var(--vscode-editor-foreground);
                }
                
                .stat-label {
                    color: var(--vscode-descriptionForeground);
                    margin-top: 5px;
                }
                
                .toolbar {
                    margin: 20px 0;
                    display: flex;
                    gap: 10px;
                }
                
                button {
                    background: var(--vscode-button-background);
                    color: var(--vscode-button-foreground);
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }
                
                button:hover {
                    background: var(--vscode-button-hoverBackground);
                }
                
                .captures-grid {
                    margin-top: 20px;
                }
                
                .capture-item {
                    background: var(--vscode-editor-background);
                    border: 1px solid var(--vscode-panel-border);
                    border-radius: 4px;
                    padding: 15px;
                    margin-bottom: 10px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .capture-item.failed {
                    border-left: 4px solid var(--vscode-errorForeground);
                }
                
                .capture-item.success {
                    border-left: 4px solid var(--vscode-testing-iconPassed);
                }
                
                .capture-info {
                    flex: 1;
                }
                
                .capture-name {
                    font-weight: bold;
                    margin-bottom: 5px;
                }
                
                .capture-meta {
                    color: var(--vscode-descriptionForeground);
                    font-size: 12px;
                }
                
                .capture-actions {
                    display: flex;
                    gap: 5px;
                }
                
                .icon-button {
                    background: transparent;
                    border: 1px solid var(--vscode-panel-border);
                    padding: 5px 10px;
                    font-size: 12px;
                }
                
                .icon-button:hover {
                    background: var(--vscode-list-hoverBackground);
                }
                
                .empty-state {
                    text-align: center;
                    padding: 40px;
                    color: var(--vscode-descriptionForeground);
                }
                
                .filter-tabs {
                    display: flex;
                    gap: 10px;
                    margin: 20px 0;
                    border-bottom: 1px solid var(--vscode-panel-border);
                }
                
                .tab {
                    padding: 10px 20px;
                    background: transparent;
                    border: none;
                    border-bottom: 2px solid transparent;
                    cursor: pointer;
                    color: var(--vscode-foreground);
                }
                
                .tab.active {
                    border-bottom-color: var(--vscode-focusBorder);
                }
                
                .badge {
                    background: var(--vscode-badge-background);
                    color: var(--vscode-badge-foreground);
                    padding: 2px 6px;
                    border-radius: 10px;
                    font-size: 11px;
                    margin-left: 5px;
                }
            </style>
        </head>
        <body>
            <h1>🎯 DOM Capture Dashboard</h1>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">${stats.total}</div>
                    <div class="stat-label">Total Captures</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.failed}</div>
                    <div class="stat-label">Failed Tests</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.success}</div>
                    <div class="stat-label">Successful Tests</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${this.formatSize(stats.totalSize)}</div>
                    <div class="stat-label">Total Size</div>
                </div>
            </div>
            
            <div class="toolbar">
                <button onclick="refresh()">🔄 Refresh</button>
                <button onclick="exportCaptures()">📤 Export All</button>
                <button onclick="cleanOldCaptures()">🗑️ Clean Old</button>
            </div>
            
            <div class="filter-tabs">
                <button class="tab active" onclick="filterCaptures('all')">
                    All <span class="badge">${stats.total}</span>
                </button>
                <button class="tab" onclick="filterCaptures('failed')">
                    Failed <span class="badge">${stats.failed}</span>
                </button>
                <button class="tab" onclick="filterCaptures('success')">
                    Success <span class="badge">${stats.success}</span>
                </button>
            </div>
            
            <div class="captures-grid">
                ${captures.length === 0 ? `
                    <div class="empty-state">
                        <h3>No captures found</h3>
                        <p>Run your tests to see DOM captures here</p>
                    </div>
                ` : captures.map(capture => `
                    <div class="capture-item ${capture.status}">
                        <div class="capture-info">
                            <div class="capture-name">${capture.testName}</div>
                            <div class="capture-meta">
                                ${new Date(capture.timestamp).toLocaleString()} | 
                                ${this.formatSize(capture.size)}
                                ${capture.hasScreenshot ? '| 📷 Screenshot' : ''}
                            </div>
                        </div>
                        <div class="capture-actions">
                            <button class="icon-button" data-action="open" data-path="${this.escapeHtml(capture.path)}">
                                👁️ View
                            </button>
                            <button class="icon-button" data-action="delete" data-path="${this.escapeHtml(capture.path)}">
                                🗑️ Delete
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <script>
                const vscode = acquireVsCodeApi();
                
                // Secure event delegation for buttons
                document.addEventListener('click', (e) => {
                    const button = e.target.closest('button[data-action]');
                    if (!button) return;
                    
                    const action = button.getAttribute('data-action');
                    const path = button.getAttribute('data-path');
                    
                    if (action === 'open') {
                        vscode.postMessage({ command: 'openCapture', path });
                    } else if (action === 'delete') {
                        if (confirm('Delete this capture?')) {
                            vscode.postMessage({ command: 'deleteCapture', path });
                        }
                    }
                });
                
                function refresh() {
                    vscode.postMessage({ command: 'refresh' });
                }
                
                function exportCaptures() {
                    vscode.postMessage({ command: 'exportCaptures' });
                }
                
                function cleanOldCaptures() {
                    vscode.postMessage({ command: 'cleanOldCaptures' });
                }
                
                function filterCaptures(filter) {
                    document.querySelectorAll('.tab').forEach(tab => {
                        tab.classList.remove('active');
                    });
                    event.target.classList.add('active');
                    
                    const items = document.querySelectorAll('.capture-item');
                    items.forEach(item => {
                        if (filter === 'all') {
                            item.style.display = 'flex';
                        } else if (filter === 'failed' && item.classList.contains('failed')) {
                            item.style.display = 'flex';
                        } else if (filter === 'success' && item.classList.contains('success')) {
                            item.style.display = 'flex';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                }
            </script>
        </body>
        </html>`;
    }

    private formatSize(bytes: number): string {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    private escapeHtml(unsafe: string): string {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;")
            .replace(/\//g, "&#x2F;");
    }
}