import * as vscode from 'vscode';
import { CaptureManager } from './captureManager';
import { ProjectConfigurator } from './projectConfigurator';

// Type definitions for Chat API (not available in older VS Code versions)
type ChatRequest = any;
type ChatContext = any;
type ChatResponseStream = any;

export class DomCaptureChatParticipant {
    private captureManager: CaptureManager;
    private configurator: ProjectConfigurator;

    constructor(context: vscode.ExtensionContext) {
        this.captureManager = new CaptureManager(context);
        this.configurator = new ProjectConfigurator(context);
    }

    async handleChatRequest(
        request: ChatRequest,
        context: ChatContext,
        stream: ChatResponseStream,
        token: vscode.CancellationToken
    ): Promise<void> {
        const query = request.prompt.toLowerCase();
        
        // Parse the command from the query
        if (query.includes('setup') || query.includes('configure') || query.includes('install')) {
            await this.handleSetup(stream, token);
        } else if (query.includes('capture') && query.includes('add')) {
            await this.handleAddCapture(stream, token);
        } else if (query.includes('dashboard') || query.includes('view') || query.includes('show')) {
            await this.handleShowDashboard(stream, token);
        } else if (query.includes('last') || query.includes('recent')) {
            await this.handleShowLastCapture(stream, token);
        } else if (query.includes('clean') || query.includes('delete')) {
            await this.handleCleanCaptures(stream, token);
        } else if (query.includes('verify') || query.includes('check')) {
            await this.handleVerifyConfig(stream, token);
        } else if (query.includes('rollback') || query.includes('remove')) {
            await this.handleRollback(stream, token);
        } else if (query.includes('help') || query.includes('what')) {
            await this.handleHelp(stream, token);
        } else {
            await this.handleGeneralQuery(request.prompt, stream, token);
        }
    }

    private async handleSetup(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 🚀 Setting up DOM Capture\n\n');
        stream.markdown('I\'ll help you configure DOM capture for your Playwright tests.\n\n');
        
        // Add button to trigger setup
        stream.button({
            command: 'playwright-dom-capture.autoConfigureProject',
            title: '▶️ Auto-Configure Project'
        });
        
        stream.markdown('\n\n**What this will do:**\n');
        stream.markdown('1. ✅ Install required dependencies\n');
        stream.markdown('2. 📁 Create backup of your current configuration\n');
        stream.markdown('3. 🔧 Add DOM capture utilities to your project\n');
        stream.markdown('4. 📝 Update your test files to support DOM capture\n\n');
        
        stream.markdown('**After setup, you can:**\n');
        stream.markdown('- Use `await captureDom()` in your tests\n');
        stream.markdown('- Automatically capture DOM on test failures\n');
        stream.markdown('- View captures in the dashboard\n');
    }

    private async handleAddCapture(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 📸 Adding DOM Capture Points\n\n');
        
        const editor = vscode.window.activeTextEditor;
        if (editor && (editor.document.fileName.includes('.spec.') || editor.document.fileName.includes('.test.'))) {
            stream.markdown('I can add a capture point at your current cursor position.\n\n');
            
            stream.button({
                command: 'playwright-dom-capture.addCapturePoint',
                title: '➕ Add Capture Point Here'
            });
            
            stream.markdown('\n\n**Example usage:**\n');
            stream.markdown('```typescript\n');
            stream.markdown('test(\'my test\', async ({ page, captureDom }) => {\n');
            stream.markdown('  await page.goto(\'https://example.com\');\n');
            stream.markdown('  \n');
            stream.markdown('  // Capture DOM at this point\n');
            stream.markdown('  await captureDom();\n');
            stream.markdown('  \n');
            stream.markdown('  await page.click(\'#submit\');\n');
            stream.markdown('});\n');
            stream.markdown('```\n');
        } else {
            stream.markdown('⚠️ Please open a test file (.spec.ts or .test.ts) to add capture points.\n');
        }
    }

    private async handleShowDashboard(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 📊 DOM Capture Dashboard\n\n');
        
        const stats = await this.captureManager.getStatistics();
        
        stream.markdown(`**Current Statistics:**\n`);
        stream.markdown(`- Total Captures: ${stats.total}\n`);
        stream.markdown(`- Failed Tests: ${stats.failed}\n`);
        stream.markdown(`- Successful Tests: ${stats.success}\n\n`);
        
        stream.button({
            command: 'playwright-dom-capture.showDashboard',
            title: '📊 Open Dashboard'
        });
        
        stream.markdown('\n\n**Dashboard Features:**\n');
        stream.markdown('- View all captured DOMs\n');
        stream.markdown('- Filter by status (failed/success)\n');
        stream.markdown('- Export captures\n');
        stream.markdown('- Clean old captures\n');
    }

    private async handleShowLastCapture(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 📄 Last DOM Capture\n\n');
        
        const lastCapture = await this.captureManager.getLastCapture();
        
        if (lastCapture) {
            stream.markdown(`**Last Capture Details:**\n`);
            stream.markdown(`- Test: ${lastCapture.testName}\n`);
            stream.markdown(`- Status: ${lastCapture.status === 'failed' ? '❌ Failed' : '✅ Success'}\n`);
            stream.markdown(`- Time: ${lastCapture.timestamp.toLocaleString()}\n\n`);
            
            stream.button({
                command: 'playwright-dom-capture.showLastCapture',
                title: '👁️ View Last Capture'
            });
        } else {
            stream.markdown('No captures found yet. Run your tests to generate DOM captures.\n');
        }
    }

    private async handleCleanCaptures(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 🧹 Clean Old Captures\n\n');
        
        const config = vscode.workspace.getConfiguration('playwright-dom-capture');
        const retentionDays = config.get<number>('retentionDays', 7);
        
        stream.markdown(`Current retention period: **${retentionDays} days**\n\n`);
        
        stream.button({
            command: 'playwright-dom-capture.cleanCaptures',
            title: '🗑️ Clean Old Captures'
        });
        
        stream.markdown('\n\nThis will delete all captures older than the retention period.\n');
    }

    private async handleVerifyConfig(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## ✅ Verifying Configuration\n\n');
        
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            stream.markdown('❌ No workspace folder found.\n');
            return;
        }
        
        const issues = await this.configurator.verifyConfiguration(workspaceFolder.uri.fsPath);
        
        if (issues.length === 0) {
            stream.markdown('✅ **DOM Capture is properly configured!**\n\n');
            stream.markdown('You\'re ready to:\n');
            stream.markdown('- Use `await captureDom()` in tests\n');
            stream.markdown('- Automatically capture DOM on failures\n');
        } else {
            stream.markdown('⚠️ **Configuration issues found:**\n\n');
            issues.forEach(issue => {
                stream.markdown(`- ${issue}\n`);
            });
            
            stream.markdown('\n');
            stream.button({
                command: 'playwright-dom-capture.autoConfigureProject',
                title: '🔧 Fix Configuration'
            });
        }
    }

    private async handleRollback(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 🔄 Rollback Configuration\n\n');
        stream.markdown('⚠️ **Warning:** This will remove DOM capture from your project and restore original configuration.\n\n');
        
        stream.button({
            command: 'playwright-dom-capture.rollbackConfig',
            title: '⚠️ Rollback Configuration'
        });
        
        stream.markdown('\n\n**This will:**\n');
        stream.markdown('- Restore backed up files\n');
        stream.markdown('- Remove DOM capture utilities\n');
        stream.markdown('- Clean up added configurations\n');
    }

    private async handleHelp(stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 🤖 DOM Capture Assistant\n\n');
        stream.markdown('I can help you with Playwright DOM capture. Here\'s what I can do:\n\n');
        
        stream.markdown('**Available Commands:**\n');
        stream.markdown('- `@domcapture setup` - Configure your project\n');
        stream.markdown('- `@domcapture add capture` - Add capture point to current test\n');
        stream.markdown('- `@domcapture show dashboard` - Open the capture dashboard\n');
        stream.markdown('- `@domcapture show last` - View most recent capture\n');
        stream.markdown('- `@domcapture verify` - Check configuration status\n');
        stream.markdown('- `@domcapture clean` - Remove old captures\n');
        stream.markdown('- `@domcapture rollback` - Remove DOM capture from project\n\n');
        
        stream.markdown('**Quick Actions:**\n');
        stream.button({
            command: 'playwright-dom-capture.autoConfigureProject',
            title: '🚀 Setup'
        });
        stream.button({
            command: 'playwright-dom-capture.showDashboard',
            title: '📊 Dashboard'
        });
        stream.button({
            command: 'playwright-dom-capture.showLastCapture',
            title: '📄 Last Capture'
        });
    }

    private async handleGeneralQuery(query: string, stream: ChatResponseStream, token: vscode.CancellationToken) {
        stream.markdown('## 💬 DOM Capture Assistant\n\n');
        
        // Provide contextual help based on the query
        if (query.includes('how') || query.includes('use')) {
            stream.markdown('**How to use DOM Capture:**\n\n');
            stream.markdown('1. First, configure your project:\n');
            stream.button({
                command: 'playwright-dom-capture.autoConfigureProject',
                title: '🚀 Auto-Configure'
            });
            
            stream.markdown('\n2. In your tests, use the `captureDom` function:\n');
            stream.markdown('```typescript\n');
            stream.markdown('test(\'example\', async ({ page, captureDom }) => {\n');
            stream.markdown('  await page.goto(\'https://example.com\');\n');
            stream.markdown('  await captureDom(); // Manual capture\n');
            stream.markdown('});\n');
            stream.markdown('```\n\n');
            
            stream.markdown('3. Failed tests automatically capture DOM\n');
            stream.markdown('4. View captures in the dashboard\n');
        } else if (query.includes('example') || query.includes('code')) {
            stream.markdown('**Example Test with DOM Capture:**\n\n');
            stream.markdown('```typescript\n');
            stream.markdown('import { test, expect } from \'./fixtures/dom-test\';\n\n');
            stream.markdown('test(\'login flow\', async ({ page, captureDom }) => {\n');
            stream.markdown('  await page.goto(\'https://app.example.com/login\');\n');
            stream.markdown('  \n');
            stream.markdown('  // Capture initial state\n');
            stream.markdown('  await captureDom();\n');
            stream.markdown('  \n');
            stream.markdown('  await page.fill(\'#username\', \'user@example.com\');\n');
            stream.markdown('  await page.fill(\'#password\', \'password\');\n');
            stream.markdown('  await page.click(\'#submit\');\n');
            stream.markdown('  \n');
            stream.markdown('  // This will auto-capture if it fails\n');
            stream.markdown('  await expect(page).toHaveURL(\'/dashboard\');\n');
            stream.markdown('  \n');
            stream.markdown('  // Capture success state\n');
            stream.markdown('  await captureDom();\n');
            stream.markdown('});\n');
            stream.markdown('```\n');
        } else {
            // Default response
            stream.markdown('I can help you set up and use DOM capture for Playwright tests.\n\n');
            stream.markdown('Try asking me to:\n');
            stream.markdown('- Set up DOM capture in your project\n');
            stream.markdown('- Show the dashboard\n');
            stream.markdown('- Add capture points to tests\n');
            stream.markdown('- View recent captures\n\n');
            
            stream.markdown('Or use `@domcapture help` for all available commands.\n');
        }
    }
}