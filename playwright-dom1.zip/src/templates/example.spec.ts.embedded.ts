// Embedded example test content for packaged extension
export = `import { test, expect } from '@playwright/test';
// Import the DOM capture utility
const { captureDom } = require('./dom-capture/capture');

/**
 * Example test showing how to use DOM Capture
 * Installed by Playwright DOM Capture VS Code Extension
 */

test.describe('Example: Using DOM Capture', () => {
    test('capture at specific points', async ({ page }) => {
        // Navigate to your application
        await page.goto('https://example.com');
        
        // Capture initial state
        await captureDom(page, 'initial-load');
        
        // Perform some actions
        await page.fill('#search', 'playwright');
        
        // Capture after user input
        await captureDom(page, 'after-search-input');
        
        // Your assertions
        await expect(page.locator('h1')).toBeVisible();
    });

    test('automatic capture on failure', async ({ page }) => {
        await page.goto('https://example.com');
        
        // This will fail and automatically capture DOM
        await expect(page.locator('.non-existent-element')).toBeVisible();
        
        // The DOM will be automatically captured before the test fails
        // Look for it in: test-results/dom-captures/DD-MM-YYYY/example_with_capture_spec_automatic_capture_on_failure/
    });
});

/**
 * Tips for using DOM Capture:
 * 
 * 1. Import the capture function:
 *    const { captureDom } = require('./dom-capture/capture');
 * 
 * 2. Call it anywhere in your test:
 *    await captureDom(page, 'descriptive-label');
 * 
 * 3. Find captures in:
 *    test-results/dom-captures/DD-MM-YYYY/ClassName_MethodName/
 * 
 * 4. Use keyboard shortcuts in VS Code:
 *    - Ctrl+Shift+C during test execution
 *    - Ctrl+Alt+C for manual capture
 */`;