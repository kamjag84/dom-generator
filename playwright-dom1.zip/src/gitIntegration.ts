import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { Logger } from './utils/logger';
import { SecurityUtils } from './utils/securityUtils';

/**
 * Git Integration Manager for safe repository operations
 * Ensures DOM captures never get committed to Git
 */
export class GitIntegrationManager {
    private logger = Logger.getInstance();
    private rollbackManifest: RollbackManifest | null = null;
    private readonly manifestPath: string;
    private readonly gitIgnoreEntries = [
        '# Playwright DOM Capture - Auto-generated entries',
        'test-results/dom-captures/',
        'dom-capture/',
        '*.dom-capture.backup',
        '.dom-capture-config.json',
        '.dom-capture-rollback.json',
        '# End of Playwright DOM Capture entries'
    ];

    constructor(private workspacePath: string) {
        this.manifestPath = path.join(workspacePath, '.dom-capture-rollback.json');
    }

    /**
     * Initialize Git-aware features
     */
    async initialize(): Promise<void> {
        this.logger.info('Initializing Git integration...');
        
        // Check if this is a Git repository
        const gitDir = path.join(this.workspacePath, '.git');
        if (!await fs.pathExists(gitDir)) {
            this.logger.warn('Not a Git repository - Git features disabled');
            return;
        }

        // Load existing rollback manifest if it exists
        await this.loadRollbackManifest();
        
        // Ensure .gitignore is properly configured
        await this.updateGitIgnore();
        
        // Install Git hooks for safety
        await this.installGitHooks();
        
        this.logger.info('Git integration initialized successfully');
    }

    /**
     * Add DOM capture paths to .gitignore
     */
    async updateGitIgnore(): Promise<void> {
        const gitIgnorePath = path.join(this.workspacePath, '.gitignore');
        
        // Create .gitignore if it doesn't exist
        if (!await fs.pathExists(gitIgnorePath)) {
            await fs.writeFile(gitIgnorePath, this.gitIgnoreEntries.join('\n') + '\n', 'utf-8');
            this.logger.info('Created .gitignore with DOM capture exclusions');
            return;
        }

        // Read existing .gitignore
        let gitIgnoreContent = await fs.readFile(gitIgnorePath, 'utf-8');
        
        // Check if our entries already exist
        if (gitIgnoreContent.includes('# Playwright DOM Capture')) {
            this.logger.info('.gitignore already configured');
            return;
        }

        // Append our entries
        if (!gitIgnoreContent.endsWith('\n')) {
            gitIgnoreContent += '\n';
        }
        gitIgnoreContent += '\n' + this.gitIgnoreEntries.join('\n') + '\n';
        
        await fs.writeFile(gitIgnorePath, gitIgnoreContent, 'utf-8');
        this.logger.info('Updated .gitignore with DOM capture exclusions');
        
        // Track this change for rollback
        await this.trackFileChange(gitIgnorePath, 'modified');
    }

    /**
     * Install Git hooks to prevent accidental commits
     */
    async installGitHooks(): Promise<void> {
        const hooksDir = path.join(this.workspacePath, '.git', 'hooks');
        const preCommitPath = path.join(hooksDir, 'pre-commit');
        
        // Backup existing pre-commit hook if it exists
        if (await fs.pathExists(preCommitPath)) {
            const backupPath = preCommitPath + '.dom-capture.backup';
            await fs.copy(preCommitPath, backupPath);
            this.logger.info('Backed up existing pre-commit hook');
        }

        // Create our pre-commit hook
        const hookScript = `#!/bin/sh
# Playwright DOM Capture - Pre-commit safety check

# Check for DOM capture files
if [ -d "test-results/dom-captures" ] && [ "\$(ls -A test-results/dom-captures 2>/dev/null)" ]; then
    echo "⚠️  DOM captures detected in test-results/dom-captures/"
    echo "Please run one of the following before committing:"
    echo "  1. VS Code: Ctrl+Shift+P → 'DOM Capture: Prepare for Commit'"
    echo "  2. Terminal: rm -rf test-results/dom-captures"
    echo ""
    echo "To bypass this check (not recommended): git commit --no-verify"
    exit 1
fi

if [ -d "dom-capture" ]; then
    echo "⚠️  DOM capture configuration files detected"
    echo "Please run: Ctrl+Shift+P → 'DOM Capture: Prepare for Commit'"
    exit 1
fi

# Check for backup files
if ls *.dom-capture.backup 1> /dev/null 2>&1; then
    echo "⚠️  DOM capture backup files detected"
    echo "Please clean up backup files before committing"
    exit 1
fi

# Call original pre-commit hook if it exists
if [ -f ".git/hooks/pre-commit.dom-capture.backup" ]; then
    .git/hooks/pre-commit.dom-capture.backup "$@"
fi
`;

        await fs.writeFile(preCommitPath, hookScript, { mode: 0o755 });
        this.logger.info('Installed pre-commit hook for DOM capture safety');
    }

    /**
     * Create a rollback manifest to track all changes
     */
    async createRollbackManifest(): Promise<void> {
        this.rollbackManifest = {
            version: '1.0.0',
            createdAt: new Date().toISOString(),
            workspacePath: this.workspacePath,
            filesModified: [],
            filesCreated: [],
            backups: []
        };

        await this.saveRollbackManifest();
        this.logger.info('Created rollback manifest');
    }

    /**
     * Track a file change for rollback
     */
    async trackFileChange(filePath: string, changeType: 'created' | 'modified'): Promise<void> {
        if (!this.rollbackManifest) {
            await this.createRollbackManifest();
        }

        const relativePath = path.relative(this.workspacePath, filePath);
        
        if (changeType === 'created') {
            if (!this.rollbackManifest!.filesCreated.includes(relativePath)) {
                this.rollbackManifest!.filesCreated.push(relativePath);
            }
        } else {
            if (!this.rollbackManifest!.filesModified.includes(relativePath)) {
                this.rollbackManifest!.filesModified.push(relativePath);
                
                // Create backup
                const backupPath = filePath + '.dom-capture.backup';
                if (await fs.pathExists(filePath) && !await fs.pathExists(backupPath)) {
                    await fs.copy(filePath, backupPath);
                    this.rollbackManifest!.backups.push({
                        original: relativePath,
                        backup: path.relative(this.workspacePath, backupPath)
                    });
                }
            }
        }

        await this.saveRollbackManifest();
    }

    /**
     * Perform complete rollback of all changes
     */
    async rollbackAllChanges(): Promise<RollbackResult> {
        const result: RollbackResult = {
            success: true,
            filesRestored: 0,
            filesDeleted: 0,
            errors: []
        };

        if (!this.rollbackManifest) {
            this.logger.warn('No rollback manifest found');
            return result;
        }

        this.logger.info('Starting complete rollback...');

        // Restore modified files from backups
        for (const backup of this.rollbackManifest.backups) {
            try {
                const originalPath = path.join(this.workspacePath, backup.original);
                const backupPath = path.join(this.workspacePath, backup.backup);
                
                if (await fs.pathExists(backupPath)) {
                    await fs.copy(backupPath, originalPath, { overwrite: true });
                    await fs.remove(backupPath);
                    result.filesRestored++;
                    this.logger.info(`Restored: ${backup.original}`);
                }
            } catch (error: any) {
                result.errors.push(`Failed to restore ${backup.original}: ${error.message}`);
                result.success = false;
            }
        }

        // Delete created files
        for (const filePath of this.rollbackManifest.filesCreated) {
            try {
                const fullPath = path.join(this.workspacePath, filePath);
                if (await fs.pathExists(fullPath)) {
                    await fs.remove(fullPath);
                    result.filesDeleted++;
                    this.logger.info(`Deleted: ${filePath}`);
                }
            } catch (error: any) {
                result.errors.push(`Failed to delete ${filePath}: ${error.message}`);
                result.success = false;
            }
        }

        // Clean up .gitignore entries
        await this.cleanGitIgnore();

        // Remove Git hooks
        await this.removeGitHooks();

        // Delete the rollback manifest
        await fs.remove(this.manifestPath);
        this.rollbackManifest = null;

        this.logger.info(`Rollback complete: ${result.filesRestored} restored, ${result.filesDeleted} deleted`);
        return result;
    }

    /**
     * Clean DOM capture entries from .gitignore
     */
    private async cleanGitIgnore(): Promise<void> {
        const gitIgnorePath = path.join(this.workspacePath, '.gitignore');
        
        if (!await fs.pathExists(gitIgnorePath)) {
            return;
        }

        let content = await fs.readFile(gitIgnorePath, 'utf-8');
        
        // Remove our section
        const startMarker = '# Playwright DOM Capture - Auto-generated entries';
        const endMarker = '# End of Playwright DOM Capture entries';
        
        const startIdx = content.indexOf(startMarker);
        const endIdx = content.indexOf(endMarker);
        
        if (startIdx !== -1 && endIdx !== -1) {
            const before = content.substring(0, startIdx).trimEnd();
            const after = content.substring(endIdx + endMarker.length).trimStart();
            
            content = before;
            if (after) {
                content += '\n\n' + after;
            }
            
            await fs.writeFile(gitIgnorePath, content, 'utf-8');
            this.logger.info('Cleaned .gitignore');
        }
    }

    /**
     * Remove Git hooks
     */
    private async removeGitHooks(): Promise<void> {
        const preCommitPath = path.join(this.workspacePath, '.git', 'hooks', 'pre-commit');
        const backupPath = preCommitPath + '.dom-capture.backup';
        
        // Restore original pre-commit hook if backed up
        if (await fs.pathExists(backupPath)) {
            await fs.copy(backupPath, preCommitPath, { overwrite: true });
            await fs.remove(backupPath);
            this.logger.info('Restored original pre-commit hook');
        } else if (await fs.pathExists(preCommitPath)) {
            // Remove our hook if no backup exists
            const content = await fs.readFile(preCommitPath, 'utf-8');
            if (content.includes('Playwright DOM Capture')) {
                await fs.remove(preCommitPath);
                this.logger.info('Removed pre-commit hook');
            }
        }
    }

    /**
     * Check if there are any DOM captures that would be committed
     */
    async checkGitSafety(): Promise<GitSafetyCheck> {
        const issues: string[] = [];
        
        // Check for DOM captures
        const capturesPath = path.join(this.workspacePath, 'test-results', 'dom-captures');
        if (await fs.pathExists(capturesPath)) {
            const files = await fs.readdir(capturesPath);
            if (files.length > 0) {
                issues.push(`Found ${files.length} items in test-results/dom-captures/`);
            }
        }

        // Check for dom-capture folder
        const domCapturePath = path.join(this.workspacePath, 'dom-capture');
        if (await fs.pathExists(domCapturePath)) {
            issues.push('dom-capture/ folder exists');
        }

        // Check for backup files
        const backupFiles = await this.findBackupFiles();
        if (backupFiles.length > 0) {
            issues.push(`Found ${backupFiles.length} backup files`);
        }

        return {
            isSafe: issues.length === 0,
            issues,
            recommendation: issues.length > 0 
                ? 'Run "DOM Capture: Prepare for Commit" before committing'
                : 'Safe to commit'
        };
    }

    /**
     * Find all backup files
     */
    private async findBackupFiles(): Promise<string[]> {
        const files: string[] = [];
        
        const walk = async (dir: string) => {
            const entries = await fs.readdir(dir, { withFileTypes: true });
            for (const entry of entries) {
                const fullPath = path.join(dir, entry.name);
                if (entry.isDirectory() && !entry.name.startsWith('.')) {
                    await walk(fullPath);
                } else if (entry.name.endsWith('.dom-capture.backup')) {
                    files.push(fullPath);
                }
            }
        };

        await walk(this.workspacePath);
        return files;
    }

    /**
     * Load rollback manifest
     */
    private async loadRollbackManifest(): Promise<void> {
        if (await fs.pathExists(this.manifestPath)) {
            this.rollbackManifest = await fs.readJson(this.manifestPath);
            this.logger.info('Loaded existing rollback manifest');
        }
    }

    /**
     * Save rollback manifest
     */
    private async saveRollbackManifest(): Promise<void> {
        if (this.rollbackManifest) {
            await fs.writeJson(this.manifestPath, this.rollbackManifest, { spaces: 2 });
        }
    }
}

/**
 * Rollback manifest structure
 */
interface RollbackManifest {
    version: string;
    createdAt: string;
    workspacePath: string;
    filesModified: string[];
    filesCreated: string[];
    backups: Array<{
        original: string;
        backup: string;
    }>;
}

/**
 * Rollback result
 */
interface RollbackResult {
    success: boolean;
    filesRestored: number;
    filesDeleted: number;
    errors: string[];
}

/**
 * Git safety check result
 */
interface GitSafetyCheck {
    isSafe: boolean;
    issues: string[];
    recommendation: string;
}