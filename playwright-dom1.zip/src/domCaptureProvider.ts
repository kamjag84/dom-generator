import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { CaptureInfo, CaptureManager } from './captureManager';

export class DomCaptureProvider implements vscode.TreeDataProvider<CaptureTreeItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<CaptureTreeItem | undefined | null | void> = new vscode.EventEmitter<CaptureTreeItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<CaptureTreeItem | undefined | null | void> = this._onDidChangeTreeData.event;

    private captureManager: CaptureManager;
    private fileWatcher: vscode.FileSystemWatcher | undefined;
    private refreshDebounceTimer: NodeJS.Timeout | undefined;
    private readonly DEBOUNCE_DELAY = 500; // 500ms debounce delay

    constructor(private context: vscode.ExtensionContext) {
        this.captureManager = new CaptureManager(context);
        this.initializeFileWatcher();
    }

    /**
     * Initialize file system watcher for the dom-captures folder
     */
    private async initializeFileWatcher(): Promise<void> {
        try {
            // Get the workspace folder
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders || workspaceFolders.length === 0) {
                console.log('No workspace folder found, skipping file watcher initialization');
                return;
            }

            const workspacePath = workspaceFolders[0].uri.fsPath;
            const capturesPath = path.join(workspacePath, 'test-results', 'dom-captures');

            // Ensure the folder exists or create it
            if (!await fs.pathExists(capturesPath)) {
                console.log(`Creating captures folder: ${capturesPath}`);
                await fs.ensureDir(capturesPath);
            }

            // Create file watcher for the captures directory
            const pattern = new vscode.RelativePattern(capturesPath, '**/*.{html,json}');
            this.fileWatcher = vscode.workspace.createFileSystemWatcher(pattern);

            // Set up event handlers with debouncing
            this.fileWatcher.onDidCreate(() => this.debouncedRefresh());
            this.fileWatcher.onDidChange(() => this.debouncedRefresh());
            this.fileWatcher.onDidDelete(() => this.debouncedRefresh());

            // Add to disposables
            this.context.subscriptions.push(this.fileWatcher);

            console.log(`File watcher initialized for: ${capturesPath}`);
        } catch (error) {
            console.error('Failed to initialize file watcher:', error);
        }
    }

    /**
     * Debounced refresh to prevent excessive updates
     */
    private debouncedRefresh(): void {
        // Clear existing timer
        if (this.refreshDebounceTimer) {
            clearTimeout(this.refreshDebounceTimer);
        }

        // Set new timer
        this.refreshDebounceTimer = setTimeout(() => {
            console.log('Refreshing DOM captures view due to file system change');
            this.refresh();
        }, this.DEBOUNCE_DELAY);
    }

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: CaptureTreeItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: CaptureTreeItem): Promise<CaptureTreeItem[]> {
        try {
            if (!element) {
                // Root level - show date folders
                const captures = await this.captureManager.getCaptures();
                
                // If no captures found, return empty array
                if (!captures || captures.length === 0) {
                    return [];
                }
                
                const dateMap = new Map<string, CaptureInfo[]>();
                
                captures.forEach(capture => {
                    const dateStr = this.formatDate(capture.timestamp);
                    if (!dateMap.has(dateStr)) {
                        dateMap.set(dateStr, []);
                    }
                    dateMap.get(dateStr)!.push(capture);
                });

                const items: CaptureTreeItem[] = [];
                dateMap.forEach((captures, date) => {
                    items.push(new CaptureTreeItem(
                        date,
                        captures.length.toString(),
                        vscode.TreeItemCollapsibleState.Collapsed,
                        'date',
                        undefined,
                        captures
                    ));
                });

                return items;
            } else if (element.contextValue === 'date') {
                // Show captures for a specific date
                return element.captures!.map(capture => 
                    new CaptureTreeItem(
                        capture.testName,
                        this.formatTime(capture.timestamp),
                        vscode.TreeItemCollapsibleState.None,
                        'capture',
                        capture,
                        undefined
                    )
                );
            }

            return [];
        } catch (error) {
            console.error('Error loading captures:', error);
            
            // Show error item if there's a permission or access issue
            if (error instanceof Error && error.message.includes('EACCES')) {
                return [new CaptureTreeItem(
                    'Permission Denied',
                    'Check folder permissions',
                    vscode.TreeItemCollapsibleState.None,
                    'error',
                    undefined,
                    undefined
                )];
            }
            
            return [];
        }
    }

    private formatDate(date: Date): string {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    private formatTime(date: Date): string {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    /**
     * Re-initialize watcher when workspace changes
     */
    async reinitializeWatcher(): Promise<void> {
        // Dispose existing watcher
        if (this.fileWatcher) {
            this.fileWatcher.dispose();
            this.fileWatcher = undefined;
        }

        // Re-initialize
        await this.initializeFileWatcher();
    }

    /**
     * Dispose resources
     */
    dispose(): void {
        if (this.refreshDebounceTimer) {
            clearTimeout(this.refreshDebounceTimer);
        }

        if (this.fileWatcher) {
            this.fileWatcher.dispose();
        }
    }
}

class CaptureTreeItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        private readonly desc: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly contextValue: string,
        public readonly capture?: CaptureInfo,
        public readonly captures?: CaptureInfo[]
    ) {
        super(label, collapsibleState);

        this.tooltip = this.label;
        this.description = this.desc;

        if (contextValue === 'capture' && capture) {
            this.iconPath = capture.status === 'failed' 
                ? new vscode.ThemeIcon('error')
                : new vscode.ThemeIcon('pass');
            
            this.command = {
                command: 'vscode.open',
                title: 'Open Capture',
                arguments: [vscode.Uri.file(capture.path)]
            };

            this.contextValue = `capture-${capture.status}`;
        } else if (contextValue === 'date') {
            this.iconPath = new vscode.ThemeIcon('calendar');
        } else if (contextValue === 'error') {
            this.iconPath = new vscode.ThemeIcon('warning');
        }
    }
}