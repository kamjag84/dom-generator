/**
 * Playwright Test Integration Module
 * This module provides seamless integration with Playwright tests for DOM capture
 */

import { Page, BrowserContext, test as baseTest } from '@playwright/test';
import { TestCaptureManager } from './playwrightTestHelper';
import * as path from 'path';
import * as fs from 'fs-extra';

/**
 * Global type declaration for DOM capture function
 * This extends the Window interface to include our injected capture function
 */
declare global {
    interface Window {
        __captureDom?: (captureId: string) => void;
        __captureState?: () => any;
    }
}

/**
 * Helper function to capture DOM at any point in the test
 * This provides a type-safe way to trigger manual DOM captures
 * 
 * @param page - The Playwright page object
 * @param captureId - Optional identifier for the capture (defaults to timestamp-based ID)
 * @returns Promise that resolves when capture is complete
 * 
 * @example
 * // Basic usage
 * await captureDOM(page);
 * 
 * // With custom ID
 * await captureDOM(page, 'after-login');
 */
export async function captureDOM(page: Page, captureId?: string): Promise<void> {
    const id = captureId || `manual-capture-${Date.now()}`;
    
    await page.evaluate((captureId) => {
        // The type is now properly declared globally
        if (window.__captureDom) {
            window.__captureDom(captureId);
        } else {
            console.warn('DOM capture not available. Ensure the page has been set up with enableHotkeyCapture()');
        }
    }, id);
}

/**
 * @deprecated Use TestCaptureManager.enableHotkeyCapture() instead
 * Install global hotkey listener for runtime capture (Ctrl+Shift+C)
 */
export async function installHotkeyListener(page: Page): Promise<void> {
  // Deprecated - kept for backward compatibility
  const captureManager = TestCaptureManager.getInstance();
  return captureManager.enableHotkeyCapture(page);
}


/**
 * @deprecated Use TestCaptureManager.enableHotkeyCapture() instead
 * Setup page-level capture listener
 */
export async function setupPageCaptureListener(page: Page): Promise<void> {
  // Deprecated - functionality moved to TestCaptureManager.enableHotkeyCapture()
  const captureManager = TestCaptureManager.getInstance();
  return captureManager.enableHotkeyCapture(page);
}

/**
 * Enhanced Playwright test with automatic DOM capture setup
 * This is the main test fixture that should be used in all tests
 */
export const test = baseTest.extend<{
  autoCapture: void;
  captureManager: TestCaptureManager;
  domCapture: (options?: any) => Promise<string>;
  enableHotkeyCapture: () => Promise<void>;
}>({
  autoCapture: [async ({ page }, use, testInfo) => {
    console.log('🔧 Setting up DOM Capture for test:', testInfo.title);
    
    // Initialize capture manager for this test
    const captureManager = TestCaptureManager.getInstance();
    captureManager.setCurrentTest(testInfo);
    
    // Use the TestCaptureManager's implementation for consistency
    await captureManager.enableHotkeyCapture(page);
    
    // Setup automatic capture on failure
    testInfo.attachments.push({
      name: 'dom-capture-enabled',
      contentType: 'text/plain',
      body: Buffer.from('DOM capture is enabled for this test')
    });
    
    // Run the test
    await use();
    
    // Capture on failure
    if (testInfo.status === 'failed') {
      console.log('❌ Test failed, capturing DOM...');
      try {
        const result = await captureManager.captureFromPage(page, {
          captureId: `failure_${Date.now()}`,
          customMetadata: {
            status: 'failed',
            error: testInfo.error?.message || 'Unknown error'
          }
        });
        
        testInfo.attachments.push({
          name: 'dom-capture-on-failure',
          contentType: 'text/html',
          path: result.path
        });
        
        console.log(`📸 Failure DOM captured: ${result.path}`);
      } catch (error) {
        console.error('Failed to capture DOM on test failure:', error);
      }
    }
  }, { auto: true }],
  
  captureManager: async ({}, use) => {
    const manager = TestCaptureManager.getInstance();
    await use(manager);
  },
  
  domCapture: async ({ page, captureManager }, use, testInfo) => {
    captureManager.setCurrentTest(testInfo);
    
    const captureFunction = async (options?: any) => {
      // Use captureManager directly for advanced options
      if (options && (options.metadata || options.name)) {
        const result = await captureManager.captureFromPage(page, {
          captureId: options.name || `manual_${Date.now()}`,
          customMetadata: options.metadata
        });
        return result.path;
      } else {
        // For simple captures, use the helper but return a path
        await captureDOM(page, options?.name);
        // Return a path for compatibility (even though the actual path is not returned by captureDOM)
        return `test-results/dom-captures/${options?.name || 'manual-capture'}.html`;
      }
    };
    
    await use(captureFunction);
  },
  
  enableHotkeyCapture: async ({ page, captureManager }, use, testInfo) => {
    captureManager.setCurrentTest(testInfo);
    
    const enableFunction = async () => {
      await captureManager.enableHotkeyCapture(page);
      console.log('🎯 Hotkey capture enabled! Press Ctrl+Shift+C to capture DOM');
    };
    
    await use(enableFunction);
  }
});


/**
 * Setup function for existing test suites
 */
export async function setupDOMCapture(page: Page, context?: BrowserContext): Promise<void> {
  const captureManager = TestCaptureManager.getInstance();
  
  // Install hotkey listener on all pages
  if (context) {
    context.on('page', async (newPage) => {
      await captureManager.enableHotkeyCapture(newPage);
    });
  }
  
  // Setup on current page
  await captureManager.enableHotkeyCapture(page);
  
  console.log('✅ DOM Capture setup complete');
}

/**
 * Utility to check if DOM capture is available
 */
export async function isDOMCaptureAvailable(): Promise<boolean> {
  try {
    // Check if the extension is installed
    const extensionPath = path.join(
      process.cwd(),
      'node_modules',
      'playwright-dom-capture'
    );
    
    if (await fs.pathExists(extensionPath)) {
      return true;
    }
    
    // Check if we're in a workspace with the extension
    const workspacePath = path.join(
      process.cwd(),
      'dom-capture'
    );
    
    return await fs.pathExists(workspacePath);
  } catch {
    return false;
  }
}

// Export all utilities
export { TestCaptureManager } from './playwrightTestHelper';
export type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

// Make window type aware of our function
declare global {
  interface Window {
    __captureDOM: (detail: any) => Promise<any>;
  }
}