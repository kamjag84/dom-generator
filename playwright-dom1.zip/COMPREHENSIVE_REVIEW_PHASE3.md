# PHASE 3: CROSS-REFERENCE MATRIX

## 📊 Complete Dependency Analysis

### **1. Function Call Dependencies**

#### Core Function Map
| Function | Defined In | Called From | Frequency | Status |
|---------|------------|-------------|-----------|---------|
| `__captureDOM` | `playwrightTestHelper.ts:447` | Browser context (3 places) | High | ✅ Active |
| `TestCaptureManager.getInstance()` | `playwrightTestHelper.ts:40` | 5 files | High | ✅ Singleton |
| `captureFromPage()` | `playwrightTestHelper.ts:153` | 4 call sites | High | ✅ Core |
| `enableHotkeyCapture()` | `playwrightTestHelper.ts:443` | 3 call sites | Medium | ✅ Active |
| `autoConfigureProject()` | `enhancedProjectConfigurator.ts:108` | ExtensionCore | Low | ✅ Command |
| `installHotkeyListener()` | `playwrightIntegration.ts:15` | None | None | ⚠️ DEPRECATED |
| `setupPageCaptureListener()` | `playwrightIntegration.ts:141` | None | None | ⚠️ DEPRECATED |

#### Call Chain Analysis
```
User Action
    ↓
extension.ts::activate()
    ↓
ExtensionCore.getInstance()
    ↓
├── CommandManager.registerCommands()
│   ├── autoConfigureCommand → enhancedProjectConfigurator.autoConfigureProject()
│   ├── rollbackCommand → enhancedProjectConfigurator.rollbackConfiguration()
│   └── captureCommand → captureManager.captureCurrentPage()
│
└── TestCaptureManager.getInstance()
    ├── enableHotkeyCapture() → page.exposeFunction('__captureDOM')
    └── captureFromPage() → File System Operations
```

---

### **2. Import/Export Relationships**

#### Import Matrix
| Module | Imports | Type | Issues |
|--------|---------|------|--------|
| `playwrightIntegration.ts` | `TestCaptureManager from './playwrightTestHelper'` | Local | ✅ |
| `playwrightIntegration.ts` | `{ test as baseTest } from '@playwright/test'` | External | ✅ |
| `playwrightTestHelper.ts` | `CompressionManager from '../domCapture/compressionManager'` | Local | ✅ |
| `playwrightTestHelper.ts` | `SecurityManager from '../domCapture/securityManager'` | Local | ✅ |
| `enhancedProjectConfigurator.ts` | `Logger from '../utils/logger'` | Local | ✅ |
| `ExtensionCore.ts` | `EnhancedProjectConfigurator from '../enhancedProjectConfigurator'` | Local | ✅ |

#### Export Matrix
| Module | Exports | Consumers | Type |
|--------|---------|-----------|------|
| `playwrightIntegration.ts` | `test, captureDOM, setupDOMCapture` | Test files | Named |
| `playwrightIntegration.ts` | `TestCaptureManager, TestCaptureOptions` | Re-export | Named |
| `playwrightTestHelper.ts` | `TestCaptureManager` | Multiple | Class |
| `playwrightTestHelper.ts` | `TestCaptureOptions, CaptureResult` | Types | Interface |
| `enhancedProjectConfigurator.ts` | `EnhancedProjectConfigurator` | ExtensionCore | Class |

---

### **3. Shared Constants & Variables**

#### Global Constants
| Constant | Value | Location | Used By | Issues |
|----------|-------|----------|---------|--------|
| `__captureDOM` | Function | `window` object | Browser scripts | ✅ Consistent |
| `DOM_CAPTURE_DIR` | `'dom-capture'` | `enhancedProjectConfigurator.ts:13` | Config methods | ✅ |
| `BACKUP_DIR` | `'.dom-capture-backup'` | `enhancedProjectConfigurator.ts:12` | Rollback | ✅ |
| `CONFIG_MANIFEST_FILE` | `'.dom-capture-manifest.json'` | `enhancedProjectConfigurator.ts:14` | Manifest | ✅ |

#### Singleton Instances
| Class | Instance Variable | Access Pattern | Thread-Safe |
|-------|------------------|----------------|-------------|
| `TestCaptureManager` | `private static instance` | `getInstance()` | ✅ Yes |
| `ExtensionCore` | `private static instance` | `getInstance()` | ✅ Yes |
| `EnhancedProjectConfigurator` | None | `new` each time | N/A |

---

### **4. Event Listeners & Handlers**

#### Browser Events
| Event | Listener Location | Handler | Condition | Status |
|-------|------------------|---------|-----------|---------|
| `keydown` | `playwrightTestHelper.ts:475` | Hotkey capture | `Ctrl+Shift+C` | ✅ Active |
| `keydown` | `playwrightIntegration.ts:31` | Legacy handler | `Ctrl+Shift+C` | ⚠️ Deprecated |
| `dom-capture-requested` | Generated stubs | Custom event | Manual trigger | ⚠️ Not used |

#### VS Code Events
| Event | Registration | Handler | Purpose |
|-------|-------------|---------|---------|
| Command: `autoConfigureProject` | `package.json` | `ExtensionCore` | Project setup |
| Command: `rollbackConfiguration` | `package.json` | `ExtensionCore` | Undo setup |
| Command: `captureCurrentPage` | `package.json` | `ExtensionCore` | Manual capture |

---

### **5. Duplicate Code Analysis**

#### Critical Duplications Found

##### 1. `__captureDOM` Implementation
| Location | Type | Lines | Status |
|----------|------|-------|--------|
| `playwrightTestHelper.ts:447-469` | Primary | 22 | ✅ Active |
| `enhancedProjectConfigurator.ts:601-650` | Stub Template | 49 | ⚠️ Potential conflict |
| `playwrightIntegration.ts:93-110` | Usage/Call | 17 | ⚠️ Deprecated path |

##### 2. Hotkey Installation Code
| Location | Function | Lines | Issue |
|----------|----------|-------|-------|
| `playwrightTestHelper.ts:443-575` | `enableHotkeyCapture` | 132 | ✅ Current |
| `playwrightIntegration.ts:24-135` | `_oldInstallHotkeyListener` | 111 | 🔴 Should remove |

##### 3. Visual Feedback Code
| Location | Color | Animation | Consistency |
|----------|-------|-----------|-------------|
| `playwrightTestHelper.ts:487-498` | Green `(0,255,0)` | 0.5s fade | ✅ |
| `playwrightIntegration.ts:49-60` | Green `(0,255,0)` | 0.5s fade | ✅ |
| Generated stubs | Green `(0,255,0)` | 0.5s fade | ✅ |

---

### **6. Configuration Dependencies**

#### File Creation Matrix
| Command | Creates | Location | Tracked | Rollback |
|---------|---------|----------|---------|----------|
| Auto-configure | `dom-capture/` folder | Workspace root | ✅ Yes | ✅ Yes |
| Auto-configure | 10+ TypeScript files | `dom-capture/` | ✅ Yes | ✅ Yes |
| Auto-configure | `manifest.json` | `dom-capture/` | ✅ Yes | N/A |
| Capture | HTML files | `test-results/` | ❌ No | ❌ No |
| Capture | Metadata JSON | `test-results/` | ❌ No | ❌ No |

#### Configuration Reading
| Module | Reads Config From | Fallback | Validation |
|--------|------------------|----------|------------|
| `TestCaptureManager` | `testInfo` object | Default values | ✅ |
| `EnhancedProjectConfigurator` | `package.json` | None | ⚠️ Basic |
| `ExtensionCore` | VS Code settings | Defaults | ✅ |

---

### **7. Type Dependencies**

#### Interface/Type Definitions
| Type | Defined In | Used By | Purpose |
|------|------------|---------|---------|
| `TestCaptureOptions` | `playwrightTestHelper.ts:14` | Multiple | Capture config |
| `CaptureResult` | `playwrightTestHelper.ts:24` | Return type | Result structure |
| `ConfigurationManifest` | `enhancedProjectConfigurator.ts:32` | Rollback | Track changes |
| `Window.__captureDOM` | `playwrightIntegration.ts:300` | TypeScript | Type safety |

#### Generic Type Usage
| Generic | Location | Purpose | Constraints |
|---------|----------|---------|-------------|
| `Page` | All capture methods | Playwright page | `@playwright/test` |
| `TestInfo` | Test fixtures | Test metadata | `@playwright/test` |
| `Buffer` | File operations | Binary data | Node.js |

---

### **8. Circular Dependency Check**

#### Analysis Results
```
✅ No circular dependencies found in:
- Import statements
- Function calls
- Type definitions
- Class inheritance
```

#### Dependency Chains
```
Valid chains identified:
1. extension → ExtensionCore → EnhancedProjectConfigurator ✅
2. playwrightIntegration → playwrightTestHelper ✅
3. ExtensionCore → CommandManager → CaptureManager ✅
4. TestCaptureManager → CompressionManager ✅
5. TestCaptureManager → SecurityManager ✅
```

---

### **9. Missing Dependencies**

#### Required But Missing
| Dependency | Expected In | Impact | Severity |
|------------|-------------|--------|----------|
| None identified | - | - | ✅ |

#### Optional Dependencies
| Dependency | Module | Present | Impact if Missing |
|------------|--------|---------|-------------------|
| `gitIntegration` | `ExtensionCore` | ✅ Yes | Git features disabled |
| `chatParticipant` | `ExtensionCore` | ✅ Yes | AI features disabled |
| `dashboardPanel` | `ExtensionCore` | ✅ Yes | No dashboard |

---

### **10. Consistency Analysis**

#### ✅ Consistent Elements
1. Function naming: `__captureDOM` used everywhere
2. Visual feedback: Green flash `(0, 255, 0)`
3. Folder structure: `test-results/dom-captures/`
4. Singleton pattern: Properly implemented
5. Error handling: Try-catch blocks present

#### ⚠️ Inconsistencies Found
1. **Import paths in generated code**
   - Some use `./dom-capture/`
   - Others use `../dom-capture/`
   
2. **Async pattern usage**
   - Some use `async/await`
   - Others use `.then()` promises

3. **Logging patterns**
   - Some use `Logger` class
   - Others use `console.log`

---

### **11. Performance Impact Matrix**

| Operation | Frequency | Duration | Impact | Optimization |
|-----------|-----------|----------|--------|--------------|
| `exposeFunction` | Once per page | ~10ms | Low | ✅ Cached |
| `captureFromPage` | On-demand | ~100-500ms | Medium | Could optimize |
| File I/O | Per capture | ~50-200ms | Medium | ✅ Async |
| DOM serialization | Per capture | ~100-300ms | High | Needs optimization |

---

### **12. Security Considerations**

| Component | Security Feature | Status | Risk Level |
|-----------|-----------------|---------|------------|
| `__captureDOM` | Exposed to page | ⚠️ | Medium - validate inputs |
| File paths | Sanitization | ✅ | Low |
| HTML content | XSS prevention | ✅ | Low |
| Metadata | JSON sanitization | ✅ | Low |

---

## 🎯 Critical Findings

### **Must Fix**
1. 🔴 Remove deprecated functions in `playwrightIntegration.ts`
2. 🔴 Remove `_oldInstallHotkeyListener` function entirely
3. 🔴 Standardize import paths in generated stubs

### **Should Fix**
1. 🟡 Consolidate logging to use Logger class everywhere
2. 🟡 Add input validation to `__captureDOM` exposed function
3. 🟡 Optimize DOM serialization performance

### **Nice to Have**
1. 🟢 Add caching for repeated captures
2. 🟢 Implement capture deduplication
3. 🟢 Add telemetry for usage patterns

---

## 📈 Dependency Health Score

| Category | Score | Status |
|----------|-------|---------|
| **No Circular Dependencies** | 10/10 | ✅ Excellent |
| **Consistent Naming** | 9/10 | ✅ Good |
| **No Missing Dependencies** | 10/10 | ✅ Excellent |
| **Code Duplication** | 6/10 | ⚠️ Needs Work |
| **Type Safety** | 9/10 | ✅ Good |
| **Overall Health** | **88%** | ✅ Healthy |

The cross-reference analysis shows a well-structured codebase with some areas for improvement, particularly around removing deprecated code and standardizing patterns.

## Next: PHASE 4 - Implementation Verification