# Change Log

## [1.0.0] - 2024-08-29

### Initial Release
- Auto-configure Playwright projects for DOM capture
- Automatic DOM capture on test failure
- Manual DOM capture with `captureDom()` function
- Visual dashboard for managing captures
- Command Palette integration
- Keyboard shortcuts for quick access
- Smart file organization by date
- Backup and rollback functionality
- Tree view in VS Code sidebar
- Status bar indicator
- Configuration options for capture behavior
- Support for screenshots alongside DOM
- Batch operations (clean, export)
- Right-click context menu in test files