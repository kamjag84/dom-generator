#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');

console.log('🚀 Setting up Playwright DOM Capture Extension Development Environment...\n');

async function setup() {
    try {
        // Check Node.js version
        const nodeVersion = process.version;
        const majorVersion = parseInt(nodeVersion.split('.')[0].substring(1));
        if (majorVersion < 18) {
            throw new Error(`Node.js 18+ required. Current version: ${nodeVersion}`);
        }
        console.log(`✅ Node.js ${nodeVersion} detected`);

        // Install dependencies
        console.log('\n📦 Installing dependencies...');
        execSync('npm install', { stdio: 'inherit' });

        // Install VS Code Extension Manager
        console.log('\n📦 Installing vsce (VS Code Extension Manager)...');
        execSync('npm install -g @vscode/vsce', { stdio: 'inherit' });

        // Compile TypeScript
        console.log('\n📝 Compiling TypeScript...');
        execSync('npm run compile', { stdio: 'inherit' });

        // Create necessary directories
        console.log('\n📁 Creating directories...');
        await fs.ensureDir('out');
        await fs.ensureDir('dist');
        await fs.ensureDir('test-results');

        // Check for icon file
        const iconPath = path.join('resources', 'icon.png');
        if (!await fs.pathExists(iconPath)) {
            console.log('\n🎨 Creating placeholder icon...');
            await fs.ensureDir('resources');
            // Create a simple base64 PNG placeholder
            const iconBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
            await fs.writeFile(iconPath, Buffer.from(iconBase64, 'base64'));
        }

        console.log('\n✅ Setup complete!');
        console.log('\n📝 Available commands:');
        console.log('   npm run compile    - Compile TypeScript');
        console.log('   npm run watch      - Watch mode for development');
        console.log('   npm run lint       - Run ESLint');
        console.log('   npm test           - Run tests');
        console.log('   npm run build      - Build production package');
        console.log('   npm run package    - Create VSIX package');
        
        console.log('\n🔧 VS Code Integration:');
        console.log('   1. Open VS Code');
        console.log('   2. Press F5 to launch Extension Development Host');
        console.log('   3. Test the extension in the new VS Code window');
        
        console.log('\n📚 Documentation:');
        console.log('   README.md                 - User documentation');
        console.log('   COPILOT_INTEGRATION.md   - Copilot Chat usage');
        
    } catch (error) {
        console.error('\n❌ Setup failed:', error.message);
        process.exit(1);
    }
}

setup();