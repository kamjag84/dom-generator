#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');

console.log('🔨 Building Playwright DOM Capture Extension...\n');

async function build() {
    try {
        // Clean previous builds
        console.log('📦 Cleaning previous builds...');
        await fs.remove('out');
        await fs.remove('dist');
        await fs.remove('*.vsix');

        // Install dependencies
        console.log('📦 Installing dependencies...');
        execSync('npm ci', { stdio: 'inherit' });

        // Run linter
        console.log('🔍 Running linter...');
        try {
            execSync('npm run lint', { stdio: 'inherit' });
        } catch (error) {
            console.warn('⚠️  Linting warnings found, continuing build...');
        }

        // Compile TypeScript
        console.log('📝 Compiling TypeScript...');
        execSync('npm run compile', { stdio: 'inherit' });

        // Run tests
        console.log('🧪 Running tests...');
        if (process.env.SKIP_TESTS !== 'true') {
            try {
                execSync('npm test', { stdio: 'inherit' });
            } catch (error) {
                console.warn('⚠️  Some tests failed, continuing build...');
            }
        } else {
            console.log('⏭️  Skipping tests (SKIP_TESTS=true)');
        }

        // Bundle with webpack
        console.log('📦 Bundling with webpack...');
        execSync('npm run webpack', { stdio: 'inherit' });

        // Create VSIX package
        console.log('📦 Creating VSIX package...');
        execSync('npx vsce package', { stdio: 'inherit' });

        // Find the generated VSIX file
        const vsixFiles = await fs.readdir('.').then(files => 
            files.filter(f => f.endsWith('.vsix'))
        );

        if (vsixFiles.length > 0) {
            console.log(`\n✅ Build successful! Package created: ${vsixFiles[0]}`);
            console.log('\n📝 To install the extension:');
            console.log(`   code --install-extension ${vsixFiles[0]}`);
            console.log('\n📤 To publish to marketplace:');
            console.log('   npm run vsce-publish');
        } else {
            throw new Error('No VSIX package was created');
        }

    } catch (error) {
        console.error('\n❌ Build failed:', error.message);
        process.exit(1);
    }
}

build();