# PHASE 2: END-TO-END FLOW TRACING

## 🔍 Complete Flow Analysis

### **Flow 1: Ctrl+Shift+C Hotkey Capture**

#### 1.1 Browser-Side Initialization
**File:** `src/testIntegration/playwrightTestHelper.ts:443-539`

```typescript
// Step 1: Enable hotkey capture
enableHotkeyCapture(page: Page)
  ↓
// Step 2: Expose Node.js function to browser
page.exposeFunction('__captureDOM', async (detail) => {...})
  ↓
// Step 3: Add init script to page
page.addInitScript(() => {
  // Step 4: Listen for keydown events
  document.addEventListener('keydown', async (event) => {
    // Step 5: Check for Ctrl+Shift+C
    if (modifier && event.shiftKey && event.key === 'C')
  })
})
```

#### 1.2 User Triggers Capture
**Location:** Browser context (injected script)

```
User presses Ctrl+Shift+C
  ↓
Keydown event fires
  ↓
Event listener checks:
  - Is Ctrl/Cmd pressed? ✓
  - Is Shift pressed? ✓
  - Is key 'C'? ✓
  ↓
preventDefault() + stopPropagation()
  ↓
Create visual feedback:
  - Green flash overlay (rgba(0, 255, 0, 0.3))
  - Status indicator "📸 Capturing DOM #X..."
  ↓
Call window.__captureDOM({
  trigger: 'hotkey',
  timestamp: Date.now(),
  count: captureCount,
  url: window.location.href,
  title: document.title
})
```

#### 1.3 Bridge to Node.js
**Location:** `playwrightTestHelper.ts:447-469`

```
window.__captureDOM() called
  ↓
Bridges to Node.js via exposeFunction
  ↓
TestCaptureManager processes:
  - captureFromPage(page, {
      captureId: `hotkey_${detail.timestamp}`,
      customMetadata: { trigger, url, title, count }
    })
  ↓
Returns: { success: true, path: result.path }
```

#### 1.4 Capture Processing
**Location:** `playwrightTestHelper.ts:153-299`

```
captureFromPage(page, options)
  ↓
1. Generate folder structure:
   - Base: test-results/dom-captures/
   - Date: DD-MM-YYYY/
   - Test: ClassName_MethodName/
  ↓
2. Capture DOM:
   - page.content() → Full HTML
   - page.evaluate() → Enhanced DOM with computed styles
  ↓
3. Create metadata:
   - timestamp, url, viewport, testInfo
   - customMetadata from options
  ↓
4. Save files:
   - capture_${captureId}.html
   - capture_${captureId}_metadata.json
  ↓
5. Optional: Take screenshot
   - capture_${captureId}_screenshot.png
```

#### 1.5 User Feedback
**Location:** Browser context

```
Result received from Node.js
  ↓
Update status indicator:
  - Success: "✅ DOM Captured!" (blue background)
  - Failure: "❌ Capture Failed!" (red background)
  ↓
Console log result
  ↓
Remove UI elements after 2 seconds
```

---

### **Flow 2: Test Failure Auto-Capture**

#### 2.1 Test Setup
**File:** `src/testIntegration/playwrightIntegration.ts:157-200`

```typescript
test = baseTest.extend({
  autoCapture: [async ({ page }, use, testInfo) => {
    // Step 1: Initialize capture manager
    const captureManager = TestCaptureManager.getInstance();
    captureManager.setCurrentTest(testInfo);
    
    // Step 2: Enable hotkey capture
    await captureManager.enableHotkeyCapture(page);
    
    // Step 3: Run test
    await use();
    
    // Step 4: Check if test failed
    if (testInfo.status === 'failed') {
      // Step 5: Capture DOM
      const result = await captureManager.captureFromPage(page, {
        captureId: `failure_${Date.now()}`,
        customMetadata: {
          status: 'failed',
          error: testInfo.error?.message
        }
      });
      
      // Step 6: Attach to test report
      testInfo.attachments.push({
        name: 'dom-capture-on-failure',
        contentType: 'text/html',
        path: result.path
      });
    }
  }, { auto: true }]
})
```

#### 2.2 Execution Flow

```
Test starts
  ↓
autoCapture fixture runs (auto: true)
  ↓
TestCaptureManager initialized with testInfo
  ↓
Hotkey capture enabled
  ↓
Test executes...
  ↓
Test fails (throws error)
  ↓
testInfo.status === 'failed'
  ↓
Capture triggered automatically
  ↓
DOM saved with failure metadata
  ↓
Attached to Playwright report
```

---

### **Flow 3: Auto-Configuration Command**

#### 3.1 Command Execution
**File:** `src/core/ExtensionCore.ts`

```
User runs: "DOM Capture: Auto-configure Project"
  ↓
ExtensionCore.handleAutoConfiguration()
  ↓
enhancedProjectConfigurator.autoConfigureProject(workspacePath)
```

#### 3.2 Configuration Process
**File:** `src/enhancedProjectConfigurator.ts:108-273`

```typescript
autoConfigureProject(workspacePath)
  ↓
1. Create manifest:
   - version, timestamp, workspacePath
   - Track createdFiles[], createdFolders[]
  ↓
2. Create dom-capture folder
  ↓
3. Copy/Create files:
   - index.ts (main export)
   - playwrightIntegration.ts
   - playwrightTestHelper.ts
   - playwrightFixtures.ts
   - advancedSerializer.ts
   - compressionManager.ts
   - stateCapture.ts
   - resourceInliner.ts
   - metadataCollector.ts
   - securityManager.ts
  ↓
4. For each file:
   - Try to find in extension
   - If not found: createStubContent()
   - Track in manifest
  ↓
5. Save manifest.json
  ↓
6. Show success message
```

#### 3.3 Stub Generation
**Location:** `enhancedProjectConfigurator.ts:758-949`

```
createStubContent(filePath, moduleName)
  ↓
Determine file type:
  - index → Main export stub
  - playwrightIntegration → Full integration with __captureDOM
  - playwrightTestHelper → TestCaptureManager with exposeFunction
  - playwrightFixtures → Test fixtures
  - advancedSerializer → DOM serialization
  - Others → Specific utility stubs
  ↓
Generate TypeScript/JavaScript code
  ↓
Return stub content
```

---

### **Flow 4: Manual Capture Command**

#### 4.1 VS Code Command
**File:** `src/extension.ts:334-429`

```
User runs: "DOM Capture: Capture Current Page"
  ↓
Command handler executes
  ↓
Check if Playwright page available
  ↓
Call captureManager.captureCurrentPage()
  ↓
Save to file system
  ↓
Show success notification
```

---

## 📊 Data Flow Matrix

| Component | Input | Processing | Output |
|-----------|-------|------------|--------|
| **Hotkey Listener** | Ctrl+Shift+C keypress | Event capture, visual feedback | Calls __captureDOM |
| **__captureDOM** | Browser context data | Bridge to Node.js | Returns capture result |
| **captureFromPage** | Page object, options | DOM extraction, file saving | File paths, success status |
| **Test Failure** | testInfo.status | Check === 'failed' | Auto-capture trigger |
| **Auto-Config** | Workspace path | File copying/generation | dom-capture/ folder |

---

## 🔄 Parameter Flow Analysis

### **Hotkey Capture Parameters**

```typescript
// Browser → Node.js
{
  trigger: 'hotkey',
  timestamp: 1234567890,
  count: 1,
  url: 'https://example.com',
  title: 'Page Title',
  stepName: 'Hotkey Capture',
  includeScreenshot: true
}
  ↓
// Node.js Processing
{
  captureId: 'hotkey_1234567890',
  stepName: 'Hotkey Capture',
  includeScreenshot: true,
  customMetadata: {
    trigger: 'hotkey',
    url: 'https://example.com',
    title: 'Page Title',
    captureCount: 1
  }
}
  ↓
// Response to Browser
{
  success: true,
  path: 'test-results/dom-captures/01-01-2024/TestClass_testMethod/capture_hotkey_1234567890.html'
}
```

### **Test Failure Parameters**

```typescript
// Test Context
{
  testInfo: {
    title: 'should do something',
    file: 'example.spec.ts',
    status: 'failed',
    error: { message: 'Assertion failed' }
  }
}
  ↓
// Capture Options
{
  captureId: 'failure_1234567890',
  customMetadata: {
    status: 'failed',
    error: 'Assertion failed'
  }
}
```

---

## ✅ Flow Verification Points

### **1. Function Name Consistency**
- ✅ All implementations use `__captureDOM`
- ✅ TypeScript declarations match
- ✅ No __performDOMCapture references

### **2. Event Flow**
- ✅ Direct function calls (no event dispatching)
- ✅ Proper async/await handling
- ✅ Error propagation through bridge

### **3. Visual Feedback**
- ✅ Green flash (0, 255, 0)
- ✅ Status indicators
- ✅ 2-second auto-dismiss

### **4. File Structure**
- ✅ Consistent folder pattern
- ✅ Metadata JSON creation
- ✅ Screenshot support

---

## 🚨 Critical Path Dependencies

1. **exposeFunction must be called BEFORE page navigation**
   - Location: `enableHotkeyCapture()` 
   - Critical for bridge setup

2. **TestCaptureManager must be singleton**
   - Ensures consistent state
   - Prevents multiple instances

3. **Folder creation must be recursive**
   - `fs.mkdirSync(..., { recursive: true })`
   - Handles nested directory structure

4. **Auto-configuration must track all files**
   - For proper rollback
   - Manifest.json is critical

---

## 📝 Flow Summary

All four major flows are correctly implemented:

1. **Ctrl+Shift+C**: Browser → __captureDOM → Node.js → File System ✅
2. **Test Failure**: Test Framework → Auto-capture → File System ✅  
3. **Auto-Config**: Command → Copy/Generate Files → dom-capture/ ✅
4. **Manual Capture**: VS Code Command → Capture Manager → File System ✅

The flows are consistent, use proper function names, and include appropriate error handling and user feedback.

## Next: PHASE 3 - Cross-Reference Matrix