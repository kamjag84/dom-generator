# GitHub Copilot Chat Integration

This extension integrates with GitHub Copilot Chat to provide an AI-powered assistant for DOM capture operations.

## 🤖 How to Use @domcapture

Once the extension is installed, you can interact with it through GitHub Copilot Chat:

### Opening Copilot Chat
1. Click the Copilot icon in the VS Code sidebar, or
2. Press `Ctrl+I` (Windows/Linux) or `Cmd+I` (Mac)

### Using @domcapture Commands

In the Copilot Chat window, type `@domcapture` followed by your request:

## 📋 Available Commands

### Setup & Configuration
```
@domcapture setup
@domcapture configure my project
@domcapture install dom capture
```
- Automatically configures your Playwright project
- Installs dependencies
- Creates backups
- Updates test files

### Dashboard & Viewing
```
@domcapture show dashboard
@domcapture open dashboard
@domcapture view captures
```
- Opens the visual dashboard
- Shows capture statistics
- Allows filtering and management

### Adding Capture Points
```
@domcapture add capture
@domcapture insert capture point
@domcapture add dom capture here
```
- Adds `await captureDom()` at cursor position
- Only works in test files

### Viewing Recent Captures
```
@domcapture show last capture
@domcapture show recent
@domcapture what was the last capture
```
- Opens the most recent DOM capture
- Shows capture details

### Verification & Maintenance
```
@domcapture verify
@domcapture check configuration
@domcapture is everything set up
```
- Checks if DOM capture is properly configured
- Lists any issues found

### Cleaning & Management
```
@domcapture clean
@domcapture delete old captures
@domcapture clean up
```
- Removes captures older than retention period
- Frees up disk space

### Getting Help
```
@domcapture help
@domcapture what can you do
@domcapture how to use
```
- Shows all available commands
- Provides usage examples

## 💬 Natural Language Examples

The assistant understands natural language, so you can also ask:

- "Hey @domcapture, can you help me set up DOM capture?"
- "@domcapture I want to see my test failures"
- "@domcapture how do I capture DOM in my tests?"
- "@domcapture please add a capture point here"
- "@domcapture show me the dashboard"

## 🎯 Interactive Buttons

The chat responses include interactive buttons that execute commands directly:
- **▶️ Auto-Configure Project** - One-click setup
- **📊 Open Dashboard** - View captures
- **➕ Add Capture Point** - Insert capture code
- **🗑️ Clean Old Captures** - Remove old files

## 📝 Code Examples

Ask for examples and the assistant will provide code snippets:

```
@domcapture show me an example test
@domcapture how to use captureDom
@domcapture example code
```

## 🔧 Context-Aware Responses

The assistant is context-aware:
- Knows when you're in a test file
- Checks your project configuration
- Provides relevant suggestions based on current state

## ⚡ Quick Tips

1. **Start conversations naturally**: "Hi @domcapture, I need help"
2. **Be specific**: "@domcapture add capture after line 25"
3. **Ask for explanations**: "@domcapture why did my test capture fail?"
4. **Request examples**: "@domcapture show me how to capture on success"

## 🔄 Workflow Example

1. **Setup**: `@domcapture setup my project`
2. **Write test**: Open your test file
3. **Add captures**: `@domcapture add capture point`
4. **Run tests**: Execute your Playwright tests
5. **View results**: `@domcapture show dashboard`
6. **Clean up**: `@domcapture clean old captures`

## 🚫 Limitations

- The chat participant requires GitHub Copilot subscription
- Commands execute in the context of your current workspace
- Some operations require an active Playwright project

## 📊 Benefits of Chat Integration

- **Natural language**: No need to remember exact commands
- **Interactive**: Buttons and links in responses
- **Contextual help**: Understands your current task
- **Code generation**: Provides examples and snippets
- **Guided workflow**: Step-by-step assistance

## 🆘 Troubleshooting

If `@domcapture` doesn't appear:
1. Ensure the extension is installed and activated
2. Restart VS Code
3. Check that you have GitHub Copilot installed
4. Open a Playwright project (with playwright.config.ts)

## 🎨 Customization

The chat participant respects your VS Code settings:
```json
{
  "playwright-dom-capture.autoCapture": true,
  "playwright-dom-capture.includeScreenshot": true,
  "playwright-dom-capture.retentionDays": 7
}
```

These settings affect the behavior of commands executed through chat.