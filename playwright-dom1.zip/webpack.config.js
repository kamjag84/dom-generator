//@ts-check

'use strict';

const path = require('path');
const webpack = require('webpack');

/** @typedef {import('webpack').Configuration} WebpackConfig **/

/** @type WebpackConfig */
const extensionConfig = {
  target: 'node', // VS Code extensions run in a Node.js-context
  mode: 'none', // this leaves the source code as close as possible to the original

  entry: './src/extension.ts', // the entry point of this extension
  output: {
    // the bundle is stored in the 'dist' folder (check package.json)
    path: path.resolve(__dirname, 'dist'),
    filename: 'extension.js',
    libraryTarget: 'commonjs2',
    devtoolModuleFilenameTemplate: '../[resource-path]'
  },
  externals: {
    vscode: 'commonjs vscode', // the vscode-module is created on-the-fly and must be excluded
    // Add other Node.js core modules that should not be bundled
    'fs': 'commonjs fs',
    'path': 'commonjs path',
    'child_process': 'commonjs child_process',
    'crypto': 'commonjs crypto',
    'stream': 'commonjs stream',
    'util': 'commonjs util',
    // Playwright modules should be external
    'playwright': 'commonjs playwright',
    '@playwright/test': 'commonjs @playwright/test'
  },
  resolve: {
    // support reading TypeScript and JavaScript files
    extensions: ['.ts', '.js', '.json'],
    alias: {
      '@': path.resolve(__dirname, 'src'),
      '@domCapture': path.resolve(__dirname, 'src/domCapture'),
      '@utils': path.resolve(__dirname, 'src/utils'),
      '@core': path.resolve(__dirname, 'src/core')
    }
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'ts-loader',
            options: {
              transpileOnly: true,
              compilerOptions: {
                module: 'commonjs'
              }
            }
          }
        ]
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'development')
    })
  ],
  devtool: 'nosources-source-map',
  infrastructureLogging: {
    level: "log", // enables logging required for problem matchers
  },
  optimization: {
    minimize: false, // Don't minimize for better debugging
    concatenateModules: true,
    sideEffects: false
  },
  performance: {
    hints: false // Disable performance warnings for extension
  },
  stats: {
    errors: true,
    warnings: true,
    colors: true,
    modules: false,
    chunks: false
  }
};

module.exports = [ extensionConfig ];