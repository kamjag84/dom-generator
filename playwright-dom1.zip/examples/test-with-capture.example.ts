/**
 * Example: How to use DOM Capture in your Playwright tests
 * 
 * USAGE:
 * 1. Import the enhanced test fixture
 * 2. Enable hotkey capture at test start
 * 3. Press Ctrl+Shift+C at any point during test execution
 * 4. Or call domCapture() programmatically
 */

import { test, expect } from '../src/testIntegration/playwrightTestHelper';

// Example 1: Basic test with hotkey capture enabled
test('login flow with DOM capture', async ({ page, enableHotkeyCapture, domCapture }) => {
  // Enable Ctrl+Shift+C hotkey for this test
  await enableHotkeyCapture();
  
  // Navigate to login page
  await page.goto('https://example.com/login');
  
  // NOW YOU CAN PRESS Ctrl+Shift+C AT ANY TIME TO CAPTURE DOM!
  
  // Fill login form
  await page.fill('#username', 'testuser@example.com');
  await page.fill('#password', 'testpass123');
  
  // Programmatic capture before clicking submit
  await domCapture({
    stepName: 'Before Login Submit',
    includeScreenshot: true
  });
  
  // Submit login
  await page.click('#submit-button');
  
  // Wait for redirect
  await page.waitForURL('https://example.com/dashboard');
  
  // PRESS Ctrl+Shift+C HERE TO CAPTURE DASHBOARD!
  
  // Navigate to another tab
  const newTab = await page.context().newPage();
  await newTab.goto('https://example.com/profile');
  
  // Fill profile form in new tab
  await newTab.fill('#firstName', 'John');
  await newTab.fill('#lastName', 'Doe');
  
  // Capture from specific tab
  await domCapture({
    stepName: 'Profile Form Filled',
    includeScreenshot: true
  });
  
  // Submit profile
  await newTab.click('#save-profile');
  
  // Go back to original tab
  await page.bringToFront();
  
  // Perform more actions
  await page.click('#settings-link');
  
  // PRESS Ctrl+Shift+C TO CAPTURE SETTINGS PAGE!
  
  // Logout
  await page.click('#logout');
});

// Example 2: Multi-tab test with capture all tabs
test('multi-tab workflow with capture', async ({ 
  page, 
  context,
  enableHotkeyCapture, 
  captureAllTabs,
  domCapture 
}) => {
  // Enable hotkey capture
  await enableHotkeyCapture();
  
  // Main page
  await page.goto('https://example.com');
  
  // Open multiple tabs
  const tab1 = await context.newPage();
  await tab1.goto('https://example.com/products');
  
  const tab2 = await context.newPage();
  await tab2.goto('https://example.com/cart');
  
  const tab3 = await context.newPage();
  await tab3.goto('https://example.com/checkout');
  
  // Fill forms across tabs
  await tab1.fill('#search', 'laptop');
  await tab1.click('#search-button');
  
  await tab2.fill('#promo-code', 'DISCOUNT10');
  
  await tab3.fill('#email', 'customer@example.com');
  await tab3.fill('#address', '123 Main St');
  
  // CAPTURE ALL TABS AT ONCE!
  await captureAllTabs({
    stepName: 'All Forms Filled',
    includeScreenshot: true,
    redactSensitive: true // Redact sensitive data
  });
  
  // Or press Ctrl+Shift+C on any tab to capture that specific tab
});

// Example 3: Test with automatic capture on specific conditions
test('conditional capture test', async ({ page, domCapture }) => {
  await page.goto('https://example.com/form');
  
  // Setup page listeners for automatic capture
  await page.evaluate(() => {
    // Capture when error occurs
    window.addEventListener('error', () => {
      (window as any).captureDom('Error occurred');
    });
    
    // Capture on form validation failure
    document.addEventListener('invalid', () => {
      (window as any).captureDom('Form validation failed');
    }, true);
    
    // Capture on specific element click
    document.addEventListener('click', (e) => {
      if ((e.target as HTMLElement).classList.contains('important-button')) {
        (window as any).captureDom('Important button clicked');
      }
    });
  });
  
  // Your test continues...
  await page.fill('#email', 'invalid-email'); // Will trigger validation capture
  await page.click('#submit'); // Will capture if validation fails
});

// Example 4: Using with existing tests (no modification needed!)
test.describe('Existing test suite', () => {
  // Just add this line to enable capture for all tests in suite
  test.beforeEach(async ({ enableHotkeyCapture }) => {
    await enableHotkeyCapture();
  });
  
  test('existing test 1', async ({ page }) => {
    await page.goto('https://example.com');
    // PRESS Ctrl+Shift+C ANYTIME!
    await page.click('#some-button');
  });
  
  test('existing test 2', async ({ page }) => {
    await page.goto('https://example.com/page2');
    // PRESS Ctrl+Shift+C ANYTIME!
    await page.fill('#input', 'value');
  });
});

// Example 5: Capture with custom metadata
test('test with rich metadata', async ({ page, domCapture }) => {
  await page.goto('https://example.com');
  
  // Capture with custom metadata
  await domCapture({
    stepName: 'Custom Capture',
    includeScreenshot: true,
    includeVideo: false,
    includeNetworkLog: true,
    redactSensitive: true,
    customMetadata: {
      testId: 'TEST-123',
      environment: 'staging',
      version: '1.2.3',
      user: 'test-user',
      additionalInfo: {
        browser: 'Chrome',
        viewport: '1920x1080'
      }
    }
  });
});

// Example 6: Global setup for ALL tests (add to playwright.config.ts)
/*
import { defineConfig } from '@playwright/test';
import { domCaptureConfig } from './src/testIntegration/runtimeInjector';

export default defineConfig({
  use: {
    ...domCaptureConfig.use,
    // Your other config
  },
  globalSetup: domCaptureConfig.globalSetup,
  globalTeardown: domCaptureConfig.globalTeardown,
});
*/