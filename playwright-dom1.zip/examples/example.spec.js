"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = require("@playwright/test");
// Import the DOM capture helper after project configuration
// import { captureDom } from '../src/domCapture/testIntegration/playwrightTestHelper';
/**
 * Example test file demonstrating DOM capture integration
 *
 * After running "DOM Capture: Auto-configure Project" command,
 * uncomment the import above to enable DOM capture in your tests
 */
test_1.test.describe('E-commerce Checkout Flow', () => {
    (0, test_1.test)('should complete purchase successfully', async ({ page }) => {
        // Navigate to the shop
        await page.goto('https://demo.playwright.dev/todomvc');
        // CAPTURE POINT 1: Initial page state
        // await captureDom(page, 'initial-page-load');
        // Or press Ctrl+Shift+C during test execution
        // Add first todo item
        await page.locator('.new-todo').fill('Buy groceries');
        await page.locator('.new-todo').press('Enter');
        // CAPTURE POINT 2: After adding first item
        // await captureDom(page, 'first-todo-added');
        // Add second todo item
        await page.locator('.new-todo').fill('Walk the dog');
        await page.locator('.new-todo').press('Enter');
        // CAPTURE POINT 3: After adding second item
        // await captureDom(page, 'second-todo-added');
        // Mark first item as complete
        await page.locator('.todo-list li').first().locator('.toggle').check();
        // CAPTURE POINT 4: After marking complete
        // await captureDom(page, 'todo-marked-complete');
        // Verify the item is marked as completed
        await (0, test_1.expect)(page.locator('.todo-list li').first()).toHaveClass(/completed/);
        // Filter by active items
        await page.locator('.filters >> text=Active').click();
        // CAPTURE POINT 5: Filtered view
        // await captureDom(page, 'filtered-active-todos');
        // Verify only active items are shown
        await (0, test_1.expect)(page.locator('.todo-list li')).toHaveCount(1);
        await (0, test_1.expect)(page.locator('.todo-list li')).toContainText('Walk the dog');
    });
    (0, test_1.test)('should handle form validation errors', async ({ page }) => {
        await page.goto('https://demo.playwright.dev/todomvc');
        // Try to submit empty todo
        await page.locator('.new-todo').press('Enter');
        // This test might fail - DOM will be automatically captured
        // The capture will be saved with FAILED_ prefix if test fails
        await (0, test_1.expect)(page.locator('.todo-list li')).toHaveCount(1);
    });
});
test_1.test.describe('Multi-Step User Journey', () => {
    (0, test_1.test)('complex workflow with multiple captures', async ({ page }) => {
        /**
         * TIP: During this test execution, you can press Ctrl+Shift+C
         * at any moment to capture the current DOM state
         */
        await page.goto('https://example.com');
        // Step 1: Login
        // await captureDom(page, 'step-1-login-page');
        // ... login actions ...
        // Step 2: Dashboard
        // await captureDom(page, 'step-2-dashboard');
        // ... dashboard interactions ...
        // Step 3: Settings
        // await captureDom(page, 'step-3-settings');
        // ... settings modifications ...
        // Step 4: Confirmation
        // await captureDom(page, 'step-4-confirmation');
        /**
         * All captures will be organized in:
         * test-results/dom-captures/DD-MM-YYYY/example_spec_complex_workflow_with_multiple_captures/
         *
         * Each capture includes:
         * - Full DOM with all styles
         * - Form states
         * - LocalStorage/SessionStorage
         * - Metadata with timestamps
         */
    });
});
test_1.test.describe('Debugging Failed Tests', () => {
    (0, test_1.test)('automatic capture on failure', async ({ page }) => {
        await page.goto('https://example.com/login');
        // Fill login form
        await page.fill('#username', 'testuser');
        await page.fill('#password', 'wrongpassword');
        await page.click('#login-button');
        // This assertion will fail and trigger automatic DOM capture
        // The capture will include the exact state showing the error message
        await (0, test_1.expect)(page.locator('.success-message')).toBeVisible();
        /**
         * When this test fails, you'll find the capture at:
         * test-results/dom-captures/DD-MM-YYYY/example_spec_automatic_capture_on_failure/
         *
         * The capture will show:
         * - The login form with filled values
         * - Any error messages displayed
         * - Complete page state at failure point
         */
    });
});
/**
 * MANUAL CAPTURE WORKFLOW:
 *
 * 1. Press Ctrl+Alt+C (Cmd+Alt+C on Mac) anywhere in VS Code
 * 2. Enter the URL you want to capture
 * 3. The DOM will be saved to:
 *    test-results/dom-captures/manual-dom-captures/DD-MM-YYYY/
 *
 * This is useful for:
 * - Quick debugging without running tests
 * - Capturing production issues
 * - Creating reference captures
 */
/**
 * TIPS FOR EFFECTIVE DOM CAPTURE:
 *
 * 1. Strategic Placement: Add captures before and after critical operations
 * 2. Use Descriptive Names: captureDom(page, 'after-payment-processed')
 * 3. Runtime Capture: Use Ctrl+Shift+C during test execution for unexpected issues
 * 4. Review Metadata: Check _metadata.json files for performance metrics
 * 5. Clean Regularly: Use "DOM Capture: Clean Old Captures" to manage disk space
 * 6. Compare States: Open multiple captures to compare DOM differences
 * 7. Check Console: Captured DOM includes console errors in metadata
 */ 
//# sourceMappingURL=example.spec.js.map