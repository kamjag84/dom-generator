# 🧪 Testing DOM Capture Commands

## Installation & Testing Steps

### 1. Install the Updated Extension
```bash
# Uninstall old version
code --uninstall-extension playwright-dom-capture

# Install new version
code --install-extension "C:\Users\Kamal Jaguri\GenAI\Playwright-domCapture\playwright-dom-capture-1.0.0.vsix"

# Restart VS Code
```

### 2. Test Auto-Configuration

1. Open your test project in VS Code:
```bash
code "C:\Users\Kamal Jaguri\GenAI\playwright-dom-capture-test"
```

2. Press `Ctrl+Shift+P` and run:
```
DOM Capture: Auto-configure Project
```

3. **What should happen:**
   - Progress notification showing configuration steps
   - Creates `dom-capture/` folder with all integration files
   - Creates `.dom-capture-backup/` with backups
   - Creates `.dom-capture-manifest.json` for tracking
   - Creates `dom-capture-example.spec.ts` test file
   - Creates `DOM_CAPTURE_GUIDE.md` documentation
   - Shows success message with options

### 3. Verify Created Structure

After auto-configuration, you should see:
```
playwright-dom-capture-test/
├── .dom-capture-backup/        # Backup of original files
│   ├── metadata.json
│   └── [backup files]
├── .dom-capture-manifest.json  # Tracks all changes
├── dom-capture/                # All integration files
│   ├── config/
│   │   └── dom-capture.config.json
│   ├── utils/
│   │   ├── compressionManager.ts
│   │   ├── securityManager.ts
│   │   └── [other utilities]
│   ├── playwrightIntegration.ts
│   ├── playwrightTestHelper.ts
│   └── index.ts
├── dom-capture-example.spec.ts # Example test
└── DOM_CAPTURE_GUIDE.md       # Documentation
```

### 4. Run Example Test

```bash
cd "C:\Users\Kamal Jaguri\GenAI\playwright-dom-capture-test"
npx playwright test dom-capture-example.spec.ts --headed
```

**During test execution:**
- Wait for browser to open
- Press `Ctrl+Shift+C` to capture DOM
- Check `test-results/dom-captures/` for captured files

### 5. Test Rollback Command

1. Press `Ctrl+Shift+P` and run:
```
DOM Capture: Rollback Configuration
```

2. Confirm the rollback

3. **What should happen:**
   - All created files are removed
   - All created folders are removed
   - Original files are restored from backup
   - Backup folder is deleted
   - Manifest file is removed
   - Success message shown

### 6. Verify Clean Rollback

After rollback, verify:
- No `dom-capture/` folder
- No `.dom-capture-backup/` folder
- No `.dom-capture-manifest.json` file
- No `dom-capture-example.spec.ts` file
- No `DOM_CAPTURE_GUIDE.md` file
- Original files (if any were modified) are restored

## Command Verification Checklist

### Auto-Configuration Command ✅
- [ ] Creates dom-capture folder
- [ ] Copies all integration files
- [ ] Creates backup of existing files
- [ ] Saves manifest for tracking
- [ ] Creates example test
- [ ] Creates documentation
- [ ] Shows success message
- [ ] All files are properly tracked

### Rollback Command ✅
- [ ] Removes all created files
- [ ] Removes all created folders
- [ ] Restores backed up files
- [ ] Removes backup folder
- [ ] Removes manifest file
- [ ] Shows success message
- [ ] Leaves no traces

## Troubleshooting

### If auto-configuration fails:
1. Check VS Code Output panel (select "Playwright DOM Capture")
2. Ensure you have a valid Playwright project
3. Check file permissions

### If rollback fails:
1. Check if `.dom-capture-manifest.json` exists
2. Manually remove `dom-capture/` folder if needed
3. Check Output panel for errors

## Expected Console Output

### During Auto-Configuration:
```
🚀 Playwright DOM Capture extension activating...
✅ Extension activated successfully
Starting auto-configuration for: [path]
✅ Validated Playwright project
✅ Created backup
✅ Setup DOM capture directory
✅ Copied integration files
✅ Created example tests
✅ Configuration complete!
```

### During Rollback:
```
Starting rollback for: [path]
Removed file: [file]
Removed folder: [folder]
Restored: [file]
✅ Rollback complete!
```