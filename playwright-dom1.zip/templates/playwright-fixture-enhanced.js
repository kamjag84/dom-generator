/**
 * Enhanced Playwright Test Fixture with Automatic DOM Capture
 * This fixture automatically enables DOM capture for all tests
 */

const base = require('@playwright/test');
const path = require('path');
const fs = require('fs-extra');

// Import capture utilities
const { captureDom } = require('./capture');

// Enhanced test fixture with auto-capture
exports.test = base.test.extend({
    // Override the page fixture to add auto-capture
    page: async ({ page }, use, testInfo) => {
        console.log(`🎯 DOM Capture enabled for: ${testInfo.title}`);
        
        // Enable hotkey capture (Ctrl+Shift+C) automatically
        await enableHotkeyCapture(page, testInfo);
        
        // Add visual indicator
        await page.addInitScript(() => {
            // Create floating capture button
            const button = document.createElement('div');
            button.id = 'dom-capture-btn';
            button.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                z-index: 999999;
                box-shadow: 0 4px 15px rgba(0,0,0,0.3);
                transition: all 0.3s ease;
                opacity: 0.7;
            `;
            button.innerHTML = '📸';
            button.title = 'Click or press Ctrl+Shift+C to capture DOM';
            
            // Hover effects
            button.onmouseenter = () => {
                button.style.opacity = '1';
                button.style.transform = 'scale(1.1)';
            };
            button.onmouseleave = () => {
                button.style.opacity = '0.7';
                button.style.transform = 'scale(1)';
            };
            
            // Click to capture
            button.onclick = () => {
                window.__triggerDomCapture = true;
                button.style.background = '#4CAF50';
                button.innerHTML = '✓';
                setTimeout(() => {
                    button.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
                    button.innerHTML = '📸';
                }, 1500);
            };
            
            // Add to body when ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => {
                    document.body.appendChild(button);
                });
            } else {
                document.body.appendChild(button);
            }
            
            // Keyboard listener for Ctrl+Shift+C
            document.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.shiftKey && e.key === 'C') {
                    e.preventDefault();
                    window.__triggerDomCapture = true;
                    console.log('🎯 DOM Capture triggered!');
                    
                    // Show notification
                    const notification = document.createElement('div');
                    notification.style.cssText = `
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: #4CAF50;
                        color: white;
                        padding: 15px 20px;
                        border-radius: 5px;
                        font-family: Arial, sans-serif;
                        font-size: 14px;
                        z-index: 999999;
                        animation: slideIn 0.3s ease-out;
                    `;
                    notification.innerHTML = '📸 Capturing DOM...';
                    document.body.appendChild(notification);
                    
                    setTimeout(() => {
                        notification.innerHTML = '✅ DOM Captured!';
                        setTimeout(() => notification.remove(), 2000);
                    }, 500);
                }
            }, true);
            
            // Add animations
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100px); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        });
        
        // Poll for capture triggers
        const captureInterval = setInterval(async () => {
            const shouldCapture = await page.evaluate(() => {
                const trigger = window.__triggerDomCapture;
                if (trigger) {
                    window.__triggerDomCapture = false;
                    return true;
                }
                return false;
            }).catch(() => false);
            
            if (shouldCapture) {
                await captureDom(page, 'manual-capture');
            }
        }, 100);
        
        // Store interval for cleanup
        page.__captureInterval = captureInterval;
        
        // Auto-capture on errors
        page.on('pageerror', async (error) => {
            console.error('Page error:', error);
            await captureDom(page, 'error-capture');
        });
        
        // Auto-capture on test failure
        let testFailed = false;
        page.on('response', response => {
            // Track if test is failing
            if (testInfo.status === 'failed' && !testFailed) {
                testFailed = true;
                captureDom(page, 'failure-capture').catch(console.error);
            }
        });
        
        // Use the page
        await use(page);
        
        // Cleanup
        clearInterval(captureInterval);
        
        // Capture on test failure
        if (testInfo.status === 'failed' && !testFailed) {
            await captureDom(page, 'test-failed');
        }
    }
});

// Helper function to enable hotkey capture
async function enableHotkeyCapture(page, testInfo) {
    console.log(`⌨️ Hotkey capture enabled: Press Ctrl+Shift+C during test execution`);
    
    // Show initial hint
    await page.evaluate(() => {
        setTimeout(() => {
            const hint = document.createElement('div');
            hint.style.cssText = `
                position: fixed;
                bottom: 80px;
                right: 20px;
                background: rgba(0,0,0,0.8);
                color: white;
                padding: 10px 15px;
                border-radius: 5px;
                font-family: Arial, sans-serif;
                font-size: 12px;
                z-index: 999998;
                animation: fadeIn 0.5s ease;
            `;
            hint.innerHTML = '💡 Press Ctrl+Shift+C to capture DOM';
            document.body.appendChild(hint);
            
            setTimeout(() => hint.remove(), 5000);
        }, 1000);
    }).catch(() => {});
}

// Export expect as-is
exports.expect = base.expect;

// Export the captureDom function for manual use
exports.captureDom = captureDom;