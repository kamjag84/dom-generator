/**
 * DOM Capture Utility for Playwright Tests
 * Automatically installed by Playwright DOM Capture VS Code Extension
 * 
 * Usage:
 * const { captureDom } = require('./dom-capture/capture');
 * await captureDom(page, 'optional-label');
 */

const fs = require('fs').promises;
const path = require('path');

/**
 * Captures the full DOM of the current page
 * @param {Page} page - Playwright page object
 * @param {string} label - Optional label for the capture
 * @param {Object} options - Optional configuration
 */
async function captureDom(page, label = '', options = {}) {
    try {
        // Get test info from environment or use defaults
        const testInfo = getTestInfo();
        
        // Capture the full DOM with all resources
        const dom = await page.evaluate(() => {
            // Helper to convert relative URLs to absolute
            function toAbsoluteUrl(url) {
                if (!url || url.startsWith('data:') || url.startsWith('blob:')) return url;
                return new URL(url, document.baseURI).href;
            }

            // Helper to inline styles
            function inlineStyles() {
                const styles = [];
                for (const sheet of document.styleSheets) {
                    try {
                        const rules = Array.from(sheet.cssRules || []);
                        styles.push(rules.map(rule => rule.cssText).join('\n'));
                    } catch (e) {
                        // Cross-origin stylesheets
                        const link = document.querySelector(`link[href="${sheet.href}"]`);
                        if (link) {
                            styles.push(`/* External stylesheet: ${sheet.href} */`);
                        }
                    }
                }
                return styles.join('\n');
            }

            // Helper to inline images
            async function inlineImages() {
                const images = document.querySelectorAll('img');
                for (const img of images) {
                    if (img.src && !img.src.startsWith('data:')) {
                        try {
                            const response = await fetch(img.src);
                            const blob = await response.blob();
                            const reader = new FileReader();
                            const dataUrl = await new Promise((resolve) => {
                                reader.onloadend = () => resolve(reader.result);
                                reader.readAsDataURL(blob);
                            });
                            img.setAttribute('data-original-src', img.src);
                            img.src = dataUrl;
                        } catch (e) {
                            console.warn('Failed to inline image:', img.src);
                        }
                    }
                }
            }

            // Clone the document
            const doctype = document.doctype;
            const doctypeString = doctype ? 
                `<!DOCTYPE ${doctype.name}>` : '';

            // Get the full HTML
            const html = document.documentElement.cloneNode(true);
            
            // Add inline styles
            const styleElement = document.createElement('style');
            styleElement.textContent = inlineStyles();
            html.querySelector('head').appendChild(styleElement);

            // Add meta information
            const metaElement = document.createElement('meta');
            metaElement.name = 'dom-capture-time';
            metaElement.content = new Date().toISOString();
            html.querySelector('head').appendChild(metaElement);

            // Add viewport meta
            const viewportMeta = document.createElement('meta');
            viewportMeta.name = 'dom-capture-viewport';
            viewportMeta.content = `width=${window.innerWidth},height=${window.innerHeight}`;
            html.querySelector('head').appendChild(viewportMeta);

            return doctypeString + html.outerHTML;
        });

        // Create folder structure
        const outputPath = await createOutputPath(testInfo, label);
        
        // Save the DOM
        await fs.writeFile(outputPath.htmlPath, dom, 'utf-8');
        
        // Save metadata
        const metadata = {
            url: page.url(),
            timestamp: new Date().toISOString(),
            viewport: await page.viewportSize(),
            label: label,
            testName: testInfo.testName,
            testFile: testInfo.testFile,
            captureType: options.isFailure ? 'failure' : 'manual'
        };
        
        await fs.writeFile(outputPath.metadataPath, JSON.stringify(metadata, null, 2), 'utf-8');
        
        // Take screenshot if enabled
        if (options.screenshot !== false) {
            await page.screenshot({ 
                path: outputPath.screenshotPath, 
                fullPage: true 
            });
        }
        
        console.log(`✅ DOM captured: ${outputPath.htmlPath}`);
        return outputPath;
        
    } catch (error) {
        console.error('Failed to capture DOM:', error);
        throw error;
    }
}

/**
 * Get test information from environment or stack trace
 */
function getTestInfo() {
    // Try to get from environment (if set by test runner)
    if (process.env.CURRENT_TEST_NAME) {
        return {
            testName: process.env.CURRENT_TEST_NAME,
            testFile: process.env.CURRENT_TEST_FILE || 'unknown'
        };
    }
    
    // Try to extract from stack trace
    const stack = new Error().stack;
    const testFileMatch = stack.match(/at.*\((.+\.(?:spec|test)\.[jt]s):/);
    const testFile = testFileMatch ? path.basename(testFileMatch[1]) : 'unknown';
    
    return {
        testName: 'test',
        testFile: testFile.replace(/\.(spec|test)\.[jt]s$/, '')
    };
}

/**
 * Create output path for captures
 */
async function createOutputPath(testInfo, label) {
    const date = new Date();
    const dateFolder = `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear()}`;
    const timestamp = `${date.getHours().toString().padStart(2, '0')}-${date.getMinutes().toString().padStart(2, '0')}-${date.getSeconds().toString().padStart(2, '0')}`;
    
    // Extract class name from test file
    const className = testInfo.testFile.replace(/[^a-zA-Z0-9]/g, '_');
    const methodName = testInfo.testName.replace(/[^a-zA-Z0-9]/g, '_');
    
    // Create folder path
    const folderPath = path.join(
        process.cwd(),
        'test-results',
        'dom-captures',
        dateFolder,
        `${className}_${methodName}`
    );
    
    // Ensure directory exists
    await fs.mkdir(folderPath, { recursive: true });
    
    // Generate file names
    const captureNumber = await getNextCaptureNumber(folderPath);
    const baseName = `capture_${captureNumber}_${timestamp}`;
    const labelSuffix = label ? `_${label.replace(/[^a-zA-Z0-9]/g, '_')}` : '';
    
    return {
        htmlPath: path.join(folderPath, `${baseName}${labelSuffix}.html`),
        metadataPath: path.join(folderPath, `${baseName}${labelSuffix}_metadata.json`),
        screenshotPath: path.join(folderPath, `${baseName}${labelSuffix}_screenshot.png`),
        folderPath
    };
}

/**
 * Get the next capture number for sequential naming
 */
async function getNextCaptureNumber(folderPath) {
    try {
        const files = await fs.readdir(folderPath);
        const captures = files.filter(f => f.startsWith('capture_'));
        
        if (captures.length === 0) return 1;
        
        const numbers = captures.map(f => {
            const match = f.match(/capture_(\d+)_/);
            return match ? parseInt(match[1]) : 0;
        });
        
        return Math.max(...numbers) + 1;
    } catch (error) {
        // Folder doesn't exist yet
        return 1;
    }
}

/**
 * Setup automatic capture on test failure
 */
function setupAutomaticCapture(test) {
    const originalTest = test;
    
    return async function(...args) {
        const testFunction = args[args.length - 1];
        const wrappedTest = async ({ page, ...rest }) => {
            try {
                await testFunction({ page, ...rest });
            } catch (error) {
                // Capture DOM on failure
                try {
                    await captureDom(page, 'failure', { isFailure: true });
                } catch (captureError) {
                    console.error('Failed to capture DOM on test failure:', captureError);
                }
                throw error; // Re-throw the original error
            }
        };
        
        args[args.length - 1] = wrappedTest;
        return originalTest(...args);
    };
}

// Export for use in tests
module.exports = {
    captureDom,
    setupAutomaticCapture
};