// Quick fix script to ensure commands work
const fs = require('fs');
const path = require('path');

// Read current package.json
const packagePath = path.join(__dirname, 'package.json');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

// Ensure correct structure
pkg.publisher = "test-publisher";
pkg.engines = { "vscode": "^1.85.0" };
pkg.main = "./out/extension.js";

// Ensure activation events include the specific command
if (!pkg.activationEvents) {
    pkg.activationEvents = [];
}

// Add specific activation for the problematic command
const requiredActivations = [
    "onCommand:playwright-dom-capture.autoConfigureProject",
    "onCommand:playwright-dom-capture.showDashboard",
    "onCommand:playwright-dom-capture.viewLastCapture",
    "onCommand:playwright-dom-capture.verifyConfig",
    "onCommand:playwright-dom-capture.rollbackConfig",
    "onCommand:playwright-dom-capture.cleanCaptures"
];

requiredActivations.forEach(event => {
    if (!pkg.activationEvents.includes(event)) {
        pkg.activationEvents.push(event);
    }
});

// Ensure commands are properly defined
if (!pkg.contributes) {
    pkg.contributes = {};
}

if (!pkg.contributes.commands) {
    pkg.contributes.commands = [];
}

// Define all commands with proper structure
const commands = [
    {
        "command": "playwright-dom-capture.autoConfigureProject",
        "title": "DOM Capture: Auto-configure Project",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.showDashboard",
        "title": "DOM Capture: Show Dashboard",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.viewLastCapture",
        "title": "DOM Capture: View Last Capture",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.verifyConfig",
        "title": "DOM Capture: Verify Configuration",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.rollbackConfig",
        "title": "DOM Capture: Rollback Configuration",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.cleanCaptures",
        "title": "DOM Capture: Clean Old Captures",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.captureCurrentPage",
        "title": "DOM Capture: Capture Current Page",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.prepareForCommit",
        "title": "DOM Capture: Prepare for Commit",
        "category": "DOM Capture"
    },
    {
        "command": "playwright-dom-capture.checkGitSafety",
        "title": "DOM Capture: Check Git Safety",
        "category": "DOM Capture"
    }
];

// Replace commands array
pkg.contributes.commands = commands;

// Write back
fs.writeFileSync(packagePath, JSON.stringify(pkg, null, 2));

console.log('✅ Package.json fixed!');
console.log('Commands registered:', commands.length);
console.log('Activation events:', pkg.activationEvents.length);