import { defineConfig, devices } from '@playwright/test';

/**
 * Configuration for Playwright tests with DOM Capture extension
 */
export default defineConfig({
  testDir: './tests',
  
  // Maximum time one test can run
  timeout: 30 * 1000,
  
  // Test execution settings
  fullyParallel: false, // Run tests sequentially for easier DOM capture testing
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1, // Single worker for testing DOM capture
  
  // Reporter configuration
  reporter: [
    ['html', { open: 'never' }],
    ['list'] // Shows test progress in console
  ],
  
  // Shared settings for all projects
  use: {
    // Base URL for relative navigation
    baseURL: 'https://example.com',
    
    // Collect trace for debugging
    trace: 'on-first-retry',
    
    // Screenshot on failure (DOM capture will also trigger)
    screenshot: {
      mode: 'only-on-failure',
      fullPage: true
    },
    
    // Video recording
    video: 'retain-on-failure',
    
    // Viewport size
    viewport: { width: 1280, height: 720 },
    
    // Timeout for actions
    actionTimeout: 10 * 1000,
    
    // Whether to ignore HTTPS errors
    ignoreHTTPSErrors: true,
    
    // Emulate user locale
    locale: 'en-US',
    
    // Timezone
    timezoneId: 'America/New_York',
  },

  // Configure projects for different browsers
  projects: [
    {
      name: 'chromium',
      use: { 
        ...devices['Desktop Chrome'],
        // Slow down actions for better visibility during manual capture
        launchOptions: {
          slowMo: process.env.SLOW ? 1000 : 0,
        }
      },
    },

    // Uncomment to test with other browsers
    // {
    //   name: 'firefox',
    //   use: { ...devices['Desktop Firefox'] },
    // },
    // {
    //   name: 'webkit',
    //   use: { ...devices['Desktop Safari'] },
    // },

    // Mobile testing
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
  ],

  // Output folder for test artifacts
  outputDir: './test-results/',
  
  // Global setup/teardown
  // globalSetup: require.resolve('./global-setup'),
  // globalTeardown: require.resolve('./global-teardown'),
});