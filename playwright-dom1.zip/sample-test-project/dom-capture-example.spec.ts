/**
 * Example test with DOM Capture enabled
 * Press Ctrl+Shift+C during test execution to capture DOM
 */

import { test, expect } from './dom-capture/playwrightIntegration';

test.describe('DOM Capture Example Tests', () => {
    test('basic navigation with capture', async ({ page }) => {
        // DOM capture is automatically enabled
        await page.goto('https://example.com');
        
        // The page title should contain "Example"
        await expect(page).toHaveTitle(/Example/);
        
        // Press Ctrl+Shift+C in the browser to capture DOM at any point!
    });

    test('capture on failure (intentional)', async ({ page }) => {
        await page.goto('https://example.com');
        
        // This will fail and automatically capture DOM
        await expect(page.locator('#non-existent')).toBeVisible();
    });

    test('manual capture example', async ({ page }) => {
        await page.goto('https://example.com');
        
        // Trigger manual capture
        await page.evaluate(() => {
            window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                detail: { trigger: 'manual', timestamp: Date.now() }
            }));
        });
        
        // Continue with test...
        await expect(page).toHaveTitle(/Example/);
    });
});
