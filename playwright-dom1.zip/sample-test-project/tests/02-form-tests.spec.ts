import { test, expect } from '../dom-capture/playwrightIntegration';

test.describe('Form Interaction Tests', () => {
  test('📝 Test form filling and submission', async ({ page }) => {
    // Go to a page with forms
    await page.goto('https://www.w3schools.com/html/html_forms.asp');
    
    // Wait for page to load
    await page.waitForLoadState('networkidle');
    
    // Try to find and fill the example form (if exists)
    const firstNameInput = page.locator('input[name="fname"]').first();
    const lastNameInput = page.locator('input[name="lname"]').first();
    
    if (await firstNameInput.isVisible()) {
      await firstNameInput.fill('John');
      await lastNameInput.fill('Doe');
      
      console.log('📝 Form filled - good time for manual DOM capture to see form state');
      await page.waitForTimeout(3000);
    }
    
    // Take a screenshot for comparison
    await page.screenshot({ path: 'test-results/form-filled.png' });
  });

  test('🔍 Search functionality test', async ({ page }) => {
    await page.goto('https://www.wikipedia.org');
    
    // Find search input
    const searchInput = page.locator('input#searchInput');
    await expect(searchInput).toBeVisible();
    
    // Type search query
    await searchInput.fill('Playwright testing');
    
    // Wait for suggestions (good capture point)
    await page.waitForTimeout(2000);
    
    // Press Enter to search
    await searchInput.press('Enter');
    
    // Wait for results page
    await page.waitForLoadState('networkidle');
    
    // Verify we're on a results page
    const heading = page.locator('h1').first();
    await expect(heading).toBeVisible();
  });

  test('❌ Form validation failure test', async ({ page }) => {
    await page.goto('https://www.w3schools.com/html/tryit.asp?filename=tryhtml_form_submit');
    
    // Switch to iframe
    const frame = page.frameLocator('#iframeResult');
    
    // Try to submit empty form (should fail validation)
    const submitButton = frame.locator('input[type="submit"]');
    
    // This might fail if button doesn't exist
    await expect(submitButton).toBeVisible();
    await submitButton.click();
    
    // Check for validation message (will likely fail and trigger capture)
    const validationMessage = frame.locator('.validation-error');
    await expect(validationMessage).toBeVisible();
  });
});

test.describe('Dynamic Content Tests', () => {
  test('🔄 Test dynamic content loading', async ({ page }) => {
    await page.goto('https://developer.mozilla.org/en-US/docs/Web/JavaScript');
    
    // Wait for dynamic content
    await page.waitForLoadState('networkidle');
    
    // Scroll to trigger lazy loading
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    
    // Wait for lazy loaded content
    await page.waitForTimeout(2000);
    
    console.log('📸 Dynamic content loaded - good capture point');
    
    // Verify some content exists
    const articles = page.locator('article');
    await expect(articles.first()).toBeVisible();
  });

  test('⚡ Single Page Application test', async ({ page }) => {
    await page.goto('https://react.dev/');
    
    // Wait for React app to load
    await page.waitForLoadState('networkidle');
    
    // Click on a navigation link
    const learnLink = page.locator('a[href*="/learn"]').first();
    if (await learnLink.isVisible()) {
      await learnLink.click();
      
      // Wait for client-side navigation
      await page.waitForTimeout(2000);
      
      // Verify URL changed without page reload
      expect(page.url()).toContain('/learn');
    }
    
    // Test will pass if navigation works
    await expect(page.locator('main')).toBeVisible();
  });
});

test.describe('Visual Regression Tests', () => {
  test('📸 Capture for visual comparison', async ({ page }) => {
    await page.goto('https://github.com/microsoft/playwright');
    
    // Wait for page to fully load
    await page.waitForLoadState('networkidle');
    
    // Capture full page screenshot
    await page.screenshot({ 
      path: 'test-results/github-playwright.png',
      fullPage: true 
    });
    
    console.log('📸 Screenshot captured - DOM capture will include current state');
    
    // Scroll to README section
    const readme = page.locator('#readme');
    if (await readme.isVisible()) {
      await readme.scrollIntoViewIfNeeded();
      await page.waitForTimeout(1000);
    }
    
    // This test passes but creates good capture points
    await expect(page).toHaveTitle(/Playwright/);
  });

  test('🎨 CSS and styling capture test', async ({ page }) => {
    await page.goto('https://www.w3schools.com/css/css_intro.asp');
    
    // Wait for styles to load
    await page.waitForLoadState('networkidle');
    
    // Check if CSS examples are visible
    const codeExample = page.locator('.w3-code').first();
    await expect(codeExample).toBeVisible();
    
    // Interact with Try It buttons if available
    const tryItButton = page.locator('a.w3-btn:has-text("Try it Yourself")').first();
    if (await tryItButton.isVisible()) {
      console.log('🎨 CSS example found - capturing styled content');
      await page.waitForTimeout(2000);
    }
    
    // Test passes to show successful capture
    await expect(page).toHaveTitle(/CSS Introduction/);
  });
});