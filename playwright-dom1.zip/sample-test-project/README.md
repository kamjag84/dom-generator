# Sample Playwright Test Project for DOM Capture Extension

This project contains various test scenarios to demonstrate and test the Playwright DOM Capture VS Code extension.

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
npx playwright install chromium
```

### 2. Configure DOM Capture Extension
1. Open this folder in VS Code
2. Press `Ctrl+Shift+P`
3. Run: `DOM Capture: Auto-configure Project`

### 3. Run Tests
```bash
# Run all tests
npm test

# Run specific test file
npx playwright test tests/01-basic-tests.spec.ts

# Run in UI mode (interactive)
npm run test:ui

# Run in debug mode
npm run test:debug

# Run with slow motion for manual capture testing
SLOW=1 npm test
```

## 📁 Test Files

### 01-basic-tests.spec.ts
- ✅ Passing tests (no capture)
- ❌ Failing tests (auto capture)
- ⏸️ Tests with pause for manual capture (Ctrl+Shift+C)
- 🔄 Navigation tests
- ⏭️ Skipped tests

### 02-form-tests.spec.ts
- 📝 Form filling and interaction
- 🔍 Search functionality
- ❌ Form validation failures
- 🔄 Dynamic content loading
- ⚡ Single Page Application tests
- 📸 Visual regression tests

### 03-advanced-tests.spec.ts
- 🌐 Multi-tab scenarios
- 🖼️ IFrame handling
- 🎭 Shadow DOM testing
- 📊 Canvas and SVG capture
- 🔐 LocalStorage/SessionStorage
- ⚡ Performance tests
- 🔄 Infinite scroll

## 🧪 Test Scenarios

### Testing Auto Capture on Failure
Run any test with ❌ emoji - these are designed to fail and trigger automatic DOM capture:
```bash
npx playwright test -g "Failing test"
```

### Testing Manual Capture (Ctrl+Shift+C)
1. Run tests with ⏸️ emoji - these have built-in pauses:
```bash
npx playwright test -g "manual capture"
```
2. When you see the pause message, press `Ctrl+Shift+C` in VS Code
3. The DOM will be captured at that moment

### Testing Ctrl+Alt+C (Manual URL Capture)
1. Open VS Code with this project
2. Press `Ctrl+Alt+C`
3. Enter any URL (e.g., https://example.com)
4. DOM will be captured and saved

## 📊 Expected Results

After running tests, you should see:

### Successful Tests
- No DOM captures generated
- Test passes normally

### Failed Tests
- DOM captures in: `test-results/dom-captures/DD-MM-YYYY/TestName/`
- Each capture includes:
  - Full DOM HTML
  - Timestamp
  - Test name
  - Failure reason

### Manual Captures
- Saved with timestamp
- Can be triggered during any test pause

## 🔍 Viewing Captures

### Using Extension Commands
1. `Ctrl+Shift+P` → `DOM Capture: View Last Capture`
2. `Ctrl+Shift+P` → `DOM Capture: Show Dashboard`
3. Check the DOM Captures tree view in Explorer sidebar

### Direct File Access
Navigate to: `test-results/dom-captures/`

## 🎯 Testing Checklist

- [ ] Extension auto-configures project
- [ ] Failed tests generate DOM captures
- [ ] Manual capture works with Ctrl+Shift+C
- [ ] URL capture works with Ctrl+Alt+C
- [ ] Dashboard shows capture statistics
- [ ] Tree view displays captures by date
- [ ] Git safety check identifies captures
- [ ] Clean command removes old captures

## 🐛 Troubleshooting

### No Captures Generated
1. Check extension is active: Look for "🧪 DOM Capture: Ready" in status bar
2. Verify auto-configuration completed
3. Check Output panel for errors

### Manual Capture Not Working
1. Ensure a test is running
2. Browser window must be active
3. Check keyboard shortcut conflicts

### View Logs
1. View → Output
2. Select "Playwright DOM Capture" from dropdown

## 📝 Notes

- Tests run with 1 worker for easier testing
- Slow mode can be enabled with `SLOW=1` environment variable
- Screenshots and videos are also captured on failure
- All test artifacts go to `test-results/` folder

## 🔗 Related

- [Playwright Documentation](https://playwright.dev)
- [VS Code Extension API](https://code.visualstudio.com/api)
- [DOM Capture Extension Repo](https://github.com/your-repo/playwright-dom-capture)