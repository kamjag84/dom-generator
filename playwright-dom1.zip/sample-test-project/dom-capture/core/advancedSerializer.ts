/**
 * Advanced DOM Serializer
 * Handles complete DOM serialization with styles and resources
 */

import type { Page } from '@playwright/test';

export class AdvancedDOMSerializer {
    async serialize(page: Page): Promise<string> {
        return await page.evaluate(() => {
            const doctype = document.doctype ? 
                '<!DOCTYPE ' + document.doctype.name + '>' : '';
            
            // Clone the document
            const html = document.documentElement.cloneNode(true) as HTMLElement;
            
            // Inline styles
            const styles = Array.from(document.styleSheets).map(sheet => {
                try {
                    return Array.from(sheet.cssRules).map(rule => rule.cssText).join('
');
                } catch (e) {
                    return '';
                }
            }).filter(Boolean).join('
');
            
            if (styles) {
                const styleElement = document.createElement('style');
                styleElement.textContent = styles;
                html.querySelector('head')?.appendChild(styleElement);
            }
            
            return doctype + html.outerHTML;
        });
    }
    
    async serializeWithMetadata(page: Page): Promise<{ html: string; metadata: any }> {
        const html = await this.serialize(page);
        const metadata = {
            url: page.url(),
            timestamp: new Date().toISOString(),
            viewport: await page.viewportSize(),
            userAgent: await page.evaluate(() => navigator.userAgent)
        };
        return { html, metadata };
    }
}
