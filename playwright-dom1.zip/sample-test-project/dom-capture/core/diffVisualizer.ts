/**
 * DOM Diff Visualizer
 * Compares two DOM captures and highlights differences
 */

export class DiffVisualizer {
    compare(dom1: string, dom2: string): string {
        // Simple diff implementation
        const lines1 = dom1.split('
');
        const lines2 = dom2.split('
');
        const diff: string[] = [];
        
        const maxLength = Math.max(lines1.length, lines2.length);
        
        for (let i = 0; i < maxLength; i++) {
            if (lines1[i] !== lines2[i]) {
                if (lines1[i]) diff.push('- ' + lines1[i]);
                if (lines2[i]) diff.push('+ ' + lines2[i]);
            } else if (lines1[i]) {
                diff.push('  ' + lines1[i]);
            }
        }
        
        return diff.join('
');
    }
    
    generateHTMLDiff(dom1: string, dom2: string): string {
        const diff = this.compare(dom1, dom2);
        return '<html><head><style>' +
            '.added { background: #90EE90; }' +
            '.removed { background: #FFB6C1; }' +
            '</style></head><body>' +
            '<pre>' + diff.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</pre>' +
            '</body></html>';
    }
}
