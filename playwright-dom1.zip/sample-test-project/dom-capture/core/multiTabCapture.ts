/**
 * Multi-Tab Capture Support
 */

import type { Browser, Page } from '@playwright/test';

export class MultiTabCapture {
    async captureAllTabs(browser: Browser): Promise<Map<string, string>> {
        const captures = new Map<string, string>();
        const contexts = browser.contexts();
        
        for (const context of contexts) {
            const pages = context.pages();
            for (const page of pages) {
                const url = page.url();
                const html = await page.content();
                captures.set(url, html);
            }
        }
        
        return captures;
    }
    
    async captureSpecificTabs(pages: Page[]): Promise<Map<string, string>> {
        const captures = new Map<string, string>();
        
        for (const page of pages) {
            const url = page.url();
            const html = await page.content();
            captures.set(url, html);
        }
        
        return captures;
    }
}
