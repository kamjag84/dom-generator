/**
 * Async DOM Serializer with chunking support
 */

import type { Page } from '@playwright/test';

export class AsyncDOMSerializer {
    private chunkSize = 1000;
    
    async serializeAsync(page: Page): Promise<string[]> {
        return await page.evaluate((chunkSize) => {
            const chunks: string[] = [];
            const elements = document.querySelectorAll('*');
            
            for (let i = 0; i < elements.length; i += chunkSize) {
                const chunk = Array.from(elements).slice(i, i + chunkSize)
                    .map(el => el.outerHTML).join('');
                chunks.push(chunk);
            }
            
            return chunks;
        }, this.chunkSize);
    }
    
    async combineChunks(chunks: string[]): Promise<string> {
        return chunks.join('');
    }
}
