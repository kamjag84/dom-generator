/**
 * Playwright Test Helper - Complete DOM Capture Manager
 * Auto-generated with full TestCaptureManager implementation
 */

import { Page, TestInfo, BrowserContext } from '@playwright/test';
import * as fs from 'fs-extra';
import * as path from 'path';

// Type definitions
export interface TestCaptureOptions {
    captureId?: string;
    stepName?: string;
    includeScreenshot?: boolean;
    customMetadata?: Record<string, any>;
    compressionLevel?: 'none' | 'low' | 'medium' | 'high';
}

export interface CaptureResult {
    path: string;
    timestamp: number;
    metadata: Record<string, any>;
    size: number;
}

export interface DOMCaptureConfig {
    outputDir?: string;
    enableAutoCapture?: boolean;
    captureOnFailure?: boolean;
    compressionLevel?: 'none' | 'low' | 'medium' | 'high';
    includeScreenshots?: boolean;
    sanitizeSensitiveData?: boolean;
}

/**
 * Singleton TestCaptureManager for consistent DOM capture across tests
 */
export class TestCaptureManager {
    private static instance: TestCaptureManager;
    private activeCaptures: Map<string, CaptureResult> = new Map();
    private outputDir: string;
    private currentTestInfo?: TestInfo;
    private captureCount: number = 0;
    private config: DOMCaptureConfig;

    private constructor() {
        this.outputDir = path.join(process.cwd(), 'test-results', 'dom-captures');
        this.config = {
            outputDir: this.outputDir,
            enableAutoCapture: true,
            captureOnFailure: true,
            compressionLevel: 'medium',
            includeScreenshots: true,
            sanitizeSensitiveData: true
        };
        this.ensureOutputDirectory();
    }

    static getInstance(): TestCaptureManager {
        if (!TestCaptureManager.instance) {
            TestCaptureManager.instance = new TestCaptureManager();
        }
        return TestCaptureManager.instance;
    }

    setCurrentTest(testInfo: TestInfo): void {
        this.currentTestInfo = testInfo;
        this.captureCount = 0;
    }

    private ensureOutputDirectory(): void {
        fs.ensureDirSync(this.outputDir);
    }

    private getTestName(): string {
        if (!this.currentTestInfo) return 'unknown-test';
        return this.currentTestInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    }

    private getOutputPath(captureId: string): string {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const testName = this.getTestName();
        const testDir = path.join(this.outputDir, timestamp, testName);
        fs.ensureDirSync(testDir);
        return path.join(testDir, `${captureId}.html`);
    }

    async enableHotkeyCapture(page: Page): Promise<void> {
        // Install hotkey listener using addInitScript (more reliable than evaluateOnNewDocument)
        await page.addInitScript(() => {
            let captureCount = 0;
            
            // Create capture function
            window.__captureDOM = async (detail: any) => {
                captureCount++;
                console.log(`📸 DOM Capture #${captureCount} triggered`, detail);
                
                // Get complete DOM with styles
                const doctype = document.doctype ? 
                    `<!DOCTYPE ${document.doctype.name}>` : '';
                
                // Clone document and inline all styles
                const clonedDoc = document.cloneNode(true) as Document;
                const allElements = clonedDoc.querySelectorAll('*');
                
                allElements.forEach((element) => {
                    const computedStyles = window.getComputedStyle(element as Element);
                    (element as HTMLElement).style.cssText = computedStyles.cssText;
                });
                
                const fullHtml = doctype + clonedDoc.documentElement.outerHTML;
                
                // Visual feedback
                const flash = document.createElement('div');
                flash.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 255, 0, 0.3);
                    z-index: 999999;
                    pointer-events: none;
                    animation: flash 0.5s ease-out;
                `;
                
                const style = document.createElement('style');
                style.textContent = `
                    @keyframes flash {
                        0% { opacity: 1; }
                        100% { opacity: 0; }
                    }
                `;
                
                document.head.appendChild(style);
                document.body.appendChild(flash);
                
                setTimeout(() => {
                    flash.remove();
                    style.remove();
                }, 500);
                
                return {
                    html: fullHtml,
                    url: window.location.href,
                    title: document.title,
                    timestamp: Date.now(),
                    captureCount: captureCount,
                    ...detail
                };
            };
            
            // Install keyboard listener
            document.addEventListener('keydown', async (event) => {
                // Ctrl+Shift+C
                if (event.ctrlKey && event.shiftKey && event.key === 'C') {
                    event.preventDefault();
                    event.stopPropagation();
                    
                    try {
                        await window.__captureDOM({
                            trigger: 'hotkey',
                            timestamp: Date.now(),
                            stepName: 'Hotkey Capture',
                            includeScreenshot: true
                        });
                    } catch (error) {
                        console.error('Failed to capture DOM:', error);
                    }
                }
            }, true);
            
            console.log('🎯 DOM Capture hotkey installed (Ctrl+Shift+C)');
        });

        // Expose the capture function to Node.js context
        await page.exposeFunction('__captureDOM', async (detail: any) => {
            return await this.performCapture(page, detail);
        });
    }

    private async performCapture(page: Page, detail: any): Promise<any> {
        this.captureCount++;
        
        try {
            // Get the DOM content that was already captured in browser
            const captureData = await page.evaluate(() => {
                const doctype = document.doctype ? 
                    `<!DOCTYPE ${document.doctype.name}>` : '';
                return {
                    html: doctype + document.documentElement.outerHTML,
                    url: window.location.href,
                    title: document.title,
                    viewport: {
                        width: window.innerWidth,
                        height: window.innerHeight
                    }
                };
            });

            // Take screenshot if requested
            let screenshot = null;
            if (detail.includeScreenshot) {
                const screenshotBuffer = await page.screenshot({ 
                    fullPage: true
                });
                screenshot = screenshotBuffer.toString('base64');
            }

            // Create enhanced HTML with metadata
            const enhancedHtml = this.createEnhancedHtml(
                captureData.html,
                {
                    ...detail,
                    ...captureData,
                    screenshot,
                    testName: this.getTestName(),
                    captureNumber: this.captureCount
                }
            );

            // Save to file
            const captureId = detail.captureId || `capture_${this.captureCount}`;
            const outputPath = this.getOutputPath(captureId);
            await fs.writeFile(outputPath, enhancedHtml, 'utf-8');

            const result: CaptureResult = {
                path: outputPath,
                timestamp: Date.now(),
                metadata: detail,
                size: Buffer.byteLength(enhancedHtml, 'utf-8')
            };

            this.activeCaptures.set(captureId, result);
            
            console.log(`✅ DOM captured: ${outputPath}`);
            return result;
            
        } catch (error) {
            console.error('Failed to perform capture:', error);
            throw error;
        }
    }

    async captureFromPage(
        page: Page, 
        options: TestCaptureOptions = {}
    ): Promise<CaptureResult> {
        const captureId = options.captureId || `manual_${Date.now()}`;
        
        // Get DOM content
        const domContent = await page.evaluate(() => {
            const doctype = document.doctype ? 
                `<!DOCTYPE ${document.doctype.name}>` : '';
            return doctype + document.documentElement.outerHTML;
        });

        // Take screenshot if requested
        let screenshot = null;
        if (options.includeScreenshot !== false) {
            const screenshotBuffer = await page.screenshot({ 
                fullPage: true
            });
            screenshot = screenshotBuffer.toString('base64');
        }

        // Create enhanced HTML
        const enhancedHtml = this.createEnhancedHtml(domContent, {
            ...options,
            screenshot,
            url: page.url(),
            timestamp: Date.now(),
            testName: this.getTestName()
        });

        // Save to file
        const outputPath = this.getOutputPath(captureId);
        await fs.writeFile(outputPath, enhancedHtml, 'utf-8');

        const result: CaptureResult = {
            path: outputPath,
            timestamp: Date.now(),
            metadata: options.customMetadata || {},
            size: Buffer.byteLength(enhancedHtml, 'utf-8')
        };

        this.activeCaptures.set(captureId, result);
        return result;
    }

    private createEnhancedHtml(
        html: string, 
        metadata: any
    ): string {
        const metaScript = `
            <script id="dom-capture-metadata">
                window.__DOM_CAPTURE_METADATA__ = ${JSON.stringify(metadata, null, 2)};
            </script>
        `;

        const screenshotSection = metadata.screenshot ? `
            <div id="dom-capture-screenshot" style="display:none;">
                <img src="data:image/png;base64,${metadata.screenshot}" />
            </div>
        ` : '';

        // Inject metadata and screenshot into HTML
        if (html.includes('</head>')) {
            html = html.replace('</head>', `${metaScript}</head>`);
        }
        
        if (html.includes('</body>')) {
            html = html.replace('</body>', `${screenshotSection}</body>`);
        }

        return html;
    }

    async captureMultipleTabs(
        context: BrowserContext,
        options: TestCaptureOptions = {}
    ): Promise<CaptureResult[]> {
        const pages = context.pages();
        const results: CaptureResult[] = [];

        for (let i = 0; i < pages.length; i++) {
            const page = pages[i];
            const tabOptions = {
                ...options,
                captureId: `${options.captureId || 'tab'}_${i}`
            };
            
            try {
                const result = await this.captureFromPage(page, tabOptions);
                results.push(result);
            } catch (error) {
                console.error(`Failed to capture tab ${i}:`, error);
            }
        }

        return results;
    }

    getActiveCaptures(): Map<string, CaptureResult> {
        return this.activeCaptures;
    }

    clearCaptures(): void {
        this.activeCaptures.clear();
    }

    getOutputDirectory(): string {
        return this.outputDir;
    }

    setOutputDirectory(dir: string): void {
        this.outputDir = dir;
        this.ensureOutputDirectory();
    }
}

// Global type declarations
declare global {
    interface Window {
        __captureDOM: (detail: any) => Promise<any>;
        __DOM_CAPTURE_METADATA__: any;
    }
}
