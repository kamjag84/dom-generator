/**
 * Capture Helper Utilities
 */

import type { Page } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

export class CaptureHelper {
    private outputDir = 'test-results/dom-captures';
    
    async captureToFile(page: Page, fileName?: string): Promise<string> {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const name = fileName || 'capture_' + timestamp + '.html';
        const html = await page.content();
        
        // Create output directory
        const fullPath = path.join(process.cwd(), this.outputDir, name);
        const dir = path.dirname(fullPath);
        
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(fullPath, html);
        return fullPath;
    }
    
    async captureWithScreenshot(page: Page): Promise<{ html: string; screenshot: Buffer }> {
        const html = await page.content();
        const screenshot = await page.screenshot();
        return { html, screenshot };
    }
}

export const captureHelper = new CaptureHelper();
