/**
 * Hotkey Helper for DOM Capture
 */

import type { Page } from '@playwright/test';

export async function installHotkeyListener(page: Page): Promise<void> {
    await page.addInitScript(() => {
        let captureCount = 0;
        
        document.addEventListener('keydown', async (event) => {
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const modifier = isMac ? event.metaKey : event.ctrlKey;
            
            // Ctrl/Cmd + Shift + C
            if (modifier && event.shiftKey && event.key === 'C') {
                event.preventDefault();
                captureCount++;
                
                // Trigger capture event
                window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                    detail: { 
                        trigger: 'hotkey',
                        timestamp: Date.now(),
                        count: captureCount
                    }
                }));
                
                // Visual feedback
                const flash = document.createElement('div');
                flash.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; ' +
                    'background: rgba(0, 255, 0, 0.3); z-index: 999999; pointer-events: none; ' +
                    'animation: flash 0.3s ease-out;';
                
                const style = document.createElement('style');
                style.textContent = '@keyframes flash { 0% { opacity: 1; } 100% { opacity: 0; } }';
                
                document.head.appendChild(style);
                document.body.appendChild(flash);
                
                setTimeout(() => {
                    flash.remove();
                    style.remove();
                }, 300);
                
                console.log('📸 DOM Capture #' + captureCount + ' triggered via hotkey');
            }
        });
        
        console.log('🔥 DOM Capture hotkey listener installed (Ctrl/Cmd+Shift+C)');
    });
}

export function createHotkeyHandler(callback: (event: any) => void) {
    return async (page: Page) => {
        await page.evaluateHandle((cb) => {
            window.addEventListener('dom-capture-requested', cb);
        }, callback);
    };
}
