/**
 * Playwright DOM Capture Integration
 * Auto-generated stub that uses TestCaptureManager for consistency
 */

import { test as base, expect } from '@playwright/test';
import { TestCaptureManager } from './playwrightTestHelper';
import type { Page, TestInfo } from '@playwright/test';
import type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

/**
 * Global type declaration for DOM capture function
 * This extends the Window interface to include our injected capture function
 */
declare global {
    interface Window {
        __captureDom?: (captureId: string) => void;
        __captureState?: () => any;
    }
}

// Type definitions for custom fixtures
type CustomFixtures = {
    autoCapture: void;
    captureManager: TestCaptureManager;
    domCapture: (options?: TestCaptureOptions) => Promise<string>;
    enableHotkeyCapture: () => Promise<void>;
};

// Enhanced test fixture with DOM capture using TestCaptureManager
export const test = base.extend<CustomFixtures>({
    autoCapture: [async ({ page }, use, testInfo) => {
        console.log('🔧 Setting up DOM Capture for test:', testInfo.title);
        
        // Use TestCaptureManager for all capture operations
        const captureManager = TestCaptureManager.getInstance();
        captureManager.setCurrentTest(testInfo);
        
        // Enable hotkey capture (Ctrl+Shift+C)
        await captureManager.enableHotkeyCapture(page);
        
        // Run the test
        await use();
        
        // Capture on failure - matching main implementation exactly
        if (testInfo.status === 'failed') {
            console.log('❌ Test failed, capturing DOM...');
            try {
                const result = await captureManager.captureFromPage(page, {
                    captureId: `failure_${Date.now()}`,
                    customMetadata: {
                        status: 'failed',
                        error: testInfo.error?.message || 'Unknown error'
                    }
                });
                
                // Attach to test report
                testInfo.attachments.push({
                    name: 'dom-capture-on-failure',
                    contentType: 'text/html',
                    path: result.path
                });
                
                console.log(`📸 Failure DOM captured: ${result.path}`);
            } catch (error) {
                console.error('Failed to capture DOM on test failure:', error);
            }
        }
    }, { auto: true }],
    
    captureManager: async ({}, use) => {
        const manager = TestCaptureManager.getInstance();
        await use(manager);
    },
    
    domCapture: async ({ page, captureManager }, use, testInfo) => {
        captureManager.setCurrentTest(testInfo);
        
        const captureFunction = async (options?: TestCaptureOptions) => {
            const result = await captureManager.captureFromPage(page, options || {});
            return result.path;
        };
        
        await use(captureFunction);
    },
    
    enableHotkeyCapture: async ({ page, captureManager }, use, testInfo) => {
        captureManager.setCurrentTest(testInfo);
        
        const enableFunction = async () => {
            await captureManager.enableHotkeyCapture(page);
            console.log('🎯 Hotkey capture enabled! Press Ctrl+Shift+C to capture DOM');
        };
        
        await use(enableFunction);
    }
});

// Setup DOM capture using TestCaptureManager
export async function setupDOMCapture(page: Page, testInfo?: TestInfo): Promise<void> {
    const captureManager = TestCaptureManager.getInstance();
    if (testInfo) {
        captureManager.setCurrentTest(testInfo);
    }
    await captureManager.enableHotkeyCapture(page);
    console.log('✅ DOM Capture setup complete');
}

/**
 * Helper function to capture DOM at any point in the test
 * This provides a type-safe way to trigger manual DOM captures
 * 
 * @param page - The Playwright page object
 * @param captureId - Optional identifier for the capture (defaults to timestamp-based ID)
 * @returns Promise that resolves when capture is complete
 * 
 * @example
 * // Basic usage
 * await captureDOM(page);
 * 
 * // With custom ID
 * await captureDOM(page, 'after-login');
 */
export async function captureDOM(page: Page, captureId?: string): Promise<void> {
    const id = captureId || `manual-capture-${Date.now()}`;
    
    await page.evaluate((captureId) => {
        // The type is now properly declared globally
        if (window.__captureDom) {
            window.__captureDom(captureId);
        } else {
            console.warn('DOM capture not available. Ensure the page has been set up with enableHotkeyCapture()');
        }
    }, id);
}

// Re-export TestCaptureManager and types for direct access
export { TestCaptureManager } from './playwrightTestHelper';
export type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

export { expect };

// TypeScript declarations already handled by TestCaptureManager
