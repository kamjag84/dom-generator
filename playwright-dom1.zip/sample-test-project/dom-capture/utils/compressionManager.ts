/**
 * Compression Manager for DOM Captures
 */

export class CompressionManager {
    compress(html: string, level: 'none' | 'low' | 'medium' | 'high' = 'medium'): string {
        if (level === 'none') return html;
        
        let compressed = html;
        
        // Low: Remove extra whitespace
        if (level >= 'low') {
            compressed = compressed.replace(/s+/g, ' ').trim();
        }
        
        // Medium: Remove comments
        if (level >= 'medium') {
            compressed = compressed.replace(/<!--[^>]*-->/g, '');
            compressed = compressed.replace(//*[^*]**+(?:[^/*][^*]**+)*//g, '');
        }
        
        // High: Minify attributes
        if (level === 'high') {
            compressed = compressed.replace(/="([^"]*)"/g, (match, value) => {
                return '="' + value.trim() + '"';
            });
        }
        
        return compressed;
    }
    
    decompress(compressed: string): string {
        // Add formatting back
        return compressed
            .replace(/></g, '>
<')
            .replace(/([^>])s*<//g, '$1
</');
    }
}
