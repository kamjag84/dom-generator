/**
 * Metadata Collector for DOM Captures
 */

import type { Page } from '@playwright/test';

export class MetadataCollector {
    async collectMetadata(page: Page): Promise<any> {
        const browserMetadata = await page.evaluate(() => {
            return {
                userAgent: navigator.userAgent,
                platform: navigator.platform,
                language: navigator.language,
                screenResolution: {
                    width: window.screen.width,
                    height: window.screen.height
                },
                windowSize: {
                    width: window.innerWidth,
                    height: window.innerHeight
                },
                pixelRatio: window.devicePixelRatio
            };
        });
        
        return {
            url: page.url(),
            title: await page.title(),
            timestamp: new Date().toISOString(),
            viewport: await page.viewportSize(),
            ...browserMetadata,
            testInfo: this.getTestInfo()
        };
    }
    
    private getTestInfo(): any {
        // Get test information if available
        const testInfo: any = {};
        
        if (typeof process !== 'undefined' && process.env) {
            testInfo.testFile = process.env.TEST_FILE;
            testInfo.testName = process.env.TEST_NAME;
            testInfo.testId = process.env.TEST_ID;
        }
        
        return testInfo;
    }
    
    formatMetadata(metadata: any): string {
        return JSON.stringify(metadata, null, 2);
    }
}
