/**
 * Resource Inliner for DOM Captures
 */

import type { Page } from '@playwright/test';

export class ResourceInliner {
    async inlineResources(page: Page): Promise<string> {
        return await page.evaluate(async () => {
            const inlineImages = async () => {
                const images = document.querySelectorAll('img');
                for (const img of Array.from(images)) {
                    if (img.src && !img.src.startsWith('data:')) {
                        try {
                            const response = await fetch(img.src);
                            const blob = await response.blob();
                            const reader = new FileReader();
                            const dataUrl = await new Promise<string>((resolve) => {
                                reader.onloadend = () => resolve(reader.result as string);
                                reader.readAsDataURL(blob);
                            });
                            img.src = dataUrl;
                        } catch (e) {
                            console.warn('Failed to inline image:', img.src);
                        }
                    }
                }
            };
            
            const inlineStyles = () => {
                const links = document.querySelectorAll('link[rel="stylesheet"]');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href) {
                        // Try to find matching stylesheet
                        const sheet = Array.from(document.styleSheets).find(
                            s => s.href === link.href
                        );
                        if (sheet) {
                            try {
                                const rules = Array.from(sheet.cssRules)
                                    .map(rule => rule.cssText)
                                    .join('
');
                                const style = document.createElement('style');
                                style.textContent = rules;
                                link.parentNode?.replaceChild(style, link);
                            } catch (e) {
                                console.warn('Failed to inline stylesheet:', href);
                            }
                        }
                    }
                });
            };
            
            await inlineImages();
            inlineStyles();
            
            return document.documentElement.outerHTML;
        });
    }
}
