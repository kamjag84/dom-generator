/**
 * Security Manager for DOM Captures
 */

export class SecurityManager {
    sanitizeHTML(html: string): string {
        // Remove sensitive data patterns
        let sanitized = html;
        
        // Remove potential passwords
        sanitized = sanitized.replace(/type="password"[^>]*value="[^"]*"/g, 'type="password"');
        
        // Remove auth tokens from URLs
        sanitized = sanitized.replace(/[?&](token|auth|key|secret|password)=[^&"']*/gi, '');
        
        // Remove common API keys patterns
        sanitized = sanitized.replace(/['"]?api[_-]?key['"]?s*[:=]s*['"][^'"]{20,}['"]/gi, '"api_key":"[REDACTED]"');
        
        // Remove bearer tokens
        sanitized = sanitized.replace(/Bearers+[A-Za-z0-9-._~+/]+=*/g, 'Bearer [REDACTED]');
        
        return sanitized;
    }
    
    redactSensitiveData(data: any): any {
        const sensitiveKeys = ['password', 'token', 'secret', 'key', 'auth', 'credential'];
        
        if (typeof data === 'string') {
            return this.sanitizeHTML(data);
        }
        
        if (typeof data === 'object' && data !== null) {
            const redacted: any = Array.isArray(data) ? [] : {};
            
            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    const lowerKey = key.toLowerCase();
                    if (sensitiveKeys.some(sensitive => lowerKey.includes(sensitive))) {
                        redacted[key] = '[REDACTED]';
                    } else {
                        redacted[key] = this.redactSensitiveData(data[key]);
                    }
                }
            }
            
            return redacted;
        }
        
        return data;
    }
}
