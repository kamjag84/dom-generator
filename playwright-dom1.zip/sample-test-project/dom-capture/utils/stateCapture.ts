/**
 * State Capture Utility
 */

import type { Page } from '@playwright/test';

export class StateCapture {
    async captureState(page: Page): Promise<any> {
        return await page.evaluate(() => {
            return {
                localStorage: { ...localStorage },
                sessionStorage: { ...sessionStorage },
                cookies: document.cookie,
                scrollPosition: {
                    x: window.scrollX,
                    y: window.scrollY
                },
                formData: this.captureFormData()
            };
        });
    }
    
    private captureFormData(): any {
        const forms = document.querySelectorAll('form');
        const formData: any = {};
        
        forms.forEach((form, index) => {
            const data: any = {};
            const inputs = form.querySelectorAll('input, select, textarea');
            
            inputs.forEach((input: any) => {
                if (input.name) {
                    data[input.name] = input.value;
                }
            });
            
            formData['form_' + index] = data;
        });
        
        return formData;
    }
    
    async restoreState(page: Page, state: any): Promise<void> {
        await page.evaluate((state) => {
            // Restore localStorage
            Object.entries(state.localStorage || {}).forEach(([key, value]) => {
                localStorage.setItem(key, value as string);
            });
            
            // Restore scroll position
            if (state.scrollPosition) {
                window.scrollTo(state.scrollPosition.x, state.scrollPosition.y);
            }
        }, state);
    }
}
