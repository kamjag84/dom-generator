import { test, expect } from '@playwright/test';

test.describe('Basic DOM Capture Tests', () => {
  test('✅ Successful test - should pass without capture', async ({ page }) => {
    await page.goto('https://example.com');
    
    
    // DOM Capture Point
    await captureDOM(page, 'manual-capture-1756700030407');
    // Verify page title
    await expect(page).toHaveTitle(/Example Domain/);
    
    // Verify main heading
    const heading = page.locator('h1');
    await expect(heading).toHaveText('Example Domain');
    
    // Verify paragraph exists
    const paragraph = page.locator('p').first();
    await expect(paragraph).toContainText('This domain is for use in illustrative examples');
    
    console.log('✅ Test passed successfully - no DOM capture needed');
  });

  

   
  test('❌ Failing test - should trigger automatic DOM capture', async ({ page }) => {
    await page.goto('https://example.com');
  
    // This selector doesn't exist - will fail and trigger DOM capture
    const nonExistentButton = page.locator('button#submit-form');
    await expect(nonExistentButton).toBeVisible({ timeout: 5000 });
    
    // This line won't be reached due to failure above
    console.log('This should not print');
  });

  test('⏸️ Test with manual capture opportunity', async ({ page }) => {
    await page.goto('https://example.com');
    
    console.log('🎯 Now is a good time to test manual capture with Ctrl+Shift+C');
    
    // Wait 3 seconds to allow manual capture
    await page.waitForTimeout(3000);
    
    // Continue with test
    await expect(page.locator('h1')).toBeVisible();
    
    console.log('📸 Another opportunity for manual capture');
    await page.waitForTimeout(3000);
    
    // Final assertion
    await expect(page).toHaveTitle(/Example Domain/);
  });

  test('🔄 Test with navigation - multiple pages', async ({ page }) => {
    // First page
    await page.goto('https://example.com');
    await expect(page).toHaveTitle(/Example Domain/);
    
    // Navigate to another page
    await page.goto('https://www.wikipedia.org');
    await expect(page).toHaveTitle(/Wikipedia/);
    
    // Go back
    await page.goBack();
    await expect(page).toHaveTitle(/Example Domain/);
    
    // Go forward
    await page.goForward();
    await expect(page).toHaveTitle(/Wikipedia/);
  });

  test.skip('⏭️ Skipped test - should not run or capture', async ({ page }) => {
    await page.goto('https://example.com');
    await expect(page.locator('.will-not-run')).toBeVisible();
  });
});

test.describe('Error Scenarios', () => {
  test('🔴 Network error simulation', async ({ page }) => {
    // This will fail with network error
    await page.goto('https://this-domain-definitely-does-not-exist-12345.com');
  });

  test('⏱️ Timeout test - will fail after timeout', async ({ page }) => {
    await page.goto('https://example.com');
    
    // This will timeout and fail
    await page.locator('.non-existent-element').click({ timeout: 3000 });
  });

  test('🎭 Multiple assertions - first failure triggers capture', async ({ page }) => {
    await page.goto('https://example.com');
    
    // First assertion passes
    await expect(page).toHaveTitle(/Example Domain/);
    
    // Second assertion fails - triggers DOM capture
    await expect(page.locator('#non-existent')).toBeVisible();
    
    // Third assertion won't run
    await expect(page.locator('h1')).toHaveText('Wrong Text');
  });
});

function captureDOM(page: any, arg1: string) {
  throw new Error('Function not implemented.');
}
