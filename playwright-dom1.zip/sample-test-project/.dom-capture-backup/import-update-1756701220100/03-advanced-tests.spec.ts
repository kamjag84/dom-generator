import { test, expect, Page } from '@playwright/test';

test.describe('Advanced DOM Capture Scenarios', () => {
  test('🌐 Multi-tab test scenario', async ({ browser }) => {
    const context = await browser.newContext();
    
    // Open first tab
    const page1 = await context.newPage();
    await page1.goto('https://example.com');
    await expect(page1).toHaveTitle(/Example Domain/);
    
    // Open second tab
    const page2 = await context.newPage();
    await page2.goto('https://www.wikipedia.org');
    await expect(page2).toHaveTitle(/Wikipedia/);
    
    // Open third tab
    const page3 = await context.newPage();
    await page3.goto('https://www.w3.org/');
    
    console.log('🌐 Three tabs open - test manual capture for specific tab');
    await page1.waitForTimeout(3000);
    
    // Switch between tabs
    await page1.bringToFront();
    await page1.waitForTimeout(1000);
    
    await page2.bringToFront();
    await page2.waitForTimeout(1000);
    
    await page3.bringToFront();
    await page3.waitForTimeout(1000);
    
    // Close context
    await context.close();
  });

  test('🖼️ IFrame handling test', async ({ page }) => {
    await page.goto('https://www.w3schools.com/html/html_iframe.asp');
    
    // Wait for page with iframes
    await page.waitForLoadState('networkidle');
    
    // Find iframe elements
    const iframes = page.locator('iframe');
    const count = await iframes.count();
    
    console.log(`🖼️ Found ${count} iframes - DOM capture should include iframe content`);
    
    // Try to interact with iframe content
    if (count > 0) {
      const firstIframe = page.frameLocator('iframe').first();
      
      // This might fail if iframe is cross-origin
      try {
        const iframeBody = firstIframe.locator('body');
        await expect(iframeBody).toBeVisible();
      } catch (e) {
        console.log('Cross-origin iframe detected');
      }
    }
    
    await page.waitForTimeout(2000);
  });

  test('🎭 Shadow DOM test', async ({ page }) => {
    // Create a page with shadow DOM
    await page.goto('data:text/html,<div id="host"></div>');
    
    // Inject shadow DOM
    await page.evaluate(() => {
      const host = document.getElementById('host');
      const shadow = host!.attachShadow({ mode: 'open' });
      shadow.innerHTML = `
        <style>
          .shadow-content {
            padding: 20px;
            background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
          }
        </style>
        <div class="shadow-content">
          <h2>Shadow DOM Content</h2>
          <p>This content is inside a shadow root</p>
          <button id="shadow-button">Click me</button>
        </div>
      `;
    });
    
    console.log('🎭 Shadow DOM created - capture should preserve shadow content');
    await page.waitForTimeout(3000);
    
    // Verify shadow DOM exists
    const shadowHost = page.locator('#host');
    await expect(shadowHost).toBeVisible();
  });

  test('📊 Canvas and SVG capture', async ({ page }) => {
    await page.goto('data:text/html,<canvas id="canvas" width="400" height="400"></canvas><svg width="200" height="200"><circle cx="100" cy="100" r="50" fill="blue"/></svg>');
    
    // Draw on canvas
    await page.evaluate(() => {
      const canvas = document.getElementById('canvas') as HTMLCanvasElement;
      const ctx = canvas.getContext('2d')!;
      
      // Draw gradient
      const gradient = ctx.createLinearGradient(0, 0, 400, 400);
      gradient.addColorStop(0, '#FF6B6B');
      gradient.addColorStop(1, '#4ECDC4');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 400, 400);
      
      // Draw text
      ctx.font = '30px Arial';
      ctx.fillStyle = 'white';
      ctx.textAlign = 'center';
      ctx.fillText('Canvas Content', 200, 200);
    });
    
    console.log('📊 Canvas and SVG rendered - capture should include visual elements');
    await page.waitForTimeout(3000);
    
    // Verify elements exist
    await expect(page.locator('#canvas')).toBeVisible();
    await expect(page.locator('svg')).toBeVisible();
  });

  test('🔐 LocalStorage and SessionStorage test', async ({ page }) => {
    await page.goto('https://example.com');
    
    // Set storage values
    await page.evaluate(() => {
      localStorage.setItem('test-key', 'test-value');
      localStorage.setItem('user-preference', JSON.stringify({ theme: 'dark', language: 'en' }));
      sessionStorage.setItem('session-id', '12345');
      sessionStorage.setItem('temp-data', 'temporary');
    });
    
    console.log('🔐 Storage values set - DOM capture might include storage state');
    
    // Verify storage
    const localStorageValue = await page.evaluate(() => localStorage.getItem('test-key'));
    expect(localStorageValue).toBe('test-value');
    
    await page.waitForTimeout(2000);
  });

  test('❌ Intentional failure with complex page', async ({ page }) => {
    await page.goto('https://github.com/');
    
    // Wait for complex page to load
    await page.waitForLoadState('networkidle');
    
    // Scroll to load more content
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight / 2));
    await page.waitForTimeout(1000);
    
    // This will fail and trigger DOM capture of complex page
    const nonExistentModal = page.locator('.modal-dialog-special-offer');
    await expect(nonExistentModal).toBeVisible({ timeout: 3000 });
  });
});

test.describe('Performance and Load Tests', () => {
  test('⚡ Heavy page load test', async ({ page }) => {
    // Set slower network to test capture during loading
    await page.route('**/*', route => {
      setTimeout(() => route.continue(), 100);
    });
    
    await page.goto('https://www.youtube.com');
    
    console.log('⚡ Loading heavy page - test capture during load');
    await page.waitForTimeout(2000);
    
    // Wait for initial content
    await page.waitForSelector('#content', { timeout: 10000 });
    
    // Page should load eventually
    await expect(page.locator('#content')).toBeVisible();
  });

  test('🔄 Infinite scroll simulation', async ({ page }) => {
    await page.goto('https://example.com');
    
    // Simulate infinite scroll by adding content dynamically
    await page.evaluate(() => {
      let counter = 0;
      const container = document.body;
      
      const addContent = () => {
        for (let i = 0; i < 10; i++) {
          const div = document.createElement('div');
          div.style.height = '100px';
          div.style.margin = '10px';
          div.style.background = `hsl(${counter * 10}, 70%, 70%)`;
          div.textContent = `Item ${counter++}`;
          container.appendChild(div);
        }
      };
      
      // Add initial content
      addContent();
      
      // Simulate infinite scroll
      let scrollCount = 0;
      window.addEventListener('scroll', () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 100) {
          if (scrollCount++ < 5) {
            addContent();
          }
        }
      });
    });
    
    // Scroll to trigger content loading
    for (let i = 0; i < 3; i++) {
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await page.waitForTimeout(500);
    }
    
    console.log('🔄 Dynamic content loaded - capture includes generated elements');
    await page.waitForTimeout(2000);
  });
});