import { test, expect } from '@playwright/test';

test.describe('Example Test Suite', () => {
  test('successful test - homepage title', async ({ page }) => {
    await page.goto('https://example.com');
    await expect(page).toHaveTitle(/Example Domain/);
    
    // This test should pass
    const heading = page.locator('h1');
    await expect(heading).toHaveText('Example Domain');
  });

  test('test with manual DOM capture trigger', async ({ page }) => {
    await page.goto('https://example.com');
    
    // Wait a moment to allow manual capture with Ctrl+Shift+C
    await page.waitForTimeout(2000);
    
    // Perform some actions
    const heading = page.locator('h1');
    await expect(heading).toBeVisible();
    
    // Another pause for manual capture
    await page.waitForTimeout(2000);
  });

  test('failing test - trigger auto capture', async ({ page }) => {
    await page.goto('https://example.com');
    
    // This will fail and should trigger automatic DOM capture
    await expect(page.locator('button.non-existent')).toBeVisible();
  });

  test('test with multiple pages', async ({ page, context }) => {
    // Open first page
    await page.goto('https://example.com');
    
    // Open second page in new tab
    const page2 = await context.newPage();
    await page2.goto('https://www.iana.org/domains/example');
    
    // Switch between pages - good for testing multi-tab capture
    await page.bringToFront();
    await expect(page).toHaveTitle(/Example Domain/);
    
    await page2.bringToFront();
    await expect(page2).toHaveTitle(/IANA/);
  });

  test('test with form interaction', async ({ page }) => {
    await page.goto('https://www.w3schools.com/html/html_forms.asp');
    
    // Try to interact with form elements
    // Good test for capturing form states
    const firstNameInput = page.locator('input[name="fname"]').first();
    if (await firstNameInput.isVisible()) {
      await firstNameInput.fill('Test User');
    }
    
    // Capture should include form field values
    await page.waitForTimeout(2000);
  });
});

test.describe('Shadow DOM Tests', () => {
  test('capture shadow DOM elements', async ({ page }) => {
    // Navigate to a page with shadow DOM
    await page.goto('https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_shadow_DOM');
    
    // Wait for content to load
    await page.waitForLoadState('networkidle');
    
    // This is a good test for shadow DOM capture
    await expect(page.locator('h1')).toBeVisible();
  });
});

test.describe('Debug Helper Tests', () => {
  test('slow test for manual capture testing', async ({ page }) => {
    console.log('Test started - you can now test Ctrl+Shift+C for manual capture');
    
    await page.goto('https://example.com');
    console.log('Page loaded - waiting 5 seconds');
    await page.waitForTimeout(5000);
    
    console.log('Navigating to second page');
    await page.goto('https://www.wikipedia.org');
    console.log('Wikipedia loaded - waiting 5 seconds');
    await page.waitForTimeout(5000);
    
    console.log('Test completing');
  });

  test.skip('skipped test - should not run', async ({ page }) => {
    // This test is skipped and shouldn't trigger any captures
    await page.goto('https://example.com');
  });
});