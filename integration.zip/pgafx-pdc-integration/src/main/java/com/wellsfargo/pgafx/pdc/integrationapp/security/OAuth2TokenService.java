package com.wellsfargo.pgafx.pdc.integrationapp.security;

import com.wellsfargo.pgafx.pdc.integrationapp.config.PdcIntegrationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Manages OAuth2 client_credentials token lifecycle for Pega PDC API.
 *
 * Features:
 * - Token caching with expiry-aware refresh
 * - Thread-safe with ReadWriteLock
 * - Automatic refresh before expiry (60-second buffer)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OAuth2TokenService {

    private final RestTemplate restTemplate;
    private final PdcIntegrationProperties properties;

    private String cachedToken;
    private Instant tokenExpiry = Instant.EPOCH;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    private static final int EXPIRY_BUFFER_SECONDS = 60;

    /**
     * Returns a valid OAuth2 access token, refreshing if needed.
     */
    public String getAccessToken() {
        // Try read lock first (fast path)
        lock.readLock().lock();
        try {
            if (isTokenValid()) {
                return cachedToken;
            }
        } finally {
            lock.readLock().unlock();
        }

        // Upgrade to write lock for refresh
        lock.writeLock().lock();
        try {
            // Double-check after acquiring write lock
            if (isTokenValid()) {
                return cachedToken;
            }
            refreshToken();
            return cachedToken;
        } finally {
            lock.writeLock().unlock();
        }
    }

    /**
     * Force a token refresh (e.g., after a 401 response).
     */
    public void invalidateToken() {
        lock.writeLock().lock();
        try {
            cachedToken = null;
            tokenExpiry = Instant.EPOCH;
            log.info("OAuth2 token invalidated");
        } finally {
            lock.writeLock().unlock();
        }
    }

    private boolean isTokenValid() {
        return cachedToken != null && Instant.now().isBefore(tokenExpiry.minusSeconds(EXPIRY_BUFFER_SECONDS));
    }

    @SuppressWarnings("unchecked")
    private void refreshToken() {
        var oauthConfig = properties.getCredentials().getPegaOAuthClient();
        String tokenUrl = oauthConfig.getTokenUrl();

        log.info("Refreshing OAuth2 token from: {}", tokenUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(oauthConfig.getClientId(), oauthConfig.getClientSecret());

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", oauthConfig.getAuthorizationGrantType());

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(
                    tokenUrl,
                    HttpMethod.POST,
                    request,
                    Map.class
            );

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> tokenResponse = response.getBody();
                cachedToken = (String) tokenResponse.get("access_token");
                int expiresIn = tokenResponse.containsKey("expires_in")
                        ? ((Number) tokenResponse.get("expires_in")).intValue()
                        : 3600;
                tokenExpiry = Instant.now().plusSeconds(expiresIn);

                log.info("OAuth2 token refreshed successfully. Expires in {} seconds", expiresIn);
            } else {
                throw new RuntimeException("Token response was not successful: " + response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Failed to refresh OAuth2 token from {}: {}", tokenUrl, e.getMessage());
            throw new RuntimeException("OAuth2 token refresh failed", e);
        }
    }
}
