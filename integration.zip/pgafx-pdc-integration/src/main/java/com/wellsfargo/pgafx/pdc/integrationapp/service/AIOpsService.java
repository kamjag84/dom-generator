package com.wellsfargo.pgafx.pdc.integrationapp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wellsfargo.pgafx.pdc.integrationapp.config.PdcIntegrationProperties;
import com.wellsfargo.pgafx.pdc.integrationapp.exception.AIOpsApiException;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlertRequest;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlertResponse;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;

/**
 * Service responsible for sending alerts to BigPanda AIOps REST API.
 *
 * Features:
 * - Non-blocking WebClient calls
 * - Retry with exponential backoff (3 attempts)
 * - Blocking wrapper for use in scheduled tasks
 * - Metrics tracking for sent/failed alerts
 */
@Slf4j
@Service
public class AIOpsService {

    private final WebClient aiopsWebClient;
    private final PdcIntegrationProperties properties;
    private final ObjectMapper objectMapper;

    private final Counter alertsSentCounter;
    private final Counter alertsFailedCounter;

    public AIOpsService(WebClient aiopsWebClient,
                        PdcIntegrationProperties properties,
                        ObjectMapper objectMapper,
                        MeterRegistry meterRegistry) {
        this.aiopsWebClient = aiopsWebClient;
        this.properties = properties;
        this.objectMapper = objectMapper;

        this.alertsSentCounter = Counter.builder("aiops.alerts.sent")
                .description("Total alerts successfully sent to BigPanda")
                .register(meterRegistry);
        this.alertsFailedCounter = Counter.builder("aiops.alerts.failed")
                .description("Total alerts failed to send to BigPanda")
                .register(meterRegistry);
    }

    /**
     * Sends alerts to BigPanda AIOps API (blocking).
     * Used by the scheduled polling task.
     */
    public AIOpsAlertResponse sendToAIOpsApiBlocking(AIOpsAlertRequest request) {
        if (request == null || request.getAlertCount() == 0) {
            log.debug("No alerts to send, skipping AIOps API call");
            return null;
        }

        log.info("Sending {} alerts to AIOps API (blocking)", request.getAlertCount());
        logPayload(request);

        try {
            AIOpsAlertResponse response = sendToAIOpsApi(request).block(Duration.ofSeconds(30));
            if (response != null) {
                alertsSentCounter.increment(request.getAlertCount());
                log.info("AIOps API response: Submitted={}, batch_id={}, msg_id={}",
                        response.getSubmitted(), response.getApBatchId(), response.getMsgId());
            }
            return response;
        } catch (Exception e) {
            alertsFailedCounter.increment(request.getAlertCount());
            log.error("Failed to send alerts to AIOps API: {}", e.getMessage());
            throw new AIOpsApiException("Failed to send alerts to BigPanda", e);
        }
    }

    /**
     * Sends alerts to BigPanda AIOps API (reactive/non-blocking).
     */
    public Mono<AIOpsAlertResponse> sendToAIOpsApi(AIOpsAlertRequest request) {
        return aiopsWebClient.post()
                .bodyValue(request)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .flatMap(body -> {
                                    log.error("AIOps API 4xx error: status={}, body={}", response.statusCode(), body);
                                    return Mono.error(new AIOpsApiException(
                                            "AIOps API client error: " + body,
                                            response.statusCode().value()));
                                }))
                .onStatus(status -> status.is5xxServerError(),
                        response -> response.bodyToMono(String.class)
                                .flatMap(body -> {
                                    log.error("AIOps API 5xx error: status={}, body={}", response.statusCode(), body);
                                    return Mono.error(new AIOpsApiException(
                                            "AIOps API server error: " + body,
                                            response.statusCode().value()));
                                }))
                .bodyToMono(AIOpsAlertResponse.class)
                .retryWhen(Retry.backoff(3, Duration.ofSeconds(2))
                        .maxBackoff(Duration.ofSeconds(10))
                        .filter(this::isRetryable)
                        .doBeforeRetry(signal ->
                                log.warn("Retrying AIOps API call, attempt {}: {}",
                                        signal.totalRetries() + 1, signal.failure().getMessage()))
                )
                .doOnSuccess(response ->
                        log.debug("AIOps API call successful"))
                .doOnError(error ->
                        log.error("AIOps API call failed after retries: {}", error.getMessage()));
    }

    private boolean isRetryable(Throwable throwable) {
        if (throwable instanceof AIOpsApiException ex) {
            // Retry on 5xx errors, not on 4xx
            return ex.getStatusCode() >= 500 || ex.getStatusCode() == -1;
        }
        if (throwable instanceof WebClientResponseException ex) {
            return ex.getStatusCode().is5xxServerError();
        }
        // Retry on connection errors
        return true;
    }

    private void logPayload(AIOpsAlertRequest request) {
        try {
            String payload = objectMapper.writeValueAsString(request);
            log.info("AIOps API payload: {}", payload);
        } catch (JsonProcessingException e) {
            log.warn("Could not serialize AIOps payload for logging", e);
        }
    }
}
