package com.wellsfargo.pgafx.pdc.integrationapp.service;

import com.wellsfargo.pgafx.pdc.integrationapp.config.PdcIntegrationProperties;
import com.wellsfargo.pgafx.pdc.integrationapp.exception.PdcApiException;
import com.wellsfargo.pgafx.pdc.integrationapp.mapper.ResultsMapper;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlertRequest;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlertResponse;
import com.wellsfargo.pgafx.pdc.integrationapp.model.pdc.PdcNotificationResponse;
import com.wellsfargo.pgafx.pdc.integrationapp.security.OAuth2TokenService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Core polling service that:
 * 1. Iterates over enabled PDC endpoints on a configurable schedule
 * 2. Calls Pega PDC Notification REST API with OAuth2 bearer token
 * 3. Maps PDC response to BigPanda AIOps alert format
 * 4. Sends alerts to BigPanda via AIOpsService
 *
 * Schedule: Configurable via pdcintegration.polling.fixed-delay-ms (default: 60000ms = 1 min)
 */
@Slf4j
@Service
public class PdcPollingService {

    private final PdcIntegrationProperties properties;
    private final RestTemplate restTemplate;
    private final OAuth2TokenService oAuth2TokenService;
    private final ResultsMapper resultsMapper;
    private final AIOpsService aiopsService;

    private final Counter pdcPollSuccessCounter;
    private final Counter pdcPollFailureCounter;
    private final Timer pdcPollTimer;

    public PdcPollingService(PdcIntegrationProperties properties,
                             RestTemplate restTemplate,
                             OAuth2TokenService oAuth2TokenService,
                             ResultsMapper resultsMapper,
                             AIOpsService aiopsService,
                             MeterRegistry meterRegistry) {
        this.properties = properties;
        this.restTemplate = restTemplate;
        this.oAuth2TokenService = oAuth2TokenService;
        this.resultsMapper = resultsMapper;
        this.aiopsService = aiopsService;

        this.pdcPollSuccessCounter = Counter.builder("pdc.poll.success")
                .description("Successful PDC polling calls")
                .register(meterRegistry);
        this.pdcPollFailureCounter = Counter.builder("pdc.poll.failure")
                .description("Failed PDC polling calls")
                .register(meterRegistry);
        this.pdcPollTimer = Timer.builder("pdc.poll.duration")
                .description("Duration of PDC polling cycle")
                .register(meterRegistry);
    }

    /**
     * Scheduled task: polls all enabled PDC endpoints.
     *
     * Uses fixedDelayString with SpEL to read from properties,
     * defaulting to 60000ms (1 minute).
     * initialDelay gives time for app startup + token acquisition.
     */
    @Scheduled(
            fixedDelayString = "${pdcintegration.polling.fixed-delay-ms:60000}",
            initialDelayString = "${pdcintegration.polling.initial-delay-ms:10000}"
    )
    public void scheduledPoll() {
        Timer.Sample sample = Timer.start();

        List<PdcIntegrationProperties.PdcEndpoint> enabledEndpoints = properties.getEndpoints().stream()
                .filter(PdcIntegrationProperties.PdcEndpoint::isEnabled)
                .toList();

        int totalEndpoints = enabledEndpoints.size();
        log.info("Processing {} enabled endpoints", totalEndpoints);

        AtomicInteger processedCount = new AtomicInteger(0);

        for (PdcIntegrationProperties.PdcEndpoint endpoint : enabledEndpoints) {
            try {
                processEndpoint(endpoint);
                processedCount.incrementAndGet();
            } catch (Exception e) {
                log.error("Error processing endpoint {}: {}", endpoint.getName(), e.getMessage(), e);
            }
        }

        sample.stop(pdcPollTimer);
        log.info("Polling cycle complete. Processed {}/{} endpoints", processedCount.get(), totalEndpoints);
    }

    /**
     * Processes a single PDC endpoint:
     * 1. Call PDC API
     * 2. Map results
     * 3. Send to BigPanda
     */
    private void processEndpoint(PdcIntegrationProperties.PdcEndpoint endpoint) {
        log.info("Processing endpoint: {}", endpoint.getName());
        log.debug("Calling endpoint: {}", endpoint.getUrl());

        // Step 1: Call PDC Notification API
        PdcNotificationResponse pdcResponse = callPdcApi(endpoint);

        if (pdcResponse == null || pdcResponse.getPxResults() == null || pdcResponse.getPxResults().isEmpty()) {
            log.info("No results from endpoint: {}", endpoint.getName());
            return;
        }

        int resultCount = pdcResponse.getPxResults().size();
        log.info("Received {} results from {}", resultCount, endpoint.getName());
        pdcPollSuccessCounter.increment();

        // Step 2: Map PDC results to BigPanda alerts
        AIOpsAlertRequest aiopsRequest = resultsMapper.mapToAIOpsRequest(pdcResponse, endpoint);

        if (aiopsRequest.getAlertCount() == 0) {
            log.info("No alerts to send for endpoint: {}", endpoint.getName());
            return;
        }

        // Step 3: Send to BigPanda AIOps
        try {
            AIOpsAlertResponse response = aiopsService.sendToAIOpsApiBlocking(aiopsRequest);
            log.info("Successfully sent {} alerts for endpoint: {}",
                    aiopsRequest.getAlertCount(), endpoint.getName());
        } catch (Exception e) {
            log.error("Failed to send alerts to AIOps for endpoint {}: {}",
                    endpoint.getName(), e.getMessage());
        }
    }

    /**
     * Calls the Pega PDC Notification REST API with OAuth2 authentication.
     * Handles 401 by refreshing token and retrying once.
     */
    private PdcNotificationResponse callPdcApi(PdcIntegrationProperties.PdcEndpoint endpoint) {
        String url = endpoint.getUrl();

        try {
            HttpHeaders headers = createAuthHeaders();
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<PdcNotificationResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    requestEntity,
                    PdcNotificationResponse.class
            );

            if (response.getStatusCode().is2xxSuccessful()) {
                return response.getBody();
            } else {
                log.warn("PDC API returned non-2xx status {} for endpoint: {}",
                        response.getStatusCode(), endpoint.getName());
                pdcPollFailureCounter.increment();
                return null;
            }

        } catch (HttpClientErrorException.Unauthorized e) {
            // Token expired or invalid — refresh and retry once
            log.warn("Received 401 from PDC API for endpoint {}. Refreshing token and retrying...",
                    endpoint.getName());
            return retryWithNewToken(endpoint);

        } catch (HttpClientErrorException e) {
            log.error("PDC API client error for endpoint {}: {} {}",
                    endpoint.getName(), e.getStatusCode(), e.getResponseBodyAsString());
            pdcPollFailureCounter.increment();
            throw new PdcApiException("PDC API client error", endpoint.getName(), e.getStatusCode().value());

        } catch (HttpServerErrorException e) {
            log.error("PDC API server error for endpoint {}: {} {}",
                    endpoint.getName(), e.getStatusCode(), e.getResponseBodyAsString());
            pdcPollFailureCounter.increment();
            throw new PdcApiException("PDC API server error", endpoint.getName(), e.getStatusCode().value());

        } catch (Exception e) {
            log.error("PDC API call failed for endpoint {}: {}", endpoint.getName(), e.getMessage());
            pdcPollFailureCounter.increment();
            throw new PdcApiException("PDC API call failed", endpoint.getName(), e);
        }
    }

    /**
     * Retries the PDC API call with a fresh OAuth2 token (after 401).
     */
    private PdcNotificationResponse retryWithNewToken(PdcIntegrationProperties.PdcEndpoint endpoint) {
        oAuth2TokenService.invalidateToken();

        try {
            HttpHeaders headers = createAuthHeaders();
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<PdcNotificationResponse> response = restTemplate.exchange(
                    endpoint.getUrl(),
                    HttpMethod.GET,
                    requestEntity,
                    PdcNotificationResponse.class
            );

            return response.getBody();

        } catch (Exception retryEx) {
            log.error("Retry with new token also failed for endpoint {}: {}",
                    endpoint.getName(), retryEx.getMessage());
            pdcPollFailureCounter.increment();
            throw new PdcApiException("PDC API retry failed", endpoint.getName(), retryEx);
        }
    }

    private HttpHeaders createAuthHeaders() {
        String token = oAuth2TokenService.getAccessToken();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        return headers;
    }
}
