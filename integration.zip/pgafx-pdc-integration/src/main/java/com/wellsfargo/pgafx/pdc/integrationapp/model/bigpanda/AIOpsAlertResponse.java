package com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response from BigPanda AIOps Alerts API.
 *
 * Example: {"Submitted": 1, "ap_batch_id": "...", "msg_id": "..."}
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AIOpsAlertResponse {

    @JsonProperty("Submitted")
    private Integer submitted;

    @JsonProperty("ap_batch_id")
    private String apBatchId;

    @JsonProperty("msg_id")
    private String msgId;
}
