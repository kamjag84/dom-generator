package com.wellsfargo.pgafx.pdc.integrationapp.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import java.util.ArrayList;
import java.util.List;

/**
 * Configuration properties for PDC Integration application.
 * Uses a clean YAML list structure for multi-endpoint support.
 *
 * Example YAML:
 * pdcintegration:
 *   credentials:
 *     pega-oauth-client:
 *       client-id: "xxx"
 *       client-secret: "${PEGA_CLIENT_SECRET}"
 *       authorization-grant-type: "client_credentials"
 *       token-url: "https://pdck-na2.pega.net/prweb/api1/oauth2/v1/token"
 *     aiops:
 *       api-url: "https://aiops-alert-test.np.wellsfargo.net:8185/api/v2/alert"
 *       app-key: "${AIOPS_APP_KEY}"
 *     rest-template:
 *       http-client:
 *         max-route-connections: 100
 *         ...
 *     http:
 *       proxy-host: "cloudproxy-prod2.wellsfargo.net"
 *       proxy-port: 80
 *       non-proxy-hosts: "localhost|127.0.0.1"
 *   endpoints:
 *     - name: "PEGA-DEVB"
 *       url: "https://pdck-na2.pega.net/prweb/api1/PDCNotificationAPI/v2/PDCNotifications/..."
 *       enabled: false
 *       environment: "DEVELOPMENT"
 *       ci-name: "PGAFX-PEGA SMART INVESTIGATE-DEVELOPMENT"
 *       event-ticket: "WHLSTECHPEGASI"
 */
@Data
@Component
@Validated
@ConfigurationProperties(prefix = "pdcintegration")
public class PdcIntegrationProperties {

    @Valid
    @NotNull
    private Credentials credentials = new Credentials();

    @Valid
    private List<PdcEndpoint> endpoints = new ArrayList<>();

    @Valid
    private Mapper mapper = new Mapper();

    @Valid
    private Polling polling = new Polling();

    // ─── Credentials ─────────────────────────────────────────────

    @Data
    public static class Credentials {

        @Valid
        private PegaOAuthClient pegaOAuthClient = new PegaOAuthClient();

        @Valid
        private Aiops aiops = new Aiops();

        @Valid
        private RestTemplateSettings restTemplate = new RestTemplateSettings();

        @Valid
        private HttpProxySettings http = new HttpProxySettings();
    }

    @Data
    public static class PegaOAuthClient {
        @NotBlank
        private String clientId;
        @NotBlank
        private String clientSecret;
        private String authorizationGrantType = "client_credentials";
        @NotBlank
        private String tokenUrl;
    }

    @Data
    public static class Aiops {
        @NotBlank
        private String apiUrl;
        @NotBlank
        private String appKey;
    }

    @Data
    public static class RestTemplateSettings {
        private HttpClientSettings httpClient = new HttpClientSettings();
        private String keyStoreLocation;
        private String keyStorePassword;
        private String trustStoreLocation;
        private String trustStorePassword;
    }

    @Data
    public static class HttpClientSettings {
        private int maxRouteConnections = 100;
        private int maxTotalConnections = 100;
        private long keepAliveTime = 20000;
        private long connectionTimeout = 60000;
        private long requestTimeout = 60000;
        private long socketTimeout = 120000;
        private long idleTimeout = 30000;
        private long connectTimeout = 5000;
        private long readTimeout = 5000;
    }

    @Data
    public static class HttpProxySettings {
        private String proxyHost;
        private int proxyPort = 80;
        private String nonProxyHosts = "localhost|127.0.0.1";
    }

    // ─── Endpoints (clean YAML list) ─────────────────────────────

    @Data
    public static class PdcEndpoint {
        @NotBlank
        private String name;
        @NotBlank
        private String url;
        private boolean enabled = false;
        @NotBlank
        private String environment;
        @NotBlank
        private String ciName;
        private String eventTicket = "WHLSTECHPEGASI";
        private String eventTicketSupport = "PLATPEGASI_Support";
    }

    // ─── Mapper configuration (hardcoded defaults, overridable) ──

    @Data
    public static class Mapper {
        private String eventSource = "pgafx";
        private String snService = "Event Monitoring Incident Management";
        private String snCategory = "Technology Faults";
        private String snSubcategory = "Error/Fault Message";
        private String snImpact = "3";
        private String snUrgency = "3";
        private String eventTargetTicket = "managed by";
        private String eventTicket = "WHLSTECHPEGASI";
        private String ciWfAppid = "PGAFX";
        private String ciBasicType = "application";
    }

    // ─── Polling configuration ───────────────────────────────────

    @Data
    public static class Polling {
        /** Cron expression for scheduling. Default: every 1 minute */
        private String cron = "0 */1 * * * *";
        /** Fixed delay in milliseconds (alternative to cron). Default: 60000ms = 1 minute */
        private long fixedDelayMs = 60000;
        /** Initial delay before first poll in milliseconds */
        private long initialDelayMs = 10000;
        /** Use cron or fixed-delay? */
        private PollingStrategy strategy = PollingStrategy.FIXED_DELAY;
    }

    public enum PollingStrategy {
        CRON,
        FIXED_DELAY
    }
}
