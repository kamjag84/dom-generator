package com.wellsfargo.pgafx.pdc.integrationapp.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.hc.core5.util.Timeout;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.concurrent.TimeUnit;

/**
 * Configures RestTemplate with:
 * - Apache HttpClient 5 connection pooling
 * - SSL/TLS (keystore + truststore)
 * - HTTP proxy support
 * - Configurable timeouts
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class RestTemplateConfig {

    private final PdcIntegrationProperties properties;

    @Bean
    public RestTemplate restTemplate() {
        var httpSettings = properties.getCredentials().getRestTemplate().getHttpClient();
        var proxySettings = properties.getCredentials().getHttp();
        var sslSettings = properties.getCredentials().getRestTemplate();

        try {
            // Build SSL context if keystores are configured
            SSLContext sslContext = buildSslContext(sslSettings);

            // Build connection manager with pooling
            var connectionConfig = ConnectionConfig.custom()
                    .setConnectTimeout(Timeout.of(httpSettings.getConnectionTimeout(), TimeUnit.MILLISECONDS))
                    .setSocketTimeout(Timeout.of(httpSettings.getSocketTimeout(), TimeUnit.MILLISECONDS))
                    .build();

            var connectionManagerBuilder = PoolingHttpClientConnectionManagerBuilder.create()
                    .setMaxConnTotal(httpSettings.getMaxTotalConnections())
                    .setMaxConnPerRoute(httpSettings.getMaxRouteConnections())
                    .setDefaultConnectionConfig(connectionConfig);

            if (sslContext != null) {
                connectionManagerBuilder.setSSLSocketFactory(
                        SSLConnectionSocketFactoryBuilder.create()
                                .setSslContext(sslContext)
                                .build()
                );
            }

            PoolingHttpClientConnectionManager connectionManager = connectionManagerBuilder.build();

            // Request config
            RequestConfig requestConfig = RequestConfig.custom()
                    .setResponseTimeout(Timeout.of(httpSettings.getRequestTimeout(), TimeUnit.MILLISECONDS))
                    .setConnectionRequestTimeout(Timeout.of(httpSettings.getConnectTimeout(), TimeUnit.MILLISECONDS))
                    .build();

            // Build HTTP client
            var httpClientBuilder = HttpClients.custom()
                    .setConnectionManager(connectionManager)
                    .setDefaultRequestConfig(requestConfig);

            // Configure proxy if set
            if (StringUtils.hasText(proxySettings.getProxyHost())) {
                HttpHost proxy = new HttpHost(proxySettings.getProxyHost(), proxySettings.getProxyPort());
                httpClientBuilder.setProxy(proxy);
                log.info("HTTP proxy configured: {}:{}", proxySettings.getProxyHost(), proxySettings.getProxyPort());
            }

            CloseableHttpClient httpClient = httpClientBuilder.build();

            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);

            log.info("RestTemplate initialized with pool size={}, maxPerRoute={}, connectTimeout={}ms, socketTimeout={}ms",
                    httpSettings.getMaxTotalConnections(),
                    httpSettings.getMaxRouteConnections(),
                    httpSettings.getConnectionTimeout(),
                    httpSettings.getSocketTimeout());

            return new RestTemplate(factory);

        } catch (Exception e) {
            log.error("Failed to create RestTemplate with SSL/proxy configuration, falling back to default", e);
            return new RestTemplate();
        }
    }

    private SSLContext buildSslContext(PdcIntegrationProperties.RestTemplateSettings sslSettings) {
        try {
            String ksLocation = sslSettings.getKeyStoreLocation();
            String tsLocation = sslSettings.getTrustStoreLocation();

            if (!StringUtils.hasText(ksLocation) && !StringUtils.hasText(tsLocation)) {
                log.info("No keystore/truststore configured, using default SSL context");
                return null;
            }

            SSLContextBuilder sslContextBuilder = SSLContextBuilder.create();

            if (StringUtils.hasText(ksLocation)) {
                KeyStore keyStore = KeyStore.getInstance("JKS");
                try (FileInputStream fis = new FileInputStream(ksLocation)) {
                    keyStore.load(fis, sslSettings.getKeyStorePassword().toCharArray());
                }
                sslContextBuilder.loadKeyMaterial(keyStore, sslSettings.getKeyStorePassword().toCharArray());
                log.info("Loaded keystore from: {}", ksLocation);
            }

            if (StringUtils.hasText(tsLocation)) {
                KeyStore trustStore = KeyStore.getInstance("JKS");
                try (FileInputStream fis = new FileInputStream(tsLocation)) {
                    trustStore.load(fis, sslSettings.getTrustStorePassword().toCharArray());
                }
                sslContextBuilder.loadTrustMaterial(trustStore, null);
                log.info("Loaded truststore from: {}", tsLocation);
            }

            return sslContextBuilder.build();

        } catch (Exception e) {
            log.error("Failed to build SSL context", e);
            throw new RuntimeException("SSL configuration failed", e);
        }
    }
}
