package com.wellsfargo.pgafx.pdc.integrationapp.exception;

/**
 * Exception thrown when Pega PDC Notification API call fails.
 */
public class PdcApiException extends RuntimeException {

    private final String endpointName;
    private final int statusCode;

    public PdcApiException(String message, String endpointName) {
        super(message);
        this.endpointName = endpointName;
        this.statusCode = -1;
    }

    public PdcApiException(String message, String endpointName, int statusCode) {
        super(message);
        this.endpointName = endpointName;
        this.statusCode = statusCode;
    }

    public PdcApiException(String message, String endpointName, Throwable cause) {
        super(message, cause);
        this.endpointName = endpointName;
        this.statusCode = -1;
    }

    public String getEndpointName() {
        return endpointName;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
