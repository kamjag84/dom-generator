package com.wellsfargo.pgafx.pdc.integrationapp.model.pdc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Individual notification result from Pega PDC Notification API.
 *
 * Maps all known fields from the PDC response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PdcResult {

    @JsonProperty("Application")
    private String application;

    @JsonProperty("ClusterName")
    private String clusterName;

    @JsonProperty("CorrelationID")
    private String correlationId;

    @JsonProperty("GeneratedDateTime")
    private String generatedDateTime;

    @JsonProperty("InitialAction")
    private String initialAction;

    @JsonProperty("KPIThreshold")
    private String kpiThreshold;

    @JsonProperty("KPIValue")
    private String kpiValue;

    @JsonProperty("LineInfo")
    private String lineInfo;

    @JsonProperty("MsgID")
    private String msgId;

    @JsonProperty("Node")
    private String node;

    @JsonProperty("NotificationCategory")
    private String notificationCategory;

    @JsonProperty("NotificationName")
    private String notificationName;

    @JsonProperty("OperatorInfo")
    private String operatorInfo;

    @JsonProperty("PDCURL")
    private String pdcUrl;

    @JsonProperty("pxObiClass")
    private String pxObiClass;

    @JsonProperty("pzInsKey")
    private String pzInsKey;
}
