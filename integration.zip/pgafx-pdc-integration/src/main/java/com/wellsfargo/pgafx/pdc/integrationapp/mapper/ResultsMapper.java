package com.wellsfargo.pgafx.pdc.integrationapp.mapper;

import com.wellsfargo.pgafx.pdc.integrationapp.config.PdcIntegrationProperties;
import com.wellsfargo.pgafx.pdc.integrationapp.exception.MappingException;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlert;
import com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda.AIOpsAlertRequest;
import com.wellsfargo.pgafx.pdc.integrationapp.model.pdc.PdcNotificationResponse;
import com.wellsfargo.pgafx.pdc.integrationapp.model.pdc.PdcResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Maps Pega PDC Notification results to BigPanda AIOps alert format.
 *
 * Mapping:
 * ┌─────────────────────────┬──────────────────────────┐
 * │ PDC Field               │ BigPanda Alert Field      │
 * ├─────────────────────────┼──────────────────────────┤
 * │ CorrelationID           │ event_unique_key          │
 * │ (derived)               │ event_severity = "ERROR"  │
 * │ MsgID                   │ event_name                │
 * │ LineInfo                │ event_description         │
 * │ config: eventSource     │ event_source              │
 * │ config: snService       │ sn_service                │
 * │ config: snCategory      │ sn_category               │
 * │ config: snSubcategory   │ sn_subcategory            │
 * │ config: snImpact        │ sn_impact                 │
 * │ config: snUrgency       │ sn_urgency                │
 * │ config: eventTargetTicket│ event_target_ticket       │
 * │ endpoint: eventTicket   │ event_ticket              │
 * │ config: ciWfAppid       │ ci_wf_appid               │
 * │ endpoint: ciName        │ ci_name                   │
 * │ endpoint: environment   │ ci_environment            │
 * │ config: ciBasicType     │ ci_basic_type             │
 * └─────────────────────────┴──────────────────────────┘
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ResultsMapper {

    private final PdcIntegrationProperties properties;

    /**
     * Maps a full PDC notification response to an AIOps alert request.
     *
     * @param pdcResponse the response from PDC Notification API
     * @param endpoint    the endpoint configuration this response came from
     * @return AIOpsAlertRequest ready to send to BigPanda
     */
    public AIOpsAlertRequest mapToAIOpsRequest(PdcNotificationResponse pdcResponse,
                                                PdcIntegrationProperties.PdcEndpoint endpoint) {
        if (pdcResponse == null || pdcResponse.getPxResults() == null || pdcResponse.getPxResults().isEmpty()) {
            log.debug("No results to map for endpoint: {}", endpoint.getName());
            return AIOpsAlertRequest.builder().build();
        }

        List<AIOpsAlert> alerts = pdcResponse.getPxResults().stream()
                .map(result -> mapSingleResult(result, endpoint))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        AIOpsAlertRequest request = AIOpsAlertRequest.builder()
                .alerts(alerts)
                .build();

        log.info("Created AIOps request with {} alerts for endpoint: {}",
                request.getAlertCount(), endpoint.getName());

        return request;
    }

    /**
     * Maps a single PDC result to a BigPanda AIOps alert.
     */
    private AIOpsAlert mapSingleResult(PdcResult result, PdcIntegrationProperties.PdcEndpoint endpoint) {
        try {
            var mapper = properties.getMapper();

            // Derive event_unique_key from CorrelationID
            String eventUniqueKey = deriveEventUniqueKey(result);

            // Derive event_severity (default ERROR for all PDC notifications)
            String eventSeverity = deriveEventSeverity(result);

            // Derive event_description: use LineInfo, fallback to message from description
            String eventDescription = deriveEventDescription(result);

            return AIOpsAlert.builder()
                    .eventUniqueKey(eventUniqueKey)
                    .eventSeverity(eventSeverity)
                    .eventName(result.getMsgId())
                    .eventDescription(eventDescription)
                    .eventSource(mapper.getEventSource())
                    .snService(mapper.getSnService())
                    .snCategory(mapper.getSnCategory())
                    .snSubcategory(mapper.getSnSubcategory())
                    .snImpact(mapper.getSnImpact())
                    .snUrgency(mapper.getSnUrgency())
                    .eventTargetTicket(mapper.getEventTargetTicket())
                    .eventTicket(endpoint.getEventTicket())
                    .ciWfAppid(mapper.getCiWfAppid())
                    .ciName(endpoint.getCiName())
                    .ciEnvironment(endpoint.getEnvironment())
                    .ciBasicType(mapper.getCiBasicType())
                    .build();

        } catch (Exception e) {
            log.error("Failed to map PDC result with MsgID={} for endpoint={}: {}",
                    result.getMsgId(), endpoint.getName(), e.getMessage());
            throw new MappingException("Mapping failed for MsgID: " + result.getMsgId(), e);
        }
    }

    /**
     * Derives the event_unique_key from PDC CorrelationID.
     * Uses CorrelationID directly as it's already unique per notification.
     */
    private String deriveEventUniqueKey(PdcResult result) {
        if (StringUtils.hasText(result.getCorrelationId())) {
            return result.getCorrelationId();
        }
        // Fallback: construct from pzInsKey if CorrelationID is missing
        if (StringUtils.hasText(result.getPzInsKey())) {
            return result.getPzInsKey();
        }
        // Last resort: use MsgID + generatedDateTime
        return result.getMsgId() + ":" + result.getGeneratedDateTime();
    }

    /**
     * Derives event severity. PDC notifications are treated as ERROR by default.
     * Can be extended to check NotificationCategory or KPIThreshold.
     */
    private String deriveEventSeverity(PdcResult result) {
        // All PDC notifications currently map to ERROR severity
        // Can be extended: if result.getNotificationCategory() checks needed
        return "ERROR";
    }

    /**
     * Derives event description from LineInfo field.
     * Falls back to a description constructed from other fields.
     */
    private String deriveEventDescription(PdcResult result) {
        if (StringUtils.hasText(result.getLineInfo())) {
            return result.getLineInfo();
        }
        // Fallback: construct description
        StringBuilder desc = new StringBuilder();
        if (StringUtils.hasText(result.getNotificationName())) {
            desc.append(result.getNotificationName());
        }
        if (StringUtils.hasText(result.getApplication())) {
            desc.append(" - ").append(result.getApplication());
        }
        if (StringUtils.hasText(result.getClusterName())) {
            desc.append(" [").append(result.getClusterName()).append("]");
        }
        return desc.length() > 0 ? desc.toString() : "PDC notification: " + result.getMsgId();
    }
}
