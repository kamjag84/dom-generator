package com.wellsfargo.pgafx.pdc.integrationapp.health;

import com.wellsfargo.pgafx.pdc.integrationapp.config.PdcIntegrationProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 * Custom health indicator for PDC Integration application.
 * Reports the number of configured and enabled endpoints.
 */
@Component
@RequiredArgsConstructor
public class AppHealthIndicator implements HealthIndicator {

    private final PdcIntegrationProperties properties;

    @Override
    public Health health() {
        long totalEndpoints = properties.getEndpoints().size();
        long enabledEndpoints = properties.getEndpoints().stream()
                .filter(PdcIntegrationProperties.PdcEndpoint::isEnabled)
                .count();

        if (enabledEndpoints == 0) {
            return Health.down()
                    .withDetail("totalEndpoints", totalEndpoints)
                    .withDetail("enabledEndpoints", enabledEndpoints)
                    .withDetail("message", "No PDC endpoints are enabled")
                    .build();
        }

        return Health.up()
                .withDetail("totalEndpoints", totalEndpoints)
                .withDetail("enabledEndpoints", enabledEndpoints)
                .withDetail("pollingIntervalMs", properties.getPolling().getFixedDelayMs())
                .withDetail("aiopsUrl", properties.getCredentials().getAiops().getApiUrl())
                .build();
    }
}
