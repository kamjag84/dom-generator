package com.wellsfargo.pgafx.pdc.integrationapp.exception;

/**
 * Exception thrown when PDC-to-BigPanda field mapping fails.
 */
public class MappingException extends RuntimeException {

    public MappingException(String message) {
        super(message);
    }

    public MappingException(String message, Throwable cause) {
        super(message, cause);
    }
}
