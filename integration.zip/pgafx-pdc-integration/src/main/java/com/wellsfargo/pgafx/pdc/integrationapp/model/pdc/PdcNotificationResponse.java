package com.wellsfargo.pgafx.pdc.integrationapp.model.pdc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Maps the Pega PDC Notification API response.
 *
 * Sample response:
 * {
 *   "pxObiClass": "Code-Pega-List",
 *   "pxResults": [
 *     {
 *       "Application": "WFInvWire",
 *       "ClusterName": "pega_8_dev_b",
 *       "CorrelationID": "pega_8_dev_b:Custom WFMsg0012333:...",
 *       "GeneratedDateTime": "2026-02-06T15:47:22.009Z",
 *       "MsgID": "CA-WFMsg0012333",
 *       ...
 *     }
 *   ]
 * }
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PdcNotificationResponse {

    @JsonProperty("pxObiClass")
    private String pxObiClass;

    @JsonProperty("pxResults")
    @Builder.Default
    private List<PdcResult> pxResults = new ArrayList<>();
}
