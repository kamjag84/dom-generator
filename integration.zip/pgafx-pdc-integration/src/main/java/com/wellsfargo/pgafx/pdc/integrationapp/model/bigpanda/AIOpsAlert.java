package com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Individual alert in BigPanda AIOps format.
 *
 * Maps to the alert structure expected by BigPanda REST API:
 * {
 *   "event_unique_key": "...",
 *   "event_severity": "ERROR",
 *   "event_name": "CA-WFMsg0012333",
 *   "event_description": "...",
 *   "event_source": "pgafx",
 *   "sn_service": "Event Monitoring Incident Management",
 *   "sn_category": "Technology Faults",
 *   "sn_subcategory": "Error/Fault Message",
 *   "sn_impact": "3",
 *   "sn_urgency": "3",
 *   "event_target_ticket": "managed by",
 *   "event_ticket": "WHLSTECHPEGASI",
 *   "ci_wf_appid": "PGAFX",
 *   "ci_name": "PGAFX-PEGA SMART INVESTIGATE-SIT_IST",
 *   "ci_environment": "SIT/IST",
 *   "ci_basic_type": "application"
 * }
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AIOpsAlert {

    @JsonProperty("event_unique_key")
    private String eventUniqueKey;

    @JsonProperty("event_severity")
    private String eventSeverity;

    @JsonProperty("event_name")
    private String eventName;

    @JsonProperty("event_description")
    private String eventDescription;

    @JsonProperty("event_source")
    private String eventSource;

    @JsonProperty("sn_service")
    private String snService;

    @JsonProperty("sn_category")
    private String snCategory;

    @JsonProperty("sn_subcategory")
    private String snSubcategory;

    @JsonProperty("sn_impact")
    private String snImpact;

    @JsonProperty("sn_urgency")
    private String snUrgency;

    @JsonProperty("event_target_ticket")
    private String eventTargetTicket;

    @JsonProperty("event_ticket")
    private String eventTicket;

    @JsonProperty("ci_wf_appid")
    private String ciWfAppid;

    @JsonProperty("ci_name")
    private String ciName;

    @JsonProperty("ci_environment")
    private String ciEnvironment;

    @JsonProperty("ci_basic_type")
    private String ciBasicType;
}
