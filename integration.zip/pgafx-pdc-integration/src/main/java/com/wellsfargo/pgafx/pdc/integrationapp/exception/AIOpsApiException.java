package com.wellsfargo.pgafx.pdc.integrationapp.exception;

/**
 * Exception thrown when BigPanda AIOps API call fails.
 */
public class AIOpsApiException extends RuntimeException {

    private final int statusCode;

    public AIOpsApiException(String message) {
        super(message);
        this.statusCode = -1;
    }

    public AIOpsApiException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    public AIOpsApiException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = -1;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
