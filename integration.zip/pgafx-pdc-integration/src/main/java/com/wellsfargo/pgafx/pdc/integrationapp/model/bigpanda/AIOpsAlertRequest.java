package com.wellsfargo.pgafx.pdc.integrationapp.model.bigpanda;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Request payload for BigPanda AIOps Alerts API.
 *
 * Format:
 * {
 *   "alerts": [
 *     { ... },
 *     { ... }
 *   ]
 * }
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AIOpsAlertRequest {

    @JsonProperty("alerts")
    @Builder.Default
    private List<AIOpsAlert> alerts = new ArrayList<>();

    public int getAlertCount() {
        return alerts != null ? alerts.size() : 0;
    }
}
