{{/*
Common labels
*/}}
{{- define "pgafx-pdc-integration.labels" -}}
app: {{ .Values.deployment.container.name }}
app.kubernetes.io/name: {{ .Values.deployment.container.name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pgafx-pdc-integration.selectorLabels" -}}
app: {{ .Values.deployment.container.name }}
{{- end }}

{{/*
Full image reference
*/}}
{{- define "pgafx-pdc-integration.image" -}}
{{ .Values.deployment.container.image }}:{{ .Values.deployment.container.imageTag | default .Chart.AppVersion }}
{{- end }}
