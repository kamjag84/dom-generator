#!/usr/bin/env node

/**
 * Setup script for integrating DOM Capture into a Playwright test project
 * Run this in your test project root to enable DOM capture functionality
 */

const fs = require('fs-extra');
const path = require('path');

async function setupTestProject() {
  console.log('🔧 Setting up Playwright DOM Capture in your test project...\n');
  
  const projectRoot = process.cwd();
  
  // Step 1: Check if this is a Playwright project
  const playwrightConfig = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs']
    .find(file => fs.existsSync(path.join(projectRoot, file)));
  
  if (!playwrightConfig) {
    console.error('❌ No Playwright configuration found. Are you in a Playwright test project?');
    process.exit(1);
  }
  
  console.log(`✅ Found Playwright config: ${playwrightConfig}`);
  
  // Step 2: Create dom-capture directory
  const domCaptureDir = path.join(projectRoot, 'dom-capture');
  await fs.ensureDir(domCaptureDir);
  console.log('✅ Created dom-capture directory');
  
  // Step 3: Copy necessary files from the extension
  const extensionPath = path.dirname(__filename);
  const filesToCopy = [
    {
      src: path.join(extensionPath, 'src', 'testIntegration', 'playwrightTestHelper.ts'),
      dest: path.join(domCaptureDir, 'playwrightTestHelper.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'testIntegration', 'playwrightIntegration.ts'),
      dest: path.join(domCaptureDir, 'playwrightIntegration.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'domCapture', 'compressionManager.ts'),
      dest: path.join(domCaptureDir, 'compressionManager.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'domCapture', 'securityManager.ts'),
      dest: path.join(domCaptureDir, 'securityManager.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'domCapture', 'stateCapture.ts'),
      dest: path.join(domCaptureDir, 'stateCapture.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'domCapture', 'resourceInliner.ts'),
      dest: path.join(domCaptureDir, 'resourceInliner.ts')
    },
    {
      src: path.join(extensionPath, 'src', 'domCapture', 'metadataCollector.ts'),
      dest: path.join(domCaptureDir, 'metadataCollector.ts')
    }
  ];
  
  for (const file of filesToCopy) {
    if (await fs.pathExists(file.src)) {
      await fs.copy(file.src, file.dest, { overwrite: true });
      console.log(`✅ Copied ${path.basename(file.dest)}`);
    }
  }
  
  // Step 4: Create example test file
  const exampleTest = `import { test } from './dom-capture/playwrightIntegration';
import { expect } from '@playwright/test';

// Use the enhanced test fixture with DOM capture
test.describe('Example Tests with DOM Capture', () => {
  test('example test with automatic capture', async ({ page }) => {
    // DOM capture is automatically set up
    // Press Ctrl+Shift+C at any time during test execution to capture DOM
    
    await page.goto('https://example.com');
    
    // Your test logic here
    await expect(page).toHaveTitle(/Example/);
    
    // Manual capture at specific points (optional)
    await page.evaluate(() => {
      window.dispatchEvent(new CustomEvent('dom-capture-requested', {
        detail: { trigger: 'manual', timestamp: Date.now() }
      }));
    });
  });
  
  test('test that fails and captures DOM', async ({ page }) => {
    await page.goto('https://example.com');
    
    // This will fail and trigger automatic DOM capture
    await expect(page.locator('#non-existent')).toBeVisible();
  });
});
`;
  
  const examplePath = path.join(projectRoot, 'example-dom-capture.spec.ts');
  if (!await fs.pathExists(examplePath)) {
    await fs.writeFile(examplePath, exampleTest);
    console.log('✅ Created example test file: example-dom-capture.spec.ts');
  }
  
  // Step 5: Create a helper script for existing tests
  const helperScript = `/**
 * Add this to your existing test files to enable DOM capture
 */

import { setupDOMCapture } from './dom-capture/playwrightIntegration';
import { test as base } from '@playwright/test';

// Extend your existing test fixture
export const test = base.extend({
  page: async ({ page }, use) => {
    // Setup DOM capture for this page
    await setupDOMCapture(page);
    
    // Use the page
    await use(page);
  }
});

// Re-export expect
export { expect } from '@playwright/test';
`;
  
  await fs.writeFile(path.join(domCaptureDir, 'test-helper.ts'), helperScript);
  console.log('✅ Created test helper for existing tests');
  
  // Step 6: Update playwright.config to include global setup (if needed)
  const globalSetup = `/**
 * Global setup for DOM capture
 */

export default async function globalSetup() {
  console.log('🎭 Playwright DOM Capture enabled');
  console.log('📸 Press Ctrl+Shift+C during test execution to capture DOM');
  
  // Set environment variables
  process.env.DOM_CAPTURE_ENABLED = 'true';
  process.env.DOM_CAPTURE_OUTPUT = 'test-results/dom-captures';
}
`;
  
  await fs.writeFile(path.join(domCaptureDir, 'global-setup.ts'), globalSetup);
  console.log('✅ Created global setup file');
  
  // Step 7: Instructions
  console.log('\n📚 Setup Complete! Next steps:\n');
  console.log('1. For NEW tests, import from dom-capture:');
  console.log('   import { test } from "./dom-capture/playwrightIntegration";\n');
  
  console.log('2. For EXISTING tests, add at the top of your test files:');
  console.log('   import { setupDOMCapture } from "./dom-capture/playwrightIntegration";');
  console.log('   // Then in your test: await setupDOMCapture(page);\n');
  
  console.log('3. During test execution:');
  console.log('   - Press Ctrl+Shift+C to capture DOM at any point');
  console.log('   - DOM is automatically captured on test failure\n');
  
  console.log('4. Optional: Add to playwright.config.ts:');
  console.log('   globalSetup: "./dom-capture/global-setup.ts"\n');
  
  console.log('5. Run the example test:');
  console.log('   npx playwright test example-dom-capture.spec.ts\n');
  
  console.log('✨ Happy testing with DOM Capture!');
}

// Run setup
setupTestProject().catch(error => {
  console.error('❌ Setup failed:', error);
  process.exit(1);
});