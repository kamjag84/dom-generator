# Breakpoints for Debugging DOM Capture Extension

## Essential Breakpoints to Set

### 1. Extension Activation
**File:** `src/extension.ts`
```typescript
Line 24:  console.log('Playwright DOM Capture extension is activating...');
Line 35:  console.log('Playwright DOM Capture extension activated successfully');
```
**Why:** Confirms extension loads and activates

### 2. Command Registration
**File:** `src/extension.ts`
```typescript
Line 78:  console.log('Auto-configure command triggered');
Line 147: console.log('Dashboard command triggered');
Line 190: console.log('View last capture command triggered');
```
**Why:** Verifies commands are registered and callable

### 3. Copilot Integration
**File:** `src/copilotIntegration.ts`
```typescript
Line 43:  console.log('Registering Copilot participant...');
Line 97:  console.log('Copilot participant registered successfully');
```
**Why:** Checks if Copilot chat participant works

### 4. Error Handling
**File:** `src/utils/errorHandler.ts`
```typescript
Line 48:  this.logger.error(errorMessage, error);
Line 68:  this.logger.error(errorMessage, error);
```
**Why:** Catches any errors during execution

### 5. Git Integration
**File:** `src/gitIntegration.ts`
```typescript
Line 33:  this.logger.info('Initializing Git integration...');
Line 51:  this.logger.info('Git integration initialized successfully');
```
**Why:** Monitors Git safety features

## How to Set Breakpoints in VS Code

1. **Open the file** in VS Code
2. **Click on the line number** (a red dot appears)
3. **Or use F9** with cursor on the line
4. **Conditional breakpoints:** Right-click on line number → Add Conditional Breakpoint

## Debug Session Workflow

### Step 1: Set Initial Breakpoints
```
src/extension.ts - Line 24 (activation start)
src/extension.ts - Line 78 (auto-configure command)
```

### Step 2: Start Debug Session
1. Press **F5**
2. Select **"Run Extension"** configuration
3. Wait for new VS Code window to open

### Step 3: Monitor Breakpoint Hits
- **First hit:** Should be Line 24 on extension activation
- **Continue (F5):** Let extension finish loading
- **Test command:** Press Ctrl+Shift+P → "DOM Capture: Auto-configure"
- **Second hit:** Should be Line 78 when command executes

### Step 4: Step Through Code
- **F10:** Step Over (execute current line)
- **F11:** Step Into (enter function calls)
- **Shift+F11:** Step Out (exit current function)
- **F5:** Continue (run to next breakpoint)

## Variable Inspection Points

### At Line 24 (Activation)
**Inspect these variables:**
```typescript
context.extensionPath     // Extension installation path
context.extensionMode     // Development or Production
context.globalState       // Persistent storage
context.subscriptions     // Registered disposables
```

### At Line 78 (Command Execution)
**Inspect these variables:**
```typescript
vscode.workspace.workspaceFolders  // Current workspace
vscode.workspace.name              // Workspace name
vscode.window.activeTextEditor     // Current editor
```

## Conditional Breakpoints

### Only break on errors:
```typescript
// Set on error handling lines
error !== undefined
```

### Break on specific command:
```typescript
// Set on command handler
commandName === 'autoConfigureProject'
```

### Break after multiple hits:
```
Hit Count: 3  // Breaks on 3rd execution
```

## Watch Expressions

Add these to Watch panel during debugging:

```typescript
vscode.extensions.getExtension('test-publisher.playwright-dom-capture')
vscode.commands.getCommands()
context.subscriptions.length
vscode.workspace.workspaceFolders?.[0]?.uri.fsPath
process.env.NODE_ENV
```

## Debug Console Commands

Run these in Debug Console while paused:

```javascript
// Check if extension is active
vscode.extensions.getExtension('test-publisher.playwright-dom-capture').isActive

// List registered commands
await vscode.commands.getCommands().then(cmds => 
  cmds.filter(c => c.includes('playwright')))

// Execute command directly
await vscode.commands.executeCommand('playwright-dom-capture.showDashboard')

// Check workspace
vscode.workspace.workspaceFolders?.[0]?.uri.fsPath

// View all subscriptions
context.subscriptions.map(s => s.constructor.name)
```

## Troubleshooting Breakpoints

### Breakpoint Not Hit
1. Check source maps are enabled in launch.json
2. Ensure TypeScript compiled successfully
3. Verify file path matches compiled output
4. Try "Clean and Rebuild" task

### Breakpoint Grayed Out
- Line has no executable code
- Set breakpoint on next statement line
- Check TypeScript compilation output

### Variables Show as Undefined
- Enable source maps: `"sourceMaps": true`
- Use compiled JavaScript files for breakpoints
- Check variable scope (might be optimized out)

## Performance Profiling

### Start CPU Profiling:
1. Debug Console: `console.profile('command-execution')`
2. Execute commands
3. Debug Console: `console.profileEnd()`
4. View in Chrome DevTools Performance tab

### Memory Profiling:
1. Open Developer Tools (Ctrl+Shift+I)
2. Go to Memory tab
3. Take Heap Snapshot before/after operations
4. Compare snapshots for memory leaks

## Quick Reference Card

| Shortcut | Action |
|----------|--------|
| F5 | Start/Continue Debugging |
| F9 | Toggle Breakpoint |
| F10 | Step Over |
| F11 | Step Into |
| Shift+F11 | Step Out |
| Ctrl+Shift+F5 | Restart Debugging |
| Shift+F5 | Stop Debugging |
| Ctrl+K Ctrl+I | Show Hover |

## Next Steps After Setting Breakpoints

1. Start debug session (F5)
2. Verify extension activates (Line 24 hits)
3. Test each command in Command Palette
4. Check Copilot integration (if GitHub Copilot installed)
5. Review Debug Console for errors
6. Check Output panel for logs
7. Use Developer Tools for deeper inspection