"use strict";
/**
 * Playwright Test Integration Module
 * This module provides seamless integration with Playwright tests for DOM capture
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TestCaptureManager = exports.test = void 0;
exports.installHotkeyListener = installHotkeyListener;
exports.setupPageCaptureListener = setupPageCaptureListener;
exports.captureDOM = captureDOM;
exports.setupDOMCapture = setupDOMCapture;
exports.isDOMCaptureAvailable = isDOMCaptureAvailable;
const test_1 = require("@playwright/test");
const playwrightTestHelper_1 = require("./playwrightTestHelper");
const path = __importStar(require("path"));
const fs = __importStar(require("fs-extra"));
// Global flag to track if hotkey listener is installed
let hotkeyListenerInstalled = false;
/**
 * Install global hotkey listener for runtime capture (Ctrl+Shift+C)
 */
async function installHotkeyListener(page) {
    if (hotkeyListenerInstalled) {
        return;
    }
    await page.addInitScript(() => {
        // Track if capture is in progress to prevent multiple captures
        let isCapturing = false;
        // Listen for Ctrl+Shift+C (or Cmd+Shift+C on Mac)
        document.addEventListener('keydown', async (event) => {
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const modifier = isMac ? event.metaKey : event.ctrlKey;
            if (modifier && event.shiftKey && event.key === 'C') {
                event.preventDefault();
                event.stopPropagation();
                if (isCapturing) {
                    console.log('⏳ Capture already in progress...');
                    return;
                }
                isCapturing = true;
                console.log('📸 Manual DOM Capture triggered via Ctrl+Shift+C');
                // Trigger the capture
                try {
                    // Send custom event that our test helper will listen for
                    window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                        detail: {
                            timestamp: Date.now(),
                            trigger: 'hotkey',
                            url: window.location.href,
                            title: document.title
                        }
                    }));
                    // Visual feedback
                    const flash = document.createElement('div');
                    flash.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.3);
            z-index: 999999;
            pointer-events: none;
            animation: flash 0.3s ease-out;
          `;
                    const style = document.createElement('style');
                    style.textContent = `
            @keyframes flash {
              0% { opacity: 1; }
              100% { opacity: 0; }
            }
          `;
                    document.head.appendChild(style);
                    document.body.appendChild(flash);
                    setTimeout(() => {
                        flash.remove();
                        style.remove();
                    }, 300);
                }
                catch (error) {
                    console.error('Failed to trigger DOM capture:', error);
                }
                finally {
                    isCapturing = false;
                }
            }
        });
        console.log('✅ DOM Capture hotkey listener installed (Ctrl+Shift+C)');
    });
    hotkeyListenerInstalled = true;
}
/**
 * Setup page-level capture listener
 */
async function setupPageCaptureListener(page) {
    const captureManager = playwrightTestHelper_1.TestCaptureManager.getInstance();
    // Listen for capture requests from the page
    await page.exposeFunction('__captureDOM', async (detail) => {
        console.log('📸 Processing DOM capture request:', detail);
        try {
            const result = await captureManager.captureFromPage(page, {
                captureId: `hotkey_${detail.timestamp}`,
                customMetadata: {
                    trigger: detail.trigger,
                    url: detail.url,
                    title: detail.title
                }
            });
            console.log(`✅ DOM captured successfully: ${result.path}`);
            return { success: true, path: result.path };
        }
        catch (error) {
            console.error('❌ DOM capture failed:', error);
            return { success: false, error: error.message };
        }
    });
    // Connect the event to the exposed function
    await page.addInitScript(() => {
        window.addEventListener('dom-capture-requested', async (event) => {
            // @ts-ignore
            if (window.__captureDOM) {
                // @ts-ignore
                const result = await window.__captureDOM(event.detail);
                if (result.success) {
                    console.log('✅ DOM saved to:', result.path);
                }
                else {
                    console.error('❌ Capture failed:', result.error);
                }
            }
        });
    });
}
/**
 * Enhanced Playwright test with automatic DOM capture setup
 */
exports.test = test_1.test.extend({
    autoCapture: [async ({ page }, use, testInfo) => {
            console.log('🔧 Setting up DOM Capture for test:', testInfo.title);
            // Install hotkey listener
            await installHotkeyListener(page);
            // Setup capture listener
            await setupPageCaptureListener(page);
            // Initialize capture manager for this test
            const captureManager = playwrightTestHelper_1.TestCaptureManager.getInstance();
            captureManager.setCurrentTest(testInfo);
            // Setup automatic capture on failure
            testInfo.attachments.push({
                name: 'dom-capture-enabled',
                contentType: 'text/plain',
                body: Buffer.from('DOM capture is enabled for this test')
            });
            // Run the test
            await use();
            // Capture on failure
            if (testInfo.status === 'failed') {
                console.log('❌ Test failed, capturing DOM...');
                try {
                    const result = await captureManager.captureFromPage(page, {
                        captureId: `failure_${Date.now()}`,
                        customMetadata: {
                            status: 'failed',
                            error: testInfo.error?.message || 'Unknown error'
                        }
                    });
                    testInfo.attachments.push({
                        name: 'dom-capture-on-failure',
                        contentType: 'text/html',
                        path: result.path
                    });
                    console.log(`📸 Failure DOM captured: ${result.path}`);
                }
                catch (error) {
                    console.error('Failed to capture DOM on test failure:', error);
                }
            }
        }, { auto: true }],
    captureManager: async ({}, use) => {
        const manager = playwrightTestHelper_1.TestCaptureManager.getInstance();
        await use(manager);
    }
});
/**
 * Helper function to manually trigger a capture
 */
async function captureDOM(page, name, metadata) {
    const captureManager = playwrightTestHelper_1.TestCaptureManager.getInstance();
    const result = await captureManager.captureFromPage(page, {
        captureId: name || `manual_${Date.now()}`,
        customMetadata: metadata
    });
    return result.path;
}
/**
 * Setup function for existing test suites
 */
async function setupDOMCapture(page, context) {
    // Install hotkey listener on all pages
    if (context) {
        context.on('page', async (newPage) => {
            await installHotkeyListener(newPage);
            await setupPageCaptureListener(newPage);
        });
    }
    // Setup on current page
    await installHotkeyListener(page);
    await setupPageCaptureListener(page);
    console.log('✅ DOM Capture setup complete');
}
/**
 * Utility to check if DOM capture is available
 */
async function isDOMCaptureAvailable() {
    try {
        // Check if the extension is installed
        const extensionPath = path.join(process.cwd(), 'node_modules', 'playwright-dom-capture');
        if (await fs.pathExists(extensionPath)) {
            return true;
        }
        // Check if we're in a workspace with the extension
        const workspacePath = path.join(process.cwd(), 'dom-capture');
        return await fs.pathExists(workspacePath);
    }
    catch {
        return false;
    }
}
// Export all utilities
var playwrightTestHelper_2 = require("./playwrightTestHelper");
Object.defineProperty(exports, "TestCaptureManager", { enumerable: true, get: function () { return playwrightTestHelper_2.TestCaptureManager; } });
//# sourceMappingURL=playwrightIntegration.js.map