"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetadataCollector = void 0;
class MetadataCollector {
    constructor(page, context) {
        this.networkRequests = [];
        this.consoleLogs = [];
        this.errors = [];
        this.page = page;
        this.context = context;
    }
    async collectFullMetadata() {
        // Set up listeners
        await this.setupListeners();
        // Collect all metadata
        const [basicInfo, deviceInfo, performance, resources, security, accessibility] = await Promise.all([
            this.collectBasicInfo(),
            this.collectDeviceInfo(),
            this.collectPerformanceMetrics(),
            this.collectPageResources(),
            this.collectSecurityInfo(),
            this.collectAccessibilityInfo()
        ]);
        return {
            timestamp: new Date().toISOString(),
            url: this.page.url(),
            title: '',
            viewport: { width: 0, height: 0, orientation: 'landscape', isFullscreen: false }, // Default viewport
            userAgent: deviceInfo.userAgent || navigator.userAgent,
            platform: deviceInfo.platform || navigator.platform,
            devicePixelRatio: window.devicePixelRatio || 1,
            colorDepth: window.screen.colorDepth || 24,
            screenResolution: { width: window.screen.width, height: window.screen.height },
            availableScreenSize: { width: window.screen.availWidth, height: window.screen.availHeight },
            ...basicInfo,
            ...deviceInfo,
            performance,
            resourceTimings: await this.collectResourceTimings(),
            networkRequests: this.networkRequests,
            failedRequests: this.networkRequests.filter(r => r.failure || (r.status && r.status >= 400)),
            totalRequests: this.networkRequests.length,
            totalTransferSize: this.networkRequests.reduce((sum, r) => sum + (r.transferSize || 0), 0),
            consoleLogs: this.consoleLogs,
            errors: this.errors,
            warnings: this.consoleLogs.filter(log => log.type === 'warn'),
            resources,
            security,
            accessibility
        };
    }
    async setupListeners() {
        // Listen to console events
        this.page.on('console', async (msg) => {
            const log = {
                type: msg.type(),
                message: msg.text(),
                timestamp: new Date().toISOString(),
                location: msg.location().url
            };
            if (msg.type() === 'error') {
                this.errors.push(log);
            }
            else {
                this.consoleLogs.push(log);
            }
        });
        // Listen to page errors
        this.page.on('pageerror', error => {
            this.errors.push({
                type: 'error',
                message: error.message,
                stack: error.stack,
                name: error.name,
                timestamp: new Date().toISOString()
            });
        });
        // Listen to network requests
        this.page.on('request', request => {
            this.networkRequests.push({
                url: request.url(),
                method: request.method(),
                requestHeaders: request.headers(),
                resourceType: request.resourceType(),
                startTime: new Date().toISOString()
            });
        });
        this.page.on('response', response => {
            const request = this.networkRequests.find(r => r.url === response.url());
            if (request) {
                request.status = response.status();
                request.statusText = response.statusText();
                request.responseHeaders = response.headers();
                request.endTime = new Date().toISOString();
            }
        });
        this.page.on('requestfailed', request => {
            const req = this.networkRequests.find(r => r.url === request.url());
            if (req) {
                req.failure = request.failure()?.errorText || 'Unknown error';
            }
        });
    }
    async collectBasicInfo() {
        return await this.page.evaluate(() => {
            const getMeta = (name) => {
                const meta = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
                return meta?.getAttribute('content') || undefined;
            };
            return {
                timestamp: new Date().toISOString(),
                url: window.location.href,
                title: document.title,
                description: getMeta('description'),
                keywords: getMeta('keywords')?.split(',').map(k => k.trim())
            };
        });
    }
    async collectDeviceInfo() {
        return await this.page.evaluate(() => {
            return {
                viewport: {
                    width: window.innerWidth,
                    height: window.innerHeight,
                    orientation: window.innerWidth > window.innerHeight ? 'landscape' : 'portrait',
                    isFullscreen: document.fullscreenElement !== null
                },
                userAgent: navigator.userAgent,
                platform: navigator.platform,
                devicePixelRatio: window.devicePixelRatio,
                colorDepth: screen.colorDepth,
                screenResolution: {
                    width: screen.width,
                    height: screen.height
                },
                availableScreenSize: {
                    width: screen.availWidth,
                    height: screen.availHeight
                },
                deviceMemory: navigator.deviceMemory,
                hardwareConcurrency: navigator.hardwareConcurrency
            };
        });
    }
    async collectPerformanceMetrics() {
        return await this.page.evaluate(() => {
            const perf = performance.timing;
            const paintMetrics = performance.getEntriesByType('paint');
            const getFCP = () => {
                const fcp = paintMetrics.find(p => p.name === 'first-contentful-paint');
                return fcp?.startTime;
            };
            const getFP = () => {
                const fp = paintMetrics.find(p => p.name === 'first-paint');
                return fp?.startTime;
            };
            const getLCP = () => {
                const entries = performance.getEntriesByType('largest-contentful-paint');
                const lastEntry = entries[entries.length - 1];
                return lastEntry?.startTime;
            };
            const getCLS = () => {
                let clsScore = 0;
                let sessionValue = 0;
                let sessionEntries = [];
                const entries = performance.getEntriesByType('layout-shift');
                entries.forEach((entry) => {
                    if (!entry.hadRecentInput) {
                        sessionValue += entry.value;
                        sessionEntries.push(entry);
                    }
                });
                return sessionValue;
            };
            const memoryUsage = performance.memory ? {
                usedJSHeapSize: performance.memory.usedJSHeapSize,
                totalJSHeapSize: performance.memory.totalJSHeapSize,
                jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
            } : undefined;
            return {
                loadTime: perf.loadEventEnd - perf.navigationStart,
                domContentLoaded: perf.domContentLoadedEventEnd - perf.navigationStart,
                firstPaint: getFP(),
                firstContentfulPaint: getFCP(),
                largestContentfulPaint: getLCP(),
                cumulativeLayoutShift: getCLS(),
                memoryUsage
            };
        });
    }
    async collectResourceTimings() {
        return await this.page.evaluate(() => {
            const entries = performance.getEntriesByType('resource');
            return entries.map(entry => ({
                name: entry.name,
                entryType: entry.entryType,
                startTime: entry.startTime,
                duration: entry.duration,
                transferSize: entry.transferSize || 0,
                encodedBodySize: entry.encodedBodySize || 0,
                decodedBodySize: entry.decodedBodySize || 0,
                serverTiming: entry.serverTiming ? Array.from(entry.serverTiming) : []
            }));
        });
    }
    async collectPageResources() {
        return await this.page.evaluate(() => {
            const resources = {
                scripts: document.querySelectorAll('script').length,
                stylesheets: document.querySelectorAll('link[rel="stylesheet"], style').length,
                images: document.querySelectorAll('img').length,
                fonts: document.querySelectorAll('link[rel="preload"][as="font"], link[rel="prefetch"][as="font"]').length,
                videos: document.querySelectorAll('video').length,
                audios: document.querySelectorAll('audio').length,
                iframes: document.querySelectorAll('iframe').length,
                totalSize: 0,
                externalResources: 0,
                inlineResources: 0
            };
            // Count external vs inline resources
            document.querySelectorAll('script').forEach(script => {
                if (script.src) {
                    resources.externalResources++;
                }
                else {
                    resources.inlineResources++;
                }
            });
            document.querySelectorAll('link[rel="stylesheet"], style').forEach(style => {
                if (style.href) {
                    resources.externalResources++;
                }
                else {
                    resources.inlineResources++;
                }
            });
            // Calculate approximate total size from resource timings
            const timings = performance.getEntriesByType('resource');
            resources.totalSize = timings.reduce((sum, t) => sum + (t.transferSize || 0), 0);
            return resources;
        });
    }
    async collectSecurityInfo() {
        return await this.page.evaluate(() => {
            const getCSP = () => {
                const meta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
                return meta?.getAttribute('content') || undefined;
            };
            const checkMixedContent = () => {
                const insecureResources = document.querySelectorAll('img[src^="http:"], script[src^="http:"], link[href^="http:"], iframe[src^="http:"]');
                return insecureResources.length > 0;
            };
            return {
                protocol: window.location.protocol,
                isSecure: window.location.protocol === 'https:',
                hasMixedContent: window.location.protocol === 'https:' && checkMixedContent(),
                cspPolicy: getCSP(),
                permissions: navigator.permissions ? [] : undefined
            };
        });
    }
    async collectAccessibilityInfo() {
        return await this.page.evaluate(() => {
            const images = document.querySelectorAll('img');
            let imagesWithAlt = 0;
            let imagesWithoutAlt = 0;
            images.forEach(img => {
                if (img.alt) {
                    imagesWithAlt++;
                }
                else {
                    imagesWithoutAlt++;
                }
            });
            const formLabels = document.querySelectorAll('label').length;
            const hasLandmarks = document.querySelector('[role="main"], [role="navigation"], [role="banner"]') !== null;
            const hasHeadings = document.querySelector('h1, h2, h3, h4, h5, h6') !== null;
            const hasAriaLabels = document.querySelector('[aria-label], [aria-labelledby]') !== null;
            return {
                hasLandmarks,
                hasHeadings,
                hasAriaLabels,
                imagesWithAlt,
                imagesWithoutAlt,
                formLabels
            };
        });
    }
}
exports.MetadataCollector = MetadataCollector;
//# sourceMappingURL=metadataCollector.js.map