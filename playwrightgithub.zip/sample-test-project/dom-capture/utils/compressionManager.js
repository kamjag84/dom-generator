"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompressionManager = void 0;
const fs = __importStar(require("fs-extra"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
class CompressionManager {
    constructor(storagePath, options = {}) {
        this.storageIndex = new Map();
        this.hashCache = new Map();
        this.storagePath = storagePath;
        this.options = {
            level: 'medium',
            enableDeduplication: true,
            enableChunking: true,
            chunkSize: 500, // 500KB per chunk
            enableDiffing: true,
            maxStorageSize: 100, // 100MB max storage
            ...options
        };
        this.loadStorageIndex();
    }
    async compressAndStore(html, metadata, testName, previousCaptureId) {
        const id = this.generateId(testName);
        const hash = this.calculateHash(html);
        // Check for deduplication
        if (this.options.enableDeduplication) {
            const existingEntry = this.findByHash(hash);
            if (existingEntry) {
                console.log(`Duplicate capture detected. Reusing existing: ${existingEntry.id}`);
                return existingEntry;
            }
        }
        // Apply compression
        let compressedHtml = html;
        if (this.options.level !== 'none') {
            compressedHtml = this.compress(html);
        }
        // Handle diffing
        if (this.options.enableDiffing && previousCaptureId) {
            const previousEntry = this.storageIndex.get(previousCaptureId);
            if (previousEntry) {
                const diff = await this.createDiff(previousCaptureId, html);
                if (diff.size < compressedHtml.length * 0.5) { // Only use diff if it's less than 50% of full size
                    return await this.storeDiff(id, diff, previousCaptureId, testName, hash);
                }
            }
        }
        // Handle chunking for large files
        if (this.options.enableChunking && compressedHtml.length > this.options.chunkSize * 1024) {
            return await this.storeChunked(id, compressedHtml, metadata, testName, hash);
        }
        // Regular storage
        return await this.store(id, compressedHtml, metadata, testName, hash);
    }
    compress(html) {
        switch (this.options.level) {
            case 'low':
                return this.lowCompression(html);
            case 'medium':
                return this.mediumCompression(html);
            case 'high':
                return this.highCompression(html);
            default:
                return html;
        }
    }
    lowCompression(html) {
        // Remove unnecessary whitespace
        return html
            .replace(/\s+/g, ' ')
            .replace(/>\s+</g, '><')
            .trim();
    }
    mediumCompression(html) {
        let compressed = this.lowCompression(html);
        // Remove comments (except IE conditional comments)
        compressed = compressed.replace(/<!--(?!\[if)[\s\S]*?-->/g, '');
        // Remove unnecessary quotes in attributes
        compressed = compressed.replace(/="([^"]*?)"/g, (match, value) => {
            if (!/[\s"'=<>`]/.test(value)) {
                return `=${value}`;
            }
            return match;
        });
        // Minify inline styles
        compressed = compressed.replace(/style="([^"]*)"/gi, (match, styles) => {
            const minified = styles
                .replace(/\s*:\s*/g, ':')
                .replace(/\s*;\s*/g, ';')
                .replace(/;\s*$/, '');
            return `style="${minified}"`;
        });
        return compressed;
    }
    highCompression(html) {
        let compressed = this.mediumCompression(html);
        // Remove optional tags
        compressed = compressed
            .replace(/<\/option>/gi, '')
            .replace(/<\/li>/gi, '')
            .replace(/<\/dt>/gi, '')
            .replace(/<\/dd>/gi, '')
            .replace(/<\/p>/gi, '')
            .replace(/<\/tr>/gi, '')
            .replace(/<\/td>/gi, '')
            .replace(/<\/th>/gi, '');
        // Remove default attributes
        compressed = compressed
            .replace(/\s+type="text\/javascript"/gi, '')
            .replace(/\s+type="text\/css"/gi, '')
            .replace(/\s+charset="utf-8"/gi, '');
        // Shorten boolean attributes
        compressed = compressed
            .replace(/\s+checked="checked"/gi, ' checked')
            .replace(/\s+selected="selected"/gi, ' selected')
            .replace(/\s+disabled="disabled"/gi, ' disabled')
            .replace(/\s+readonly="readonly"/gi, ' readonly');
        // Minify inline scripts
        compressed = compressed.replace(/<script\b[^>]*>([\s\S]*?)<\/script>/gi, (match, script) => {
            const minified = script
                .replace(/\/\*[\s\S]*?\*\//g, '')
                .replace(/\/\/.*$/gm, '')
                .replace(/\s+/g, ' ')
                .trim();
            return match.replace(script, minified);
        });
        return compressed;
    }
    async storeChunked(id, html, metadata, testName, hash) {
        const chunks = [];
        const chunkSize = this.options.chunkSize * 1024;
        // Store chunks in the chunks directory at root level
        for (let i = 0; i < html.length; i += chunkSize) {
            const chunk = html.slice(i, Math.min(i + chunkSize, html.length));
            const chunkId = `${id}_chunk_${chunks.length}`;
            const chunkPath = path.join(this.storagePath, 'chunks', `${chunkId}.html`);
            await fs.ensureDir(path.dirname(chunkPath));
            await fs.writeFile(chunkPath, chunk, 'utf-8');
            chunks.push(chunkId);
        }
        // Store metadata
        const metadataPath = path.join(this.storagePath, 'metadata', `${id}.json`);
        await fs.ensureDir(path.dirname(metadataPath));
        await fs.writeJson(metadataPath, {
            ...metadata,
            chunks,
            totalSize: html.length
        });
        const entry = {
            id,
            hash,
            timestamp: new Date().toISOString(),
            testName,
            size: html.length,
            compressed: this.options.level !== 'none',
            chunks
        };
        this.storageIndex.set(id, entry);
        await this.saveStorageIndex();
        return entry;
    }
    async store(id, html, metadata, testName, hash) {
        const filePath = path.join(this.storagePath, 'captures', `${id}.html`);
        const metadataPath = path.join(this.storagePath, 'metadata', `${id}.json`);
        await fs.ensureDir(path.dirname(filePath));
        await fs.ensureDir(path.dirname(metadataPath));
        await fs.writeFile(filePath, html, 'utf-8');
        await fs.writeJson(metadataPath, metadata);
        const entry = {
            id,
            hash,
            timestamp: new Date().toISOString(),
            testName,
            size: html.length,
            compressed: this.options.level !== 'none'
        };
        this.storageIndex.set(id, entry);
        await this.saveStorageIndex();
        // Clean up old captures if storage limit exceeded
        await this.enforceStorageLimit();
        return entry;
    }
    async storeDiff(id, diff, parentId, testName, hash) {
        const diffPath = path.join(this.storagePath, 'diffs', `${id}.json`);
        await fs.ensureDir(path.dirname(diffPath));
        await fs.writeJson(diffPath, diff);
        const entry = {
            id,
            hash,
            timestamp: new Date().toISOString(),
            testName,
            size: JSON.stringify(diff).length,
            compressed: true,
            parentId,
            diff
        };
        this.storageIndex.set(id, entry);
        await this.saveStorageIndex();
        return entry;
    }
    async createDiff(previousId, currentHtml) {
        const previousHtml = await this.retrieve(previousId);
        // Simple line-based diff
        const previousLines = previousHtml.split('\n');
        const currentLines = currentHtml.split('\n');
        const diff = {
            additions: [],
            deletions: [],
            modifications: [],
            size: 0
        };
        const maxLines = Math.max(previousLines.length, currentLines.length);
        for (let i = 0; i < maxLines; i++) {
            if (i >= previousLines.length) {
                diff.additions.push({ line: i, content: currentLines[i] });
            }
            else if (i >= currentLines.length) {
                diff.deletions.push({ line: i, content: previousLines[i] });
            }
            else if (previousLines[i] !== currentLines[i]) {
                diff.modifications.push({
                    line: i,
                    old: previousLines[i],
                    new: currentLines[i]
                });
            }
        }
        diff.size = JSON.stringify(diff).length;
        return diff;
    }
    async retrieve(id) {
        const entry = this.storageIndex.get(id);
        if (!entry) {
            throw new Error(`Capture not found: ${id}`);
        }
        // Handle diff-based storage
        if (entry.parentId && entry.diff) {
            const parentHtml = await this.retrieve(entry.parentId);
            return this.applyDiff(parentHtml, entry.diff);
        }
        // Handle chunked storage
        if (entry.chunks) {
            const chunks = [];
            for (const chunkId of entry.chunks) {
                const chunkPath = path.join(this.storagePath, 'chunks', `${chunkId}.html`);
                const chunk = await fs.readFile(chunkPath, 'utf-8');
                chunks.push(chunk);
            }
            return chunks.join('');
        }
        // Regular storage
        const filePath = path.join(this.storagePath, 'captures', `${id}.html`);
        return await fs.readFile(filePath, 'utf-8');
    }
    applyDiff(baseHtml, diff) {
        const lines = baseHtml.split('\n');
        // Apply deletions (in reverse order to maintain indices)
        diff.deletions.sort((a, b) => b.line - a.line).forEach((del) => {
            lines.splice(del.line, 1);
        });
        // Apply modifications
        diff.modifications.forEach((mod) => {
            if (mod.line < lines.length) {
                lines[mod.line] = mod.new;
            }
        });
        // Apply additions
        diff.additions.forEach((add) => {
            lines.splice(add.line, 0, add.content);
        });
        return lines.join('\n');
    }
    calculateHash(content) {
        return crypto.createHash('sha256').update(content).digest('hex');
    }
    generateId(testName) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const sanitized = testName.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
        return `${sanitized}_${timestamp}`;
    }
    findByHash(hash) {
        for (const [, entry] of this.storageIndex) {
            if (entry.hash === hash) {
                return entry;
            }
        }
        return undefined;
    }
    async enforceStorageLimit() {
        const totalSize = await this.calculateTotalSize();
        const maxSize = this.options.maxStorageSize * 1024 * 1024; // Convert MB to bytes
        if (totalSize > maxSize) {
            // Sort by timestamp (oldest first)
            const entries = Array.from(this.storageIndex.values())
                .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
            let currentSize = totalSize;
            for (const entry of entries) {
                if (currentSize <= maxSize)
                    break;
                await this.deleteEntry(entry.id);
                currentSize -= entry.size;
            }
        }
    }
    async calculateTotalSize() {
        let total = 0;
        for (const [, entry] of this.storageIndex) {
            total += entry.size;
        }
        return total;
    }
    async deleteEntry(id) {
        const entry = this.storageIndex.get(id);
        if (!entry)
            return;
        // Delete files
        if (entry.chunks) {
            for (const chunkId of entry.chunks) {
                const chunkPath = path.join(this.storagePath, 'chunks', `${chunkId}.html`);
                await fs.remove(chunkPath);
            }
        }
        else if (entry.diff) {
            const diffPath = path.join(this.storagePath, 'diffs', `${id}.json`);
            await fs.remove(diffPath);
        }
        else {
            const filePath = path.join(this.storagePath, 'captures', `${id}.html`);
            await fs.remove(filePath);
        }
        // Delete metadata
        const metadataPath = path.join(this.storagePath, 'metadata', `${id}.json`);
        await fs.remove(metadataPath);
        // Remove from index
        this.storageIndex.delete(id);
    }
    async loadStorageIndex() {
        const indexPath = path.join(this.storagePath, 'index.json');
        if (await fs.pathExists(indexPath)) {
            const index = await fs.readJson(indexPath);
            this.storageIndex = new Map(Object.entries(index));
        }
    }
    async saveStorageIndex() {
        const indexPath = path.join(this.storagePath, 'index.json');
        await fs.ensureDir(path.dirname(indexPath));
        const index = Object.fromEntries(this.storageIndex);
        await fs.writeJson(indexPath, index, { spaces: 2 });
    }
    async getStorageStats() {
        const totalSize = await this.calculateTotalSize();
        const uniqueHashes = new Set(Array.from(this.storageIndex.values()).map(e => e.hash));
        return {
            totalCaptures: this.storageIndex.size,
            totalSize,
            compressionRatio: 0, // Would need to track original sizes
            deduplicationSavings: this.storageIndex.size - uniqueHashes.size
        };
    }
}
exports.CompressionManager = CompressionManager;
//# sourceMappingURL=compressionManager.js.map