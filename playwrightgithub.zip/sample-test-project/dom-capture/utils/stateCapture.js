"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateCapture = void 0;
class StateCapture {
    constructor(page) {
        this.interactions = [];
        this.page = page;
    }
    async captureFullState() {
        // Set up interaction tracking
        await this.setupInteractionTracking();
        const state = {
            forms: await this.captureFormState(),
            scrollPositions: await this.captureScrollPositions(),
            localStorage: await this.captureLocalStorage(),
            sessionStorage: await this.captureSessionStorage(),
            cookies: await this.captureCookies(),
            windowState: await this.captureWindowState(),
            interactions: this.interactions,
            customDataAttributes: await this.captureCustomDataAttributes(),
            ariaStates: await this.captureAriaStates()
        };
        return state;
    }
    async setupInteractionTracking() {
        await this.page.addInitScript(() => {
            const interactions = [];
            // Track clicks
            document.addEventListener('click', (e) => {
                const target = e.target;
                interactions.push({
                    type: 'click',
                    selector: target.tagName + (target.id ? `#${target.id}` : ''),
                    timestamp: new Date().toISOString(),
                    coordinates: { x: e.clientX, y: e.clientY }
                });
            }, true);
            // Track inputs
            document.addEventListener('input', (e) => {
                const target = e.target;
                interactions.push({
                    type: 'input',
                    selector: target.tagName + (target.id ? `#${target.id}` : ''),
                    timestamp: new Date().toISOString(),
                    value: target.value
                });
            }, true);
            // Track focus/blur
            document.addEventListener('focus', (e) => {
                const target = e.target;
                interactions.push({
                    type: 'focus',
                    selector: target.tagName + (target.id ? `#${target.id}` : ''),
                    timestamp: new Date().toISOString()
                });
            }, true);
            document.addEventListener('blur', (e) => {
                const target = e.target;
                interactions.push({
                    type: 'blur',
                    selector: target.tagName + (target.id ? `#${target.id}` : ''),
                    timestamp: new Date().toISOString()
                });
            }, true);
            // Store interactions globally
            window.__interactions = interactions;
        });
    }
    async captureFormState() {
        return await this.page.evaluate(() => {
            const forms = [];
            // Capture all form elements
            const formElements = document.querySelectorAll('input, textarea, select');
            formElements.forEach((element, index) => {
                const el = element;
                const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
                const state = {
                    selector,
                    type: el.type || el.tagName.toLowerCase(),
                    name: el.name,
                    id: el.id,
                    value: null
                };
                if (el instanceof HTMLInputElement) {
                    if (el.type === 'checkbox' || el.type === 'radio') {
                        state.checked = el.checked;
                        state.value = el.value;
                    }
                    else if (el.type === 'file') {
                        state.value = el.files ? Array.from(el.files).map(f => f.name) : [];
                    }
                    else {
                        state.value = el.value;
                    }
                }
                else if (el instanceof HTMLTextAreaElement) {
                    state.value = el.value;
                }
                else if (el instanceof HTMLSelectElement) {
                    state.selectedIndex = el.selectedIndex;
                    state.selectedOptions = Array.from(el.selectedOptions).map(opt => opt.value);
                    state.value = el.value;
                }
                forms.push(state);
            });
            return forms;
        });
    }
    async captureScrollPositions() {
        return await this.page.evaluate(() => {
            const positions = [];
            // Capture window scroll
            positions.push({
                selector: 'window',
                scrollTop: window.scrollY || document.documentElement.scrollTop,
                scrollLeft: window.scrollX || document.documentElement.scrollLeft
            });
            // Capture all scrollable elements
            const elements = document.querySelectorAll('*');
            elements.forEach((element, index) => {
                const el = element;
                if (el.scrollHeight > el.clientHeight || el.scrollWidth > el.clientWidth) {
                    if (el.scrollTop > 0 || el.scrollLeft > 0) {
                        positions.push({
                            selector: `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`,
                            scrollTop: el.scrollTop,
                            scrollLeft: el.scrollLeft
                        });
                    }
                }
            });
            return positions;
        });
    }
    async captureLocalStorage() {
        return await this.page.evaluate(() => {
            const storage = {};
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key) {
                    const value = localStorage.getItem(key);
                    try {
                        // Try to parse JSON values
                        storage[key] = JSON.parse(value || '');
                    }
                    catch {
                        // Store as string if not JSON
                        storage[key] = value;
                    }
                }
            }
            return storage;
        });
    }
    async captureSessionStorage() {
        return await this.page.evaluate(() => {
            const storage = {};
            for (let i = 0; i < sessionStorage.length; i++) {
                const key = sessionStorage.key(i);
                if (key) {
                    const value = sessionStorage.getItem(key);
                    try {
                        // Try to parse JSON values
                        storage[key] = JSON.parse(value || '');
                    }
                    catch {
                        // Store as string if not JSON
                        storage[key] = value;
                    }
                }
            }
            return storage;
        });
    }
    async captureCookies() {
        const cookies = await this.page.context().cookies();
        return cookies.map(cookie => ({
            name: cookie.name,
            value: cookie.value,
            domain: cookie.domain,
            path: cookie.path,
            expires: cookie.expires,
            httpOnly: cookie.httpOnly,
            secure: cookie.secure,
            sameSite: cookie.sameSite
        }));
    }
    async captureWindowState() {
        return await this.page.evaluate(() => {
            return {
                width: window.innerWidth,
                height: window.innerHeight,
                scrollX: window.scrollX,
                scrollY: window.scrollY,
                devicePixelRatio: window.devicePixelRatio,
                orientation: screen.orientation?.type
            };
        });
    }
    async captureCustomDataAttributes() {
        return await this.page.evaluate(() => {
            const dataAttributes = {};
            // Find all elements with data attributes
            const elements = document.querySelectorAll('[data-*]');
            elements.forEach((element, index) => {
                const el = element;
                const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
                const attrs = {};
                // Get all data attributes
                for (const attr of el.attributes) {
                    if (attr.name.startsWith('data-')) {
                        attrs[attr.name] = attr.value;
                    }
                }
                if (Object.keys(attrs).length > 0) {
                    dataAttributes[selector] = attrs;
                }
            });
            return dataAttributes;
        });
    }
    async captureAriaStates() {
        return await this.page.evaluate(() => {
            const ariaStates = [];
            // Find all elements with ARIA attributes
            const elements = document.querySelectorAll('[aria-*], [role]');
            elements.forEach((element, index) => {
                const el = element;
                const selector = `${el.tagName.toLowerCase()}:nth-of-type(${index + 1})`;
                const attributes = {};
                // Get all ARIA attributes
                for (const attr of el.attributes) {
                    if (attr.name.startsWith('aria-') || attr.name === 'role') {
                        attributes[attr.name] = attr.value;
                    }
                }
                if (Object.keys(attributes).length > 0) {
                    ariaStates.push({ selector, attributes });
                }
            });
            return ariaStates;
        });
    }
    async restoreState(state) {
        // Restore localStorage
        await this.page.evaluate((storage) => {
            localStorage.clear();
            for (const [key, value] of Object.entries(storage)) {
                localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
            }
        }, state.localStorage);
        // Restore sessionStorage
        await this.page.evaluate((storage) => {
            sessionStorage.clear();
            for (const [key, value] of Object.entries(storage)) {
                sessionStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
            }
        }, state.sessionStorage);
        // Restore form state
        for (const formState of state.forms) {
            await this.page.evaluate((state) => {
                const element = document.querySelector(state.selector);
                if (element) {
                    if (element instanceof HTMLInputElement) {
                        if (element.type === 'checkbox' || element.type === 'radio') {
                            element.checked = state.checked || false;
                        }
                        else {
                            element.value = state.value || '';
                        }
                    }
                    else if (element instanceof HTMLTextAreaElement) {
                        element.value = state.value || '';
                    }
                    else if (element instanceof HTMLSelectElement) {
                        if (state.selectedIndex !== undefined) {
                            element.selectedIndex = state.selectedIndex;
                        }
                    }
                }
            }, formState);
        }
        // Restore scroll positions
        for (const position of state.scrollPositions) {
            if (position.selector === 'window') {
                await this.page.evaluate((pos) => {
                    window.scrollTo(pos.scrollLeft, pos.scrollTop);
                }, position);
            }
            else {
                await this.page.evaluate((pos) => {
                    const element = document.querySelector(pos.selector);
                    if (element) {
                        element.scrollTop = pos.scrollTop;
                        element.scrollLeft = pos.scrollLeft;
                    }
                }, position);
            }
        }
    }
}
exports.StateCapture = StateCapture;
//# sourceMappingURL=stateCapture.js.map