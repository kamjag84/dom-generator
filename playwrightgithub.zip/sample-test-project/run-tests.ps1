# PowerShell script to run Playwright tests with DOM Capture

Write-Host "🚀 Playwright DOM Capture Test Runner" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Check if node_modules exists
if (-not (Test-Path "node_modules")) {
    Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
    npm install
    npx playwright install chromium
}

# Menu for test selection
Write-Host "`n📋 Select Test Suite to Run:" -ForegroundColor Green
Write-Host "1. All Tests (includes failures for DOM capture)"
Write-Host "2. Basic Tests Only"
Write-Host "3. Form Interaction Tests"
Write-Host "4. Advanced Tests"
Write-Host "5. Only Passing Tests"
Write-Host "6. Only Failing Tests (triggers DOM capture)"
Write-Host "7. Tests with Manual Capture Points"
Write-Host "8. Run in UI Mode (Interactive)"
Write-Host "9. Run in Debug Mode"
Write-Host "10. Run with Slow Motion"

$choice = Read-Host "`nEnter your choice (1-10)"

switch ($choice) {
    "1" {
        Write-Host "`n▶️ Running all tests..." -ForegroundColor Green
        npx playwright test
    }
    "2" {
        Write-Host "`n▶️ Running basic tests..." -ForegroundColor Green
        npx playwright test tests/01-basic-tests.spec.ts
    }
    "3" {
        Write-Host "`n▶️ Running form tests..." -ForegroundColor Green
        npx playwright test tests/02-form-tests.spec.ts
    }
    "4" {
        Write-Host "`n▶️ Running advanced tests..." -ForegroundColor Green
        npx playwright test tests/03-advanced-tests.spec.ts
    }
    "5" {
        Write-Host "`n▶️ Running only passing tests..." -ForegroundColor Green
        npx playwright test -g "✅|Successful"
    }
    "6" {
        Write-Host "`n▶️ Running failing tests (will trigger DOM capture)..." -ForegroundColor Yellow
        npx playwright test -g "❌|Failing|failure"
    }
    "7" {
        Write-Host "`n▶️ Running tests with manual capture points..." -ForegroundColor Green
        Write-Host "Press Ctrl+Shift+C during pauses to capture DOM manually!" -ForegroundColor Yellow
        npx playwright test -g "⏸️|manual capture"
    }
    "8" {
        Write-Host "`n▶️ Launching UI Mode..." -ForegroundColor Green
        npx playwright test --ui
    }
    "9" {
        Write-Host "`n▶️ Running in Debug Mode..." -ForegroundColor Green
        npx playwright test --debug
    }
    "10" {
        Write-Host "`n▶️ Running with Slow Motion..." -ForegroundColor Green
        $env:SLOW = "1"
        npx playwright test
        $env:SLOW = ""
    }
    default {
        Write-Host "`n❌ Invalid choice. Running all tests..." -ForegroundColor Red
        npx playwright test
    }
}

Write-Host "`n✅ Test execution completed!" -ForegroundColor Green
Write-Host "`n📊 Check DOM captures in: test-results\dom-captures\" -ForegroundColor Cyan
Write-Host "💡 Use 'DOM Capture: View Last Capture' in VS Code to view captures" -ForegroundColor Cyan

# Ask if user wants to open the HTML report
$openReport = Read-Host "`nOpen HTML test report? (y/n)"
if ($openReport -eq "y") {
    npx playwright show-report
}