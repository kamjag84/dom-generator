/**
 * Playwright Test Integration Module
 * This module provides seamless integration with Playwright tests for DOM capture
 */

import { Page, BrowserContext, test as baseTest } from '@playwright/test';
import { TestCaptureManager } from './playwrightTestHelper';
import * as path from 'path';
import * as fs from 'fs-extra';

// Global flag to track if hotkey listener is installed
let hotkeyListenerInstalled = false;

/**
 * Install global hotkey listener for runtime capture (Ctrl+Shift+C)
 */
export async function installHotkeyListener(page: Page): Promise<void> {
  if (hotkeyListenerInstalled) {
    return;
  }

  await page.addInitScript(() => {
    // Track if capture is in progress to prevent multiple captures
    let isCapturing = false;
    
    // Listen for Ctrl+Shift+C (or Cmd+Shift+C on Mac)
    document.addEventListener('keydown', async (event) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const modifier = isMac ? event.metaKey : event.ctrlKey;
      
      if (modifier && event.shiftKey && event.key === 'C') {
        event.preventDefault();
        event.stopPropagation();
        
        if (isCapturing) {
          console.log('⏳ Capture already in progress...');
          return;
        }
        
        isCapturing = true;
        console.log('📸 Manual DOM Capture triggered via Ctrl+Shift+C');
        
        // Trigger the capture
        try {
          // Send custom event that our test helper will listen for
          window.dispatchEvent(new CustomEvent('dom-capture-requested', {
            detail: {
              timestamp: Date.now(),
              trigger: 'hotkey',
              url: window.location.href,
              title: document.title
            }
          }));
          
          // Visual feedback
          const flash = document.createElement('div');
          flash.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.3);
            z-index: 999999;
            pointer-events: none;
            animation: flash 0.3s ease-out;
          `;
          
          const style = document.createElement('style');
          style.textContent = `
            @keyframes flash {
              0% { opacity: 1; }
              100% { opacity: 0; }
            }
          `;
          document.head.appendChild(style);
          document.body.appendChild(flash);
          
          setTimeout(() => {
            flash.remove();
            style.remove();
          }, 300);
          
        } catch (error) {
          console.error('Failed to trigger DOM capture:', error);
        } finally {
          isCapturing = false;
        }
      }
    });
    
    console.log('✅ DOM Capture hotkey listener installed (Ctrl+Shift+C)');
  });
  
  hotkeyListenerInstalled = true;
}

/**
 * Setup page-level capture listener
 */
export async function setupPageCaptureListener(page: Page): Promise<void> {
  const captureManager = TestCaptureManager.getInstance();
  
  // Listen for capture requests from the page
  await page.exposeFunction('__captureDOM', async (detail: any) => {
    console.log('📸 Processing DOM capture request:', detail);
    
    try {
      const result = await captureManager.captureFromPage(page, {
        captureId: `hotkey_${detail.timestamp}`,
        customMetadata: {
          trigger: detail.trigger,
          url: detail.url,
          title: detail.title
        }
      });
      
      console.log(`✅ DOM captured successfully: ${result.path}`);
      return { success: true, path: result.path };
    } catch (error: any) {
      console.error('❌ DOM capture failed:', error);
      return { success: false, error: error.message };
    }
  });
  
  // Connect the event to the exposed function
  await page.addInitScript(() => {
    window.addEventListener('dom-capture-requested', async (event: any) => {
      // @ts-ignore
      if (window.__captureDOM) {
        // @ts-ignore
        const result = await window.__captureDOM(event.detail);
        if (result.success) {
          console.log('✅ DOM saved to:', result.path);
        } else {
          console.error('❌ Capture failed:', result.error);
        }
      }
    });
  });
}

/**
 * Enhanced Playwright test with automatic DOM capture setup
 */
export const test = baseTest.extend<{
  autoCapture: void;
  captureManager: TestCaptureManager;
}>({
  autoCapture: [async ({ page }, use, testInfo) => {
    console.log('🔧 Setting up DOM Capture for test:', testInfo.title);
    
    // Install hotkey listener
    await installHotkeyListener(page);
    
    // Setup capture listener
    await setupPageCaptureListener(page);
    
    // Initialize capture manager for this test
    const captureManager = TestCaptureManager.getInstance();
    captureManager.setCurrentTest(testInfo);
    
    // Setup automatic capture on failure
    testInfo.attachments.push({
      name: 'dom-capture-enabled',
      contentType: 'text/plain',
      body: Buffer.from('DOM capture is enabled for this test')
    });
    
    // Run the test
    await use();
    
    // Capture on failure
    if (testInfo.status === 'failed') {
      console.log('❌ Test failed, capturing DOM...');
      try {
        const result = await captureManager.captureFromPage(page, {
          captureId: `failure_${Date.now()}`,
          customMetadata: {
            status: 'failed',
            error: testInfo.error?.message || 'Unknown error'
          }
        });
        
        testInfo.attachments.push({
          name: 'dom-capture-on-failure',
          contentType: 'text/html',
          path: result.path
        });
        
        console.log(`📸 Failure DOM captured: ${result.path}`);
      } catch (error) {
        console.error('Failed to capture DOM on test failure:', error);
      }
    }
  }, { auto: true }],
  
  captureManager: async ({}, use) => {
    const manager = TestCaptureManager.getInstance();
    await use(manager);
  }
});

/**
 * Helper function to manually trigger a capture
 */
export async function captureDOM(
  page: Page, 
  name?: string,
  metadata?: Record<string, any>
): Promise<string> {
  const captureManager = TestCaptureManager.getInstance();
  
  const result = await captureManager.captureFromPage(page, {
    captureId: name || `manual_${Date.now()}`,
    customMetadata: metadata
  });
  
  return result.path;
}

/**
 * Setup function for existing test suites
 */
export async function setupDOMCapture(page: Page, context?: BrowserContext): Promise<void> {
  // Install hotkey listener on all pages
  if (context) {
    context.on('page', async (newPage) => {
      await installHotkeyListener(newPage);
      await setupPageCaptureListener(newPage);
    });
  }
  
  // Setup on current page
  await installHotkeyListener(page);
  await setupPageCaptureListener(page);
  
  console.log('✅ DOM Capture setup complete');
}

/**
 * Utility to check if DOM capture is available
 */
export async function isDOMCaptureAvailable(): Promise<boolean> {
  try {
    // Check if the extension is installed
    const extensionPath = path.join(
      process.cwd(),
      'node_modules',
      'playwright-dom-capture'
    );
    
    if (await fs.pathExists(extensionPath)) {
      return true;
    }
    
    // Check if we're in a workspace with the extension
    const workspacePath = path.join(
      process.cwd(),
      'dom-capture'
    );
    
    return await fs.pathExists(workspacePath);
  } catch {
    return false;
  }
}

// Export all utilities
export { TestCaptureManager } from './playwrightTestHelper';
export type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';