import { Page, BrowserContext, test as base, TestInfo, Locator } from '@playwright/test';
import * as path from 'path';
import * as fs from 'fs-extra';
// Advanced serializer components (using available modules)
import { ResourceInliner } from '../domCapture/resourceInliner';
import { StateCapture } from '../domCapture/stateCapture';
import { MetadataCollector } from '../domCapture/metadataCollector';
import { SecurityManager } from '../domCapture/securityManager';
import { CompressionManager } from '../domCapture/compressionManager';

export interface TestCaptureOptions {
  captureId?: string;
  stepName?: string;
  includeAllTabs?: boolean;
  includeScreenshot?: boolean;
  includeVideo?: boolean;
  includeNetworkLog?: boolean;
  redactSensitive?: boolean;
  customMetadata?: Record<string, any>;
}

export interface CaptureResult {
  id: string;
  path: string;
  timestamp: string;
  testName: string;
  stepName?: string;
  url: string;
  tabIndex: number;
  totalTabs: number;
  metadata: any;
}

/**
 * Global capture manager for test runtime
 */
export class TestCaptureManager {
  private static instance: TestCaptureManager;
  private activeCaptures: Map<string, CaptureResult> = new Map();
  private outputDir: string;
  private compressionManager: CompressionManager;
  private securityManager: SecurityManager;
  private captureCount: number = 0;
  private currentTest: TestInfo | null = null;
  private isHotkeyEnabled: boolean = false;

  private constructor() {
    // Use workspace root for consistent path resolution
    const workspaceRoot = this.getWorkspaceRoot();
    this.outputDir = path.join(workspaceRoot, 'test-results', 'dom-captures');
    fs.ensureDirSync(this.outputDir);
    
    this.compressionManager = new CompressionManager(this.outputDir, {
      level: 'medium',
      enableDeduplication: true,
      enableDiffing: true
    });
    
    this.securityManager = new SecurityManager({
      redactPasswords: true,
      redactTokens: true,
      preserveLength: true
    });
  }

  static getInstance(): TestCaptureManager {
    if (!TestCaptureManager.instance) {
      TestCaptureManager.instance = new TestCaptureManager();
    }
    return TestCaptureManager.instance;
  }

  setCurrentTest(testInfo: TestInfo): void {
    this.currentTest = testInfo;
    this.captureCount = 0;
  }

  async captureFromPage(
    page: Page,
    options: TestCaptureOptions = {}
  ): Promise<CaptureResult> {
    this.captureCount++;
    
    const testName = this.currentTest?.title || 'unknown-test';
    const testFile = this.currentTest?.file ? path.basename(this.currentTest.file) : 'unknown-file';
    const className = this.extractClassName(testFile);
    const methodName = this.sanitizeFileName(testName);
    const timestamp = this.formatTimestamp(new Date());
    const captureId = this.sanitizeFileName(options.captureId || `capture_${this.captureCount}_${timestamp}`);
    
    console.log(`📸 Capturing DOM: ${captureId}`);
    
    // Get current URL and title
    const url = page.url();
    const title = await page.title();
    
    // Capture DOM with full state using inline implementation
    const dom = await page.evaluate(() => {
      // Helper to inline styles
      function inlineStyles() {
        const styles = [];
        for (const sheet of document.styleSheets) {
          try {
            const rules = Array.from(sheet.cssRules || []);
            styles.push(rules.map(rule => rule.cssText).join('\n'));
          } catch (e) {
            if (sheet.href) {
              styles.push(`/* External stylesheet: ${sheet.href} */`);
            }
          }
        }
        return styles.join('\n');
      }

      // Clone the document
      const doctype = document.doctype;
      const doctypeString = doctype ? `<!DOCTYPE ${doctype.name}>` : '';
      const html = document.documentElement.cloneNode(true) as HTMLElement;
      
      // Add inline styles
      const styleElement = document.createElement('style');
      styleElement.textContent = inlineStyles();
      html.querySelector('head')?.appendChild(styleElement);

      // Preserve form values
      const inputs = document.querySelectorAll('input, textarea, select');
      const clonedInputs = html.querySelectorAll('input, textarea, select');
      inputs.forEach((input, index) => {
        const clonedInput = clonedInputs[index];
        if (!clonedInput) return;
        
        if (input instanceof HTMLInputElement) {
          if (input.type === 'checkbox' || input.type === 'radio') {
            (clonedInput as HTMLInputElement).checked = input.checked;
          } else {
            (clonedInput as HTMLInputElement).value = input.value;
          }
        } else if (input instanceof HTMLTextAreaElement) {
          (clonedInput as HTMLTextAreaElement).value = input.value;
        } else if (input instanceof HTMLSelectElement) {
          (clonedInput as HTMLSelectElement).selectedIndex = input.selectedIndex;
        }
      });

      return doctypeString + html.outerHTML;
    });
    
    // Capture additional state
    const state = await this.capturePageState(page);
    
    // Capture metadata
    const metadata = await this.captureMetadata(page, options);
    
    // Add test context to metadata
    metadata.testContext = {
      testName,
      testFile,
      stepName: options.stepName,
      captureNumber: this.captureCount,
      timestamp: new Date().toISOString(),
      testStatus: this.currentTest?.status,
      testDuration: this.currentTest?.duration,
      annotations: this.currentTest?.annotations,
      tags: this.currentTest?.tags
    };
    
    // Apply security if requested
    let finalDom = dom;
    if (options.redactSensitive) {
      const { sanitized } = this.securityManager.sanitizeDom(dom);
      finalDom = sanitized;
    }
    
    // Save capture
    const outputPath = await this.saveCapture(captureId, finalDom, metadata, state);
    
    // Take screenshot if requested
    if (options.includeScreenshot) {
      const screenshotPath = outputPath.replace('.html', '_screenshot.png');
      await page.screenshot({ path: screenshotPath, fullPage: true });
      metadata.screenshotPath = screenshotPath;
    }
    
    // Create result
    const result: CaptureResult = {
      id: captureId,
      path: outputPath,
      timestamp: new Date().toISOString(),
      testName,
      stepName: options.stepName,
      url,
      tabIndex: 0,
      totalTabs: 1,
      metadata
    };
    
    this.activeCaptures.set(captureId, result);
    
    console.log(`✅ DOM captured: ${outputPath}`);
    
    return result;
  }

  async captureAllTabs(
    context: BrowserContext,
    options: TestCaptureOptions = {}
  ): Promise<CaptureResult[]> {
    const pages = context.pages();
    const results: CaptureResult[] = [];
    
    console.log(`📸 Capturing DOM from ${pages.length} tab(s)`);
    
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      const tabOptions = {
        ...options,
        captureId: `${options.captureId || 'capture'}_tab_${i}`,
        customMetadata: {
          ...options.customMetadata,
          tabIndex: i,
          totalTabs: pages.length,
          isActiveTab: i === pages.indexOf(context.pages()[0])
        }
      };
      
      const result = await this.captureFromPage(page, tabOptions);
      result.tabIndex = i;
      result.totalTabs = pages.length;
      results.push(result);
    }
    
    return results;
  }

  private async capturePageState(page: Page): Promise<any> {
    return await page.evaluate(() => {
      return {
        // Scroll positions
        scrollPositions: {
          window: { x: window.scrollX, y: window.scrollY },
          elements: Array.from(document.querySelectorAll('*')).filter(el => {
            const elem = el as HTMLElement;
            return elem.scrollHeight > elem.clientHeight || elem.scrollWidth > elem.clientWidth;
          }).map(el => {
            const elem = el as HTMLElement;
            return {
              selector: elem.tagName + (elem.id ? `#${elem.id}` : ''),
              scrollTop: elem.scrollTop,
              scrollLeft: elem.scrollLeft
            };
          })
        },
        
        // Form data
        formData: Array.from(document.querySelectorAll('input, textarea, select')).map(el => {
          const elem = el as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
          return {
            selector: elem.tagName + (elem.id ? `#${elem.id}` : ''),
            type: elem.type || elem.tagName.toLowerCase(),
            value: elem.value,
            checked: (elem as HTMLInputElement).checked,
            selectedIndex: (elem as HTMLSelectElement).selectedIndex
          };
        }),
        
        // Storage
        localStorage: { ...localStorage },
        sessionStorage: { ...sessionStorage },
        
        // Cookies
        cookies: document.cookie,
        
        // Window dimensions
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
          devicePixelRatio: window.devicePixelRatio
        }
      };
    });
  }

  private async captureMetadata(page: Page, options: TestCaptureOptions): Promise<any> {
    const metrics = await page.evaluate(() => {
      const perf = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      const resources = performance.getEntriesByType('resource');
      
      return {
        url: window.location.href,
        title: document.title,
        referrer: document.referrer,
        navigation: {
          loadTime: perf?.loadEventEnd - perf?.fetchStart,
          domContentLoaded: perf?.domContentLoadedEventEnd - perf?.fetchStart,
          domInteractive: perf?.domInteractive - perf?.fetchStart
        },
        resources: {
          count: resources.length,
          totalSize: resources.reduce((sum, r: any) => sum + (r.transferSize || 0), 0)
        },
        memory: (performance as any).memory ? {
          usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
          totalJSHeapSize: (performance as any).memory.totalJSHeapSize
        } : null
      };
    });
    
    return {
      ...metrics,
      captureOptions: options,
      customMetadata: options.customMetadata,
      timestamp: new Date().toISOString()
    };
  }

  private async saveCapture(
    captureId: string,
    dom: string,
    metadata: any,
    state: any
  ): Promise<string> {
    const date = new Date();
    const dateFolder = this.formatDateFolder(date);
    
    // Extract class name from test file and method name from test title
    const testFile = this.currentTest?.file ? path.basename(this.currentTest.file) : 'unknown-file';
    const className = this.extractClassName(testFile);
    const methodName = this.sanitizeName(this.currentTest?.title || 'unknown-test');
    const testFolder = `${className}_${methodName}`;
    
    const outputDir = path.join(this.outputDir, dateFolder, testFolder);
    await fs.ensureDir(outputDir);
    
    const fileName = `${captureId}.html`;
    const filePath = path.join(outputDir, fileName);
    
    // Embed metadata and state in the HTML
    const enhancedDom = dom.replace('</head>', `
      <script type="application/json" id="dom-capture-metadata">
        ${JSON.stringify(metadata, null, 2)}
      </script>
      <script type="application/json" id="dom-capture-state">
        ${JSON.stringify(state, null, 2)}
      </script>
      </head>
    `);
    
    await fs.writeFile(filePath, enhancedDom, 'utf-8');
    
    // Save metadata in the same test folder
    const metadataPath = filePath.replace('.html', '_metadata.json');
    await fs.writeJson(metadataPath, { 
      metadata, 
      state,
      testContext: {
        className: className,
        methodName: methodName,
        testFile: testFile,
        captureId: captureId
      }
    }, { spaces: 2 });
    
    return filePath;
  }

  private getWorkspaceRoot(): string {
    // Try to find workspace root
    const cwd = process.cwd();
    
    // Check for common project indicators
    const indicators = ['package.json', 'playwright.config.ts', 'playwright.config.js', '.git'];
    let currentPath = cwd;
    
    while (currentPath !== path.dirname(currentPath)) {
      for (const indicator of indicators) {
        if (fs.existsSync(path.join(currentPath, indicator))) {
          return currentPath;
        }
      }
      currentPath = path.dirname(currentPath);
    }
    
    return cwd; // Fallback to current working directory
  }

  private extractClassName(testFileName: string): string {
    // Remove extension and sanitize
    // e.g., 'login.spec.ts' -> 'login_spec'
    return testFileName
      .replace(/\.(spec|test)\.(ts|js)$/, '')
      .replace(/[^a-zA-Z0-9]/g, '_');
  }

  private sanitizeName(name: string): string {
    // Replace spaces and special characters with underscores
    return name.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 100);
  }

  /**
   * Sanitize file names to prevent path traversal and invalid characters
   */
  private sanitizeFileName(name: string): string {
    // Remove path traversal attempts
    let sanitized = name
      .replace(/\.\./g, '')
      .replace(/[\/\\]/g, '_');
    
    // Remove invalid filename characters for all platforms
    const invalidChars = /[<>:"|?*\x00-\x1F]/g;
    sanitized = sanitized.replace(invalidChars, '_');
    
    // Remove leading/trailing dots and spaces
    sanitized = sanitized.replace(/^[\s.]+|[\s.]+$/g, '');
    
    // Limit length to prevent filesystem issues
    const maxLength = 200;
    if (sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength);
    }
    
    // Ensure we have a valid filename
    if (!sanitized || sanitized === '_') {
      sanitized = `capture_${Date.now()}`;
    }
    
    return sanitized;
  }

  private formatDateFolder(date: Date): string {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  private formatTimestamp(date: Date): string {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${hours}-${minutes}-${seconds}`;
  }

  async enableHotkeyCapture(page: Page): Promise<void> {
    if (this.isHotkeyEnabled) return;
    
    // Clean up any existing interval
    const existingInterval = (page as any).__captureInterval;
    if (existingInterval) {
      clearInterval(existingInterval);
    }
    
    await page.addInitScript(() => {
      // Listen for Ctrl+Shift+C
      document.addEventListener('keydown', async (event) => {
        if (event.ctrlKey && event.shiftKey && event.key === 'C') {
          event.preventDefault();
          event.stopPropagation();
          
          // Signal to capture
          (window as any).__triggerDomCapture = true;
          console.log('🎯 DOM Capture triggered by hotkey!');
          
          // Visual feedback
          const indicator = document.createElement('div');
          indicator.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            z-index: 999999;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            animation: slideIn 0.3s ease-out;
          `;
          indicator.innerHTML = '📸 DOM Capture in progress...';
          document.body.appendChild(indicator);
          
          setTimeout(() => {
            indicator.innerHTML = '✅ DOM Captured!';
            indicator.style.background = '#2196F3';
            setTimeout(() => indicator.remove(), 2000);
          }, 1000);
        }
      }, true);
      
      // Add animation
      const style = document.createElement('style');
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `;
      document.head.appendChild(style);
    });
    
    // Poll for capture trigger
    const checkInterval = setInterval(async () => {
      const shouldCapture = await page.evaluate(() => {
        const trigger = (window as any).__triggerDomCapture;
        if (trigger) {
          (window as any).__triggerDomCapture = false;
          return true;
        }
        return false;
      });
      
      if (shouldCapture) {
        await this.captureFromPage(page, {
          stepName: 'Hotkey Capture',
          includeScreenshot: true
        });
      }
    }, 100);
    
    // Store interval for cleanup
    (page as any).__captureInterval = checkInterval;
    
    this.isHotkeyEnabled = true;
  }

  getCaptureHistory(): CaptureResult[] {
    return Array.from(this.activeCaptures.values());
  }

  clearHistory(): void {
    this.activeCaptures.clear();
    this.captureCount = 0;
  }
  
  /**
   * Cleanup method to prevent memory leaks
   */
  async cleanup(page: Page): Promise<void> {
    // Clear the capture interval if it exists
    const interval = (page as any).__captureInterval;
    if (interval) {
      clearInterval(interval);
      delete (page as any).__captureInterval;
    }
    
    // Reset the hotkey flag
    this.isHotkeyEnabled = false;
    
    // Clear any pending captures
    try {
      await page.evaluate(() => {
        (window as any).__triggerDomCapture = false;
      });
    } catch {
      // Page might be closed already
    }
  }
  
  /**
   * Dispose all resources
   */
  dispose(): void {
    this.clearHistory();
    this.isHotkeyEnabled = false;
  }
}

/**
 * Enhanced Playwright test fixture with DOM capture
 */
export const test = base.extend<{
  domCapture: (options?: TestCaptureOptions) => Promise<CaptureResult>;
  enableHotkeyCapture: () => Promise<void>;
  captureAllTabs: (options?: TestCaptureOptions) => Promise<CaptureResult[]>;
  captureManager: TestCaptureManager;
}>({
  captureManager: async ({}, use) => {
    const manager = TestCaptureManager.getInstance();
    await use(manager);
  },

  domCapture: async ({ page, captureManager }, use, testInfo) => {
    captureManager.setCurrentTest(testInfo);
    
    const captureFunction = async (options?: TestCaptureOptions) => {
      return await captureManager.captureFromPage(page, options);
    };
    
    await use(captureFunction);
  },

  enableHotkeyCapture: async ({ page, captureManager }, use, testInfo) => {
    captureManager.setCurrentTest(testInfo);
    
    const enableFunction = async () => {
      await captureManager.enableHotkeyCapture(page);
      console.log('🎯 Hotkey capture enabled! Press Ctrl+Shift+C to capture DOM');
    };
    
    await use(enableFunction);
  },

  captureAllTabs: async ({ context, captureManager }, use, testInfo) => {
    captureManager.setCurrentTest(testInfo);
    
    const captureFunction = async (options?: TestCaptureOptions) => {
      return await captureManager.captureAllTabs(context, options);
    };
    
    await use(captureFunction);
  }
});

export { expect } from '@playwright/test';

/**
 * Helper function to capture DOM at any point in test
 */
export async function captureDom(
  page: Page,
  stepName?: string,
  options?: TestCaptureOptions
): Promise<CaptureResult> {
  const manager = TestCaptureManager.getInstance();
  return await manager.captureFromPage(page, {
    stepName,
    ...options
  });
}

/**
 * Decorator to automatically capture DOM on test failure
 */
export function captureOnFailure(testFunction: any) {
  return async function(...args: any[]) {
    try {
      return await testFunction(...args);
    } catch (error) {
      const page = args.find(arg => arg.constructor.name === 'Page');
      if (page) {
        console.log('❌ Test failed - Capturing DOM automatically');
        await captureDom(page, 'Test Failure', {
          includeScreenshot: true,
          redactSensitive: true
        });
      }
      throw error;
    }
  };
}