import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { Logger } from './utils/logger';

/**
 * Enhanced Project Configurator for DOM Capture
 * Handles complete setup and rollback of DOM capture in Playwright projects
 */
export class EnhancedProjectConfigurator {
    private logger: Logger;
    private readonly BACKUP_DIR = '.dom-capture-backup';
    private readonly DOM_CAPTURE_DIR = 'dom-capture';
    private readonly CONFIG_MANIFEST_FILE = '.dom-capture-manifest.json';
    
    constructor(private context: vscode.ExtensionContext) {
        this.logger = Logger.getInstance();
    }

    /**
     * Complete auto-configuration of a Playwright project
     */
    async autoConfigureProject(workspacePath: string): Promise<void> {
        this.logger.info(`Starting auto-configuration for: ${workspacePath}`);
        
        // Track all created files/folders for rollback
        const manifest: ConfigurationManifest = {
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            workspacePath,
            createdFiles: [],
            createdFolders: [],
            modifiedFiles: [],
            backupLocation: path.join(workspacePath, this.BACKUP_DIR)
        };

        try {
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Configuring Playwright DOM Capture',
                cancellable: false
            }, async (progress) => {
                
                // Step 1: Validate environment
                progress.report({ increment: 10, message: 'Validating Playwright project...' });
                await this.validateProject(workspacePath);
                
                // Step 2: Create backup
                progress.report({ increment: 10, message: 'Creating backup...' });
                await this.createBackup(workspacePath, manifest);
                
                // Step 3: Create dom-capture directory structure
                progress.report({ increment: 20, message: 'Setting up DOM capture utilities...' });
                await this.setupDomCaptureDirectory(workspacePath, manifest);
                
                // Step 4: Copy integration files
                progress.report({ increment: 20, message: 'Installing integration files...' });
                await this.copyIntegrationFiles(workspacePath, manifest);
                
                // Step 5: Create example tests
                progress.report({ increment: 10, message: 'Creating example tests...' });
                await this.createExampleTests(workspacePath, manifest);
                
                // Step 6: Update Playwright config if needed
                progress.report({ increment: 10, message: 'Updating configuration...' });
                await this.updatePlaywrightConfig(workspacePath, manifest);
                
                // Step 7: Save manifest for rollback
                progress.report({ increment: 10, message: 'Saving configuration manifest...' });
                await this.saveManifest(workspacePath, manifest);
                
                // Step 8: Create documentation
                progress.report({ increment: 10, message: 'Creating documentation...' });
                await this.createDocumentation(workspacePath, manifest);
                
                progress.report({ increment: 100, message: 'Configuration complete!' });
            });

            // Show success message with next steps
            const selection = await vscode.window.showInformationMessage(
                '✅ DOM Capture configured successfully!',
                'View Instructions',
                'Run Example Test',
                'Close'
            );

            if (selection === 'View Instructions') {
                const docPath = path.join(workspacePath, 'DOM_CAPTURE_GUIDE.md');
                const doc = await vscode.workspace.openTextDocument(docPath);
                await vscode.window.showTextDocument(doc);
            } else if (selection === 'Run Example Test') {
                const terminal = vscode.window.createTerminal('DOM Capture Test');
                terminal.show();
                terminal.sendText(`cd "${workspacePath}"`);
                terminal.sendText('npx playwright test dom-capture-example.spec.ts --headed');
            }

        } catch (error) {
            this.logger.error('Auto-configuration failed:', error);
            
            // Attempt rollback on failure
            try {
                await this.rollbackConfiguration(workspacePath);
            } catch (rollbackError) {
                this.logger.error('Rollback failed:', rollbackError);
            }
            
            throw error;
        }
    }

    /**
     * Validate that this is a Playwright project
     */
    private async validateProject(workspacePath: string): Promise<void> {
        const packageJsonPath = path.join(workspacePath, 'package.json');
        
        if (!await fs.pathExists(packageJsonPath)) {
            throw new Error('No package.json found. Is this a Node.js project?');
        }

        const packageJson = await fs.readJson(packageJsonPath);
        const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
        
        if (!deps['@playwright/test'] && !deps['playwright']) {
            const install = await vscode.window.showWarningMessage(
                'Playwright is not installed. Would you like to install it?',
                'Install Playwright',
                'Cancel'
            );
            
            if (install === 'Install Playwright') {
                await this.installPlaywright(workspacePath);
            } else {
                throw new Error('Playwright is required for DOM Capture');
            }
        }

        // Check for Playwright config
        const configFiles = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs'];
        const hasConfig = await Promise.all(configFiles.map(f => fs.pathExists(path.join(workspacePath, f))));
        
        if (!hasConfig.some(exists => exists)) {
            this.logger.warn('No Playwright config found. Will create one.');
        }
    }

    /**
     * Create backup of existing configuration
     */
    private async createBackup(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const backupDir = path.join(workspacePath, this.BACKUP_DIR);
        await fs.ensureDir(backupDir);
        manifest.createdFolders.push(this.BACKUP_DIR);

        const filesToBackup = [
            'playwright.config.ts',
            'playwright.config.js',
            'playwright.config.mjs',
            'package.json',
            'tsconfig.json'
        ];

        for (const file of filesToBackup) {
            const filePath = path.join(workspacePath, file);
            if (await fs.pathExists(filePath)) {
                const backupPath = path.join(backupDir, `${file}.backup`);
                await fs.copy(filePath, backupPath);
                manifest.modifiedFiles.push(file);
            }
        }

        // Save backup metadata
        const metadata = {
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            files: manifest.modifiedFiles
        };
        await fs.writeJson(path.join(backupDir, 'metadata.json'), metadata, { spaces: 2 });
    }

    /**
     * Setup dom-capture directory with all necessary files
     */
    private async setupDomCaptureDirectory(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const domCapturePath = path.join(workspacePath, this.DOM_CAPTURE_DIR);
        await fs.ensureDir(domCapturePath);
        manifest.createdFolders.push(this.DOM_CAPTURE_DIR);

        // Create subdirectories
        const subdirs = ['utils', 'helpers', 'config'];
        for (const subdir of subdirs) {
            const subdirPath = path.join(domCapturePath, subdir);
            await fs.ensureDir(subdirPath);
            manifest.createdFolders.push(path.join(this.DOM_CAPTURE_DIR, subdir));
        }
    }

    /**
     * Copy all integration files from extension to project
     */
    private async copyIntegrationFiles(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const domCapturePath = path.join(workspacePath, this.DOM_CAPTURE_DIR);
        const extensionPath = this.context.extensionPath;

        // Try multiple source locations (compiled output first, then source)
        const sourceLocations = ['out', 'dist', 'src'];
        
        // Files to copy from extension
        const filesToCopy = [
            // Main integration file
            {
                source: 'testIntegration/playwrightIntegration',
                dest: 'playwrightIntegration'
            },
            // Test helper
            {
                source: 'testIntegration/playwrightTestHelper',
                dest: 'playwrightTestHelper'
            },
            // Utilities
            {
                source: 'domCapture/compressionManager',
                dest: 'utils/compressionManager'
            },
            {
                source: 'domCapture/securityManager',
                dest: 'utils/securityManager'
            },
            {
                source: 'domCapture/stateCapture',
                dest: 'utils/stateCapture'
            },
            {
                source: 'domCapture/resourceInliner',
                dest: 'utils/resourceInliner'
            },
            {
                source: 'domCapture/metadataCollector',
                dest: 'utils/metadataCollector'
            }
        ];

        for (const file of filesToCopy) {
            let copied = false;
            
            // Try to find and copy the file from various locations
            for (const location of sourceLocations) {
                for (const ext of ['.js', '.ts']) {
                    const sourcePath = path.join(extensionPath, location, file.source + ext);
                    const destPath = path.join(domCapturePath, file.dest + ext);
                    
                    if (await fs.pathExists(sourcePath)) {
                        await fs.ensureDir(path.dirname(destPath));
                        await fs.copy(sourcePath, destPath);
                        manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, file.dest + ext));
                        this.logger.info(`Copied: ${file.dest}${ext} from ${location}`);
                        copied = true;
                        break;
                    }
                }
                if (copied) break;
            }
            
            if (!copied) {
                this.logger.warn(`Could not find source file for: ${file.source}`);
                // Create a stub file with import instructions
                const stubPath = path.join(domCapturePath, file.dest + '.ts');
                await fs.ensureDir(path.dirname(stubPath));
                await fs.writeFile(stubPath, this.createStubContent(file.dest));
                manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, file.dest + '.ts'));
            }
        }

        // Create configuration file
        const configPath = path.join(domCapturePath, 'config', 'dom-capture.config.json');
        const config = {
            version: '1.0.0',
            autoCapture: true,
            captureOnFailure: true,
            hotkey: 'Ctrl+Shift+C',
            outputPath: '../test-results/dom-captures',
            compressionLevel: 'medium',
            includeMetadata: true,
            includeScreenshot: true,
            retentionDays: 7
        };
        await fs.writeJson(configPath, config, { spaces: 2 });
        manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, 'config', 'dom-capture.config.json'));

        // Create index file for easier imports
        const indexContent = `/**
 * DOM Capture Integration for Playwright
 * Auto-generated by Playwright DOM Capture Extension
 */

export { test, captureDOM, setupDOMCapture } from './playwrightIntegration';
export { TestCaptureManager } from './playwrightTestHelper';
export type { TestCaptureOptions, CaptureResult } from './playwrightTestHelper';

// Re-export Playwright expect for convenience
export { expect } from '@playwright/test';
`;
        await fs.writeFile(path.join(domCapturePath, 'index.ts'), indexContent);
        manifest.createdFiles.push(path.join(this.DOM_CAPTURE_DIR, 'index.ts'));
    }

    /**
     * Create example test files
     */
    private async createExampleTests(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const exampleContent = `/**
 * Example test with DOM Capture enabled
 * Press Ctrl+Shift+C during test execution to capture DOM
 */

import { test, expect } from './dom-capture';

test.describe('DOM Capture Example Tests', () => {
    test('basic navigation with capture', async ({ page }) => {
        // DOM capture is automatically enabled
        await page.goto('https://example.com');
        
        // The page title should contain "Example"
        await expect(page).toHaveTitle(/Example/);
        
        // Press Ctrl+Shift+C in the browser to capture DOM at any point!
    });

    test('capture on failure (intentional)', async ({ page }) => {
        await page.goto('https://example.com');
        
        // This will fail and automatically capture DOM
        await expect(page.locator('#non-existent')).toBeVisible();
    });

    test('manual capture example', async ({ page }) => {
        await page.goto('https://example.com');
        
        // Trigger manual capture
        await page.evaluate(() => {
            window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                detail: { trigger: 'manual', timestamp: Date.now() }
            }));
        });
        
        // Continue with test...
        await expect(page).toHaveTitle(/Example/);
    });
});
`;

        const examplePath = path.join(workspacePath, 'dom-capture-example.spec.ts');
        await fs.writeFile(examplePath, exampleContent);
        manifest.createdFiles.push('dom-capture-example.spec.ts');
    }

    /**
     * Update Playwright configuration to include DOM capture
     */
    private async updatePlaywrightConfig(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        // Find existing config
        const configFiles = ['playwright.config.ts', 'playwright.config.js', 'playwright.config.mjs'];
        let configPath = '';
        
        for (const file of configFiles) {
            const filePath = path.join(workspacePath, file);
            if (await fs.pathExists(filePath)) {
                configPath = filePath;
                break;
            }
        }

        if (!configPath) {
            // Create a new config
            configPath = path.join(workspacePath, 'playwright.config.ts');
            const configContent = `import { defineConfig } from '@playwright/test';

export default defineConfig({
    testDir: './tests',
    timeout: 30000,
    fullyParallel: true,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: process.env.CI ? 1 : undefined,
    reporter: 'html',
    use: {
        actionTimeout: 0,
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
        video: 'retain-on-failure',
    },
    projects: [
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'] },
        },
    ],
});
`;
            await fs.writeFile(configPath, configContent);
            manifest.createdFiles.push('playwright.config.ts');
        }

        // Note: We don't modify existing configs to avoid breaking user setup
        this.logger.info('Playwright config checked/created');
    }

    /**
     * Create documentation for the user
     */
    private async createDocumentation(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const docContent = `# 🎭 DOM Capture - Setup Complete!

## ✅ Installation Successful

Your Playwright project has been configured with DOM Capture capabilities.

## 🚀 Quick Start

### Running Tests with DOM Capture

\`\`\`bash
# Run the example test
npx playwright test dom-capture-example.spec.ts --headed

# Run any test with DOM capture enabled
npx playwright test --headed
\`\`\`

### Using DOM Capture in Your Tests

1. **Import the enhanced test fixture:**
\`\`\`typescript
import { test, expect } from './dom-capture';
\`\`\`

2. **Write your tests normally - DOM capture is automatic!**

### 📸 Capture Methods

#### Method 1: Hotkey Capture (Recommended)
- Run tests in headed mode: \`--headed\`
- Press **Ctrl+Shift+C** in the browser at any point
- You'll see a visual flash confirming capture

#### Method 2: Automatic on Failure
- Tests automatically capture DOM when they fail
- No code changes needed!

#### Method 3: Programmatic Capture
\`\`\`typescript
await page.evaluate(() => {
    window.dispatchEvent(new CustomEvent('dom-capture-requested', {
        detail: { trigger: 'manual', timestamp: Date.now() }
    }));
});
\`\`\`

## 📁 Capture Location

\`\`\`
test-results/
└── dom-captures/
    └── [date]/
        └── [test-name]/
            ├── capture_*.html
            └── capture_*_metadata.json
\`\`\`

## 🔧 Configuration

Edit \`dom-capture/config/dom-capture.config.json\` to customize:
- Auto-capture settings
- Compression level
- Retention period
- Output directory

## 🔄 Rollback

To remove DOM Capture from your project:
1. Press \`Ctrl+Shift+P\`
2. Run: "DOM Capture: Rollback Configuration"

## 📚 Files Created

The following files were added to your project:
${manifest.createdFiles.map(f => `- ${f}`).join('\n')}

## 🆘 Troubleshooting

- **Captures not appearing?** Check \`test-results/dom-captures/\`
- **Hotkey not working?** Ensure tests run in headed mode
- **Need help?** Run: "DOM Capture: Show Diagnostics"

---
*Created by Playwright DOM Capture Extension v1.0.0*
`;

        const docPath = path.join(workspacePath, 'DOM_CAPTURE_GUIDE.md');
        await fs.writeFile(docPath, docContent);
        manifest.createdFiles.push('DOM_CAPTURE_GUIDE.md');
    }

    /**
     * Save manifest for rollback purposes
     */
    private async saveManifest(workspacePath: string, manifest: ConfigurationManifest): Promise<void> {
        const manifestPath = path.join(workspacePath, this.CONFIG_MANIFEST_FILE);
        await fs.writeJson(manifestPath, manifest, { spaces: 2 });
        // Don't add to manifest.createdFiles as it should persist for rollback
    }

    /**
     * Create stub content for missing files
     */
    private createStubContent(moduleName: string): string {
        const baseModule = moduleName.split('/').pop() || moduleName;
        
        // Create appropriate stub based on module name
        if (moduleName.includes('playwrightIntegration')) {
            return `/**
 * Playwright DOM Capture Integration
 * Auto-generated stub - Replace with actual implementation
 */

import { test as base, expect } from '@playwright/test';
import type { Page, Browser, BrowserContext } from '@playwright/test';

// Enhanced test fixture with DOM capture
export const test = base.extend({
    page: async ({ page }, use) => {
        // Setup DOM capture
        await setupDOMCapture(page);
        await use(page);
    }
});

export async function setupDOMCapture(page: Page): Promise<void> {
    // Install hotkey listener for Ctrl+Shift+C
    await page.addInitScript(() => {
        document.addEventListener('keydown', async (event) => {
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const modifier = isMac ? event.metaKey : event.ctrlKey;
            
            if (modifier && event.shiftKey && event.key === 'C') {
                event.preventDefault();
                
                // Trigger DOM capture
                window.dispatchEvent(new CustomEvent('dom-capture-requested', {
                    detail: { 
                        trigger: 'hotkey',
                        timestamp: Date.now()
                    }
                }));
                
                // Visual feedback
                const flash = document.createElement('div');
                flash.style.cssText = \`
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 255, 0, 0.2);
                    z-index: 999999;
                    pointer-events: none;
                \`;
                document.body.appendChild(flash);
                setTimeout(() => flash.remove(), 200);
            }
        });
        
        // Listen for capture events
        window.addEventListener('dom-capture-requested', async (event) => {
            console.log('📸 DOM Capture triggered:', event.detail);
            // Capture logic will be handled by test helper
        });
    });
}

export async function captureDOM(page: Page, options?: any): Promise<void> {
    const timestamp = Date.now();
    const html = await page.content();
    
    // Save DOM content
    const fs = require('fs');
    const path = require('path');
    const outputDir = path.join(process.cwd(), 'test-results', 'dom-captures');
    
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const fileName = \`capture_\${timestamp}.html\`;
    const filePath = path.join(outputDir, fileName);
    fs.writeFileSync(filePath, html);
    
    console.log(\`✅ DOM captured: \${fileName}\`);
}

export { expect };
`;
        }
        
        if (moduleName.includes('playwrightTestHelper')) {
            return `/**
 * Playwright Test Helper for DOM Capture
 * Auto-generated stub
 */

export interface TestCaptureOptions {
    autoCapture?: boolean;
    captureOnFailure?: boolean;
    outputPath?: string;
}

export interface CaptureResult {
    success: boolean;
    filePath?: string;
    error?: string;
}

export class TestCaptureManager {
    private options: TestCaptureOptions;
    
    constructor(options: TestCaptureOptions = {}) {
        this.options = {
            autoCapture: true,
            captureOnFailure: true,
            outputPath: 'test-results/dom-captures',
            ...options
        };
    }
    
    async capture(page: any, reason: string): Promise<CaptureResult> {
        try {
            const html = await page.content();
            const timestamp = Date.now();
            const fileName = \`capture_\${reason}_\${timestamp}.html\`;
            
            // Save capture
            const fs = require('fs');
            const path = require('path');
            const filePath = path.join(this.options.outputPath!, fileName);
            
            if (!fs.existsSync(this.options.outputPath!)) {
                fs.mkdirSync(this.options.outputPath!, { recursive: true });
            }
            
            fs.writeFileSync(filePath, html);
            
            return {
                success: true,
                filePath
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
`;
        }
        
        // Default stub for utilities
        return `/**
 * ${baseModule} - DOM Capture Utility
 * Auto-generated stub
 */

export class ${baseModule.charAt(0).toUpperCase() + baseModule.slice(1)} {
    constructor() {
        // Implementation needed
    }
}

export default ${baseModule.charAt(0).toUpperCase() + baseModule.slice(1)};
`;
    }

    /**
     * Install Playwright if not present
     */
    private async installPlaywright(workspacePath: string): Promise<void> {
        const terminal = vscode.window.createTerminal('Install Playwright');
        terminal.show();
        terminal.sendText(`cd "${workspacePath}"`);
        terminal.sendText('npm install --save-dev @playwright/test');
        terminal.sendText('npx playwright install');
        
        // Wait for installation
        await new Promise(resolve => setTimeout(resolve, 30000));
    }

    /**
     * Complete rollback of all DOM Capture configuration
     */
    async rollbackConfiguration(workspacePath: string): Promise<void> {
        this.logger.info(`Starting rollback for: ${workspacePath}`);
        
        try {
            // Load manifest
            const manifestPath = path.join(workspacePath, this.CONFIG_MANIFEST_FILE);
            if (!await fs.pathExists(manifestPath)) {
                throw new Error('No configuration manifest found. Cannot rollback.');
            }

            const manifest: ConfigurationManifest = await fs.readJson(manifestPath);
            
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'Rolling back DOM Capture configuration',
                cancellable: false
            }, async (progress) => {
                
                // Step 1: Remove created files
                progress.report({ increment: 30, message: 'Removing created files...' });
                for (const file of manifest.createdFiles) {
                    const filePath = path.join(workspacePath, file);
                    if (await fs.pathExists(filePath)) {
                        await fs.remove(filePath);
                        this.logger.info(`Removed file: ${file}`);
                    }
                }

                // Step 2: Remove created folders (in reverse order to handle nested folders)
                progress.report({ increment: 30, message: 'Removing created folders...' });
                const foldersToRemove = manifest.createdFolders.sort().reverse();
                for (const folder of foldersToRemove) {
                    const folderPath = path.join(workspacePath, folder);
                    if (await fs.pathExists(folderPath)) {
                        // Only remove if empty or if it's the dom-capture folder
                        if (folder === this.DOM_CAPTURE_DIR || folder.startsWith(this.DOM_CAPTURE_DIR)) {
                            await fs.remove(folderPath);
                            this.logger.info(`Removed folder: ${folder}`);
                        } else {
                            // Check if folder is empty before removing
                            const contents = await fs.readdir(folderPath);
                            if (contents.length === 0) {
                                await fs.remove(folderPath);
                                this.logger.info(`Removed empty folder: ${folder}`);
                            }
                        }
                    }
                }

                // Step 3: Restore backed up files
                progress.report({ increment: 30, message: 'Restoring original files...' });
                const backupDir = path.join(workspacePath, this.BACKUP_DIR);
                if (await fs.pathExists(backupDir)) {
                    for (const file of manifest.modifiedFiles) {
                        const backupPath = path.join(backupDir, `${file}.backup`);
                        const originalPath = path.join(workspacePath, file);
                        
                        if (await fs.pathExists(backupPath)) {
                            await fs.copy(backupPath, originalPath, { overwrite: true });
                            this.logger.info(`Restored: ${file}`);
                        }
                    }
                    
                    // Remove backup directory
                    await fs.remove(backupDir);
                }

                // Step 4: Remove manifest file
                progress.report({ increment: 10, message: 'Cleaning up...' });
                await fs.remove(manifestPath);
                
                progress.report({ increment: 100, message: 'Rollback complete!' });
            });

            vscode.window.showInformationMessage('✅ DOM Capture configuration has been rolled back successfully.');
            
        } catch (error) {
            this.logger.error('Rollback failed:', error);
            vscode.window.showErrorMessage(`Rollback failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
            throw error;
        }
    }
}

/**
 * Configuration manifest for tracking changes
 */
interface ConfigurationManifest {
    version: string;
    timestamp: string;
    workspacePath: string;
    createdFiles: string[];
    createdFolders: string[];
    modifiedFiles: string[];
    backupLocation: string;
}