export interface SecurityOptions {
  redactPasswords: boolean;
  redactTokens: boolean;
  redactEmails: boolean;
  redactPhoneNumbers: boolean;
  redactCreditCards: boolean;
  redactSSN: boolean;
  redactCustomPatterns: RegExp[];
  maskCharacter: string;
  preserveLength: boolean;
  whitelist: string[];
  blacklist: string[];
}

export interface PIIDetectionResult {
  type: string;
  count: number;
  locations: Array<{
    path: string;
    line?: number;
    column?: number;
  }>;
}

export class SecurityManager {
  private options: SecurityOptions;
  private piiPatterns: Map<string, RegExp>;
  private redactedCount: Map<string, number> = new Map();

  constructor(options: Partial<SecurityOptions> = {}) {
    this.options = {
      redactPasswords: true,
      redactTokens: true,
      redactEmails: true,
      redactPhoneNumbers: true,
      redactCreditCards: true,
      redactSSN: true,
      redactCustomPatterns: [],
      maskCharacter: '*',
      preserveLength: true,
      whitelist: [],
      blacklist: [],
      ...options
    };

    this.piiPatterns = this.initializePatterns();
  }

  private initializePatterns(): Map<string, RegExp> {
    const patterns = new Map<string, RegExp>();

    // Email pattern
    patterns.set('email', /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g);

    // Phone numbers (various formats)
    patterns.set('phone', /(\+?[1-9]\d{0,2}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g);

    // Credit card numbers
    patterns.set('creditCard', /\b(?:\d{4}[-\s]?){3}\d{4}\b/g);

    // Social Security Numbers
    patterns.set('ssn', /\b\d{3}-\d{2}-\d{4}\b/g);

    // API tokens and keys (common patterns)
    patterns.set('apiKey', /\b(api[_-]?key|apikey|api[_-]?token|access[_-]?token|auth[_-]?token|authentication[_-]?token|bearer)\s*[:=]\s*["']?[a-zA-Z0-9\-._~+/]{20,}["']?/gi);

    // JWT tokens
    patterns.set('jwt', /\beyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\b/g);

    // AWS keys
    patterns.set('awsKey', /\b(AKIA|A3T|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}\b/g);

    // Private keys
    patterns.set('privateKey', /-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----[\s\S]+?-----END\s+(RSA\s+)?PRIVATE\s+KEY-----/g);

    // Password fields and values
    patterns.set('password', /(<input[^>]*type\s*=\s*["']password["'][^>]*value\s*=\s*["'])([^"']+)(["'])/gi);

    // Authorization headers
    patterns.set('authHeader', /(authorization|auth|bearer|token)\s*[:=]\s*["']?([a-zA-Z0-9\-._~+/=]+)["']?/gi);

    // Database connection strings - Enhanced patterns
    patterns.set('connectionString', 
      /((mongodb(\+srv)?|postgres(ql)?|mysql|mariadb|redis|amqp|rabbitmq|kafka|elasticsearch|cassandra|couchdb|influxdb|clickhouse|mssql|oracle|db2|sqlite|neo4j|arangodb|cosmosdb|dynamodb|firestore|firebase):\/\/[^\s<>"']+)|((Server|Data Source|User ID|Password|Database|Integrated Security)\s*=\s*[^;]+)/gi
    );
    
    // Additional database patterns
    patterns.set('sqlServerConnString', 
      /Server\s*=\s*[^;]+;.*?(Database|Initial Catalog)\s*=\s*[^;]+;.*?(User ID|UID|Integrated Security|Trusted_Connection)/gi
    );
    
    // Redis connection patterns
    patterns.set('redisConnString',
      /(redis:\/\/(?::[^@]+@)?[^\/\s]+(?::\d+)?(?:\/\d+)?)|(\bredis\s*=\s*["']?[^"'\s]+["']?)/gi
    );
    
    // Cloud service connection strings
    patterns.set('azureConnString',
      /DefaultEndpointsProtocol\s*=\s*https?;.*?AccountName\s*=\s*[^;]+;.*?AccountKey\s*=\s*[^;]+/gi
    );
    
    patterns.set('awsConnString',
      /(aws_access_key_id|aws_secret_access_key|aws_session_token)\s*=\s*[^\s]+/gi
    );

    // IP addresses
    patterns.set('ipAddress', /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g);

    return patterns;
  }

  public sanitizeDom(html: string): { sanitized: string; report: PIIDetectionResult[] } {
    let sanitized = html;
    const report: PIIDetectionResult[] = [];

    // Detect PII before sanitization
    const detectedPII = this.detectPII(html);
    report.push(...detectedPII);

    // Apply redaction based on options
    if (this.options.redactPasswords) {
      sanitized = this.redactPasswords(sanitized);
    }

    if (this.options.redactTokens) {
      sanitized = this.redactTokens(sanitized);
    }

    if (this.options.redactEmails) {
      sanitized = this.redactPattern(sanitized, this.piiPatterns.get('email')!, 'email');
    }

    if (this.options.redactPhoneNumbers) {
      sanitized = this.redactPattern(sanitized, this.piiPatterns.get('phone')!, 'phone');
    }

    if (this.options.redactCreditCards) {
      sanitized = this.redactPattern(sanitized, this.piiPatterns.get('creditCard')!, 'creditCard');
    }

    if (this.options.redactSSN) {
      sanitized = this.redactPattern(sanitized, this.piiPatterns.get('ssn')!, 'ssn');
    }

    // Apply custom patterns
    for (const pattern of this.options.redactCustomPatterns) {
      sanitized = this.redactPattern(sanitized, pattern, 'custom');
    }

    // Sanitize data attributes
    sanitized = this.sanitizeDataAttributes(sanitized);

    // Sanitize inline scripts
    sanitized = this.sanitizeInlineScripts(sanitized);

    // Sanitize meta tags
    sanitized = this.sanitizeMetaTags(sanitized);

    return { sanitized, report };
  }

  private detectPII(html: string): PIIDetectionResult[] {
    const results: PIIDetectionResult[] = [];

    for (const [type, pattern] of this.piiPatterns) {
      const matches = Array.from(html.matchAll(pattern));
      if (matches.length > 0) {
        const locations = matches.map(match => ({
          path: this.getContextPath(html, match.index || 0),
          line: this.getLineNumber(html, match.index || 0),
          column: this.getColumnNumber(html, match.index || 0)
        }));

        results.push({
          type,
          count: matches.length,
          locations
        });
      }
    }

    return results;
  }

  private redactPasswords(html: string): string {
    // Redact password input values
    html = html.replace(
      /<input([^>]*type\s*=\s*["']password["'][^>]*)value\s*=\s*["']([^"']+)["']([^>]*)>/gi,
      (match, before, value, after) => {
        const redacted = this.options.preserveLength 
          ? this.options.maskCharacter.repeat(value.length)
          : this.options.maskCharacter.repeat(8);
        this.incrementRedactedCount('password');
        return `<input${before}value="${redacted}"${after}>`;
      }
    );

    // Redact password-like attributes
    html = html.replace(
      /(\bpassword\b|\bpass\b|\bpwd\b)\s*[:=]\s*["']([^"']+)["']/gi,
      (match, key, value) => {
        const redacted = this.options.preserveLength
          ? this.options.maskCharacter.repeat(value.length)
          : this.options.maskCharacter.repeat(8);
        this.incrementRedactedCount('password');
        return `${key}="${redacted}"`;
      }
    );

    return html;
  }

  private redactTokens(html: string): string {
    // Redact API keys and tokens
    const tokenPatterns = [
      this.piiPatterns.get('apiKey')!,
      this.piiPatterns.get('jwt')!,
      this.piiPatterns.get('awsKey')!,
      this.piiPatterns.get('authHeader')!
    ];

    for (const pattern of tokenPatterns) {
      html = this.redactPattern(html, pattern, 'token');
    }

    // Redact connection strings
    html = html.replace(this.piiPatterns.get('connectionString')!, (match) => {
      const url = new URL(match);
      if (url.password) {
        url.password = this.options.maskCharacter.repeat(8);
      }
      if (url.username && url.username !== 'admin' && url.username !== 'root') {
        url.username = this.options.maskCharacter.repeat(url.username.length);
      }
      this.incrementRedactedCount('connectionString');
      return url.toString();
    });

    return html;
  }

  private redactPattern(html: string, pattern: RegExp, type: string): string {
    return html.replace(pattern, (match) => {
      // Check whitelist
      if (this.options.whitelist.some(item => match.includes(item))) {
        return match;
      }

      // Check blacklist
      if (this.options.blacklist.length > 0 && !this.options.blacklist.some(item => match.includes(item))) {
        return match;
      }

      this.incrementRedactedCount(type);
      
      if (this.options.preserveLength) {
        // Preserve some structure for emails
        if (type === 'email') {
          const [local, domain] = match.split('@');
          return this.options.maskCharacter.repeat(local.length) + '@' + domain;
        }
        
        // Preserve some structure for phone numbers
        if (type === 'phone') {
          return match.replace(/\d/g, this.options.maskCharacter);
        }
        
        // Preserve some structure for credit cards
        if (type === 'creditCard') {
          const lastFour = match.slice(-4);
          return this.options.maskCharacter.repeat(match.length - 4) + lastFour;
        }
        
        return this.options.maskCharacter.repeat(match.length);
      }
      
      return `[REDACTED_${type.toUpperCase()}]`;
    });
  }

  private sanitizeDataAttributes(html: string): string {
    // Redact sensitive data attributes
    const sensitiveDataAttrs = [
      'data-user-id',
      'data-session-id',
      'data-api-key',
      'data-token',
      'data-auth',
      'data-password',
      'data-secret'
    ];

    for (const attr of sensitiveDataAttrs) {
      const pattern = new RegExp(`${attr}\\s*=\\s*["']([^"']+)["']`, 'gi');
      html = html.replace(pattern, (match, value) => {
        this.incrementRedactedCount('dataAttribute');
        const redacted = this.options.preserveLength
          ? this.options.maskCharacter.repeat(value.length)
          : '[REDACTED]';
        return `${attr}="${redacted}"`;
      });
    }

    return html;
  }

  private sanitizeInlineScripts(html: string): string {
    // Remove or sanitize inline scripts that might contain sensitive data
    html = html.replace(
      /<script\b[^>]*>([\s\S]*?)<\/script>/gi,
      (match, content) => {
        // Check for sensitive patterns in script content
        let sanitizedContent = content;
        
        // Redact variable assignments with sensitive names
        sanitizedContent = sanitizedContent.replace(
          /\b(apiKey|api_key|token|password|secret|auth|credential)\s*=\s*["']([^"']+)["']/gi,
          (m: string, key: string) => {
            this.incrementRedactedCount('scriptVariable');
            return `${key} = "[REDACTED]"`;
          }
        );
        
        // Redact localStorage/sessionStorage operations with sensitive keys
        sanitizedContent = sanitizedContent.replace(
          /(localStorage|sessionStorage)\.(setItem|getItem)\(["'](.*?(token|key|password|auth|secret).*?)["']/gi,
          (m: string, storage: string, method: string, key: string) => {
            this.incrementRedactedCount('storageOperation');
            return `${storage}.${method}("[REDACTED_KEY]"`;
          }
        );
        
        return `<script>${sanitizedContent}</script>`;
      }
    );

    return html;
  }

  private sanitizeMetaTags(html: string): string {
    // Sanitize potentially sensitive meta tags
    const sensitiveMeta = [
      'csrf-token',
      'api-key',
      'session-id',
      'user-id'
    ];

    for (const metaName of sensitiveMeta) {
      const pattern = new RegExp(
        `<meta\\s+name=["']${metaName}["']\\s+content=["']([^"']+)["']`,
        'gi'
      );
      
      html = html.replace(pattern, (match, content) => {
        this.incrementRedactedCount('metaTag');
        const redacted = this.options.preserveLength
          ? this.options.maskCharacter.repeat(content.length)
          : '[REDACTED]';
        return `<meta name="${metaName}" content="${redacted}"`;
      });
    }

    return html;
  }

  private getContextPath(html: string, index: number): string {
    // Get the HTML path context (simplified)
    const beforeContent = html.substring(Math.max(0, index - 100), index);
    const tagMatch = beforeContent.match(/<(\w+)[^>]*$/);
    return tagMatch ? tagMatch[1] : 'text';
  }

  private getLineNumber(html: string, index: number): number {
    return html.substring(0, index).split('\n').length;
  }

  private getColumnNumber(html: string, index: number): number {
    const lines = html.substring(0, index).split('\n');
    return lines[lines.length - 1].length + 1;
  }

  private incrementRedactedCount(type: string): void {
    this.redactedCount.set(type, (this.redactedCount.get(type) || 0) + 1);
  }

  public getRedactionReport(): Map<string, number> {
    return this.redactedCount;
  }

  public validateSecurity(html: string): {
    isSecure: boolean;
    issues: string[];
    recommendations: string[];
  } {
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Check for inline scripts
    if (/<script\b[^>]*>[\s\S]*?<\/script>/gi.test(html)) {
      issues.push('Inline scripts detected');
      recommendations.push('Consider moving scripts to external files with CSP headers');
    }

    // Check for inline event handlers
    if (/on\w+\s*=\s*["'][^"']+["']/gi.test(html)) {
      issues.push('Inline event handlers detected');
      recommendations.push('Use addEventListener instead of inline event handlers');
    }

    // Check for http resources in https context
    if (/src\s*=\s*["']http:\/\//gi.test(html) || /href\s*=\s*["']http:\/\//gi.test(html)) {
      issues.push('Mixed content: HTTP resources in HTTPS context');
      recommendations.push('Use HTTPS for all external resources');
    }

    // Check for sensitive data patterns
    const piiResults = this.detectPII(html);
    if (piiResults.length > 0) {
      issues.push(`Potential PII detected: ${piiResults.map(r => r.type).join(', ')}`);
      recommendations.push('Enable PII redaction before storing or sharing captures');
    }

    return {
      isSecure: issues.length === 0,
      issues,
      recommendations
    };
  }
}