import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { JSDOM } from 'jsdom';

export interface DiffResult {
  type: 'added' | 'removed' | 'modified' | 'unchanged';
  path: string;
  element?: string;
  oldValue?: any;
  newValue?: any;
  details?: string;
}

export interface DomComparison {
  timestamp: string;
  file1: string;
  file2: string;
  totalDifferences: number;
  differences: DiffResult[];
  similarity: number;
  summary: {
    added: number;
    removed: number;
    modified: number;
    unchanged: number;
  };
}

/**
 * DOM Diff Visualizer for comparing captures
 */
export class DiffVisualizer {
  private outputChannel: vscode.OutputChannel;
  
  constructor() {
    this.outputChannel = vscode.window.createOutputChannel('DOM Capture Diff');
  }
  
  /**
   * Compare two DOM captures and visualize differences
   */
  async compareDomCaptures(
    capture1Path: string,
    capture2Path: string
  ): Promise<DomComparison> {
    console.log(`🔍 Comparing DOM captures...`);
    
    // Load captures
    const html1 = await fs.readFile(capture1Path, 'utf-8');
    const html2 = await fs.readFile(capture2Path, 'utf-8');
    
    // Parse DOMs
    const dom1 = new JSDOM(html1);
    const dom2 = new JSDOM(html2);
    
    // Perform comparison
    const differences = this.compareDoms(
      dom1.window.document,
      dom2.window.document
    );
    
    // Calculate summary
    const summary = this.calculateSummary(differences);
    const similarity = this.calculateSimilarity(differences);
    
    const comparison: DomComparison = {
      timestamp: new Date().toISOString(),
      file1: capture1Path,
      file2: capture2Path,
      totalDifferences: differences.filter(d => d.type !== 'unchanged').length,
      differences,
      similarity,
      summary
    };
    
    // Generate visualization
    await this.generateVisualization(comparison);
    
    return comparison;
  }
  
  /**
   * Compare two DOM documents
   */
  private compareDoms(doc1: Document, doc2: Document): DiffResult[] {
    const differences: DiffResult[] = [];
    
    // Compare document structure
    this.compareElements(
      doc1.documentElement,
      doc2.documentElement,
      '',
      differences
    );
    
    return differences;
  }
  
  /**
   * Recursively compare elements
   */
  private compareElements(
    elem1: Element | null,
    elem2: Element | null,
    path: string,
    differences: DiffResult[]
  ): void {
    // Handle missing elements
    if (!elem1 && elem2) {
      differences.push({
        type: 'added',
        path,
        element: elem2.tagName,
        newValue: this.serializeElement(elem2),
        details: `Element added: ${elem2.tagName}`
      });
      return;
    }
    
    if (elem1 && !elem2) {
      differences.push({
        type: 'removed',
        path,
        element: elem1.tagName,
        oldValue: this.serializeElement(elem1),
        details: `Element removed: ${elem1.tagName}`
      });
      return;
    }
    
    if (!elem1 || !elem2) return;
    
    // Compare tag names
    if (elem1.tagName !== elem2.tagName) {
      differences.push({
        type: 'modified',
        path,
        element: elem1.tagName,
        oldValue: elem1.tagName,
        newValue: elem2.tagName,
        details: `Tag changed: ${elem1.tagName} → ${elem2.tagName}`
      });
      return;
    }
    
    // Compare attributes
    this.compareAttributes(elem1, elem2, path, differences);
    
    // Compare text content (for leaf nodes)
    if (elem1.children.length === 0 && elem2.children.length === 0) {
      const text1 = elem1.textContent?.trim() || '';
      const text2 = elem2.textContent?.trim() || '';
      
      if (text1 !== text2) {
        differences.push({
          type: 'modified',
          path,
          element: elem1.tagName,
          oldValue: text1,
          newValue: text2,
          details: `Text content changed`
        });
      }
    }
    
    // Compare children
    const children1 = Array.from(elem1.children);
    const children2 = Array.from(elem2.children);
    const maxChildren = Math.max(children1.length, children2.length);
    
    for (let i = 0; i < maxChildren; i++) {
      const childPath = `${path}/${elem1.tagName}[${i}]`;
      this.compareElements(
        children1[i] || null,
        children2[i] || null,
        childPath,
        differences
      );
    }
  }
  
  /**
   * Compare element attributes
   */
  private compareAttributes(
    elem1: Element,
    elem2: Element,
    path: string,
    differences: DiffResult[]
  ): void {
    const attrs1 = new Map(
      Array.from(elem1.attributes).map(attr => [attr.name, attr.value])
    );
    const attrs2 = new Map(
      Array.from(elem2.attributes).map(attr => [attr.name, attr.value])
    );
    
    // Check for removed attributes
    attrs1.forEach((value, name) => {
      if (!attrs2.has(name)) {
        differences.push({
          type: 'removed',
          path: `${path}@${name}`,
          element: elem1.tagName,
          oldValue: value,
          details: `Attribute removed: ${name}`
        });
      }
    });
    
    // Check for added or modified attributes
    attrs2.forEach((value, name) => {
      const oldValue = attrs1.get(name);
      
      if (oldValue === undefined) {
        differences.push({
          type: 'added',
          path: `${path}@${name}`,
          element: elem2.tagName,
          newValue: value,
          details: `Attribute added: ${name}="${value}"`
        });
      } else if (oldValue !== value) {
        // Special handling for certain attributes
        if (this.shouldIgnoreAttributeChange(name, oldValue, value)) {
          return;
        }
        
        differences.push({
          type: 'modified',
          path: `${path}@${name}`,
          element: elem1.tagName,
          oldValue,
          newValue: value,
          details: `Attribute ${name} changed`
        });
      }
    });
  }
  
  /**
   * Check if attribute change should be ignored
   */
  private shouldIgnoreAttributeChange(
    name: string,
    oldValue: string,
    newValue: string
  ): boolean {
    // Ignore timestamp-like values
    if (name === 'data-timestamp' || name === 'data-capture-time') {
      return true;
    }
    
    // Ignore certain dynamic IDs
    if (name === 'id' && /^(react-|vue-|angular-|ember-)/.test(oldValue)) {
      return true;
    }
    
    // Ignore CSRF tokens
    if (name === 'data-csrf' || name === 'csrf-token') {
      return true;
    }
    
    return false;
  }
  
  /**
   * Serialize element for storage
   */
  private serializeElement(elem: Element): string {
    const clone = elem.cloneNode(false) as Element;
    return clone.outerHTML;
  }
  
  /**
   * Calculate summary statistics
   */
  private calculateSummary(differences: DiffResult[]) {
    return {
      added: differences.filter(d => d.type === 'added').length,
      removed: differences.filter(d => d.type === 'removed').length,
      modified: differences.filter(d => d.type === 'modified').length,
      unchanged: differences.filter(d => d.type === 'unchanged').length
    };
  }
  
  /**
   * Calculate similarity score
   */
  private calculateSimilarity(differences: DiffResult[]): number {
    const totalElements = differences.length || 1;
    const changedElements = differences.filter(d => d.type !== 'unchanged').length;
    
    return Math.max(0, 1 - (changedElements / totalElements));
  }
  
  /**
   * Generate HTML visualization of differences
   */
  async generateVisualization(comparison: DomComparison): Promise<string> {
    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <title>DOM Capture Diff - ${new Date().toLocaleString()}</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 20px;
      background: #f5f5f5;
    }
    
    .header {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .summary {
      display: flex;
      gap: 20px;
      margin: 20px 0;
    }
    
    .summary-item {
      flex: 1;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      color: white;
      font-weight: bold;
    }
    
    .added { background: #28a745; }
    .removed { background: #dc3545; }
    .modified { background: #ffc107; color: #333; }
    .unchanged { background: #6c757d; }
    
    .similarity-meter {
      margin: 20px 0;
      background: white;
      padding: 15px;
      border-radius: 8px;
    }
    
    .similarity-bar {
      height: 30px;
      background: #e9ecef;
      border-radius: 15px;
      overflow: hidden;
    }
    
    .similarity-fill {
      height: 100%;
      background: linear-gradient(90deg, #dc3545, #ffc107, #28a745);
      transition: width 0.3s;
    }
    
    .differences {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .diff-item {
      padding: 10px;
      margin: 10px 0;
      border-left: 4px solid;
      background: #f8f9fa;
      border-radius: 4px;
    }
    
    .diff-item.added { border-color: #28a745; }
    .diff-item.removed { border-color: #dc3545; }
    .diff-item.modified { border-color: #ffc107; }
    
    .diff-path {
      font-family: 'Courier New', monospace;
      font-size: 12px;
      color: #666;
    }
    
    .diff-details {
      margin-top: 5px;
      font-size: 14px;
    }
    
    .diff-values {
      display: flex;
      gap: 20px;
      margin-top: 10px;
    }
    
    .old-value, .new-value {
      flex: 1;
      padding: 8px;
      border-radius: 4px;
      font-family: 'Courier New', monospace;
      font-size: 12px;
      white-space: pre-wrap;
      word-break: break-all;
    }
    
    .old-value {
      background: #ffebee;
      border: 1px solid #ffcdd2;
    }
    
    .new-value {
      background: #e8f5e9;
      border: 1px solid #c8e6c9;
    }
    
    .filter-controls {
      margin: 20px 0;
      display: flex;
      gap: 10px;
    }
    
    .filter-btn {
      padding: 8px 16px;
      border: 1px solid #dee2e6;
      background: white;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .filter-btn:hover {
      background: #f8f9fa;
    }
    
    .filter-btn.active {
      background: #007bff;
      color: white;
      border-color: #007bff;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>DOM Capture Comparison</h1>
    <p>File 1: ${path.basename(comparison.file1)}</p>
    <p>File 2: ${path.basename(comparison.file2)}</p>
    <p>Timestamp: ${new Date(comparison.timestamp).toLocaleString()}</p>
  </div>
  
  <div class="summary">
    <div class="summary-item added">
      Added: ${comparison.summary.added}
    </div>
    <div class="summary-item removed">
      Removed: ${comparison.summary.removed}
    </div>
    <div class="summary-item modified">
      Modified: ${comparison.summary.modified}
    </div>
    <div class="summary-item unchanged">
      Unchanged: ${comparison.summary.unchanged}
    </div>
  </div>
  
  <div class="similarity-meter">
    <h3>Similarity: ${(comparison.similarity * 100).toFixed(1)}%</h3>
    <div class="similarity-bar">
      <div class="similarity-fill" style="width: ${comparison.similarity * 100}%"></div>
    </div>
  </div>
  
  <div class="filter-controls">
    <button class="filter-btn active" onclick="filterDiffs('all')">All (${comparison.totalDifferences})</button>
    <button class="filter-btn" onclick="filterDiffs('added')">Added (${comparison.summary.added})</button>
    <button class="filter-btn" onclick="filterDiffs('removed')">Removed (${comparison.summary.removed})</button>
    <button class="filter-btn" onclick="filterDiffs('modified')">Modified (${comparison.summary.modified})</button>
  </div>
  
  <div class="differences">
    <h2>Differences (${comparison.totalDifferences})</h2>
    ${comparison.differences
      .filter(d => d.type !== 'unchanged')
      .slice(0, 100) // Limit to first 100 differences
      .map(diff => `
        <div class="diff-item ${diff.type}" data-type="${diff.type}">
          <div class="diff-path">${diff.path}</div>
          <div class="diff-details">
            <strong>${diff.type.toUpperCase()}:</strong> ${diff.details || ''}
          </div>
          ${diff.oldValue || diff.newValue ? `
            <div class="diff-values">
              ${diff.oldValue ? `<div class="old-value">Old: ${this.escapeHtml(String(diff.oldValue))}</div>` : ''}
              ${diff.newValue ? `<div class="new-value">New: ${this.escapeHtml(String(diff.newValue))}</div>` : ''}
            </div>
          ` : ''}
        </div>
      `).join('')}
  </div>
  
  <script>
    function filterDiffs(type) {
      const items = document.querySelectorAll('.diff-item');
      const buttons = document.querySelectorAll('.filter-btn');
      
      buttons.forEach(btn => btn.classList.remove('active'));
      event.target.classList.add('active');
      
      items.forEach(item => {
        if (type === 'all' || item.dataset.type === type) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    }
  </script>
</body>
</html>
    `;
    
    // Save visualization
    const outputPath = path.join(
      path.dirname(comparison.file1),
      `diff_${Date.now()}.html`
    );
    
    await fs.writeFile(outputPath, htmlContent, 'utf-8');
    
    // Open in browser
    await vscode.env.openExternal(vscode.Uri.file(outputPath));
    
    return outputPath;
  }
  
  /**
   * Escape HTML for safe display
   */
  private escapeHtml(text: string): string {
    const map: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    
    return text.replace(/[&<>"']/g, m => map[m]);
  }
  
  /**
   * Show diff in output channel
   */
  showDiffInOutput(comparison: DomComparison): void {
    this.outputChannel.clear();
    this.outputChannel.appendLine('='.repeat(80));
    this.outputChannel.appendLine('DOM CAPTURE COMPARISON');
    this.outputChannel.appendLine('='.repeat(80));
    this.outputChannel.appendLine('');
    this.outputChannel.appendLine(`File 1: ${comparison.file1}`);
    this.outputChannel.appendLine(`File 2: ${comparison.file2}`);
    this.outputChannel.appendLine(`Similarity: ${(comparison.similarity * 100).toFixed(1)}%`);
    this.outputChannel.appendLine('');
    this.outputChannel.appendLine('SUMMARY:');
    this.outputChannel.appendLine(`  Added:     ${comparison.summary.added}`);
    this.outputChannel.appendLine(`  Removed:   ${comparison.summary.removed}`);
    this.outputChannel.appendLine(`  Modified:  ${comparison.summary.modified}`);
    this.outputChannel.appendLine(`  Unchanged: ${comparison.summary.unchanged}`);
    this.outputChannel.appendLine('');
    this.outputChannel.appendLine('DIFFERENCES:');
    this.outputChannel.appendLine('-'.repeat(80));
    
    comparison.differences
      .filter(d => d.type !== 'unchanged')
      .slice(0, 50)
      .forEach(diff => {
        this.outputChannel.appendLine(`[${diff.type.toUpperCase()}] ${diff.path}`);
        if (diff.details) {
          this.outputChannel.appendLine(`  ${diff.details}`);
        }
        if (diff.oldValue) {
          this.outputChannel.appendLine(`  Old: ${diff.oldValue}`);
        }
        if (diff.newValue) {
          this.outputChannel.appendLine(`  New: ${diff.newValue}`);
        }
        this.outputChannel.appendLine('');
      });
    
    this.outputChannel.show();
  }
}