import { Page, BrowserContext } from 'playwright';
import { AsyncDomSerializer, SerializationResult } from './asyncDomSerializer';
import * as path from 'path';
import * as fs from 'fs-extra';

export interface TabCaptureResult {
  tabId: string;
  tabIndex: number;
  url: string;
  title: string;
  isActive: boolean;
  serialization: SerializationResult;
  screenshot?: string;
  timestamp: string;
}

export interface MultiTabCaptureOptions {
  includeInactiveTabs: boolean;
  captureScreenshots: boolean;
  parallelCapture: boolean;
  maxParallelCaptures: number;
  captureOrder: 'sequential' | 'parallel' | 'active-first';
  outputDir: string;
}

/**
 * Enhanced multi-tab capture manager
 */
export class MultiTabCaptureManager {
  private options: MultiTabCaptureOptions;
  
  constructor(options: Partial<MultiTabCaptureOptions> = {}) {
    this.options = {
      includeInactiveTabs: true,
      captureScreenshots: true,
      parallelCapture: true,
      maxParallelCaptures: 3,
      captureOrder: 'active-first',
      outputDir: 'test-results/dom-captures',
      ...options
    };
  }
  
  /**
   * Capture all tabs in a browser context
   */
  async captureAllTabs(context: BrowserContext): Promise<TabCaptureResult[]> {
    const pages = context.pages();
    
    if (pages.length === 0) {
      throw new Error('No pages found in browser context');
    }
    
    console.log(`📸 Capturing ${pages.length} tab(s) in ${this.options.captureOrder} mode`);
    
    // Sort pages based on capture order
    const sortedPages = await this.sortPages(pages);
    
    // Capture based on strategy
    if (this.options.parallelCapture && pages.length > 1) {
      return await this.captureParallel(sortedPages);
    } else {
      return await this.captureSequential(sortedPages);
    }
  }
  
  /**
   * Sort pages based on capture order preference
   */
  private async sortPages(pages: Page[]): Promise<Page[]> {
    if (this.options.captureOrder === 'active-first') {
      // Try to identify the active tab (usually the last interacted with)
      const pagesWithActivity = await Promise.all(
        pages.map(async (page, index) => {
          const isVisible = await page.evaluate(() => document.visibilityState === 'visible').catch(() => false);
          return { page, index, isVisible };
        })
      );
      
      // Sort by visibility (active tabs first)
      return pagesWithActivity
        .sort((a, b) => {
          if (a.isVisible && !b.isVisible) return -1;
          if (!a.isVisible && b.isVisible) return 1;
          return a.index - b.index;
        })
        .map(item => item.page);
    }
    
    return pages; // Default sequential order
  }
  
  /**
   * Capture tabs in parallel with concurrency limit
   */
  private async captureParallel(pages: Page[]): Promise<TabCaptureResult[]> {
    const results: TabCaptureResult[] = [];
    const maxConcurrent = Math.min(this.options.maxParallelCaptures, pages.length);
    
    // Process in batches
    for (let i = 0; i < pages.length; i += maxConcurrent) {
      const batch = pages.slice(i, i + maxConcurrent);
      const batchResults = await Promise.all(
        batch.map((page, batchIndex) => 
          this.captureSingleTab(page, i + batchIndex, pages.length)
        )
      );
      results.push(...batchResults);
    }
    
    return results;
  }
  
  /**
   * Capture tabs sequentially
   */
  private async captureSequential(pages: Page[]): Promise<TabCaptureResult[]> {
    const results: TabCaptureResult[] = [];
    
    for (let i = 0; i < pages.length; i++) {
      const result = await this.captureSingleTab(pages[i], i, pages.length);
      results.push(result);
    }
    
    return results;
  }
  
  /**
   * Capture a single tab
   */
  private async captureSingleTab(
    page: Page,
    index: number,
    totalTabs: number
  ): Promise<TabCaptureResult> {
    const startTime = Date.now();
    const tabId = `tab_${index}_${Date.now()}`;
    
    console.log(`  📄 Capturing tab ${index + 1}/${totalTabs}: ${page.url()}`);
    
    try {
      // Get tab info
      const url = page.url();
      const title = await page.title();
      const isActive = await page.evaluate(() => document.visibilityState === 'visible').catch(() => false);
      
      // Serialize DOM with async serializer
      const serializer = new AsyncDomSerializer(page, {
        captureIframes: true,
        captureShadowDom: true,
        captureFormState: true,
        compressionLevel: 'medium'
      });
      
      const serialization = await serializer.serialize();
      
      // Capture screenshot if enabled
      let screenshot: string | undefined;
      if (this.options.captureScreenshots) {
        const screenshotPath = await this.captureScreenshot(page, tabId);
        screenshot = screenshotPath;
      }
      
      // Save capture
      await this.saveTabCapture(tabId, serialization, { url, title, index });
      
      console.log(`  ✅ Tab ${index + 1} captured in ${Date.now() - startTime}ms`);
      
      return {
        tabId,
        tabIndex: index,
        url,
        title,
        isActive,
        serialization,
        screenshot,
        timestamp: new Date().toISOString()
      };
      
    } catch (error) {
      console.error(`  ❌ Failed to capture tab ${index + 1}: ${error}`);
      throw error;
    }
  }
  
  /**
   * Capture screenshot of a page
   */
  private async captureScreenshot(page: Page, tabId: string): Promise<string> {
    const screenshotDir = path.join(this.options.outputDir, 'screenshots');
    await fs.ensureDir(screenshotDir);
    
    const screenshotPath = path.join(screenshotDir, `${tabId}.png`);
    
    await page.screenshot({
      path: screenshotPath,
      fullPage: true,
      animations: 'disabled'
    });
    
    return screenshotPath;
  }
  
  /**
   * Save tab capture to disk
   */
  private async saveTabCapture(
    tabId: string,
    serialization: SerializationResult,
    metadata: any
  ): Promise<void> {
    const captureDir = path.join(this.options.outputDir, 'captures', tabId);
    await fs.ensureDir(captureDir);
    
    // Save chunks
    for (const chunk of serialization.chunks) {
      const chunkPath = path.join(captureDir, `chunk_${chunk.index}.json`);
      await fs.writeJson(chunkPath, chunk, { spaces: 2 });
    }
    
    // Save metadata
    const metadataPath = path.join(captureDir, 'metadata.json');
    await fs.writeJson(metadataPath, {
      ...metadata,
      ...serialization.metadata
    }, { spaces: 2 });
  }
  
  /**
   * Compare two tab captures for differences
   */
  static async compareCaptures(
    capture1: TabCaptureResult,
    capture2: TabCaptureResult
  ): Promise<{
    identical: boolean;
    differences: string[];
    similarity: number;
  }> {
    const differences: string[] = [];
    
    // Compare URLs
    if (capture1.url !== capture2.url) {
      differences.push(`URL changed: ${capture1.url} → ${capture2.url}`);
    }
    
    // Compare titles
    if (capture1.title !== capture2.title) {
      differences.push(`Title changed: ${capture1.title} → ${capture2.title}`);
    }
    
    // Compare serialization metadata
    const size1 = capture1.serialization.metadata.totalSize;
    const size2 = capture2.serialization.metadata.totalSize;
    const sizeDiff = Math.abs(size1 - size2) / Math.max(size1, size2);
    
    if (sizeDiff > 0.1) { // More than 10% size difference
      differences.push(`Significant size change: ${sizeDiff * 100}%`);
    }
    
    // Calculate similarity score
    const similarity = 1 - (differences.length / 10); // Simple scoring
    
    return {
      identical: differences.length === 0,
      differences,
      similarity: Math.max(0, Math.min(1, similarity))
    };
  }
}

/**
 * Tab synchronization helper for coordinated captures
 */
export class TabSynchronizer {
  private syncPoints: Map<string, Set<Page>> = new Map();
  
  /**
   * Register a sync point for multiple tabs
   */
  async createSyncPoint(name: string, pages: Page[]): Promise<void> {
    this.syncPoints.set(name, new Set(pages));
    
    // Inject sync script into all pages
    await Promise.all(pages.map(page => 
      page.addInitScript((syncName) => {
        // @ts-ignore
        window.__syncPoints = window.__syncPoints || {};
        // @ts-ignore
        window.__syncPoints[syncName] = {
          ready: false,
          timestamp: null
        };
        
        // @ts-ignore
        window.__markSyncReady = (name: string) => {
          // @ts-ignore
          if (window.__syncPoints[name]) {
            // @ts-ignore
            window.__syncPoints[name].ready = true;
            // @ts-ignore
            window.__syncPoints[name].timestamp = Date.now();
          }
        };
      }, name)
    ));
  }
  
  /**
   * Wait for all tabs to reach a sync point
   */
  async waitForSync(name: string, timeout = 30000): Promise<void> {
    const pages = this.syncPoints.get(name);
    if (!pages) {
      throw new Error(`Sync point ${name} not found`);
    }
    
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const readyStates = await Promise.all(
        Array.from(pages).map(page =>
          page.evaluate((syncName) => {
            // @ts-ignore
            return window.__syncPoints?.[syncName]?.ready || false;
          }, name).catch(() => false)
        )
      );
      
      if (readyStates.every((ready: boolean) => ready)) {
        console.log(`✅ All tabs synchronized at point: ${name}`);
        return;
      }
      
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    throw new Error(`Sync timeout: Not all tabs reached sync point ${name}`);
  }
  
  /**
   * Clear a sync point
   */
  clearSyncPoint(name: string): void {
    this.syncPoints.delete(name);
  }
}