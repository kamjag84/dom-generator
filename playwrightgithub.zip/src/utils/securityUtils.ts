import * as path from 'path';
import * as vscode from 'vscode';

/**
 * Security utilities for input validation and sanitization
 */
export class SecurityUtils {
    /**
     * Validates that a path is within the workspace
     */
    static isValidWorkspacePath(filePath: string): boolean {
        if (!filePath) return false;
        
        // Normalize the path
        const normalizedPath = path.normalize(filePath);
        
        // Check for path traversal attempts
        if (normalizedPath.includes('..') || normalizedPath.includes('~')) {
            return false;
        }
        
        // Ensure path is within workspace
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) return false;
        
        return workspaceFolders.some(folder => {
            const folderPath = folder.uri.fsPath;
            return normalizedPath.startsWith(folderPath);
        });
    }
    
    /**
     * Sanitizes a file path for safe usage
     */
    static sanitizePath(filePath: string): string {
        if (!filePath) return '';
        
        // Remove any null bytes
        let sanitized = filePath.replace(/\0/g, '');
        
        // Normalize path separators
        sanitized = path.normalize(sanitized);
        
        // Remove leading dots and tildes
        sanitized = sanitized.replace(/^[.~]+/, '');
        
        // Remove any command injection attempts
        sanitized = sanitized.replace(/[;&|`$()]/g, '');
        
        return sanitized;
    }
    
    /**
     * Escapes shell arguments to prevent injection
     */
    static escapeShellArg(arg: string): string {
        if (!arg) return '""';
        
        // For Windows
        if (process.platform === 'win32') {
            // Escape double quotes and wrap in quotes
            return `"${arg.replace(/"/g, '""')}"`;
        }
        
        // For Unix-like systems
        // Escape single quotes and wrap in single quotes
        return `'${arg.replace(/'/g, "'\\''")}'`;
    }
    
    /**
     * Validates that a URL is safe to open
     */
    static isValidUrl(url: string): boolean {
        try {
            const parsed = new URL(url);
            // Only allow http and https protocols
            return ['http:', 'https:'].includes(parsed.protocol);
        } catch {
            return false;
        }
    }
    
    /**
     * Sanitizes HTML to prevent XSS
     */
    static escapeHtml(unsafe: string): string {
        if (!unsafe) return '';
        
        return unsafe
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\//g, '&#x2F;');
    }
    
    /**
     * Validates file name to prevent directory traversal
     */
    static isValidFileName(fileName: string): boolean {
        if (!fileName) return false;
        
        // Check for path traversal patterns
        const invalidPatterns = [
            '..',
            '~',
            '/',
            '\\',
            ':',
            '*',
            '?',
            '"',
            '<',
            '>',
            '|',
            '\0'
        ];
        
        return !invalidPatterns.some(pattern => fileName.includes(pattern));
    }
    
    /**
     * Generates a cryptographically secure random ID
     */
    static generateSecureId(): string {
        const array = new Uint8Array(16);
        if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
            crypto.getRandomValues(array);
        } else {
            // Fallback for Node.js environment
            const crypto = require('crypto');
            crypto.randomFillSync(array);
        }
        
        return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
    }
    
    /**
     * Validates and sanitizes terminal commands
     */
    static sanitizeTerminalCommand(command: string, allowedCommands: string[] = []): string | null {
        if (!command) return null;
        
        // Remove any command chaining attempts
        const sanitized = command.split(/[;&|]/, 1)[0].trim();
        
        // Extract the base command
        const baseCommand = sanitized.split(/\s+/, 1)[0];
        
        // Check if command is in allowed list
        if (allowedCommands.length > 0 && !allowedCommands.includes(baseCommand)) {
            return null;
        }
        
        // Remove any shell expansion attempts
        return sanitized.replace(/[$`]/g, '');
    }
}