import * as path from 'path';
const sanitizeFilename = require('sanitize-filename');

export class SecurityUtils {
    /**
     * Sanitizes file paths to prevent directory traversal attacks
     */
    static sanitizePath(inputPath: string, basePath: string): string {
        // Normalize and resolve the path
        const normalizedPath = path.normalize(inputPath);
        const resolvedPath = path.resolve(basePath, normalizedPath);
        
        // Ensure the resolved path is within the base path
        if (!resolvedPath.startsWith(path.resolve(basePath))) {
            throw new Error('Invalid path: Path traversal detected');
        }
        
        return resolvedPath;
    }

    /**
     * Sanitizes filename to prevent injection attacks
     */
    static sanitizeFileName(fileName: string): string {
        // Use sanitize-filename library
        const sanitized = sanitizeFilename(fileName, { replacement: '_' });
        
        // Additional validation
        if (!sanitized || sanitized.length === 0) {
            throw new Error('Invalid filename');
        }
        
        // Limit length
        if (sanitized.length > 255) {
            return sanitized.substring(0, 255);
        }
        
        return sanitized;
    }

    /**
     * Validates and sanitizes HTML content to prevent XSS
     */
    static sanitizeHtml(html: string): string {
        // Basic HTML entity encoding for dangerous characters
        const entityMap: { [key: string]: string } = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;',
            '/': '&#x2F;',
            '`': '&#x60;',
            '=': '&#x3D;'
        };
        
        // Only encode script tags and event handlers in comments
        return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '<!-- SCRIPT REMOVED -->')
                  .replace(/on\w+\s*=\s*"[^"]*"/gi, '');
    }

    /**
     * Validates input to prevent injection attacks
     */
    static validateInput(input: string, maxLength: number = 1000): string {
        if (typeof input !== 'string') {
            throw new Error('Invalid input type');
        }
        
        if (input.length > maxLength) {
            throw new Error(`Input exceeds maximum length of ${maxLength}`);
        }
        
        // Remove null bytes
        const sanitized = input.replace(/\0/g, '');
        
        // Check for common injection patterns
        const dangerousPatterns = [
            /(\.\.[\/\\])+/,  // Directory traversal
            /<script/i,        // Script injection
            /javascript:/i,    // JavaScript protocol
            /data:text\/html/i // Data URI HTML
        ];
        
        for (const pattern of dangerousPatterns) {
            if (pattern.test(sanitized)) {
                throw new Error('Potentially dangerous input detected');
            }
        }
        
        return sanitized;
    }

    /**
     * Safely parses JSON with error handling
     */
    static safeJsonParse<T>(jsonString: string, defaultValue: T): T {
        try {
            return JSON.parse(jsonString) as T;
        } catch {
            return defaultValue;
        }
    }

    /**
     * Validates workspace folder path
     */
    static isValidWorkspacePath(workspacePath: string): boolean {
        try {
            const resolved = path.resolve(workspacePath);
            // Check if path is absolute and doesn't contain suspicious patterns
            return path.isAbsolute(resolved) && 
                   !resolved.includes('..') &&
                   !resolved.includes('~');
        } catch {
            return false;
        }
    }
}