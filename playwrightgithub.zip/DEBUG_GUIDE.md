# Debugging Guide for Playwright DOM Capture Extension

## Quick Start Debugging (F5 Method)

### Step 1: Open Project in VS Code
```bash
cd "C:\Users\Kamal Jaguri\GenAI\Playwright-domCapture"
code .
```

### Step 2: Set Breakpoints
Open these files and click on the line numbers to set breakpoints:

1. **src/extension.ts** - Line 24 (inside `activate` function)
   ```typescript
   export async function activate(context: vscode.ExtensionContext) {
       console.log('Playwright DOM Capture extension is activating...'); // SET BREAKPOINT HERE
   ```

2. **src/extension.ts** - Line 78 (auto-configure command)
   ```typescript
   vscode.commands.registerCommand('playwright-dom-capture.autoConfigureProject', async () => {
       console.log('Auto-configure command triggered'); // SET BREAKPOINT HERE
   ```

3. **src/copilotIntegration.ts** - Line 43 (Copilot participant registration)
   ```typescript
   export function registerCopilotParticipant(context: vscode.ExtensionContext): void {
       console.log('Registering Copilot participant...'); // SET BREAKPOINT HERE
   ```

### Step 3: Start Debugging
1. Press **F5** or go to Run → Start Debugging
2. Select "Run Extension" from the dropdown if prompted
3. A new VS Code window will open (Extension Development Host)

### Step 4: Test Commands in Debug Mode

In the **new VS Code window** that opened:

1. **Open Developer Tools** (for additional debugging):
   - Press `Ctrl+Shift+I` or
   - Help → Toggle Developer Tools

2. **Check Extension is Loaded**:
   - Press `Ctrl+Shift+P`
   - Type: `Developer: Show Running Extensions`
   - Look for "Playwright DOM Capture"

3. **Test Each Command**:
   ```
   Ctrl+Shift+P → DOM Capture: Auto-configure Project
   Ctrl+Shift+P → DOM Capture: Open Dashboard
   Ctrl+Shift+P → DOM Capture: View Last Capture
   Ctrl+Shift+P → DOM Capture: Clean Old Captures
   ```

4. **Test Copilot Integration**:
   - Open any JavaScript/TypeScript file
   - Type: `@domcapture` in Copilot chat
   - Ask: "How do I capture DOM?"

## Debug Output Locations

### 1. Debug Console (Original VS Code Window)
Shows breakpoint hits and console.log outputs

### 2. Output Panel (New VS Code Window)
- View → Output
- Select "Playwright DOM Capture" from dropdown
- Also check "Extension Host" channel

### 3. Developer Console (New VS Code Window)
- Ctrl+Shift+I → Console tab
- Shows JavaScript errors and warnings

## Common Issues and Solutions

### Issue 1: Extension Not Activating
**Check activation events in package.json:**
```json
"activationEvents": [
  "onStartupFinished",
  "onCommand:playwright-dom-capture.autoConfigureProject"
]
```

**Debug steps:**
1. Set breakpoint at line 24 in extension.ts
2. If breakpoint doesn't hit, extension isn't loading
3. Check Output → Extension Host for errors

### Issue 2: Commands Not Found
**Verify command registration:**
1. Set breakpoint inside each registerCommand
2. Check if registration code executes
3. Look for errors in try-catch blocks

### Issue 3: Copilot Not Responding
**Test Copilot integration:**
1. Ensure GitHub Copilot is installed and active
2. Check if participant registration succeeds
3. Try without special characters: `domcapture help`

## Advanced Debugging

### Enable Verbose Logging
Add to src/extension.ts activate function:
```typescript
// Enable verbose logging
const outputChannel = vscode.window.createOutputChannel('Playwright DOM Capture Debug');
outputChannel.appendLine(`Activation started at ${new Date().toISOString()}`);
outputChannel.appendLine(`Workspace: ${vscode.workspace.workspaceFolders?.[0]?.uri.fsPath}`);
outputChannel.appendLine(`Extension mode: ${context.extensionMode}`);
outputChannel.show();
```

### Check Extension Context
```typescript
// Log all registered commands
context.subscriptions.forEach((sub, index) => {
    console.log(`Subscription ${index}:`, sub);
});
```

### Monitor Command Execution
```typescript
// Wrap commands with detailed logging
const wrapCommand = (name: string, handler: Function) => {
    return async (...args: any[]) => {
        console.log(`Command ${name} called with args:`, args);
        try {
            const result = await handler(...args);
            console.log(`Command ${name} succeeded:`, result);
            return result;
        } catch (error) {
            console.error(`Command ${name} failed:`, error);
            throw error;
        }
    };
};
```

## Test Scenarios

### Scenario 1: Fresh Install
1. Uninstall any existing version
2. Install the VSIX
3. Reload VS Code
4. Test commands immediately

### Scenario 2: With Sample Project
1. Use "Run Extension (with sample workspace)" debug config
2. Tests with a Playwright project ready

### Scenario 3: Manual Activation
```typescript
// In Debug Console, force activation:
vscode.commands.executeCommand('playwright-dom-capture.autoConfigureProject')
```

## Debugging Checklist

- [ ] Extension appears in "Show Running Extensions"
- [ ] Activation breakpoint hits on startup
- [ ] Commands appear in Command Palette
- [ ] No errors in Extension Host output
- [ ] No errors in Debug Console
- [ ] Logger output channel created
- [ ] Commands execute when selected
- [ ] Copilot participant registered (if Copilot installed)

## Quick Debug Commands

Open Debug Console (Ctrl+Shift+Y) and run:

```javascript
// Check if extension is active
vscode.extensions.getExtension('test-publisher.playwright-dom-capture').isActive

// List all registered commands
vscode.commands.getCommands().then(cmds => 
    cmds.filter(c => c.includes('playwright-dom-capture')))

// Force activate extension
vscode.extensions.getExtension('test-publisher.playwright-dom-capture').activate()

// Execute a command directly
vscode.commands.executeCommand('playwright-dom-capture.showDashboard')
```

## VS Code Settings for Better Debugging

Add to User Settings (Ctrl+,):
```json
{
  "extensions.logLevel": "trace",
  "developer.showExtensionHostLog": true
}
```

## Report Issues

If commands still don't work after debugging:

1. Copy error messages from:
   - Debug Console
   - Extension Host Output
   - Developer Console

2. Note:
   - VS Code version
   - Extension version
   - Which commands fail
   - Any error messages

3. Check extension.ts line 24-35 executes without errors