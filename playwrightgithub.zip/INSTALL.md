# 📦 Installation & Setup Guide

## Prerequisites

- **Node.js**: Version 18.0 or higher
- **VS Code**: Version 1.85.0 or higher
- **Git**: For version control (optional)
- **GitHub Copilot**: For chat integration (optional)

## Quick Install (For Users)

### Option 1: Install Pre-built Extension

1. Download the latest `.vsix` file from releases
2. Open VS Code
3. Run Command Palette (`Ctrl+Shift+P`)
4. Type: `Extensions: Install from VSIX`
5. Select the downloaded `.vsix` file
6. Reload VS Code

Or via command line:
```bash
code --install-extension playwright-dom-capture-1.0.0.vsix
```

### Option 2: Install from Source

```bash
# Clone the repository
git clone https://github.com/yourusername/playwright-dom-capture.git
cd playwright-dom-capture

# Run automated setup
npm run setup

# Build the extension
npm run build

# Install in VS Code
npm run install-extension
```

## Development Setup

### 1. Clone and Setup

```bash
# Clone repository
git clone https://github.com/yourusername/playwright-dom-capture.git
cd playwright-dom-capture

# Install dependencies and setup
npm run setup
```

### 2. Development Workflow

```bash
# Start TypeScript compiler in watch mode
npm run watch

# In VS Code, press F5 to launch Extension Development Host
# Make changes and test in the new VS Code window
```

### 3. Build for Production

```bash
# Full production build with tests
npm run build:prod

# Skip tests for faster build
SKIP_TESTS=true npm run build
```

## First Time Setup for Your Project

After installing the extension:

1. **Open your Playwright project** in VS Code

2. **Auto-configure via Command Palette**:
   - Press `Ctrl+Shift+P`
   - Type: `DOM Capture: Auto-configure Project`
   - Follow the prompts

3. **Or use Copilot Chat** (if available):
   - Open Copilot Chat
   - Type: `@domcapture setup`
   - Click the setup button

## Verify Installation

### Check Extension is Active

1. Look for the DOM Capture icon in the status bar
2. Should show: `$(beaker) DOM Capture: Ready`

### Run Verification

```bash
# Via Command Palette
Ctrl+Shift+P → "DOM Capture: Verify Configuration"

# Via Copilot Chat
@domcapture verify
```

### Test the Extension

Create a simple test file:

```typescript
// test.spec.ts
import { test, expect } from './fixtures/dom-test';

test('sample test', async ({ page, captureDom }) => {
    await page.goto('https://example.com');
    await captureDom(); // Manual capture
    await expect(page).toHaveTitle(/Example/);
});
```

Run the test:
```bash
npm test
```

Check captures in: `test-results/dom-capture/`

## Troubleshooting

### Extension Not Loading

1. Check VS Code version: `code --version`
2. Ensure minimum version 1.85.0
3. Check extension logs: `View → Output → Playwright DOM Capture`

### Commands Not Available

1. Ensure you have a Playwright project open
2. Look for `playwright.config.ts` or `playwright.config.js`
3. Reload window: `Ctrl+Shift+P` → `Developer: Reload Window`

### Copilot Integration Not Working

1. Ensure GitHub Copilot is installed and active
2. Check Copilot Chat is available: `Ctrl+I`
3. Restart VS Code after installation

### Build Errors

```bash
# Clean everything and rebuild
npm run clean
npm run setup
npm run build
```

### Permission Errors

On Windows, run as Administrator:
```powershell
# Run PowerShell as Administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## Configuration

Edit VS Code settings (`Ctrl+,`):

```json
{
  "playwright-dom-capture.autoCapture": true,
  "playwright-dom-capture.includeScreenshot": true,
  "playwright-dom-capture.retentionDays": 7,
  "playwright-dom-capture.outputPath": "test-results/dom-capture"
}
```

## Uninstall

### Via VS Code

1. Open Extensions panel (`Ctrl+Shift+X`)
2. Find "Playwright DOM Capture"
3. Click Uninstall

### Via Command Line

```bash
code --uninstall-extension playwright-dom-capture
```

### Clean Project Configuration

To remove DOM capture from your project:
```bash
# Via Command Palette
Ctrl+Shift+P → "DOM Capture: Rollback Configuration"

# Or manually
rm -rf fixtures utils/dom-capture .dom-capture-backup
```

## Support

- **Documentation**: See README.md
- **Issues**: GitHub Issues page
- **Logs**: View → Output → Playwright DOM Capture

## Version Requirements

| Component | Minimum Version | Recommended |
|-----------|----------------|-------------|
| VS Code | 1.85.0 | Latest |
| Node.js | 18.0.0 | 20.x |
| TypeScript | 5.0.0 | 5.3.x |
| Playwright | 1.40.0 | Latest |

## License

MIT - See LICENSE file