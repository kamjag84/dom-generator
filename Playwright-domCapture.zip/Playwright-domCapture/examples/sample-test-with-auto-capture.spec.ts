/**
 * Sample Playwright test with automatic DOM capture enabled
 * 
 * Features:
 * - Press Ctrl+Shift+C anytime during test to capture DOM
 * - Click the floating capture button (bottom-right)
 * - Automatic capture on test failure
 * - Visual indicators show when capture is ready
 */

// Import the enhanced test fixture (auto-configured by extension)
import { test, expect } from '../dom-capture/playwright-fixture';

test.describe('Sample tests with auto DOM capture', () => {
    test('Basic navigation test', async ({ page }) => {
        // DOM capture is automatically enabled!
        // You'll see a floating capture button in the bottom-right corner
        
        await page.goto('https://playwright.dev');
        
        // Press Ctrl+Shift+C at any point to capture DOM
        // Or click the floating button
        
        await expect(page).toHaveTitle(/Playwright/);
        
        // Navigate to another page
        await page.click('text=Get started');
        
        // Capture will happen automatically if this test fails
        await expect(page).toHaveURL(/.*docs/);
    });
    
    test('Form interaction test', async ({ page }) => {
        await page.goto('https://demo.playwright.dev/todomvc');
        
        // The capture button follows you to every page
        
        // Add a todo item
        await page.locator('.new-todo').fill('Buy milk');
        await page.locator('.new-todo').press('Enter');
        
        // Press Ctrl+Shift+C here to capture the state with the todo
        
        await page.locator('.new-todo').fill('Write tests');
        await page.locator('.new-todo').press('Enter');
        
        // Check todos are added
        const todos = page.locator('.todo-list li');
        await expect(todos).toHaveCount(2);
    });
    
    test('Test with deliberate failure (to show auto-capture)', async ({ page }) => {
        await page.goto('https://example.com');
        
        // This will fail and trigger automatic DOM capture
        await expect(page.locator('h1')).toHaveText('This will fail');
        
        // The DOM will be automatically captured with:
        // - Full HTML structure
        // - All styles inlined
        // - Form states preserved
        // - Scroll positions saved
        // - Console logs included
    });
});

test.describe('Manual capture examples', () => {
    test('Using manual capture function', async ({ page }) => {
        await page.goto('https://github.com');
        
        // You can still manually capture at specific points
        // This is imported from the fixture
        const { captureDom } = require('../dom-capture/capture');
        
        // Capture after navigation
        await captureDom(page, 'after-github-load');
        
        // Do some actions
        await page.fill('[aria-label="Search GitHub"]', 'playwright');
        
        // Capture after search input
        await captureDom(page, 'after-search-input');
        
        // Both manual and hotkey captures work together!
    });
});

/**
 * HOW TO USE:
 * 
 * 1. Run this test: npx playwright test sample-test-with-auto-capture.spec.ts --headed
 * 2. Watch for the floating capture button (bottom-right corner)
 * 3. Press Ctrl+Shift+C anytime to capture DOM
 * 4. Click the floating button as an alternative
 * 5. Check test-results/dom-captures/ for captured files
 * 
 * CAPTURED FILES LOCATION:
 * test-results/
 * └── dom-captures/
 *     └── DD-MM-YYYY/
 *         └── TestClassName_TestMethodName/
 *             ├── capture_1_HH-MM-SS.html
 *             ├── capture_1_HH-MM-SS_metadata.json
 *             └── capture_1_HH-MM-SS_screenshot.png
 */