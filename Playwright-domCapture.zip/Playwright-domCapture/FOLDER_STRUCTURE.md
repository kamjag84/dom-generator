# 📁 DOM Capture Folder Structure

## Overview
All DOM captures are organized under a unified structure at `{PROJECT_ROOT}/test-results/dom-captures/`

## Complete Folder Structure

```
YOUR_PROJECT_ROOT/
│
├── test-results/
│   └── dom-captures/                              # All DOM captures root
│       │
│       ├── DD-MM-YYYY/                           # Date folders (e.g., 29-08-2025)
│       │   └── ClassName_MethodName/              # Test-specific folders
│       │       ├── capture_1_HH-MM-SS.html       # Full DOM capture
│       │       ├── capture_1_HH-MM-SS_metadata.json
│       │       ├── capture_1_HH-MM-SS_screenshot.png (optional)
│       │       ├── capture_2_HH-MM-SS.html       # Second capture in same test
│       │       ├── capture_2_HH-MM-SS_metadata.json
│       │       └── ...
│       │
│       ├── manual-dom-captures/                  # Manual captures (Ctrl+Alt+C)
│       │   └── DD-MM-YYYY/
│       │       ├── manual_capture_example_com_14-30-45.html
│       │       ├── manual_capture_example_com_14-30-45_metadata.json
│       │       └── manual_capture_google_com_15-22-10.html
│       │
│       ├── metadata/                             # Global metadata storage
│       ├── captures/                             # Programmatic captures
│       ├── chunks/                               # Large file chunks (>500KB)
│       ├── diffs/                                # Incremental diffs
│       ├── reports/                              # HTML analysis reports
│       └── integration/                          # Playwright integration
│           └── capture_id/
│               ├── screenshots/
│               └── trace.zip
```

## Naming Conventions

### Test Captures
- **Folder**: `{ClassName}_{MethodName}/`
  - ClassName: Extracted from test file name (e.g., `login.spec.ts` → `login_spec`)
  - MethodName: Sanitized test name (e.g., `should login successfully` → `should_login_successfully`)
- **Files**: `capture_{N}_{HH-MM-SS}.html`
  - N: Capture number within test (1, 2, 3...)
  - HH-MM-SS: Time of capture

### Manual Captures
- **Folder**: `manual-dom-captures/DD-MM-YYYY/`
- **Files**: `manual_capture_{hostname}_{HH-MM-SS}.html`
  - hostname: Domain with dots replaced (e.g., `example_com`)

## Examples

### Test Capture Path
```
test-results/dom-captures/29-08-2025/login_spec_should_login_successfully/
├── capture_1_14-30-45.html
├── capture_1_14-30-45_metadata.json
├── capture_1_14-30-45_screenshot.png
├── capture_2_14-31-20.html
└── capture_2_14-31-20_metadata.json
```

### Manual Capture Path
```
test-results/dom-captures/manual-dom-captures/29-08-2025/
├── manual_capture_example_com_14-30-45.html
└── manual_capture_example_com_14-30-45_metadata.json
```

## Metadata Structure

Each capture includes a `_metadata.json` file with:

```json
{
  "metadata": {
    "url": "https://example.com/page",
    "timestamp": "2025-08-29T14:30:45.123Z",
    "title": "Page Title",
    "viewport": { "width": 1280, "height": 720 },
    "performance": { ... },
    "resources": { ... }
  },
  "state": {
    "formData": [ ... ],
    "scrollPositions": { ... },
    "localStorage": { ... },
    "sessionStorage": { ... }
  },
  "testContext": {
    "className": "login_spec",
    "methodName": "should_login_successfully",
    "testFile": "login.spec.ts",
    "captureId": "capture_1_14-30-45"
  }
}
```

## Key Features

1. **Date Organization**: All captures organized by date (DD-MM-YYYY)
2. **Test Isolation**: Each test gets its own folder with class and method names
3. **Manual Separation**: Manual captures in dedicated `manual-dom-captures` folder
4. **Metadata Colocation**: Metadata files stored alongside captures
5. **Workspace Relative**: All paths relative to project root
6. **Consistent Timestamps**: HH-MM-SS format for all captures

## Path Resolution

The system automatically detects project root by looking for:
- `package.json`
- `playwright.config.ts` or `playwright.config.js`
- `.git` directory

## Size Management

- Files > 500KB are automatically chunked and stored in `/chunks`
- Incremental diffs stored in `/diffs` for space efficiency
- Configurable retention policies for automatic cleanup