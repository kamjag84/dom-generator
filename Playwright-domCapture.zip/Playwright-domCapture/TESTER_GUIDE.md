# 🎯 Playwright DOM Capture - Tester's Complete Guide

## ✅ Git-Safe Testing Workflow

This extension is specifically designed for testers who clone test repositories, run tests with DOM capture, and need to commit changes back to Git without accidentally including capture files.

## 📦 Installation

```bash
# Install the extension (one-time setup)
code --install-extension playwright-dom-capture-1.0.0.vsix
```

## 🚀 Complete Workflow for Testers

### Step 1: Clone Your Test Repository
```bash
git clone https://github.com/your-team/test-suite.git
cd test-suite
code .  # Open in VS Code
```

### Step 2: Auto-Configure the Project
```
Press: Ctrl+Shift+P
Type: "DOM Capture: Auto-configure Project"
Press: Enter
```

**What this does automatically:**
- ✅ Adds DOM capture paths to `.gitignore`
- ✅ Installs Git pre-commit hooks for safety
- ✅ Creates rollback manifest for easy cleanup
- ✅ Sets up Playwright integration

### Step 3: Run Your Tests with DOM Capture

#### During Test Execution:
- **Press `Ctrl+Shift+C`** - Capture DOM at any moment
- **Click floating button** - Alternative capture method (bottom-right)
- **Automatic capture** - Failures are captured automatically

```bash
# Run your tests
npm test
# or
npx playwright test --headed

# DOM captures are saved to:
# test-results/dom-captures/DD-MM-YYYY/TestClass_TestMethod/
```

### Step 4: Review Your Captures
```
Press: Ctrl+Shift+P
Type: "DOM Capture: Show Dashboard"
```

### Step 5: BEFORE COMMITTING (CRITICAL!)

**⚠️ ALWAYS run this command before git commit:**

```
Press: Ctrl+Shift+P
Type: "DOM Capture: Prepare for Commit"
Press: Enter
```

**This command will:**
- 🗑️ Delete all DOM captures
- 🔄 Rollback all configuration changes
- 📁 Remove all plugin-created files
- 🧹 Clean `.gitignore` entries
- 🔓 Remove Git hooks
- 📊 Show `git status` automatically

### Step 6: Commit and Push
```bash
# Now safe to commit
git add .
git commit -m "Fixed failing tests"
git push origin main
```

## 🛡️ Safety Features

### Pre-Commit Hook Protection
If you forget to clean captures before committing:
```
$ git commit -m "my changes"
⚠️  DOM captures detected in test-results/dom-captures/
Please run one of the following before committing:
  1. VS Code: Ctrl+Shift+P → 'DOM Capture: Prepare for Commit'
  2. Terminal: rm -rf test-results/dom-captures

To bypass this check (not recommended): git commit --no-verify
```

### Git Safety Check
```
Press: Ctrl+Shift+P
Type: "DOM Capture: Check Git Safety"
```
This will tell you if it's safe to commit or if cleanup is needed.

## 🎮 All Available Commands

| Command | Shortcut | Description |
|---------|----------|-------------|
| **Auto-configure Project** | - | Set up project for DOM capture |
| **Prepare for Commit** | - | Clean everything before git commit |
| **Check Git Safety** | - | Verify no captures will be committed |
| **Emergency Cleanup** | - | Force remove all captures and config |
| **Show Dashboard** | `Ctrl+Shift+D Ctrl+Shift+C` | View all captures |
| **Add Capture Point** | `Ctrl+Shift+C` (in editor) | Insert capture code |
| **Capture Current Page** | `Ctrl+Alt+C` | Manual URL capture |
| **Clean Old Captures** | - | Remove old capture files |

## 📁 What Gets Created (and Auto-Cleaned)

### Created During Use:
```
your-project/
├── test-results/
│   └── dom-captures/          # All DOM captures (auto-ignored by Git)
├── dom-capture/               # Configuration files (auto-ignored)
├── .gitignore                 # Updated with exclusions
├── .git/hooks/pre-commit      # Safety hook
└── .dom-capture-rollback.json # Rollback manifest (auto-ignored)
```

### After "Prepare for Commit":
```
your-project/
├── (your original files only)
└── .gitignore                 # Restored to original
```

## ⚡ Quick Commands Reference

```bash
# Essential workflow
Ctrl+Shift+P → "Auto-configure"     # Once after cloning
Ctrl+Shift+C                        # During test to capture
Ctrl+Shift+P → "Prepare for Commit" # Before EVERY commit
```

## 🚨 Emergency Situations

### If Something Goes Wrong:
```
Ctrl+Shift+P → "DOM Capture: Emergency Cleanup"
```
This will force-remove ALL captures and configuration.

### Manual Cleanup (if extension fails):
```bash
# Remove all captures
rm -rf test-results/dom-captures
rm -rf dom-capture
rm -f .dom-capture-rollback.json
rm -f *.dom-capture.backup

# Check what's left
git status
```

## ✅ Best Practices

1. **Always run "Prepare for Commit"** before `git commit`
2. **Check Git Safety** if unsure about repository state
3. **Use Emergency Cleanup** only as last resort
4. **Review captures** in dashboard before deleting
5. **Export important captures** before cleanup if needed

## 🔍 Verification Checklist

Before pushing to Git:
- [ ] Ran "Prepare for Commit"
- [ ] No `test-results/dom-captures/` folder exists
- [ ] No `dom-capture/` folder exists
- [ ] No `.dom-capture-rollback.json` file
- [ ] No `*.dom-capture.backup` files
- [ ] `git status` shows only intended changes

## 💡 Tips

- The extension automatically adds entries to `.gitignore` - no manual setup needed
- Git hooks prevent accidental commits of captures
- All changes are tracked for easy rollback
- The extension is Git-aware and repository-safe

## ⚠️ Important Notes

- **Never commit with `--no-verify`** unless you're certain captures are cleaned
- **Always use VS Code commands** for cleanup (not manual deletion)
- **The extension tracks all changes** for safe rollback

## 📞 Support

If you encounter issues:
1. Try "Emergency Cleanup"
2. Check VS Code Output panel → "Playwright DOM Capture"
3. Manually verify with `git status`

---

**Remember:** The golden rule is **"Prepare for Commit"** before EVERY git commit!