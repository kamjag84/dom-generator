# Development Commands for Claude Code

This file contains essential commands for development and maintenance of the Playwright DOM Capture extension.

## Build & Package Commands

### Compile TypeScript
```bash
npm run compile
```

### Package Extension
```bash
npm run package
```

### Watch for Changes
```bash
npm run watch
```

## Testing Commands

### Run Lint
```bash
npm run lint
```

### Type Check
```bash
npm run typecheck
```

### Run Tests
```bash
npm test
```

## Development Workflow

### Complete Build & Package
```bash
npm run compile && npm run package
```

### Install VSIX Locally
```bash
code --install-extension playwright-dom-capture-1.0.0.vsix
```

## Project Structure

```
Playwright-domCapture/
├── src/
│   ├── extension.ts                 # Main extension entry
│   ├── domCapture/                  # Core capture functionality
│   │   ├── advancedSerializer.ts    # DOM serialization
│   │   ├── compressionManager.ts    # Compression & storage
│   │   └── stateCapture.ts         # State preservation
│   ├── testIntegration/            # Playwright integration
│   │   └── playwrightTestHelper.ts # Test runtime integration
│   └── utils/                      # Utilities
│       ├── logger.ts               # Logging
│       └── errorHandler.ts        # Error handling
├── test-results/
│   └── dom-captures/               # Capture output directory
├── package.json                    # Extension manifest
├── tsconfig.json                   # TypeScript config
└── webpack.config.js              # Webpack bundling
```

## Key Features Implementation

### 1. Automatic Capture on Test Failure
- Location: `src/testIntegration/playwrightTestHelper.ts`
- Automatically triggers when Playwright tests fail

### 2. Runtime Capture (Ctrl+Shift+C)
- Location: `src/testIntegration/playwrightTestHelper.ts`
- Global hotkey listener during test execution

### 3. Manual Capture (Ctrl+Alt+C)
- Location: `src/extension.ts:334-429`
- Command: `playwright-dom-capture.captureCurrentPage`

### 4. Folder Structure Organization
- Pattern: `test-results/dom-captures/DD-MM-YYYY/ClassName_MethodName/`
- Defined in: `FOLDER_STRUCTURE.md`

## Important Files to Review

1. **Extension Entry**: `src/extension.ts`
2. **Test Integration**: `src/testIntegration/playwrightTestHelper.ts`
3. **DOM Serializer**: `src/domCapture/advancedSerializer.ts`
4. **Compression**: `src/domCapture/compressionManager.ts`
5. **Package Config**: `package.json`

## Common Issues & Solutions

### Compilation Errors
```bash
# Clean build
rm -rf dist/
npm run compile
```

### Extension Not Loading
1. Check `main` in package.json points to `./dist/extension.js`
2. Ensure activation events include `onStartupFinished`
3. Reload VS Code window

### Captures Not Appearing
1. Check folder permissions: `test-results/dom-captures/`
2. Verify Playwright is installed
3. Check test integration is properly configured

## Performance Optimization

### Compression Levels
- `none`: No compression, fastest
- `low`: Basic whitespace removal
- `medium`: Remove comments, minify styles (default)
- `high`: Full minification, smallest size

### Storage Management
- Enable deduplication to avoid storing identical DOMs
- Use chunking for files > 500KB
- Set appropriate retention period

## Debugging

### Enable Debug Logs
```typescript
// In src/utils/logger.ts
Logger.setLogLevel('debug');
```

### Check Extension Logs
1. Open VS Code Output panel
2. Select "Playwright DOM Capture" from dropdown

### Test Integration Issues
```bash
# Verify test helper is accessible
node -e "require('./dist/domCapture/testIntegration/playwrightTestHelper')"
```

## Release Checklist

- [ ] Update version in package.json
- [ ] Run `npm run compile`
- [ ] Run `npm run lint`
- [ ] Run `npm run typecheck`
- [ ] Test all commands manually
- [ ] Run `npm run package`
- [ ] Test VSIX installation
- [ ] Update README if needed
- [ ] Tag release in git

## VS Code Extension Development

### Reload Extension
- Press `Ctrl+Shift+P`
- Run "Developer: Reload Window"

### Debug Extension
1. Open project in VS Code
2. Press F5 to launch Extension Development Host
3. Set breakpoints in TypeScript files

### Test Commands
In Extension Development Host:
- `Ctrl+Shift+P` → Type "DOM Capture"
- Test each command
- Check Output panel for logs

## Useful NPM Scripts to Add

```json
{
  "scripts": {
    "clean": "rm -rf dist/",
    "build": "npm run clean && npm run compile",
    "build:prod": "npm run build && npm run package",
    "test:integration": "playwright test examples/",
    "format": "prettier --write src/**/*.ts",
    "check": "npm run lint && npm run typecheck"
  }
}
```

## Environment Variables

```bash
# Development
NODE_ENV=development

# Production build
NODE_ENV=production
```

## Git Workflow

```bash
# Feature branch
git checkout -b feature/new-capture-mode

# Commit with conventional commits
git commit -m "feat: add multi-tab capture support"
git commit -m "fix: resolve memory leak in serializer"
git commit -m "docs: update capture workflow documentation"

# Push and create PR
git push origin feature/new-capture-mode
```

---

**Note**: Always run `npm run compile` before `npm run package` to ensure latest changes are included in the VSIX bundle.