import * as assert from 'assert';
import * as vscode from 'vscode';
import * as path from 'path';
import { SecurityUtils } from '../../utils/security';
import { Logger } from '../../utils/logger';
import { ErrorHandler } from '../../utils/errorHandler';

suite('Extension Test Suite', () => {
    vscode.window.showInformationMessage('Start all tests.');

    test('Extension should be present', () => {
        assert.ok(vscode.extensions.getExtension('playwright-dom-capture'));
    });

    test('Should register all commands', async () => {
        const commands = await vscode.commands.getCommands();
        const expectedCommands = [
            'playwright-dom-capture.autoConfigureProject',
            'playwright-dom-capture.verifyConfig',
            'playwright-dom-capture.showLastCapture',
            'playwright-dom-capture.rollbackConfig',
            'playwright-dom-capture.showDashboard',
            'playwright-dom-capture.addCapturePoint',
            'playwright-dom-capture.toggleAutoCapture',
            'playwright-dom-capture.cleanCaptures'
        ];

        for (const cmd of expectedCommands) {
            assert.ok(commands.includes(cmd), `Command ${cmd} not registered`);
        }
    });

    test('Configuration should have correct defaults', () => {
        const config = vscode.workspace.getConfiguration('playwright-dom-capture');
        
        assert.strictEqual(config.get('autoCapture'), true);
        assert.strictEqual(config.get('captureOnSuccess'), false);
        assert.strictEqual(config.get('includeScreenshot'), true);
        assert.strictEqual(config.get('retentionDays'), 7);
    });
});

suite('Security Utils Test Suite', () => {
    test('Should sanitize file paths correctly', () => {
        const basePath = '/home/user/project';
        
        // Valid path
        const validPath = SecurityUtils.sanitizePath('test.html', basePath);
        assert.ok(validPath.startsWith(basePath));
        
        // Should throw on path traversal
        assert.throws(() => {
            SecurityUtils.sanitizePath('../../../etc/passwd', basePath);
        }, /Path traversal detected/);
    });

    test('Should sanitize file names', () => {
        // Normal filename
        const normal = SecurityUtils.sanitizeFileName('test_file.html');
        assert.strictEqual(normal, 'test_file.html');
        
        // Dangerous characters
        const dangerous = SecurityUtils.sanitizeFileName('test<script>alert(1)</script>.html');
        assert.ok(!dangerous.includes('<script>'));
        
        // Long filename
        const longName = 'a'.repeat(300);
        const sanitized = SecurityUtils.sanitizeFileName(longName);
        assert.ok(sanitized.length <= 255);
    });

    test('Should sanitize HTML content', () => {
        const html = '<div><script>alert("xss")</script><p onclick="evil()">Text</p></div>';
        const sanitized = SecurityUtils.sanitizeHtml(html);
        
        assert.ok(!sanitized.includes('<script>'));
        assert.ok(!sanitized.includes('onclick'));
    });

    test('Should validate input', () => {
        // Valid input
        const valid = SecurityUtils.validateInput('normal text');
        assert.strictEqual(valid, 'normal text');
        
        // Directory traversal
        assert.throws(() => {
            SecurityUtils.validateInput('../../etc/passwd');
        }, /dangerous input/);
        
        // Script injection
        assert.throws(() => {
            SecurityUtils.validateInput('<script>alert(1)</script>');
        }, /dangerous input/);
    });
});

suite('Error Handler Test Suite', () => {
    test('Should handle async errors gracefully', async () => {
        const result = await ErrorHandler.withErrorHandling(
            async () => {
                throw new Error('Test error');
            },
            'Test operation failed',
            false // Don't show to user
        );
        
        assert.strictEqual(result, undefined);
    });

    test('Should handle sync errors with default value', () => {
        const result = ErrorHandler.withErrorHandlingSync(
            () => {
                throw new Error('Test error');
            },
            'Test operation failed',
            'default',
            false
        );
        
        assert.strictEqual(result, 'default');
    });

    test('Should retry operations', async () => {
        let attempts = 0;
        const result = await ErrorHandler.withRetry(
            async () => {
                attempts++;
                if (attempts < 2) {
                    throw new Error('Retry test');
                }
                return 'success';
            },
            3,
            100
        );
        
        assert.strictEqual(result, 'success');
        assert.strictEqual(attempts, 2);
    });

    test('Should validate conditions', () => {
        // Should pass
        assert.doesNotThrow(() => {
            ErrorHandler.validateConditions([
                { condition: true, message: 'Should not throw' }
            ]);
        });
        
        // Should fail
        assert.throws(() => {
            ErrorHandler.validateConditions([
                { condition: false, message: 'Should throw this' }
            ]);
        }, /Should throw this/);
    });
});

suite('Logger Test Suite', () => {
    let logger: Logger;

    setup(() => {
        logger = Logger.getInstance();
    });

    test('Should create singleton instance', () => {
        const logger1 = Logger.getInstance();
        const logger2 = Logger.getInstance();
        assert.strictEqual(logger1, logger2);
    });

    test('Should log messages at different levels', () => {
        // These should not throw
        assert.doesNotThrow(() => {
            logger.debug('Debug message');
            logger.info('Info message');
            logger.warn('Warning message');
            logger.error('Error message', new Error('Test error'));
        });
    });
});