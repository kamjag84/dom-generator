import * as vscode from 'vscode';
import * as path from 'path';
import { CaptureInfo, CaptureManager } from './captureManager';

export class DomCaptureProvider implements vscode.TreeDataProvider<CaptureTreeItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<CaptureTreeItem | undefined | null | void> = new vscode.EventEmitter<CaptureTreeItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<CaptureTreeItem | undefined | null | void> = this._onDidChangeTreeData.event;

    private captureManager: CaptureManager;

    constructor(private context: vscode.ExtensionContext) {
        this.captureManager = new CaptureManager(context);
    }

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: CaptureTreeItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: CaptureTreeItem): Promise<CaptureTreeItem[]> {
        if (!element) {
            // Root level - show date folders
            const captures = await this.captureManager.getCaptures();
            const dateMap = new Map<string, CaptureInfo[]>();
            
            captures.forEach(capture => {
                const dateStr = this.formatDate(capture.timestamp);
                if (!dateMap.has(dateStr)) {
                    dateMap.set(dateStr, []);
                }
                dateMap.get(dateStr)!.push(capture);
            });

            const items: CaptureTreeItem[] = [];
            dateMap.forEach((captures, date) => {
                items.push(new CaptureTreeItem(
                    date,
                    captures.length.toString(),
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'date',
                    undefined,
                    captures
                ));
            });

            return items;
        } else if (element.contextValue === 'date') {
            // Show captures for a specific date
            return element.captures!.map(capture => 
                new CaptureTreeItem(
                    capture.testName,
                    this.formatTime(capture.timestamp),
                    vscode.TreeItemCollapsibleState.None,
                    'capture',
                    capture,
                    undefined
                )
            );
        }

        return [];
    }

    private formatDate(date: Date): string {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    private formatTime(date: Date): string {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }
}

class CaptureTreeItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        private readonly desc: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly contextValue: string,
        public readonly capture?: CaptureInfo,
        public readonly captures?: CaptureInfo[]
    ) {
        super(label, collapsibleState);

        this.tooltip = this.label;
        this.description = this.desc;

        if (contextValue === 'capture' && capture) {
            this.iconPath = capture.status === 'failed' 
                ? new vscode.ThemeIcon('error')
                : new vscode.ThemeIcon('pass');
            
            this.command = {
                command: 'vscode.open',
                title: 'Open Capture',
                arguments: [vscode.Uri.file(capture.path)]
            };

            this.contextValue = `capture-${capture.status}`;
        } else if (contextValue === 'date') {
            this.iconPath = new vscode.ThemeIcon('calendar');
        }
    }
}