import { test as base, Page } from '@playwright/test';
import { TestCaptureManager } from './playwrightTestHelper';

/**
 * Enhanced Playwright test fixtures with automatic DOM capture support
 */
export const test = base.extend<{
  autoCapturePage: Page;
}>({
  autoCapturePage: async ({ page }, use) => {
    const captureManager = TestCaptureManager.getInstance();
    
    // Automatically enable hotkey capture for every page
    await captureManager.enableHotkeyCapture(page);
    
    // Add visual indicator that capture is ready
    await page.addInitScript(() => {
      // Create floating capture button
      const button = document.createElement('div');
      button.id = 'dom-capture-indicator';
      button.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 999998;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        transition: all 0.3s ease;
        opacity: 0.7;
      `;
      button.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
      button.title = 'Press Ctrl+Shift+C to capture DOM';
      
      // Add hover effect
      button.addEventListener('mouseenter', () => {
        button.style.opacity = '1';
        button.style.transform = 'scale(1.1)';
      });
      
      button.addEventListener('mouseleave', () => {
        button.style.opacity = '0.7';
        button.style.transform = 'scale(1)';
      });
      
      // Click to capture
      button.addEventListener('click', () => {
        (window as any).__triggerDomCapture = true;
        
        // Visual feedback
        button.style.background = '#4CAF50';
        button.innerHTML = '✓';
        setTimeout(() => {
          button.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
          button.innerHTML = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          `;
        }, 1500);
      });
      
      // Add to page after load
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
          document.body.appendChild(button);
        });
      } else {
        document.body.appendChild(button);
      }
      
      // Show hint on first load
      setTimeout(() => {
        const hint = document.createElement('div');
        hint.style.cssText = `
          position: fixed;
          bottom: 80px;
          right: 20px;
          background: rgba(0,0,0,0.8);
          color: white;
          padding: 10px 15px;
          border-radius: 5px;
          font-family: Arial, sans-serif;
          font-size: 12px;
          z-index: 999997;
          animation: fadeIn 0.5s ease;
        `;
        hint.innerHTML = 'Ctrl+Shift+C to capture DOM';
        document.body.appendChild(hint);
        
        setTimeout(() => hint.remove(), 5000);
      }, 1000);
      
      // Add fade animation
      const style = document.createElement('style');
      style.textContent = `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `;
      document.head.appendChild(style);
    });
    
    // Auto-capture on test failure
    page.on('pageerror', async (error) => {
      console.error('Page error detected, capturing DOM...');
      await captureManager.captureFromPage(page, {
        stepName: 'Error Capture',
        includeScreenshot: true,
        customMetadata: { error: error.message }
      });
    });
    
    // Use the enhanced page
    await use(page);
    
    // Cleanup
    const interval = (page as any).__captureInterval;
    if (interval) {
      clearInterval(interval);
    }
  }
});

export { expect } from '@playwright/test';