import { Page, BrowserContext, Browser } from '@playwright/test';
import { captureDom } from './playwrightTestHelper';

/**
 * Runtime DOM Capture Injector
 * Automatically adds capture capability to any Playwright test
 */
export class RuntimeDomCaptureInjector {
  private static isInjected = false;
  private static captureQueue: Array<{ page: Page; trigger: string }> = [];
  private static globalHotkeyListener: NodeJS.Timer | null = null;

  /**
   * Inject capture capability into a browser instance
   */
  static async injectIntoBrowser(browser: Browser): Promise<void> {
    browser.on('disconnected', () => {
      this.cleanup();
    });

    // Monitor all new contexts
    const originalNewContext = browser.newContext.bind(browser);
    browser.newContext = async function(...args: any[]) {
      const context = await originalNewContext(...args);
      await RuntimeDomCaptureInjector.injectIntoContext(context);
      return context;
    };

    // Also handle newPage directly on browser
    const originalNewPage = browser.newPage.bind(browser);
    browser.newPage = async function(...args: any[]) {
      const page = await originalNewPage(...args);
      await RuntimeDomCaptureInjector.injectIntoPage(page);
      return page;
    };

    console.log('✅ DOM Capture injected into browser');
  }

  /**
   * Inject capture capability into a browser context
   */
  static async injectIntoContext(context: BrowserContext): Promise<void> {
    // Monitor all pages in context
    context.on('page', async (page) => {
      await this.injectIntoPage(page);
    });

    // Inject into existing pages
    for (const page of context.pages()) {
      await this.injectIntoPage(page);
    }

    console.log('✅ DOM Capture injected into context');
  }

  /**
   * Inject capture capability into a page
   */
  static async injectIntoPage(page: Page): Promise<void> {
    // Add initialization script that runs before page loads
    await page.addInitScript(() => {
      // Global capture trigger
      (window as any).__domCaptureEnabled = true;
      (window as any).__captureHistory = [];
      
      // Enhanced console log to track captures
      const originalLog = console.log;
      console.log = function(...args: any[]) {
        originalLog.apply(console, args);
        if (args[0]?.includes?.('DOM_CAPTURE_TRIGGER')) {
          (window as any).__triggerCapture = {
            timestamp: Date.now(),
            reason: args[1] || 'Manual trigger'
          };
        }
      };

      // Capture function available in page context
      (window as any).captureDom = function(reason?: string) {
        console.log('DOM_CAPTURE_TRIGGER', reason || 'Manual API call');
        return new Promise((resolve) => {
          const checkInterval = setInterval(() => {
            const history = (window as any).__captureHistory;
            if (history.length > 0) {
              clearInterval(checkInterval);
              resolve(history[history.length - 1]);
            }
          }, 100);
        });
      };

      // Visual capture button
      if (!(window as any).__captureButtonAdded) {
        const addCaptureButton = () => {
          const button = document.createElement('button');
          button.id = 'dom-capture-button';
          button.innerHTML = '📸';
          button.title = 'Capture DOM (Ctrl+Shift+C)';
          button.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #2196F3;
            color: white;
            border: none;
            font-size: 24px;
            cursor: pointer;
            z-index: 999999;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            opacity: 0.8;
          `;
          
          button.onmouseover = () => {
            button.style.opacity = '1';
            button.style.transform = 'scale(1.1)';
          };
          
          button.onmouseout = () => {
            button.style.opacity = '0.8';
            button.style.transform = 'scale(1)';
          };
          
          button.onclick = () => {
            (window as any).captureDom('Button click');
            
            // Visual feedback
            button.style.background = '#4CAF50';
            button.innerHTML = '✅';
            setTimeout(() => {
              button.style.background = '#2196F3';
              button.innerHTML = '📸';
            }, 1000);
          };
          
          document.body.appendChild(button);
          (window as any).__captureButtonAdded = true;
        };

        // Add button when DOM is ready
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', addCaptureButton);
        } else {
          setTimeout(addCaptureButton, 100);
        }
      }

      // Keyboard shortcut handler
      document.addEventListener('keydown', (event) => {
        // Ctrl+Shift+C for capture
        if (event.ctrlKey && event.shiftKey && event.key === 'C') {
          event.preventDefault();
          event.stopPropagation();
          (window as any).captureDom('Hotkey Ctrl+Shift+C');
        }
        
        // Ctrl+Shift+D for capture with dialog
        if (event.ctrlKey && event.shiftKey && event.key === 'D') {
          event.preventDefault();
          event.stopPropagation();
          const reason = prompt('Enter capture reason (optional):');
          (window as any).captureDom(reason || 'Hotkey with dialog');
        }
      }, true);

      // Notify that injection is complete
      console.log('🎯 DOM Capture injected - Press Ctrl+Shift+C to capture');
    });

    // Monitor for capture triggers
    const monitorInterval = setInterval(async () => {
      try {
        const trigger = await page.evaluate(() => {
          const t = (window as any).__triggerCapture;
          if (t) {
            (window as any).__triggerCapture = null;
            return t;
          }
          return null;
        });

        if (trigger) {
          console.log(`📸 Capturing DOM: ${trigger.reason}`);
          
          // Perform capture
          const result = await captureDom(page, trigger.reason, {
            includeScreenshot: true,
            customMetadata: {
              trigger: 'runtime',
              reason: trigger.reason,
              timestamp: trigger.timestamp
            }
          });

          // Store result in page context
          await page.evaluate((captureResult) => {
            (window as any).__captureHistory.push(captureResult);
            
            // Show notification
            const notification = document.createElement('div');
            notification.style.cssText = `
              position: fixed;
              top: 20px;
              left: 50%;
              transform: translateX(-50%);
              background: #4CAF50;
              color: white;
              padding: 15px 25px;
              border-radius: 5px;
              font-family: Arial, sans-serif;
              font-size: 14px;
              z-index: 999999;
              box-shadow: 0 4px 6px rgba(0,0,0,0.2);
              animation: slideDown 0.3s ease-out;
            `;
            notification.innerHTML = `✅ DOM Captured: ${captureResult.id}`;
            document.body.appendChild(notification);
            
            setTimeout(() => {
              notification.style.animation = 'slideUp 0.3s ease-in';
              setTimeout(() => notification.remove(), 300);
            }, 3000);
          }, result);
        }
      } catch (error: any) {
        // Page might be closed or navigated
        if (error?.message?.includes('closed') || error?.message?.includes('navigat')) {
          clearInterval(monitorInterval);
        }
      }
    }, 100);

    // Clean up on page close
    page.once('close', () => {
      clearInterval(monitorInterval);
    });
  }

  /**
   * Enable global capture across all Playwright tests
   */
  static async enableGlobalCapture(): Promise<void> {
    if (this.isInjected) return;

    // Override Playwright's chromium.launch
    const playwright = require('@playwright/test');
    const originalLaunch = playwright.chromium.launch;
    
    playwright.chromium.launch = async function(...args: any[]) {
      const browser = await originalLaunch.apply(playwright.chromium, args);
      await RuntimeDomCaptureInjector.injectIntoBrowser(browser);
      return browser;
    };

    // Also override firefox and webkit
    ['firefox', 'webkit'].forEach(browserType => {
      const original = playwright[browserType].launch;
      playwright[browserType].launch = async function(...args: any[]) {
        const browser = await original.apply(playwright[browserType], args);
        await RuntimeDomCaptureInjector.injectIntoBrowser(browser);
        return browser;
      };
    });

    this.isInjected = true;
    console.log('✅ Global DOM Capture enabled for all tests');
  }

  /**
   * Capture from all active pages
   */
  static async captureAllActive(reason?: string): Promise<void> {
    for (const { page } of this.captureQueue) {
      try {
        await captureDom(page, reason || 'Bulk capture');
      } catch (error: any) {
        console.error(`Failed to capture from page: ${error?.message || 'Unknown error'}`);
      }
    }
  }

  /**
   * Clean up resources
   */
  static cleanup(): void {
    if (this.globalHotkeyListener) {
      clearInterval(this.globalHotkeyListener as any);
      this.globalHotkeyListener = null;
    }
    this.captureQueue = [];
  }
}

/**
 * Middleware for automatic injection in test files
 */
export async function withDomCapture<T>(
  testFunction: () => Promise<T>
): Promise<T> {
  await RuntimeDomCaptureInjector.enableGlobalCapture();
  
  try {
    return await testFunction();
  } finally {
    RuntimeDomCaptureInjector.cleanup();
  }
}

/**
 * Test configuration helper
 */
export const domCaptureConfig = {
  /**
   * Use in playwright.config.ts to enable globally
   */
  use: {
    ...{
      // Automatically inject DOM capture
      beforeEach: async ({ page }: any) => {
        await RuntimeDomCaptureInjector.injectIntoPage(page);
      }
    }
  },

  /**
   * Global setup function
   */
  globalSetup: async () => {
    await RuntimeDomCaptureInjector.enableGlobalCapture();
  },

  /**
   * Global teardown function
   */
  globalTeardown: async () => {
    RuntimeDomCaptureInjector.cleanup();
  }
};