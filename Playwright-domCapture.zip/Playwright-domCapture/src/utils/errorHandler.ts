import * as vscode from 'vscode';
import { Logger } from './logger';

export class ErrorHandler {
    private static logger = Logger.getInstance();

    /**
     * Wraps an async function with error handling
     */
    static async withErrorHandling<T>(
        operation: () => Promise<T>,
        errorMessage: string,
        showUser: boolean = true
    ): Promise<T | undefined> {
        try {
            return await operation();
        } catch (error: any) {
            this.logger.error(errorMessage, error);
            
            if (showUser) {
                const detailedMessage = `${errorMessage}: ${error?.message || 'Unknown error'}`;
                vscode.window.showErrorMessage(detailedMessage, 'Show Logs').then(selection => {
                    if (selection === 'Show Logs') {
                        this.logger.show();
                    }
                });
            }
            
            return undefined;
        }
    }

    /**
     * Wraps a sync function with error handling
     */
    static withErrorHandlingSync<T>(
        operation: () => T,
        errorMessage: string,
        defaultValue: T,
        showUser: boolean = true
    ): T {
        try {
            return operation();
        } catch (error: any) {
            this.logger.error(errorMessage, error);
            
            if (showUser) {
                vscode.window.showErrorMessage(`${errorMessage}: ${error?.message || 'Unknown error'}`);
            }
            
            return defaultValue;
        }
    }

    /**
     * Retries an operation with exponential backoff
     */
    static async withRetry<T>(
        operation: () => Promise<T>,
        maxRetries: number = 3,
        initialDelay: number = 1000
    ): Promise<T> {
        let lastError: Error | undefined;
        
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            try {
                return await operation();
            } catch (error: any) {
                lastError = error;
                this.logger.warn(`Operation failed (attempt ${attempt + 1}/${maxRetries})`, error.message);
                
                if (attempt < maxRetries - 1) {
                    const delay = initialDelay * Math.pow(2, attempt);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        
        throw lastError || new Error('Operation failed after retries');
    }

    /**
     * Validates required conditions before proceeding
     */
    static validateConditions(conditions: { condition: boolean; message: string }[]): void {
        for (const { condition, message } of conditions) {
            if (!condition) {
                throw new Error(message);
            }
        }
    }

    /**
     * Handles disposal of resources safely
     */
    static async safeDispose(disposables: vscode.Disposable[]): Promise<void> {
        for (const disposable of disposables) {
            try {
                disposable.dispose();
            } catch (error: any) {
                this.logger.error('Failed to dispose resource', error);
            }
        }
    }

    /**
     * Creates a timeout promise
     */
    static timeout<T>(promise: Promise<T>, timeoutMs: number, timeoutMessage?: string): Promise<T> {
        return Promise.race([
            promise,
            new Promise<T>((_, reject) => 
                setTimeout(() => reject(new Error(timeoutMessage || `Operation timed out after ${timeoutMs}ms`)), timeoutMs)
            )
        ]);
    }
}