import * as vscode from 'vscode';

export enum LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARN = 2,
    ERROR = 3
}

export class Logger {
    private static instance: Logger;
    private outputChannel: vscode.OutputChannel;
    private logLevel: LogLevel;

    private constructor() {
        this.outputChannel = vscode.window.createOutputChannel('Playwright DOM Capture');
        this.logLevel = this.getConfiguredLogLevel();
    }

    static getInstance(): Logger {
        if (!Logger.instance) {
            Logger.instance = new Logger();
        }
        return Logger.instance;
    }

    private getConfiguredLogLevel(): LogLevel {
        const config = vscode.workspace.getConfiguration('playwright-dom-capture');
        const level = config.get<string>('logLevel', 'info').toLowerCase();
        
        switch (level) {
            case 'debug': return LogLevel.DEBUG;
            case 'info': return LogLevel.INFO;
            case 'warn': return LogLevel.WARN;
            case 'error': return LogLevel.ERROR;
            default: return LogLevel.INFO;
        }
    }

    private formatMessage(level: string, message: string, ...args: any[]): string {
        const timestamp = new Date().toISOString();
        const formattedArgs = args.length > 0 ? ' ' + JSON.stringify(args) : '';
        return `[${timestamp}] [${level}] ${message}${formattedArgs}`;
    }

    debug(message: string, ...args: any[]): void {
        if (this.logLevel <= LogLevel.DEBUG) {
            const formatted = this.formatMessage('DEBUG', message, ...args);
            this.outputChannel.appendLine(formatted);
            console.log(formatted);
        }
    }

    info(message: string, ...args: any[]): void {
        if (this.logLevel <= LogLevel.INFO) {
            const formatted = this.formatMessage('INFO', message, ...args);
            this.outputChannel.appendLine(formatted);
            console.log(formatted);
        }
    }

    warn(message: string, ...args: any[]): void {
        if (this.logLevel <= LogLevel.WARN) {
            const formatted = this.formatMessage('WARN', message, ...args);
            this.outputChannel.appendLine(formatted);
            console.warn(formatted);
        }
    }

    error(message: string, error?: Error | any, ...args: any[]): void {
        if (this.logLevel <= LogLevel.ERROR) {
            const errorDetails = error ? {
                message: error.message || String(error),
                stack: error.stack,
                ...error
            } : undefined;
            
            const formatted = this.formatMessage('ERROR', message, errorDetails, ...args);
            this.outputChannel.appendLine(formatted);
            console.error(formatted);
        }
    }

    show(): void {
        this.outputChannel.show();
    }

    dispose(): void {
        this.outputChannel.dispose();
    }
}