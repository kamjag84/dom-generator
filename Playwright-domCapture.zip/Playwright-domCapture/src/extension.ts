console.log('[PLAYWRIGHT-DOM-CAPTURE] Extension file loaded at:', new Date().toISOString());

import * as vscode from 'vscode';

console.log('[PLAYWRIGHT-DOM-CAPTURE] vscode imported successfully');

import * as path from 'path';
import * as fs from 'fs-extra';
import { DomCaptureProvider } from './domCaptureProvider';
import { ProjectConfigurator } from './projectConfigurator';
import { DashboardPanel } from './dashboardPanel';
import { CaptureManager } from './captureManager';
import { DomCaptureChatParticipant } from './chatParticipant';
import { Logger } from './utils/logger';
import { ErrorHandler } from './utils/errorHandler';
import { GitIntegrationManager } from './gitIntegration';

let logger: Logger | undefined;
let fileWatcher: vscode.FileSystemWatcher | undefined;

// Safe logging function that falls back to console
function safeLog(level: 'info' | 'error' | 'warn' | 'debug', message: string, ...args: any[]) {
    try {
        if (!logger) {
            logger = Logger.getInstance();
        }
        (logger as any)[level](message, ...args);
    } catch (e) {
        console.log(`[Playwright DOM Capture] [${level.toUpperCase()}] ${message}`, ...args);
        if (e instanceof Error) {
            console.error('[Playwright DOM Capture] Logger error:', e.message);
        }
    }
}

export async function activate(context: vscode.ExtensionContext) {
    console.log('[Playwright DOM Capture] Extension activation started');
    safeLog('info', 'Playwright DOM Capture extension is activating...');

    try {
        console.log('[Playwright DOM Capture] Initializing components...');
        
        let captureManager: CaptureManager | undefined;
        let configurator: ProjectConfigurator | undefined;
        let dashboardProvider: DomCaptureProvider | undefined;
        let chatParticipant: DomCaptureChatParticipant | undefined;
        let gitIntegration: GitIntegrationManager | undefined;
        
        try {
            captureManager = new CaptureManager(context);
            console.log('[Playwright DOM Capture] CaptureManager initialized');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to initialize CaptureManager:', e);
        }
        
        try {
            configurator = new ProjectConfigurator(context);
            console.log('[Playwright DOM Capture] ProjectConfigurator initialized');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to initialize ProjectConfigurator:', e);
        }
        
        try {
            dashboardProvider = new DomCaptureProvider(context);
            console.log('[Playwright DOM Capture] DomCaptureProvider initialized');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to initialize DomCaptureProvider:', e);
        }
        
        try {
            chatParticipant = new DomCaptureChatParticipant(context);
            console.log('[Playwright DOM Capture] DomCaptureChatParticipant initialized');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to initialize DomCaptureChatParticipant:', e);
        }
        
        // Initialize Git integration
        try {
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (workspaceFolder) {
                gitIntegration = new GitIntegrationManager(workspaceFolder.uri.fsPath);
                await gitIntegration.initialize();
                console.log('[Playwright DOM Capture] GitIntegrationManager initialized');
            }
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to initialize GitIntegrationManager:', e);
        }

        // Register commands with error handling
        console.log('[Playwright DOM Capture] Registering commands...');
        const commands = [];
        
        // Register each command with individual error handling
        try {
            const cmd1 = vscode.commands.registerCommand('playwright-dom-capture.autoConfigureProject', async () => {
                console.log('[Playwright DOM Capture] autoConfigureProject command triggered');
                if (!configurator) {
                    vscode.window.showErrorMessage('Project configurator not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => autoConfigureProject(configurator),
                    'Failed to configure project'
                );
            });
            commands.push(cmd1);
            console.log('[Playwright DOM Capture] Registered: autoConfigureProject');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register autoConfigureProject:', e);
        }
        
        try {
            const cmd2 = vscode.commands.registerCommand('playwright-dom-capture.verifyConfig', async () => {
                if (!configurator) {
                    vscode.window.showErrorMessage('Project configurator not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => verifyConfiguration(configurator),
                    'Failed to verify configuration'
                );
            });
            commands.push(cmd2);
            console.log('[Playwright DOM Capture] Registered: verifyConfig');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register verifyConfig:', e);
        }
        
        try {
            const cmd3 = vscode.commands.registerCommand('playwright-dom-capture.showLastCapture', async () => {
                if (!captureManager) {
                    vscode.window.showErrorMessage('Capture manager not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => showLastCapture(captureManager),
                    'Failed to show last capture'
                );
            });
            commands.push(cmd3);
            console.log('[Playwright DOM Capture] Registered: showLastCapture');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register showLastCapture:', e);
        }
        
        try {
            const cmd4 = vscode.commands.registerCommand('playwright-dom-capture.rollbackConfig', async () => {
                if (!configurator) {
                    vscode.window.showErrorMessage('Project configurator not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => rollbackConfiguration(configurator),
                    'Failed to rollback configuration'
                );
            });
            commands.push(cmd4);
            console.log('[Playwright DOM Capture] Registered: rollbackConfig');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register rollbackConfig:', e);
        }
        
        try {
            const cmd5 = vscode.commands.registerCommand('playwright-dom-capture.showDashboard', () => {
                if (!captureManager) {
                    vscode.window.showErrorMessage('Capture manager not initialized');
                    return;
                }
                ErrorHandler.withErrorHandlingSync(
                    () => DashboardPanel.createOrShow(context.extensionUri, captureManager),
                    'Failed to show dashboard',
                    undefined
                );
            });
            commands.push(cmd5);
            console.log('[Playwright DOM Capture] Registered: showDashboard');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register showDashboard:', e);
        }
        
        try {
            const cmd6 = vscode.commands.registerCommand('playwright-dom-capture.addCapturePoint', async () => {
                await ErrorHandler.withErrorHandling(
                    () => addCapturePoint(),
                    'Failed to add capture point'
                );
            });
            commands.push(cmd6);
            console.log('[Playwright DOM Capture] Registered: addCapturePoint');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register addCapturePoint:', e);
        }
        
        try {
            const cmd7 = vscode.commands.registerCommand('playwright-dom-capture.toggleAutoCapture', async () => {
                await ErrorHandler.withErrorHandling(
                    () => toggleAutoCapture(),
                    'Failed to toggle auto-capture'
                );
            });
            commands.push(cmd7);
            console.log('[Playwright DOM Capture] Registered: toggleAutoCapture');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register toggleAutoCapture:', e);
        }
        
        try {
            const cmd8 = vscode.commands.registerCommand('playwright-dom-capture.cleanCaptures', async () => {
                if (!captureManager) {
                    vscode.window.showErrorMessage('Capture manager not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => cleanOldCaptures(captureManager),
                    'Failed to clean captures'
                );
            });
            commands.push(cmd8);
            console.log('[Playwright DOM Capture] Registered: cleanCaptures');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register cleanCaptures:', e);
        }
        
        try {
            const cmd9 = vscode.commands.registerCommand('playwright-dom-capture.captureCurrentPage', async () => {
                if (!captureManager) {
                    vscode.window.showErrorMessage('Capture manager not initialized');
                    return;
                }
                await ErrorHandler.withErrorHandling(
                    () => captureCurrentPage(captureManager),
                    'Failed to capture current page'
                );
            });
            commands.push(cmd9);
            console.log('[Playwright DOM Capture] Registered: captureCurrentPage');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register captureCurrentPage:', e);
        }
        
        // Register Git integration commands
        try {
            const cmd10 = vscode.commands.registerCommand('playwright-dom-capture.prepareForCommit', async () => {
                await ErrorHandler.withErrorHandling(
                    async () => {
                        // Clean all captures
                        if (captureManager) {
                            await captureManager.cleanOldCaptures(0); // Delete all
                        }
                        
                        // Rollback configuration
                        if (gitIntegration) {
                            const result = await gitIntegration.rollbackAllChanges();
                            if (result.success) {
                                vscode.window.showInformationMessage(
                                    `✅ Ready to commit! Cleaned ${result.filesDeleted} files, restored ${result.filesRestored} files.`
                                );
                            } else {
                                vscode.window.showWarningMessage(
                                    `⚠️ Cleanup completed with errors: ${result.errors.join(', ')}`
                                );
                            }
                        }
                        
                        // Show git status
                        const terminal = vscode.window.createTerminal('Git Status');
                        terminal.show();
                        terminal.sendText('git status');
                    },
                    'Failed to prepare for commit'
                );
            });
            commands.push(cmd10);
            console.log('[Playwright DOM Capture] Registered: prepareForCommit');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register prepareForCommit:', e);
        }
        
        try {
            const cmd11 = vscode.commands.registerCommand('playwright-dom-capture.checkGitSafety', async () => {
                if (!gitIntegration) {
                    vscode.window.showWarningMessage('Git integration not available');
                    return;
                }
                
                const safety = await gitIntegration.checkGitSafety();
                if (safety.isSafe) {
                    vscode.window.showInformationMessage('✅ ' + safety.recommendation);
                } else {
                    const action = await vscode.window.showWarningMessage(
                        `⚠️ ${safety.recommendation}\n\nIssues:\n${safety.issues.join('\n')}`,
                        'Clean Now',
                        'Ignore'
                    );
                    
                    if (action === 'Clean Now') {
                        vscode.commands.executeCommand('playwright-dom-capture.prepareForCommit');
                    }
                }
            });
            commands.push(cmd11);
            console.log('[Playwright DOM Capture] Registered: checkGitSafety');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register checkGitSafety:', e);
        }
        
        try {
            const cmd12 = vscode.commands.registerCommand('playwright-dom-capture.emergencyCleanup', async () => {
                const confirm = await vscode.window.showWarningMessage(
                    '⚠️ This will remove ALL DOM captures and configuration. Continue?',
                    'Yes, Clean Everything',
                    'Cancel'
                );
                
                if (confirm === 'Yes, Clean Everything') {
                    await ErrorHandler.withErrorHandling(
                        async () => {
                            // Force clean everything
                            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
                            if (workspaceFolder) {
                                const capturesPath = path.join(workspaceFolder.uri.fsPath, 'test-results', 'dom-captures');
                                await fs.remove(capturesPath);
                                
                                const domCapturePath = path.join(workspaceFolder.uri.fsPath, 'dom-capture');
                                await fs.remove(domCapturePath);
                                
                                // Rollback if possible
                                if (gitIntegration) {
                                    await gitIntegration.rollbackAllChanges();
                                }
                                
                                vscode.window.showInformationMessage('✅ Emergency cleanup complete!');
                            }
                        },
                        'Emergency cleanup failed'
                    );
                }
            });
            commands.push(cmd12);
            console.log('[Playwright DOM Capture] Registered: emergencyCleanup');
        } catch (e) {
            console.error('[Playwright DOM Capture] Failed to register emergencyCleanup:', e);
        }

        // Register all commands
        commands.forEach(cmd => context.subscriptions.push(cmd));
        console.log(`[Playwright DOM Capture] Total commands registered: ${commands.length}`);

        // Register tree data provider for captures
        if (dashboardProvider) {
            vscode.window.registerTreeDataProvider('domCaptures', dashboardProvider);
        }

        // Register chat participant for Copilot integration (with fallback)
        try {
            if (vscode.chat && vscode.chat.createChatParticipant && chatParticipant) {
                const participant = vscode.chat.createChatParticipant('domcapture', async (request, context, stream, token) => {
                    await ErrorHandler.withErrorHandling(
                        () => chatParticipant!.handleChatRequest(request, context, stream, token),
                        'Chat request failed',
                        false
                    );
                });
                participant.iconPath = vscode.Uri.joinPath(context.extensionUri, 'resources', 'icon.png');
                context.subscriptions.push(participant);
                safeLog('info', 'Chat participant registered successfully');
            } else {
                safeLog('warn', 'Chat API not available - Copilot integration disabled');
            }
        } catch (error: any) {
            safeLog('warn', 'Failed to register chat participant', error);
        }

        // Watch for test failures
        fileWatcher = await watchTestResults(captureManager);
        if (fileWatcher) {
            context.subscriptions.push(fileWatcher);
        }

        // Status bar item
        const statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
        statusBarItem.text = '$(beaker) DOM Capture: Ready';
        statusBarItem.command = 'playwright-dom-capture.showDashboard';
        statusBarItem.tooltip = 'Click to open DOM Capture Dashboard';
        statusBarItem.show();
        context.subscriptions.push(statusBarItem);

        safeLog('info', 'Playwright DOM Capture extension activated successfully');
        console.log('[Playwright DOM Capture] Extension activation completed successfully');
        
        // Show welcome message on first activation
        const hasShownWelcome = context.globalState.get('domCapture.welcomeShown', false);
        if (!hasShownWelcome) {
            const selection = await vscode.window.showInformationMessage(
                'Playwright DOM Capture is ready! Would you like to configure your project?',
                'Configure Now',
                'Later'
            );
            if (selection === 'Configure Now') {
                vscode.commands.executeCommand('playwright-dom-capture.autoConfigureProject');
            }
            await context.globalState.update('domCapture.welcomeShown', true);
        }
    } catch (error: any) {
        console.error('[Playwright DOM Capture] Critical error during activation:', error);
        safeLog('error', 'Failed to activate extension', error);
        vscode.window.showErrorMessage(`Failed to activate Playwright DOM Capture: ${error.message}`);
    }
}

async function autoConfigureProject(configurator: ProjectConfigurator) {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    
    ErrorHandler.validateConditions([
        { condition: !!workspaceFolder, message: 'No workspace folder found' }
    ]);

    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'Configuring Playwright DOM Capture',
        cancellable: true
    }, async (progress, token) => {
        progress.report({ increment: 0, message: 'Analyzing project structure...' });
        
        // Initialize Git integration
        const gitIntegration = new GitIntegrationManager(workspaceFolder!.uri.fsPath);
        await gitIntegration.initialize();
        await gitIntegration.createRollbackManifest();
        progress.report({ increment: 10, message: 'Git integration configured...' });
        
        // Check if Playwright is installed
        const hasPlaywright = await configurator.checkPlaywrightInstallation(workspaceFolder!.uri.fsPath);
        
        if (!hasPlaywright && !token.isCancellationRequested) {
            const install = await vscode.window.showInformationMessage(
                'Playwright not found. Would you like to install it?',
                'Yes', 'No'
            );
            if (install === 'Yes') {
                progress.report({ increment: 20, message: 'Installing Playwright...' });
                await configurator.installPlaywright(workspaceFolder!.uri.fsPath);
            } else {
                throw new Error('Playwright installation cancelled');
            }
        }

        if (token.isCancellationRequested) {
            throw new Error('Configuration cancelled');
        }

        progress.report({ increment: 40, message: 'Creating backup...' });
        await configurator.backupExistingConfig(workspaceFolder!.uri.fsPath);

        progress.report({ increment: 60, message: 'Installing DOM capture utilities...' });
        await configurator.installDomCaptureUtilities(workspaceFolder!.uri.fsPath);

        progress.report({ increment: 80, message: 'Updating test files...' });
        await configurator.updateTestFiles(workspaceFolder!.uri.fsPath);

        progress.report({ increment: 100, message: 'Configuration complete!' });
        
        const selection = await vscode.window.showInformationMessage(
            'DOM Capture configured successfully!',
            'View Dashboard',
            'Run Tests'
        );
        
        if (selection === 'View Dashboard') {
            vscode.commands.executeCommand('playwright-dom-capture.showDashboard');
        } else if (selection === 'Run Tests') {
            const terminal = vscode.window.createTerminal('Playwright Tests');
            terminal.show();
            terminal.sendText('npm test');
        }
    });
}

async function verifyConfiguration(configurator: ProjectConfigurator) {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    
    ErrorHandler.validateConditions([
        { condition: !!workspaceFolder, message: 'No workspace folder found' }
    ]);

    const issues = await configurator.verifyConfiguration(workspaceFolder!.uri.fsPath);
    
    if (issues.length === 0) {
        vscode.window.showInformationMessage('✅ DOM Capture is properly configured!');
    } else {
        const message = issues.map(issue => `• ${issue}`).join('\n');
        const selection = await vscode.window.showWarningMessage(
            `Configuration issues found:\n${message}`,
            'Auto-fix',
            'Ignore'
        );
        
        if (selection === 'Auto-fix') {
            vscode.commands.executeCommand('playwright-dom-capture.autoConfigureProject');
        }
    }
}

async function showLastCapture(captureManager: CaptureManager) {
    const lastCapture = await captureManager.getLastCapture();
    
    if (!lastCapture) {
        vscode.window.showInformationMessage('No captures found. Run your tests to generate captures.');
        return;
    }

    const uri = vscode.Uri.file(lastCapture.path);
    await vscode.commands.executeCommand('vscode.open', uri);
}

async function rollbackConfiguration(configurator: ProjectConfigurator) {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    
    ErrorHandler.validateConditions([
        { condition: !!workspaceFolder, message: 'No workspace folder found' }
    ]);

    const confirm = await vscode.window.showWarningMessage(
        'This will rollback DOM Capture configuration. Continue?',
        'Yes', 'No'
    );

    if (confirm === 'Yes') {
        await configurator.rollbackConfiguration(workspaceFolder!.uri.fsPath);
        vscode.window.showInformationMessage('Configuration rolled back successfully');
    }
}

async function addCapturePoint() {
    const editor = vscode.window.activeTextEditor;
    
    ErrorHandler.validateConditions([
        { condition: !!editor, message: 'No active editor' }
    ]);

    const document = editor!.document;
    const selection = editor!.selection;
    
    // Check if we're in a test file
    if (!document.fileName.includes('.spec.') && !document.fileName.includes('.test.')) {
        vscode.window.showWarningMessage('This command works only in test files (.spec.ts or .test.ts)');
        return;
    }

    const captureCode = `\n    // DOM Capture Point\n    await captureDom();\n`;
    
    await editor!.edit(editBuilder => {
        const position = selection.end;
        editBuilder.insert(position, captureCode);
    });
}

async function toggleAutoCapture() {
    const config = vscode.workspace.getConfiguration('playwright-dom-capture');
    const currentValue = config.get<boolean>('autoCapture', true);
    
    await config.update('autoCapture', !currentValue, vscode.ConfigurationTarget.Workspace);
    
    vscode.window.showInformationMessage(
        `Auto-capture on failure is now ${!currentValue ? 'enabled' : 'disabled'}`
    );
}

async function cleanOldCaptures(captureManager: CaptureManager) {
    const config = vscode.workspace.getConfiguration('playwright-dom-capture');
    const retentionDays = config.get<number>('retentionDays', 7);
    
    const result = await vscode.window.showInformationMessage(
        `Delete captures older than ${retentionDays} days?`,
        'Yes', 'No', 'Change Retention'
    );

    if (result === 'Yes') {
        const deletedCount = await captureManager.cleanOldCaptures(retentionDays);
        vscode.window.showInformationMessage(`Deleted ${deletedCount} old captures`);
    } else if (result === 'Change Retention') {
        const input = await vscode.window.showInputBox({
            prompt: 'Enter retention days',
            value: retentionDays.toString(),
            validateInput: (value) => {
                const num = parseInt(value);
                if (isNaN(num) || num < 1) {
                    return 'Please enter a valid number greater than 0';
                }
                return null;
            }
        });
        
        if (input) {
            await config.update('retentionDays', parseInt(input), vscode.ConfigurationTarget.Workspace);
        }
    }
}

async function captureCurrentPage(captureManager: CaptureManager) {
    // Get URL from user
    const url = await vscode.window.showInputBox({
        prompt: 'Enter URL to capture DOM',
        placeHolder: 'https://example.com',
        value: 'https://',
        validateInput: (value) => {
            try {
                new URL(value);
                return null;
            } catch {
                return 'Please enter a valid URL';
            }
        }
    });

    if (!url) {
        return;
    }

    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'Capturing DOM',
        cancellable: false
    }, async (progress) => {
        progress.report({ increment: 0, message: 'Launching browser...' });
        
        let browser: any = null;
        try {
            // Check if Playwright is installed
            let playwright: any;
            try {
                playwright = require('playwright');
            } catch (error) {
                throw new Error('Playwright is not installed. Please run: npm install playwright');
            }
            
            browser = await playwright.chromium.launch({ headless: true });
            const page = await browser.newPage();
            
            progress.report({ increment: 30, message: 'Loading page...' });
            await page.goto(url, { waitUntil: 'networkidle' });
            
            progress.report({ increment: 60, message: 'Capturing DOM...' });
            
            // Capture DOM and save to manual-dom-captures folder
            const dom = await page.content();
            
            // Create proper folder structure for manual captures
            const date = new Date();
            const dateFolder = `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear()}`;
            const timestamp = `${date.getHours().toString().padStart(2, '0')}-${date.getMinutes().toString().padStart(2, '0')}-${date.getSeconds().toString().padStart(2, '0')}`;
            const urlHost = new URL(url).hostname.replace(/\./g, '_');
            const fileName = `manual_capture_${urlHost}_${timestamp}.html`;
            
            // Save the DOM
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (!workspaceFolder) {
                throw new Error('No workspace folder found');
            }
            
            const outputPath = path.join(workspaceFolder.uri.fsPath, 'test-results', 'dom-captures', 'manual-dom-captures', dateFolder);
            
            await fs.ensureDir(outputPath);
            const filePath = path.join(outputPath, fileName);
            await fs.writeFile(filePath, dom, 'utf-8');
            
            // Save metadata alongside the capture
            const metadataPath = filePath.replace('.html', '_metadata.json');
            await fs.writeJson(metadataPath, {
                url: url,
                timestamp: new Date().toISOString(),
                captureType: 'manual',
                triggeredBy: 'VS Code Command (Ctrl+Alt+C)',
                hostname: urlHost
            }, { spaces: 2 });
            
            await browser.close();
            browser = null;
            
            progress.report({ increment: 100, message: 'DOM captured successfully!' });
            
            // Ask user what to do with the capture
            const action = await vscode.window.showInformationMessage(
                `DOM captured: ${fileName}`,
                'Open File',
                'Show in Explorer',
                'Close'
            );
            
            if (action === 'Open File') {
                const uri = vscode.Uri.file(filePath);
                await vscode.commands.executeCommand('vscode.open', uri);
            } else if (action === 'Show in Explorer') {
                await vscode.commands.executeCommand('revealFileInOS', vscode.Uri.file(filePath));
            }
            
            safeLog('info', `DOM captured successfully: ${filePath}`);
        } catch (error: any) {
            // Ensure browser is closed on error
            if (browser) {
                try {
                    await browser.close();
                } catch {
                    // Ignore close errors
                }
            }
            
            safeLog('error', 'Failed to capture DOM', error);
            
            // Provide user-friendly error message
            const errorMessage = error.message || 'Unknown error occurred';
            vscode.window.showErrorMessage(`Failed to capture DOM: ${errorMessage}`);
            throw error;
        } finally {
            // Final cleanup
            if (browser) {
                try {
                    await browser.close();
                } catch {
                    // Ignore close errors
                }
            }
        }
    });
}

async function watchTestResults(captureManager: CaptureManager | undefined): Promise<vscode.FileSystemWatcher | undefined> {
    if (!captureManager) {
        return undefined;
    }
    
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    if (!workspaceFolder) {
        safeLog('warn', 'No workspace folder found for file watcher');
        return undefined;
    }

    try {
        const pattern = path.join(workspaceFolder.uri.fsPath, 'test-results', '**', '*.html');
        const watcher = vscode.workspace.createFileSystemWatcher(pattern);
        
        watcher.onDidCreate(async (uri) => {
            const fileName = path.basename(uri.fsPath);
            if (fileName.includes('FAILED_')) {
                const selection = await vscode.window.showWarningMessage(
                    `Test failed - DOM captured: ${fileName}`,
                    'View Capture',
                    'View Dashboard'
                );
                
                if (selection === 'View Capture') {
                    vscode.commands.executeCommand('vscode.open', uri);
                } else if (selection === 'View Dashboard') {
                    vscode.commands.executeCommand('playwright-dom-capture.showDashboard');
                }
            }
        });

        safeLog('info', 'File watcher initialized for test results');
        return watcher;
    } catch (error: any) {
        safeLog('error', 'Failed to initialize file watcher', error);
        return undefined;
    }
}

export function deactivate() {
    safeLog('info', 'Playwright DOM Capture extension deactivating...');
    console.log('[Playwright DOM Capture] Extension deactivating...');
    
    // Clean up file watcher
    if (fileWatcher) {
        fileWatcher.dispose();
    }
    
    // Dispose logger
    if (logger) {
        logger.dispose();
    }
    
    safeLog('info', 'Playwright DOM Capture extension deactivated');
    console.log('[Playwright DOM Capture] Extension deactivated');
}