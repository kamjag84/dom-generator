import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';

export interface CaptureInfo {
    path: string;
    testName: string;
    timestamp: Date;
    status: 'failed' | 'success';
    size: number;
    hasScreenshot: boolean;
}

export class CaptureManager {
    private captures: CaptureInfo[] = [];
    
    constructor(private context: vscode.ExtensionContext) {
        this.loadCaptures();
    }

    async loadCaptures(): Promise<void> {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            return;
        }

        const captureDir = path.join(workspaceFolder.uri.fsPath, 'test-results', 'dom-capture');
        
        if (!await fs.pathExists(captureDir)) {
            return;
        }

        this.captures = [];
        await this.scanDirectory(captureDir);
        
        // Sort by timestamp, newest first
        this.captures.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    }

    private async scanDirectory(dir: string): Promise<void> {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            
            if (entry.isDirectory()) {
                await this.scanDirectory(fullPath);
            } else if (entry.name.endsWith('.html')) {
                const stats = await fs.stat(fullPath);
                const capture: CaptureInfo = {
                    path: fullPath,
                    testName: this.extractTestName(entry.name),
                    timestamp: stats.mtime,
                    status: entry.name.startsWith('FAILED_') ? 'failed' : 'success',
                    size: stats.size,
                    hasScreenshot: await this.checkForScreenshot(fullPath)
                };
                this.captures.push(capture);
            }
        }
    }

    private extractTestName(fileName: string): string {
        // Remove FAILED_ prefix if present
        let name = fileName.replace(/^FAILED_/, '');
        // Remove timestamp and extension
        name = name.replace(/_dom_\d{2}-\d{2}-\d{2}\.html$/, '');
        // Replace underscores with spaces
        return name.replace(/_/g, ' ');
    }

    private async checkForScreenshot(htmlPath: string): Promise<boolean> {
        const screenshotPath = htmlPath.replace('.html', '_screenshot.png');
        return await fs.pathExists(screenshotPath);
    }

    async getLastCapture(): Promise<CaptureInfo | undefined> {
        await this.loadCaptures();
        return this.captures[0];
    }

    async getCaptures(limit?: number): Promise<CaptureInfo[]> {
        await this.loadCaptures();
        return limit ? this.captures.slice(0, limit) : this.captures;
    }

    async getCapturesByStatus(status: 'failed' | 'success'): Promise<CaptureInfo[]> {
        await this.loadCaptures();
        return this.captures.filter(c => c.status === status);
    }

    async getCapturesByDate(date: Date): Promise<CaptureInfo[]> {
        await this.loadCaptures();
        const dateStr = this.formatDate(date);
        return this.captures.filter(c => {
            const captureDate = this.formatDate(c.timestamp);
            return captureDate === dateStr;
        });
    }

    private formatDate(date: Date): string {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    async cleanOldCaptures(retentionDays: number): Promise<number> {
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            return 0;
        }

        const captureDir = path.join(workspaceFolder.uri.fsPath, 'test-results', 'dom-capture');
        
        if (!await fs.pathExists(captureDir)) {
            return 0;
        }

        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
        
        let deletedCount = 0;
        await this.loadCaptures();
        
        for (const capture of this.captures) {
            if (capture.timestamp < cutoffDate) {
                await fs.remove(capture.path);
                
                // Also remove screenshot if exists
                const screenshotPath = capture.path.replace('.html', '_screenshot.png');
                if (await fs.pathExists(screenshotPath)) {
                    await fs.remove(screenshotPath);
                }
                
                deletedCount++;
            }
        }
        
        // Clean empty directories
        await this.cleanEmptyDirectories(captureDir);
        
        return deletedCount;
    }

    private async cleanEmptyDirectories(dir: string): Promise<void> {
        const entries = await fs.readdir(dir);
        
        if (entries.length === 0) {
            await fs.remove(dir);
        } else {
            for (const entry of entries) {
                const fullPath = path.join(dir, entry);
                const stats = await fs.stat(fullPath);
                
                if (stats.isDirectory()) {
                    await this.cleanEmptyDirectories(fullPath);
                }
            }
        }
    }

    async getStatistics(): Promise<{
        total: number;
        failed: number;
        success: number;
        totalSize: number;
        averageSize: number;
        oldestCapture?: Date;
        newestCapture?: Date;
    }> {
        await this.loadCaptures();
        
        const stats = {
            total: this.captures.length,
            failed: this.captures.filter(c => c.status === 'failed').length,
            success: this.captures.filter(c => c.status === 'success').length,
            totalSize: this.captures.reduce((sum, c) => sum + c.size, 0),
            averageSize: 0,
            oldestCapture: undefined as Date | undefined,
            newestCapture: undefined as Date | undefined
        };
        
        if (this.captures.length > 0) {
            stats.averageSize = stats.totalSize / this.captures.length;
            stats.newestCapture = this.captures[0].timestamp;
            stats.oldestCapture = this.captures[this.captures.length - 1].timestamp;
        }
        
        return stats;
    }

    async openCapture(capture: CaptureInfo): Promise<void> {
        const uri = vscode.Uri.file(capture.path);
        await vscode.commands.executeCommand('vscode.open', uri);
        
        // If screenshot exists, offer to open it too
        if (capture.hasScreenshot) {
            const screenshotPath = capture.path.replace('.html', '_screenshot.png');
            const openScreenshot = await vscode.window.showInformationMessage(
                'Screenshot available for this capture',
                'Open Screenshot'
            );
            
            if (openScreenshot) {
                const screenshotUri = vscode.Uri.file(screenshotPath);
                await vscode.commands.executeCommand('vscode.open', screenshotUri);
            }
        }
    }

    async exportCaptures(exportPath: string): Promise<void> {
        await this.loadCaptures();
        
        const exportDir = path.join(exportPath, `dom-captures-export-${Date.now()}`);
        await fs.ensureDir(exportDir);
        
        for (const capture of this.captures) {
            const destPath = path.join(exportDir, path.basename(capture.path));
            await fs.copy(capture.path, destPath);
            
            // Copy screenshot if exists
            if (capture.hasScreenshot) {
                const screenshotSrc = capture.path.replace('.html', '_screenshot.png');
                const screenshotDest = destPath.replace('.html', '_screenshot.png');
                await fs.copy(screenshotSrc, screenshotDest);
            }
        }
        
        // Create manifest
        const manifest = {
            exportDate: new Date().toISOString(),
            captureCount: this.captures.length,
            captures: this.captures.map(c => ({
                testName: c.testName,
                status: c.status,
                timestamp: c.timestamp,
                size: c.size,
                hasScreenshot: c.hasScreenshot
            }))
        };
        
        await fs.writeJson(path.join(exportDir, 'manifest.json'), manifest, { spaces: 2 });
    }
}