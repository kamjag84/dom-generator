import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import { Logger } from './utils/logger';
// Advanced serializer removed - using inline implementation
interface DomCaptureOptions {
  captureIframes?: boolean;
  captureShadowDom?: boolean;
  inlineResources?: boolean;
  captureCanvas?: boolean;
  captureFormState?: boolean;
  captureScrollPositions?: boolean;
  captureStorage?: boolean;
  maxDepth?: number;
}
import { ResourceInliner } from './domCapture/resourceInliner';
import { StateCapture, PageState } from './domCapture/stateCapture';
import { MetadataCollector, EnhancedMetadata } from './domCapture/metadataCollector';
import { CompressionManager, StorageEntry } from './domCapture/compressionManager';
import { SecurityManager, PIIDetectionResult } from './domCapture/securityManager';
import { PlaywrightIntegration, IntegrationResult } from './domCapture/playwrightIntegration';
import { EnhancedDomViewer } from './domCapture/domViewer';

export interface AdvancedCaptureOptions extends DomCaptureOptions {
    // Resource Options
    inlineResources?: boolean;
    inlineImages?: boolean;
    inlineFonts?: boolean;
    inlineStylesheets?: boolean;
    
    // Security Options
    enableSecurity?: boolean;
    redactSensitiveData?: boolean;
    securityWhitelist?: string[];
    
    // Compression Options
    compressionLevel?: 'none' | 'low' | 'medium' | 'high';
    enableDeduplication?: boolean;
    enableChunking?: boolean;
    enableDiffing?: boolean;
    
    // Integration Options
    enableTracing?: boolean;
    enableVideo?: boolean;
    
    // Metadata
    customMetadata?: Record<string, any>;
    captureConsole?: boolean;
    capturePerformanceMetrics?: boolean;
    captureNetworkActivity?: boolean;
    enableScreenshots?: boolean;
    enableHar?: boolean;
    enableCoverage?: boolean;
    enableLighthouse?: boolean;
    
    // Output Options
    outputFormat?: 'html' | 'json' | 'both';
    includeReport?: boolean;
    openAfterCapture?: boolean;
}

export interface AdvancedCaptureResult {
    id: string;
    path: string;
    metadataPath: string;
    dom: string;
    metadata: EnhancedMetadata;
    state: PageState;
    security: {
        sanitized: boolean;
        report: PIIDetectionResult[];
    };
    compression: StorageEntry;
    integration?: IntegrationResult;
    timestamp: string;
    duration: number;
}

export class AdvancedCaptureManager {
    private context: vscode.ExtensionContext;
    private logger: Logger;
    private capturesPath: string;
    private compressionManager: CompressionManager;
    private securityManager: SecurityManager;
    private playwrightIntegration?: PlaywrightIntegration;
    private captureHistory: Map<string, AdvancedCaptureResult> = new Map();

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
        this.logger = Logger.getInstance();
        
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        this.capturesPath = workspaceFolder 
            ? path.join(workspaceFolder.uri.fsPath, 'test-results', 'dom-captures')
            : path.join(context.extensionPath, 'test-results', 'dom-captures');
            
        this.ensureCapturesDirectory();
        
        // Initialize advanced components
        this.compressionManager = new CompressionManager(this.capturesPath, {
            level: 'medium',
            enableDeduplication: true,
            enableChunking: true,
            enableDiffing: true,
            maxStorageSize: 100
        });
        
        this.securityManager = new SecurityManager({
            redactPasswords: true,
            redactTokens: true,
            redactEmails: true,
            redactPhoneNumbers: true,
            redactCreditCards: true,
            preserveLength: true
        });
        
        this.loadCaptureHistory();
    }

    private async ensureCapturesDirectory(): Promise<void> {
        await fs.ensureDir(this.capturesPath);
        await fs.ensureDir(path.join(this.capturesPath, 'manual-dom-captures'));
        await fs.ensureDir(path.join(this.capturesPath, 'metadata'));
        await fs.ensureDir(path.join(this.capturesPath, 'captures'));
        await fs.ensureDir(path.join(this.capturesPath, 'chunks'));
        await fs.ensureDir(path.join(this.capturesPath, 'diffs'));
        await fs.ensureDir(path.join(this.capturesPath, 'reports'));
        await fs.ensureDir(path.join(this.capturesPath, 'integration'));
    }

    async captureAdvanced(
        url: string,
        options: AdvancedCaptureOptions = {}
    ): Promise<AdvancedCaptureResult> {
        const startTime = Date.now();
        const captureId = this.generateCaptureId(url);
        
        this.logger.info(`Starting advanced DOM capture for: ${url}`);
        
        // Show progress
        return await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: 'Advanced DOM Capture',
            cancellable: true
        }, async (progress, token) => {
            progress.report({ increment: 0, message: 'Initializing browser...' });
            
            const playwright = require('playwright');
            const browser = await playwright.chromium.launch({ 
                headless: true,
                args: ['--enable-features=NetworkService']
            });
            
            const context = await browser.newContext({
                viewport: { width: 1280, height: 720 },
                ignoreHTTPSErrors: true
            });
            
            const page = await context.newPage();
            
            try {
                // Initialize components
                // Use inline serializer instead of missing AdvancedDomSerializer
                const inliner = new ResourceInliner(page);
                const stateCapture = new StateCapture(page);
                const metadataCollector = new MetadataCollector(page, context);
                
                // Initialize Playwright integration if enabled
                let integration: PlaywrightIntegration | undefined;
                if (options.enableTracing || options.enableVideo || options.enableScreenshots) {
                    integration = new PlaywrightIntegration(
                        path.join(this.capturesPath, 'integration', captureId),
                        {
                            enableTracing: options.enableTracing,
                            enableVideo: options.enableVideo,
                            enableScreenshots: options.enableScreenshots,
                            enableHar: options.enableHar,
                            enableCoverage: options.enableCoverage,
                            enableLighthouse: options.enableLighthouse
                        }
                    );
                    await integration.initialize();
                }
                
                // Skip browser serializer injection (evaluateOnNewDocument not available)
                
                progress.report({ increment: 20, message: 'Loading page...' });
                
                // Navigate to URL
                await page.goto(url, { 
                    waitUntil: 'networkidle',
                    timeout: 30000
                });
                
                // Wait for any lazy-loaded content
                await page.waitForTimeout(2000);
                
                if (token.isCancellationRequested) {
                    throw new Error('Capture cancelled by user');
                }
                
                progress.report({ increment: 40, message: 'Capturing DOM and metadata...' });
                
                // Capture everything in parallel (serializer removed due to missing implementation)
                const [domContent, state, metadata] = await Promise.all([
                    page.content(), // Get raw DOM instead of using serializer
                    stateCapture.captureFullState(),
                    metadataCollector.collectFullMetadata()
                ]);
                const domData = { html: domContent, metadata: {} };
                
                progress.report({ increment: 60, message: 'Processing resources...' });
                
                // Inline resources if enabled
                let processedHtml = domData.html;
                if (options.inlineResources !== false) {
                    processedHtml = await inliner.inlineAllResources(processedHtml);
                }
                
                progress.report({ increment: 70, message: 'Applying security and compression...' });
                
                // Apply security sanitization if enabled
                let finalHtml = processedHtml;
                let securityReport: PIIDetectionResult[] = [];
                
                if (options.enableSecurity !== false) {
                    const securityResult = this.securityManager.sanitizeDom(processedHtml);
                    finalHtml = securityResult.sanitized;
                    securityReport = securityResult.report;
                }
                
                // Get previous capture for diffing
                const previousCapture = this.getLastCaptureForUrl(url);
                
                // Compress and store
                const compressionEntry = await this.compressionManager.compressAndStore(
                    finalHtml,
                    { ...metadata, state, securityReport },
                    captureId,
                    previousCapture?.compression.id
                );
                
                progress.report({ increment: 80, message: 'Saving capture...' });
                
                // Save main capture file in date-based structure
                const date = new Date();
                const dateFolder = this.formatDateFolder(date);
                const timestamp = this.formatTimestamp(date);
                
                // For VS Code captures, use a simplified structure
                const captureDir = path.join(this.capturesPath, 'captures', dateFolder);
                await fs.ensureDir(captureDir);
                
                const fileName = `${captureId}_${timestamp}.html`;
                const filePath = path.join(captureDir, fileName);
                
                await fs.writeFile(filePath, finalHtml, 'utf-8');
                
                // Save metadata in same folder as capture
                const metadataPath = filePath.replace('.html', '_metadata.json');
                const fullMetadata = {
                    ...domData.metadata,
                    ...metadata,
                    state,
                    security: {
                        sanitized: options.enableSecurity !== false,
                        report: securityReport
                    },
                    compression: compressionEntry,
                    captureOptions: options
                };
                
                await fs.writeJson(metadataPath, fullMetadata, { spaces: 2 });
                
                // Get integration results if available
                let integrationResult: IntegrationResult | undefined;
                if (integration) {
                    integrationResult = await integration.captureWithIntegration(url);
                    await integration.cleanup();
                }
                
                progress.report({ increment: 90, message: 'Generating report...' });
                
                // Generate report if requested
                if (options.includeReport) {
                    await this.generateCaptureReport(
                        captureId,
                        finalHtml,
                        fullMetadata,
                        integrationResult
                    );
                }
                
                const duration = Date.now() - startTime;
                
                // Create result
                const result: AdvancedCaptureResult = {
                    id: captureId,
                    path: filePath,
                    metadataPath,
                    dom: finalHtml,
                    metadata: fullMetadata as unknown as EnhancedMetadata,
                    state,
                    security: {
                        sanitized: options.enableSecurity !== false,
                        report: securityReport
                    },
                    compression: compressionEntry,
                    integration: integrationResult,
                    timestamp: new Date().toISOString(),
                    duration
                };
                
                // Store in history
                this.captureHistory.set(captureId, result);
                await this.saveCaptureHistory();
                
                progress.report({ increment: 100, message: 'Capture complete!' });
                
                // Open viewer if requested
                if (options.openAfterCapture) {
                    await this.showEnhancedViewer(result);
                }
                
                await browser.close();
                
                this.logger.info(`Advanced DOM capture completed in ${duration}ms: ${filePath}`);
                
                // Show success message
                const actions = await vscode.window.showInformationMessage(
                    `✅ DOM Capture Complete (${(duration / 1000).toFixed(2)}s)`,
                    'View Capture',
                    'View Report',
                    'Compare'
                );
                
                if (actions === 'View Capture') {
                    await this.showEnhancedViewer(result);
                } else if (actions === 'View Report') {
                    await this.openReport(captureId);
                } else if (actions === 'Compare') {
                    await this.compareWithPrevious(result);
                }
                
                return result;
                
            } catch (error: any) {
                this.logger.error('Advanced capture failed', error);
                throw error;
            } finally {
                await page.close();
                await context.close();
                await browser.close();
            }
        });
    }

    async captureCurrentPage(): Promise<void> {
        const url = await vscode.window.showInputBox({
            prompt: 'Enter URL to capture DOM',
            placeHolder: 'https://example.com',
            value: 'https://',
            validateInput: (value) => {
                try {
                    new URL(value);
                    return null;
                } catch {
                    return 'Please enter a valid URL';
                }
            }
        });

        if (!url) {
            return;
        }

        // For manual captures, save in manual-dom-captures folder
        const date = new Date();
        const dateFolder = this.formatDateFolder(date);
        const timestamp = this.formatTimestamp(date);
        const hostname = new URL(url).hostname.replace(/\./g, '_');
        
        const manualCaptureDir = path.join(this.capturesPath, 'manual-dom-captures', dateFolder);
        await fs.ensureDir(manualCaptureDir);
        
        const fileName = `manual_capture_${hostname}_${timestamp}.html`;
        const filePath = path.join(manualCaptureDir, fileName);
        
        // Capture with special handling for manual captures
        const options = await this.promptForOptions();
        options.customMetadata = {
            ...options.customMetadata,
            captureType: 'manual',
            hostname: hostname,
            outputPath: filePath
        };
        
        await this.captureAdvanced(url, options);
    }

    private formatDateFolder(date: Date): string {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    private formatTimestamp(date: Date): string {
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const seconds = date.getSeconds().toString().padStart(2, '0');
        return `${hours}-${minutes}-${seconds}`;
    }

    private async promptForOptions(): Promise<AdvancedCaptureOptions> {
        const quickPick = await vscode.window.showQuickPick(
            [
                { label: '🚀 Full Capture', description: 'All features enabled', value: 'full' },
                { label: '⚡ Fast Capture', description: 'Basic DOM only', value: 'fast' },
                { label: '🔒 Secure Capture', description: 'With PII redaction', value: 'secure' },
                { label: '📊 Analytics Capture', description: 'With performance metrics', value: 'analytics' },
                { label: '⚙️ Custom', description: 'Configure options', value: 'custom' }
            ],
            {
                placeHolder: 'Select capture mode'
            }
        );

        switch (quickPick?.value) {
            case 'full':
                return {
                    captureIframes: true,
                    captureShadowDom: true,
                    inlineResources: true,
                    captureCanvas: true,
                    captureFormState: true,
                    captureScrollPositions: true,
                    captureStorage: true,
                    captureConsole: true,
                    captureNetworkActivity: true,
                    capturePerformanceMetrics: true,
                    enableSecurity: true,
                    compressionLevel: 'medium',
                    enableScreenshots: true,
                    includeReport: true,
                    openAfterCapture: true
                };
            
            case 'fast':
                return {
                    captureIframes: false,
                    captureShadowDom: false,
                    inlineResources: false,
                    enableSecurity: false,
                    compressionLevel: 'none',
                    openAfterCapture: true
                };
            
            case 'secure':
                return {
                    enableSecurity: true,
                    redactSensitiveData: true,
                    compressionLevel: 'high',
                    openAfterCapture: true
                };
            
            case 'analytics':
                return {
                    capturePerformanceMetrics: true,
                    captureNetworkActivity: true,
                    enableTracing: true,
                    enableCoverage: true,
                    includeReport: true,
                    openAfterCapture: true
                };
            
            default:
                return await this.showCustomOptionsDialog();
        }
    }

    private async showCustomOptionsDialog(): Promise<AdvancedCaptureOptions> {
        // In a real implementation, this would show a more complex dialog
        return {
            captureIframes: true,
            captureShadowDom: true,
            inlineResources: true,
            enableSecurity: true,
            compressionLevel: 'medium',
            openAfterCapture: true
        };
    }

    private async showEnhancedViewer(result: AdvancedCaptureResult): Promise<void> {
        await EnhancedDomViewer.show(this.context, result.path, result.metadata);
    }

    private async generateCaptureReport(
        captureId: string,
        html: string,
        metadata: any,
        integration?: IntegrationResult
    ): Promise<void> {
        const reportPath = path.join(this.capturesPath, 'reports', `${captureId}_report.html`);
        
        const report = `<!DOCTYPE html>
<html>
<head>
    <title>DOM Capture Report - ${captureId}</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 30px;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #007ACC;
            padding-bottom: 10px;
        }
        .section {
            margin: 30px 0;
        }
        .metric-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            border-left: 3px solid #007ACC;
        }
        .metric-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .metric-unit {
            font-size: 14px;
            color: #666;
            font-weight: normal;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Advanced DOM Capture Report</h1>
        
        <div class="section">
            <h2>📊 Capture Summary</h2>
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-label">Capture ID</div>
                    <div class="metric-value" style="font-size: 14px;">${captureId}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Timestamp</div>
                    <div class="metric-value" style="font-size: 14px;">${new Date(metadata.timestamp).toLocaleString()}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">DOM Size</div>
                    <div class="metric-value">${(html.length / 1024).toFixed(1)}<span class="metric-unit"> KB</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">URL</div>
                    <div class="metric-value" style="font-size: 14px; word-break: break-all;">${metadata.url}</div>
                </div>
            </div>
        </div>

        ${metadata.performance ? `
        <div class="section">
            <h2>⚡ Performance Metrics</h2>
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-label">Load Time</div>
                    <div class="metric-value">${metadata.performance.loadTime}<span class="metric-unit"> ms</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">First Contentful Paint</div>
                    <div class="metric-value">${metadata.performance.firstContentfulPaint?.toFixed(0) || 'N/A'}<span class="metric-unit"> ms</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Largest Contentful Paint</div>
                    <div class="metric-value">${metadata.performance.largestContentfulPaint?.toFixed(0) || 'N/A'}<span class="metric-unit"> ms</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Cumulative Layout Shift</div>
                    <div class="metric-value">${metadata.performance.cumulativeLayoutShift?.toFixed(3) || 'N/A'}</div>
                </div>
            </div>
        </div>
        ` : ''}

        ${metadata.resources ? `
        <div class="section">
            <h2>📦 Resources</h2>
            <table>
                <thead>
                    <tr>
                        <th>Resource Type</th>
                        <th>Count</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Scripts</td>
                        <td>${metadata.resources.scripts}</td>
                        <td><span class="badge badge-info">Captured</span></td>
                    </tr>
                    <tr>
                        <td>Stylesheets</td>
                        <td>${metadata.resources.stylesheets}</td>
                        <td><span class="badge badge-info">Captured</span></td>
                    </tr>
                    <tr>
                        <td>Images</td>
                        <td>${metadata.resources.images}</td>
                        <td><span class="badge badge-${metadata.captureOptions?.inlineResources ? 'success' : 'warning'}">${metadata.captureOptions?.inlineResources ? 'Inlined' : 'Referenced'}</span></td>
                    </tr>
                    <tr>
                        <td>Fonts</td>
                        <td>${metadata.resources.fonts}</td>
                        <td><span class="badge badge-info">Captured</span></td>
                    </tr>
                    <tr>
                        <td>iFrames</td>
                        <td>${metadata.resources.iframes}</td>
                        <td><span class="badge badge-${metadata.captureOptions?.captureIframes ? 'success' : 'warning'}">${metadata.captureOptions?.captureIframes ? 'Captured' : 'Skipped'}</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
        ` : ''}

        ${metadata.security ? `
        <div class="section">
            <h2>🔒 Security Analysis</h2>
            ${metadata.security.report && metadata.security.report.length > 0 ? `
            <table>
                <thead>
                    <tr>
                        <th>PII Type</th>
                        <th>Count</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${metadata.security.report.map((item: any) => `
                    <tr>
                        <td>${item.type}</td>
                        <td>${item.count}</td>
                        <td><span class="badge badge-${metadata.security.sanitized ? 'success' : 'danger'}">${metadata.security.sanitized ? 'Redacted' : 'Detected'}</span></td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
            ` : '<p>✅ No sensitive data detected</p>'}
        </div>
        ` : ''}

        ${metadata.networkRequests && metadata.networkRequests.length > 0 ? `
        <div class="section">
            <h2>🌐 Network Activity</h2>
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-label">Total Requests</div>
                    <div class="metric-value">${metadata.totalRequests}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Failed Requests</div>
                    <div class="metric-value">${metadata.failedRequests?.length || 0}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Transfer Size</div>
                    <div class="metric-value">${(metadata.totalTransferSize / 1024 / 1024).toFixed(2)}<span class="metric-unit"> MB</span></div>
                </div>
            </div>
        </div>
        ` : ''}

        ${metadata.accessibility ? `
        <div class="section">
            <h2>♿ Accessibility</h2>
            <table>
                <thead>
                    <tr>
                        <th>Check</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Landmarks Present</td>
                        <td><span class="badge badge-${metadata.accessibility.hasLandmarks ? 'success' : 'warning'}">${metadata.accessibility.hasLandmarks ? 'Yes' : 'No'}</span></td>
                    </tr>
                    <tr>
                        <td>Headings Structure</td>
                        <td><span class="badge badge-${metadata.accessibility.hasHeadings ? 'success' : 'warning'}">${metadata.accessibility.hasHeadings ? 'Yes' : 'No'}</span></td>
                    </tr>
                    <tr>
                        <td>ARIA Labels</td>
                        <td><span class="badge badge-${metadata.accessibility.hasAriaLabels ? 'success' : 'warning'}">${metadata.accessibility.hasAriaLabels ? 'Yes' : 'No'}</span></td>
                    </tr>
                    <tr>
                        <td>Images with Alt Text</td>
                        <td>${metadata.accessibility.imagesWithAlt} / ${metadata.accessibility.imagesWithAlt + metadata.accessibility.imagesWithoutAlt}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        ` : ''}

        <div class="section">
            <h2>📋 Capture Options</h2>
            <table>
                <thead>
                    <tr>
                        <th>Option</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    ${Object.entries(metadata.captureOptions || {}).map(([key, value]) => `
                    <tr>
                        <td>${key.replace(/([A-Z])/g, ' $1').trim()}</td>
                        <td><span class="badge badge-${value ? 'success' : 'danger'}">${value}</span></td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>`;

        await fs.writeFile(reportPath, report, 'utf-8');
        this.logger.info(`Report generated: ${reportPath}`);
    }

    private async openReport(captureId: string): Promise<void> {
        const reportPath = path.join(this.capturesPath, 'reports', `${captureId}_report.html`);
        if (await fs.pathExists(reportPath)) {
            const uri = vscode.Uri.file(reportPath);
            await vscode.commands.executeCommand('vscode.open', uri);
        } else {
            vscode.window.showWarningMessage('Report not found. Enable report generation in capture options.');
        }
    }

    private async compareWithPrevious(current: AdvancedCaptureResult): Promise<void> {
        const previous = this.getLastCaptureForUrl(current.metadata.url);
        if (!previous) {
            vscode.window.showInformationMessage('No previous capture found for comparison');
            return;
        }

        // Implementation for comparison view
        vscode.window.showInformationMessage('Comparison feature coming soon!');
    }

    private generateCaptureId(url: string): string {
        const timestamp = Date.now();
        const urlHash = url.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30);
        return `capture_${urlHash}_${timestamp}`;
    }

    private getLastCaptureForUrl(url: string): AdvancedCaptureResult | undefined {
        const captures = Array.from(this.captureHistory.values())
            .filter(c => c.metadata.url === url)
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        
        return captures[1]; // Return second most recent (first is current)
    }

    private async loadCaptureHistory(): Promise<void> {
        const historyPath = path.join(this.capturesPath, 'capture-history.json');
        if (await fs.pathExists(historyPath)) {
            const history = await fs.readJson(historyPath);
            this.captureHistory = new Map(Object.entries(history));
        }
    }

    private async saveCaptureHistory(): Promise<void> {
        const historyPath = path.join(this.capturesPath, 'capture-history.json');
        const history = Object.fromEntries(this.captureHistory);
        await fs.writeJson(historyPath, history, { spaces: 2 });
    }

    async getStatistics(): Promise<any> {
        const stats = await this.compressionManager.getStorageStats();
        const captures = Array.from(this.captureHistory.values());
        
        return {
            totalCaptures: captures.length,
            totalSize: stats.totalSize,
            compressionRatio: stats.compressionRatio,
            deduplicationSavings: stats.deduplicationSavings,
            averageCaptureTime: captures.reduce((sum, c) => sum + c.duration, 0) / captures.length,
            capturesByUrl: this.groupCapturesByUrl(captures)
        };
    }

    private groupCapturesByUrl(captures: AdvancedCaptureResult[]): Map<string, number> {
        const grouped = new Map<string, number>();
        for (const capture of captures) {
            const url = capture.metadata.url;
            grouped.set(url, (grouped.get(url) || 0) + 1);
        }
        return grouped;
    }
}