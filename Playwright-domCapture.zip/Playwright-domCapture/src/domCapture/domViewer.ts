import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';

export class EnhancedDomViewer {
  private static currentPanel: vscode.WebviewPanel | undefined;

  public static async show(
    context: vscode.ExtensionContext,
    capturePath: string,
    metadata?: any
  ): Promise<void> {
    const column = vscode.window.activeTextEditor
      ? vscode.window.activeTextEditor.viewColumn
      : undefined;

    // If we already have a panel, reveal it
    if (EnhancedDomViewer.currentPanel) {
      EnhancedDomViewer.currentPanel.reveal(column);
    } else {
      // Create a new panel
      const panel = vscode.window.createWebviewPanel(
        'domViewer',
        'DOM Capture Viewer',
        column || vscode.ViewColumn.One,
        {
          enableScripts: true,
          retainContextWhenHidden: true,
          localResourceRoots: [
            vscode.Uri.file(path.join(context.extensionPath, 'resources')),
            vscode.Uri.file(path.dirname(capturePath))
          ]
        }
      );

      EnhancedDomViewer.currentPanel = panel;

      // Load and display the capture
      await EnhancedDomViewer.updateContent(capturePath, metadata);

      // Listen for when the panel is disposed
      panel.onDidDispose(
        () => {
          EnhancedDomViewer.currentPanel = undefined;
        },
        null,
        context.subscriptions
      );

      // Handle messages from the webview
      panel.webview.onDidReceiveMessage(
        async message => {
          await EnhancedDomViewer.handleMessage(message, context);
        },
        undefined,
        context.subscriptions
      );
    }
  }

  private static async updateContent(capturePath: string, metadata?: any): Promise<void> {
    if (!EnhancedDomViewer.currentPanel) return;

    const domContent = await fs.readFile(capturePath, 'utf-8');
    const html = EnhancedDomViewer.getHtmlContent(domContent, metadata);
    
    EnhancedDomViewer.currentPanel.webview.html = html;
  }

  private static getHtmlContent(domContent: string, metadata?: any): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOM Capture Viewer</title>
    <style>
        :root {
            --vscode-font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            --primary-color: #007ACC;
            --secondary-color: #1E1E1E;
            --border-color: #3C3C3C;
            --hover-color: #2A2A2A;
            --text-color: #CCCCCC;
            --success-color: #4EC9B0;
            --warning-color: #CE9178;
            --error-color: #F48771;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--vscode-font-family);
            background: var(--secondary-color);
            color: var(--text-color);
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header Controls */
        .header {
            background: #252526;
            border-bottom: 1px solid var(--border-color);
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .header h2 {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
        }

        .controls {
            display: flex;
            gap: 10px;
        }

        .control-group {
            display: flex;
            gap: 5px;
            align-items: center;
            padding: 0 10px;
            border-right: 1px solid var(--border-color);
        }

        .control-group:last-child {
            border-right: none;
        }

        button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 12px;
            transition: opacity 0.2s;
        }

        button:hover {
            opacity: 0.8;
        }

        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        button.secondary {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-color);
        }

        input[type="text"] {
            background: var(--secondary-color);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 5px;
            border-radius: 3px;
            font-size: 12px;
        }

        select {
            background: var(--secondary-color);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 5px;
            border-radius: 3px;
            font-size: 12px;
        }

        /* Main Content Area */
        .content {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        /* Sidebar */
        .sidebar {
            width: 300px;
            background: #252526;
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            transition: width 0.3s;
        }

        .sidebar.collapsed {
            width: 40px;
        }

        .sidebar-header {
            padding: 10px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar-tabs {
            display: flex;
            border-bottom: 1px solid var(--border-color);
        }

        .sidebar-tab {
            flex: 1;
            padding: 8px;
            text-align: center;
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--text-color);
            font-size: 12px;
        }

        .sidebar-tab.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar-content {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }

        /* DOM Tree */
        .dom-tree {
            font-family: 'Courier New', monospace;
            font-size: 12px;
        }

        .tree-node {
            margin-left: 20px;
            position: relative;
        }

        .tree-node::before {
            content: '';
            position: absolute;
            left: -15px;
            top: 8px;
            width: 10px;
            height: 1px;
            background: var(--border-color);
        }

        .tree-node-content {
            display: flex;
            align-items: center;
            padding: 2px 4px;
            cursor: pointer;
            border-radius: 3px;
        }

        .tree-node-content:hover {
            background: var(--hover-color);
        }

        .tree-node-content.selected {
            background: var(--primary-color);
            color: white;
        }

        .tree-toggle {
            width: 16px;
            height: 16px;
            margin-right: 4px;
            cursor: pointer;
            user-select: none;
        }

        .tree-tag {
            color: #569CD6;
        }

        .tree-attr {
            color: #9CDCFE;
        }

        .tree-value {
            color: #CE9178;
        }

        /* Metadata Panel */
        .metadata-item {
            margin-bottom: 10px;
            padding: 8px;
            background: var(--secondary-color);
            border-radius: 3px;
        }

        .metadata-label {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 4px;
            font-size: 11px;
            text-transform: uppercase;
        }

        .metadata-value {
            color: var(--text-color);
            font-size: 12px;
            word-break: break-all;
        }

        .metadata-list {
            list-style: none;
            margin-left: 10px;
        }

        .metadata-list li {
            padding: 2px 0;
            font-size: 11px;
        }

        /* Main View */
        .main-view {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .view-tabs {
            display: flex;
            background: #252526;
            border-bottom: 1px solid var(--border-color);
        }

        .view-tab {
            padding: 8px 16px;
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--text-color);
            font-size: 12px;
            border-right: 1px solid var(--border-color);
        }

        .view-tab.active {
            background: var(--secondary-color);
            border-bottom: 2px solid var(--primary-color);
        }

        .view-content {
            flex: 1;
            overflow: auto;
            position: relative;
        }

        /* DOM Preview */
        .dom-preview {
            width: 100%;
            height: 100%;
            background: white;
        }

        .dom-preview iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        /* Source View */
        .source-view {
            padding: 20px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }

        .line-number {
            display: inline-block;
            width: 50px;
            color: #858585;
            text-align: right;
            margin-right: 10px;
            user-select: none;
        }

        .highlight {
            background: rgba(255, 235, 59, 0.2);
            border: 1px solid #FFEB3B;
        }

        /* Resource List */
        .resource-list {
            padding: 20px;
        }

        .resource-item {
            display: flex;
            justify-content: space-between;
            padding: 8px;
            margin-bottom: 5px;
            background: #252526;
            border-radius: 3px;
            font-size: 12px;
        }

        .resource-type {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            text-transform: uppercase;
            margin-right: 10px;
        }

        .resource-type.image { background: #4CAF50; }
        .resource-type.script { background: #FF9800; }
        .resource-type.style { background: #2196F3; }
        .resource-type.font { background: #9C27B0; }

        /* Diff View */
        .diff-container {
            padding: 20px;
        }

        .diff-line {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            padding: 2px 10px;
        }

        .diff-addition {
            background: rgba(76, 175, 80, 0.2);
            border-left: 3px solid #4CAF50;
        }

        .diff-deletion {
            background: rgba(244, 67, 54, 0.2);
            border-left: 3px solid #F44336;
        }

        .diff-modification {
            background: rgba(255, 152, 0, 0.2);
            border-left: 3px solid #FF9800;
        }

        /* Search Bar */
        .search-bar {
            padding: 10px;
            background: #252526;
            border-bottom: 1px solid var(--border-color);
            display: none;
        }

        .search-bar.active {
            display: flex;
            gap: 10px;
        }

        .search-input {
            flex: 1;
        }

        .search-results {
            color: var(--warning-color);
            font-size: 12px;
        }

        /* Status Bar */
        .status-bar {
            background: #007ACC;
            color: white;
            padding: 5px 10px;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
        }

        /* Loading Overlay */
        .loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        .spinner {
            border: 3px solid transparent;
            border-top: 3px solid var(--primary-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>🔍 Enhanced DOM Capture Viewer</h2>
        <div class="controls">
            <div class="control-group">
                <button onclick="toggleSidebar()">☰ Toggle Sidebar</button>
                <button onclick="toggleSearch()">🔍 Search</button>
            </div>
            <div class="control-group">
                <select id="viewMode" onchange="changeViewMode()">
                    <option value="preview">Preview</option>
                    <option value="source">Source</option>
                    <option value="tree">DOM Tree</option>
                    <option value="resources">Resources</option>
                    <option value="diff">Diff View</option>
                </select>
            </div>
            <div class="control-group">
                <button onclick="exportCapture()">📥 Export</button>
                <button onclick="compareCaptures()">📊 Compare</button>
                <button class="secondary" onclick="refreshView()">🔄 Refresh</button>
            </div>
        </div>
    </div>

    <div class="search-bar" id="searchBar">
        <input type="text" class="search-input" id="searchInput" placeholder="Search DOM..." onkeyup="performSearch(event)">
        <span class="search-results" id="searchResults"></span>
        <button onclick="findNext()">Next</button>
        <button onclick="findPrevious()">Previous</button>
        <button onclick="toggleSearch()">✕</button>
    </div>

    <div class="content">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-tabs">
                <button class="sidebar-tab active" onclick="switchSidebarTab('metadata')">Metadata</button>
                <button class="sidebar-tab" onclick="switchSidebarTab('outline')">Outline</button>
                <button class="sidebar-tab" onclick="switchSidebarTab('issues')">Issues</button>
            </div>
            <div class="sidebar-content" id="sidebarContent">
                <!-- Metadata content will be injected here -->
            </div>
        </div>

        <div class="main-view">
            <div class="view-tabs">
                <button class="view-tab active" onclick="switchViewTab('rendered')">Rendered</button>
                <button class="view-tab" onclick="switchViewTab('source')">Source</button>
                <button class="view-tab" onclick="switchViewTab('inspector')">Inspector</button>
            </div>
            <div class="view-content" id="viewContent">
                <!-- Main content will be injected here -->
            </div>
        </div>
    </div>

    <div class="status-bar">
        <span id="statusText">Ready</span>
        <span id="statusInfo"></span>
    </div>

    <script>
        const vscode = acquireVsCodeApi();
        let currentView = 'preview';
        let currentSidebarTab = 'metadata';
        let domContent = ${JSON.stringify(domContent)};
        let metadata = ${JSON.stringify(metadata || {})};
        let searchResults = [];
        let currentSearchIndex = 0;

        // Initialize the viewer
        window.onload = () => {
            loadMetadata();
            loadDomPreview();
            updateStatus('DOM Capture loaded successfully');
        };

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('collapsed');
        }

        function toggleSearch() {
            const searchBar = document.getElementById('searchBar');
            searchBar.classList.toggle('active');
            if (searchBar.classList.contains('active')) {
                document.getElementById('searchInput').focus();
            }
        }

        function changeViewMode() {
            const mode = document.getElementById('viewMode').value;
            currentView = mode;
            updateView();
        }

        function switchSidebarTab(tab) {
            currentSidebarTab = tab;
            document.querySelectorAll('.sidebar-tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            updateSidebarContent();
        }

        function switchViewTab(tab) {
            document.querySelectorAll('.view-tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            updateViewContent(tab);
        }

        function loadMetadata() {
            const content = document.getElementById('sidebarContent');
            let html = '<div class="metadata-panel">';
            
            if (metadata.timestamp) {
                html += createMetadataItem('Captured', new Date(metadata.timestamp).toLocaleString());
            }
            if (metadata.url) {
                html += createMetadataItem('URL', metadata.url);
            }
            if (metadata.viewport) {
                html += createMetadataItem('Viewport', \`\${metadata.viewport.width}x\${metadata.viewport.height}\`);
            }
            if (metadata.performance) {
                html += createMetadataItem('Load Time', \`\${metadata.performance.loadTime}ms\`);
            }
            if (metadata.resources) {
                html += '<div class="metadata-item">';
                html += '<div class="metadata-label">Resources</div>';
                html += '<ul class="metadata-list">';
                html += \`<li>Scripts: \${metadata.resources.scripts}</li>\`;
                html += \`<li>Stylesheets: \${metadata.resources.stylesheets}</li>\`;
                html += \`<li>Images: \${metadata.resources.images}</li>\`;
                html += '</ul></div>';
            }
            
            html += '</div>';
            content.innerHTML = html;
        }

        function createMetadataItem(label, value) {
            return \`
                <div class="metadata-item">
                    <div class="metadata-label">\${label}</div>
                    <div class="metadata-value">\${value}</div>
                </div>
            \`;
        }

        function loadDomPreview() {
            const content = document.getElementById('viewContent');
            const iframe = document.createElement('iframe');
            iframe.className = 'dom-preview';
            iframe.srcdoc = domContent;
            content.innerHTML = '';
            content.appendChild(iframe);
        }

        function updateView() {
            switch(currentView) {
                case 'preview':
                    loadDomPreview();
                    break;
                case 'source':
                    loadSourceView();
                    break;
                case 'tree':
                    loadDomTree();
                    break;
                case 'resources':
                    loadResourceList();
                    break;
                case 'diff':
                    loadDiffView();
                    break;
            }
        }

        function loadSourceView() {
            const content = document.getElementById('viewContent');
            const lines = domContent.split('\\n');
            let html = '<div class="source-view">';
            
            lines.forEach((line, index) => {
                html += \`<div><span class="line-number">\${index + 1}</span>\${escapeHtml(line)}</div>\`;
            });
            
            html += '</div>';
            content.innerHTML = html;
        }

        function loadDomTree() {
            const content = document.getElementById('viewContent');
            const parser = new DOMParser();
            const doc = parser.parseFromString(domContent, 'text/html');
            
            content.innerHTML = '<div class="dom-tree">' + buildTreeNode(doc.documentElement) + '</div>';
        }

        function buildTreeNode(element) {
            const tagName = element.tagName.toLowerCase();
            const attributes = Array.from(element.attributes)
                .map(attr => \` <span class="tree-attr">\${attr.name}</span>=<span class="tree-value">"\${attr.value}"</span>\`)
                .join('');
            
            let html = '<div class="tree-node">';
            html += '<div class="tree-node-content">';
            html += \`<span class="tree-toggle">▼</span>\`;
            html += \`<span class="tree-tag">&lt;\${tagName}\${attributes}&gt;</span>\`;
            html += '</div>';
            
            if (element.children.length > 0) {
                html += '<div class="tree-children">';
                for (const child of element.children) {
                    html += buildTreeNode(child);
                }
                html += '</div>';
            }
            
            html += '</div>';
            return html;
        }

        function performSearch(event) {
            if (event.key === 'Enter') {
                const query = document.getElementById('searchInput').value;
                if (query) {
                    searchInDom(query);
                }
            }
        }

        function searchInDom(query) {
            // Implement search logic
            updateStatus(\`Searching for: \${query}\`);
        }

        function exportCapture() {
            vscode.postMessage({
                command: 'export',
                data: domContent
            });
        }

        function compareCaptures() {
            vscode.postMessage({
                command: 'compare'
            });
        }

        function refreshView() {
            updateView();
            updateStatus('View refreshed');
        }

        function updateStatus(text, info = '') {
            document.getElementById('statusText').textContent = text;
            document.getElementById('statusInfo').textContent = info;
        }

        function updateSidebarContent() {
            // Update sidebar based on current tab
            switch(currentSidebarTab) {
                case 'metadata':
                    loadMetadata();
                    break;
                case 'outline':
                    loadOutline();
                    break;
                case 'issues':
                    loadIssues();
                    break;
            }
        }

        function loadOutline() {
            const content = document.getElementById('sidebarContent');
            content.innerHTML = '<div>Document outline will appear here</div>';
        }

        function loadIssues() {
            const content = document.getElementById('sidebarContent');
            content.innerHTML = '<div>Accessibility and performance issues will appear here</div>';
        }

        function loadResourceList() {
            const content = document.getElementById('viewContent');
            content.innerHTML = '<div class="resource-list">Resource analysis will appear here</div>';
        }

        function loadDiffView() {
            const content = document.getElementById('viewContent');
            content.innerHTML = '<div class="diff-container">Diff view will appear here when comparing captures</div>';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function updateViewContent(tab) {
            switch(tab) {
                case 'rendered':
                    loadDomPreview();
                    break;
                case 'source':
                    loadSourceView();
                    break;
                case 'inspector':
                    loadDomTree();
                    break;
            }
        }
    </script>
</body>
</html>`;
  }

  private static async handleMessage(message: any, context: vscode.ExtensionContext): Promise<void> {
    switch (message.command) {
      case 'export':
        await EnhancedDomViewer.exportCapture(message.data);
        break;
      case 'compare':
        await EnhancedDomViewer.compareCaptures();
        break;
    }
  }

  private static async exportCapture(data: string): Promise<void> {
    const uri = await vscode.window.showSaveDialog({
      defaultUri: vscode.Uri.file('dom-capture.html'),
      filters: {
        'HTML Files': ['html'],
        'All Files': ['*']
      }
    });

    if (uri) {
      await fs.writeFile(uri.fsPath, data, 'utf-8');
      vscode.window.showInformationMessage(`DOM capture exported to ${uri.fsPath}`);
    }
  }

  private static async compareCaptures(): Promise<void> {
    // Implement comparison logic
    vscode.window.showInformationMessage('Compare functionality coming soon!');
  }
}