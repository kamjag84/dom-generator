// DOM Capture Utility Functions
// These will be injected into the user's project

const domCaptureTemplate = `
import { test as base, TestInfo } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

export class DomCapture {
  private rootDir: string;

  constructor(rootDir: string = 'test-results/dom-capture') {
    this.rootDir = rootDir;
  }

  async captureFullDom(page) {
    const fullDom = await page.evaluate(() => {
      const doctype = document.doctype 
        ? \`<!DOCTYPE \${document.doctype.name}>\`
        : '';
      
      const clonedDoc = document.documentElement.cloneNode(true);
      
      const styles = Array.from(document.styleSheets).map(sheet => {
        try {
          const rules = Array.from(sheet.cssRules || []);
          return rules.map(rule => rule.cssText).join('\\n');
        } catch (e) {
          return \`/* Cross-origin stylesheet: \${sheet.href} */\`;
        }
      }).join('\\n');

      if (styles) {
        const styleElement = document.createElement('style');
        styleElement.textContent = styles;
        const head = clonedDoc.querySelector('head');
        if (head) {
          head.appendChild(styleElement);
        }
      }

      const metaElement = document.createElement('meta');
      metaElement.name = 'dom-capture-time';
      metaElement.content = new Date().toISOString();
      const head = clonedDoc.querySelector('head');
      if (head) {
        head.appendChild(metaElement);
      }

      return doctype + clonedDoc.outerHTML;
    });

    return this.formatHtml(fullDom);
  }

  private formatHtml(html: string): string {
    let formatted = html;
    let indent = 0;
    
    formatted = formatted.replace(/></g, '>\\n<');
    const lines = formatted.split('\\n');
    
    const formattedLines = lines.map(line => {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('</')) {
        indent = Math.max(0, indent - 1);
      }
      
      const indentedLine = '  '.repeat(indent) + trimmed;
      
      if (trimmed.startsWith('<') && !trimmed.startsWith('</') && 
          !trimmed.endsWith('/>') && !trimmed.includes('</')) {
        indent++;
      }
      
      return indentedLine;
    });
    
    return formattedLines.join('\\n');
  }

  generateFilePath(testName: string, className: string = 'UnknownClass', methodName: string = 'unknownMethod'): string {
    const now = new Date();
    const dateFolder = this.formatDate(now);
    const timestamp = this.formatTime(now);
    
    const sanitizedTestName = this.sanitizeFileName(testName);
    const sanitizedClassName = this.sanitizeFileName(className);
    const sanitizedMethodName = this.sanitizeFileName(methodName);
    
    const fileName = \`\${sanitizedTestName}_\${sanitizedClassName}_\${sanitizedMethodName}_dom_\${timestamp}.html\`;
    const fullPath = path.join(this.rootDir, dateFolder, fileName);
    
    return fullPath;
  }

  async saveDom(dom: string, testName: string, className: string = 'UnknownClass', methodName: string = 'unknownMethod'): Promise<string> {
    const filePath = this.generateFilePath(testName, className, methodName);
    const dir = path.dirname(filePath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    const enhancedDom = this.addMetadata(dom, testName, className, methodName);
    fs.writeFileSync(filePath, enhancedDom, 'utf-8');
    
    return filePath;
  }

  private addMetadata(dom: string, testName: string, className: string, methodName: string): string {
    const metadata = \`
<!-- 
  DOM Capture Metadata
  ====================
  Test Name: \${testName}
  Class Name: \${className}
  Method Name: \${methodName}
  Captured At: \${new Date().toISOString()}
-->
\`;
    return metadata + dom;
  }

  private formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return \`\${day}-\${month}-\${year}\`;
  }

  private formatTime(date: Date): string {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return \`\${hours}-\${minutes}-\${seconds}\`;
  }

  private sanitizeFileName(name: string): string {
    return name
      .replace(/[<>:"/\\\\|?*]/g, '_')
      .replace(/\\s+/g, '_')
      .substring(0, 100);
  }

  async captureAndSave(page, testName: string, className?: string, methodName?: string): Promise<string> {
    const dom = await this.captureFullDom(page);
    const filePath = await this.saveDom(dom, testName, className, methodName);
    return filePath;
  }
}

type DomTestFixtures = {
  domCapture: DomCapture;
  captureDom: () => Promise<string>;
};

export const test = base.extend<DomTestFixtures>({
  domCapture: async ({}, use) => {
    const capture = new DomCapture();
    await use(capture);
  },

  captureDom: async ({ page, domCapture }, use, testInfo: TestInfo) => {
    const captureFunction = async () => {
      const testName = testInfo.title;
      const fileName = testInfo.file?.split('/').pop()?.replace('.spec.ts', '') || 'UnknownFile';
      const suiteName = testInfo.project?.name || 'DefaultSuite';
      
      console.log(\`📸 Capturing DOM for: \${testName}\`);
      const filePath = await domCapture.captureAndSave(
        page,
        testName,
        fileName,
        suiteName
      );
      console.log(\`✅ DOM captured successfully: \${filePath}\`);
      
      await testInfo.attach('dom-capture', {
        path: filePath,
        contentType: 'text/html'
      });
      
      return filePath;
    };

    await use(captureFunction);
  },
});

test.afterEach(async ({ page, domCapture }, testInfo: TestInfo) => {
  if (testInfo.status === 'failed' || testInfo.status === 'timedOut') {
    try {
      console.log(\`❌ Test failed - Capturing DOM automatically\`);
      
      const testName = testInfo.title;
      const fileName = testInfo.file?.split('/').pop()?.replace('.spec.ts', '') || 'UnknownFile';
      const suiteName = testInfo.project?.name || 'DefaultSuite';
      
      const filePath = await domCapture.captureAndSave(
        page,
        \`FAILED_\${testName}\`,
        fileName,
        suiteName
      );
      
      console.log(\`📁 Failure DOM saved to: \${filePath}\`);
      
      await testInfo.attach('failed-dom-capture', {
        path: filePath,
        contentType: 'text/html'
      });
    } catch (error) {
      console.error('Failed to capture DOM on test failure:', error);
    }
  }
});

export { expect } from '@playwright/test';
`;

module.exports = { domCaptureTemplate };