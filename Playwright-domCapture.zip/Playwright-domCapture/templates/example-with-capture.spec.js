"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = require("@playwright/test");
// Import the DOM capture utility
const { captureDom } = require('./dom-capture/capture');
/**
 * Example test showing how to use DOM Capture
 * Installed by Playwright DOM Capture VS Code Extension
 */
test_1.test.describe('Example: Using DOM Capture', () => {
    (0, test_1.test)('capture at specific points', async ({ page }) => {
        // Navigate to your application
        await page.goto('https://example.com');
        // Capture initial state
        await captureDom(page, 'initial-load');
        // Perform some actions
        await page.fill('#search', 'playwright');
        // Capture after user input
        await captureDom(page, 'after-search-input');
        // Click search button
        await page.click('#search-button');
        await page.waitForLoadState('networkidle');
        // Capture search results
        await captureDom(page, 'search-results');
        // Your assertions
        await (0, test_1.expect)(page.locator('.results')).toBeVisible();
    });
    (0, test_1.test)('automatic capture on failure', async ({ page }) => {
        await page.goto('https://example.com');
        // This will fail and automatically capture DOM
        await (0, test_1.expect)(page.locator('.non-existent-element')).toBeVisible();
        // The DOM will be automatically captured before the test fails
        // Look for it in: test-results/dom-captures/DD-MM-YYYY/example_with_capture_spec_automatic_capture_on_failure/
    });
    (0, test_1.test)('capture during debugging', async ({ page }) => {
        await page.goto('https://example.com');
        // Multiple step workflow
        await page.click('.login-button');
        await captureDom(page, 'step-1-login-page');
        await page.fill('#username', 'testuser');
        await page.fill('#password', 'testpass');
        await captureDom(page, 'step-2-credentials-filled');
        await page.click('#submit');
        await page.waitForLoadState('networkidle');
        await captureDom(page, 'step-3-after-login');
        // TIP: You can also press Ctrl+Shift+C during test execution
        // to capture DOM at any point (when using VS Code extension)
    });
});
/**
 * Tips for using DOM Capture:
 *
 * 1. Import the capture function:
 *    const { captureDom } = require('./dom-capture/capture');
 *
 * 2. Call it anywhere in your test:
 *    await captureDom(page, 'descriptive-label');
 *
 * 3. Find captures in:
 *    test-results/dom-captures/DD-MM-YYYY/ClassName_MethodName/
 *
 * 4. Each capture includes:
 *    - Full HTML with inlined styles
 *    - Screenshot (optional)
 *    - Metadata JSON with test context
 *
 * 5. Use keyboard shortcut:
 *    - Ctrl+Shift+C during test execution (VS Code)
 *    - Ctrl+Alt+C for manual capture (VS Code)
 */ 
//# sourceMappingURL=example-with-capture.spec.js.map