const fs = require('fs-extra');
const path = require('path');

async function copyTemplates() {
    console.log('📁 Copying template files to output directory...');
    
    const templatesSource = path.join(__dirname, '..', 'templates');
    const templatesDestination = path.join(__dirname, '..', 'out', 'templates');
    
    try {
        // Ensure the output directory exists
        await fs.ensureDir(templatesDestination);
        
        // Copy all template files
        if (await fs.pathExists(templatesSource)) {
            await fs.copy(templatesSource, templatesDestination);
            console.log('✅ Templates copied successfully');
        } else {
            console.log('⚠️ Templates folder not found, skipping...');
        }
        
        // Also copy embedded template TypeScript files from src/templates
        const srcTemplates = path.join(__dirname, '..', 'src', 'templates');
        const outSrcTemplates = path.join(__dirname, '..', 'out', 'templates');
        
        if (await fs.pathExists(srcTemplates)) {
            // Copy the embedded .ts files as .js (they're already compiled)
            const files = await fs.readdir(srcTemplates);
            for (const file of files) {
                if (file.endsWith('.embedded.ts')) {
                    // These are already compiled to .js in out folder
                    console.log(`  - ${file} (compiled)`);
                }
            }
        }
        
    } catch (error) {
        console.error('❌ Error copying templates:', error);
        process.exit(1);
    }
}

copyTemplates();